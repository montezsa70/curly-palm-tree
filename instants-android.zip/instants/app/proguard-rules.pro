# R8 rules for the release build (minify + shrink resources).
# Libraries ship their own rules (Firebase, OkHttp, WorkManager, Compose, Play services); these cover the rest.

# Readable crash reports in Play Console: keep line numbers, and the mapping file uploaded with the bundle un-scrambles names.
-keepattributes SourceFile,LineNumberTable,Signature,*Annotation*,InnerClasses,EnclosingMethod
-renamesourcefileattribute SourceFile

# WebRTC: its native code (JNI) looks up Java classes and methods by name.
-keep class org.webrtc.** { *; }
-dontwarn org.webrtc.**

# OkHttp's optional TLS providers are not on Android.
-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
-dontwarn org.openjsse.**
