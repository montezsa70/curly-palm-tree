package app.instants.call

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.Person
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.ProcessLifecycleOwner
import app.instants.MainActivity
import app.instants.R
import app.instants.push.Push

/**
 * Keeps the process alive during a call and owns everything the system shows for it:
 * the ringtone, the incoming-call notification with its full-screen screen, and the ongoing-call notification.
 * It holds no call logic: it just mirrors [CallManager.phase] (CallManager calls [sync] whenever it changes).
 */
class CallService : Service() {
    private var ringtone: Ringtone? = null
    private var vibrator: Vibrator? = null
    private var ringing = false
    private var screenShownFor: String? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        instance = this
        when (intent?.action) {
            ACTION_DECLINE -> CallManager.decline()
            ACTION_HANGUP -> CallManager.hangUp()
            ACTION_PROJECTION -> {
                if (refresh()) CallManager.beginCapture() else CallManager.abortCapture()
                return START_NOT_STICKY
            }
        }
        refresh()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        stopRinging()
        if (instance === this) instance = null
        super.onDestroy()
    }

    /** Re-reads the call state: updates the notification, starts or stops the ringtone, or shuts the service down. */
    fun refresh(): Boolean {
        val phase = CallManager.phase
        if (phase == CallPhase.Idle) {
            // A service started with startForegroundService() must enter the foreground before it may stop.
            promote(buildNotification(CallPhase.Ended), ServiceInfo.FOREGROUND_SERVICE_TYPE_PHONE_CALL)
            stopRinging()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return false
        }
        val ok = promote(buildNotification(phase), foregroundTypes(phase))
        if (phase == CallPhase.Incoming) {
            startRinging()
            showCallScreenIfAppIsOpen()
        } else {
            stopRinging()
        }
        return ok
    }

    private fun foregroundTypes(phase: CallPhase): Int {
        var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_PHONE_CALL
        if (phase != CallPhase.Incoming && hasMicPermission(this)) type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        if (CallManager.projectionActive) type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        return type
    }

    private fun promote(notification: Notification, type: Int): Boolean {
        return try {
            ServiceCompat.startForeground(this, NOTIF_ID, notification, type)
            true
        } catch (e: Exception) {
            Log.w(TAG, "startForeground($type) failed: ${e.message}")
            if (type != ServiceInfo.FOREGROUND_SERVICE_TYPE_PHONE_CALL) {
                try {
                    ServiceCompat.startForeground(this, NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_PHONE_CALL)
                } catch (e2: Exception) {
                    Log.w(TAG, "fallback startForeground failed: ${e2.message}")
                }
            }
            false
        }
    }

    // ---- the app is open: go straight to the call screen instead of waiting for a heads-up tap ----

    private fun showCallScreenIfAppIsOpen() {
        val id = CallManager.currentCallId ?: return
        if (screenShownFor == id) return
        val visible = ProcessLifecycleOwner.get().lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)
        if (!visible) return
        screenShownFor = id
        try {
            startActivity(
                Intent(this, CallActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            )
        } catch (_: Exception) {
        }
    }

    // ---- ringtone ----------------------------------------------------------------------------

    private fun startRinging() {
        if (ringing) return
        ringing = true
        val am = getSystemService(AudioManager::class.java)
        val nm = getSystemService(NotificationManager::class.java)
        val filter = nm.currentInterruptionFilter
        val doNotDisturb = filter == NotificationManager.INTERRUPTION_FILTER_NONE ||
            filter == NotificationManager.INTERRUPTION_FILTER_ALARMS
        val mode = am.ringerMode
        try {
            if (mode == AudioManager.RINGER_MODE_NORMAL && !doNotDisturb) {
                val uri = RingtoneManager.getActualDefaultRingtoneUri(this, RingtoneManager.TYPE_RINGTONE)
                    ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
                val r = RingtoneManager.getRingtone(this, uri)
                if (r != null) {
                    r.audioAttributes = AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                    r.isLooping = true
                    r.play()
                    ringtone = r
                }
            }
            if (mode != AudioManager.RINGER_MODE_SILENT && !doNotDisturb) {
                val v = getSystemService(VibratorManager::class.java).defaultVibrator
                @Suppress("DEPRECATION")
                v.vibrate(
                    VibrationEffect.createWaveform(longArrayOf(0, 800, 800), 0),
                    AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE).build(),
                )
                vibrator = v
            }
        } catch (e: Exception) {
            Log.w(TAG, "ringing failed: ${e.message}")
        }
    }

    private fun stopRinging() {
        ringing = false
        try { ringtone?.stop() } catch (_: Exception) { }
        try { vibrator?.cancel() } catch (_: Exception) { }
        ringtone = null
        vibrator = null
    }

    // ---- notifications -----------------------------------------------------------------------

    private fun buildNotification(phase: CallPhase): Notification {
        val name = CallManager.peerName.ifBlank { "Instants" }
        val person = Person.Builder().setName(name).setImportant(true).build()
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val screen = Intent(this, CallActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        val open = PendingIntent.getActivity(this, 10, screen, flags)

        if (phase == CallPhase.Incoming) {
            val answer = PendingIntent.getActivity(
                this, 11,
                Intent(this, CallActivity::class.java).setAction(CallActivity.ACTION_ANSWER)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
                flags,
            )
            val decline = PendingIntent.getForegroundService(
                this, 12, Intent(this, CallService::class.java).setAction(ACTION_DECLINE), flags,
            )
            return NotificationCompat.Builder(this, CH_INCOMING)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentText("Incoming Instants call")
                .setStyle(NotificationCompat.CallStyle.forIncomingCall(person, decline, answer))
                .setCategory(NotificationCompat.CATEGORY_CALL)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setFullScreenIntent(open, true)
                .setContentIntent(open)
                .build()
        }

        val hangUp = PendingIntent.getForegroundService(
            this, 13, Intent(this, CallService::class.java).setAction(ACTION_HANGUP), flags,
        )
        val text = when (phase) {
            CallPhase.Outgoing -> "Calling…"
            CallPhase.Connecting -> "Connecting…"
            CallPhase.Ended -> "Call ended"
            else -> "Ongoing call"
        }
        val builder = NotificationCompat.Builder(this, CH_ONGOING)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentText(text)
            .setStyle(NotificationCompat.CallStyle.forOngoingCall(person, hangUp))
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(open)
        if (phase == CallPhase.Connected && CallManager.connectedAtMs > 0) {
            val sinceConnect = SystemClock.elapsedRealtime() - CallManager.connectedAtMs
            builder.setUsesChronometer(true).setShowWhen(true).setWhen(System.currentTimeMillis() - sinceConnect)
        }
        return builder.build()
    }

    companion object {
        private const val TAG = "CallService"
        const val ACTION_SYNC = "app.instants.call.SYNC"
        const val ACTION_DECLINE = "app.instants.call.DECLINE"
        const val ACTION_HANGUP = "app.instants.call.HANGUP"
        const val ACTION_PROJECTION = "app.instants.call.PROJECTION"

        private const val CH_INCOMING = "calls_incoming"
        private const val CH_ONGOING = "calls_ongoing"
        private const val CH_MISSED = "calls_missed"
        private const val NOTIF_ID = 4201

        @Volatile
        private var instance: CallService? = null

        fun initChannels(context: Context) {
            val nm = context.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(CH_INCOMING, "Incoming calls", NotificationManager.IMPORTANCE_HIGH).apply {
                    description = "Rings when someone calls you"
                    setSound(null, null) // the service plays the ringtone itself so it can loop and follow the ringer switch
                    enableVibration(false)
                    setShowBadge(false)
                    lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                },
            )
            nm.createNotificationChannel(
                NotificationChannel(CH_ONGOING, "Ongoing calls", NotificationManager.IMPORTANCE_LOW).apply {
                    setShowBadge(false)
                },
            )
            nm.createNotificationChannel(
                NotificationChannel(CH_MISSED, "Missed calls", NotificationManager.IMPORTANCE_DEFAULT),
            )
        }

        fun start(context: Context, action: String) {
            try {
                ContextCompat.startForegroundService(context, Intent(context, CallService::class.java).setAction(action))
            } catch (e: Exception) {
                Log.w(TAG, "could not start the call service: ${e.message}")
            }
        }

        /** Called by CallManager whenever the call state changes. */
        fun sync() {
            Handler(Looper.getMainLooper()).post { instance?.refresh() }
        }

        fun notifyMissed(context: Context, name: String, chatId: String?) {
            val nm = context.getSystemService(NotificationManager::class.java)
            if (!nm.areNotificationsEnabled()) return
            val open = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
                if (chatId != null) putExtra(Push.EXTRA_CHAT, chatId)
            }
            val pending = PendingIntent.getActivity(
                context, (chatId ?: name).hashCode(), open,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
            )
            val n = NotificationCompat.Builder(context, CH_MISSED)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle("Missed call")
                .setContentText(name)
                .setContentIntent(pending)
                .setAutoCancel(true)
                .build()
            nm.notify(("missed" + (chatId ?: name)).hashCode(), n)
        }
    }
}
