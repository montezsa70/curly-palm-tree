package app.instants.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.instants.data.StatusRepo
import app.instants.data.StatusViewer
import app.instants.data.clock
import app.instants.data.listLabel
import app.instants.ui.components.Ic
import app.instants.ui.components.LIcon
import app.instants.ui.components.ProfileAvatar
import app.instants.ui.theme.Palette
import kotlinx.coroutines.CancellationException
import java.time.Instant
import java.time.ZoneId

/** Who has viewed one of my statuses, newest first. Opens from the view count under the status. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StatusViewersSheet(statusId: String, onDismiss: () -> Unit) {
    val sheetState = rememberModalBottomSheetState()
    var viewers by remember(statusId) { mutableStateOf<List<StatusViewer>?>(null) }
    LaunchedEffect(statusId) {
        viewers = try {
            StatusRepo.loadViewers(statusId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            emptyList()
        }
    }
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = Palette.Sheet,
        contentColor = Palette.TextPrimary,
    ) {
        Column(Modifier.fillMaxWidth().navigationBarsPadding().padding(bottom = 16.dp)) {
            val list = viewers
            Row(
                Modifier.padding(horizontal = 24.dp).padding(bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                LIcon(Ic.Eye, Palette.TextSecondary, 20.dp)
                Text(
                    when (list?.size) {
                        null -> "Viewed by"
                        0 -> "Viewed by"
                        1 -> "Viewed by 1 person"
                        else -> "Viewed by ${list.size} people"
                    },
                    color = Palette.TextPrimary, fontSize = 17.sp, fontWeight = FontWeight.SemiBold,
                )
            }
            when {
                list == null -> Unit
                list.isEmpty() -> Box(Modifier.fillMaxWidth().padding(vertical = 40.dp), contentAlignment = Alignment.Center) {
                    Text("No views yet", color = Palette.TextSecondary, fontSize = 15.sp, textAlign = TextAlign.Center)
                }
                else -> LazyColumn(Modifier.heightIn(max = 440.dp)) {
                    items(list, key = { it.profile.id }) { v ->
                        Row(
                            Modifier.fillMaxWidth().heightIn(min = 60.dp).padding(horizontal = 24.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(14.dp),
                        ) {
                            ProfileAvatar(v.profile.initials, 44.dp, v.profile.avatarPath)
                            Column(Modifier.weight(1f)) {
                                Text(v.profile.name, color = Palette.TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Medium, maxLines = 1)
                                Text("@${v.profile.username}", color = Palette.TextSecondary, fontSize = 13.sp, maxLines = 1)
                            }
                            Text(viewedLabel(v.at), color = Palette.TextSecondary, fontSize = 13.sp)
                        }
                    }
                }
            }
        }
    }
}

/** "Today, 11:27" for today, otherwise the usual short date followed by the time. */
private fun viewedLabel(at: Instant): String {
    val zone = ZoneId.systemDefault()
    return if (at.atZone(zone).toLocalDate() == java.time.LocalDate.now(zone)) "Today, ${at.clock()}"
    else "${at.listLabel()}, ${at.clock()}"
}
