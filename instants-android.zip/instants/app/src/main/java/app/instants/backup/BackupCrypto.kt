package app.instants.backup

import android.content.Context
import android.content.SharedPreferences
import android.util.Base64
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import app.instants.data.DeviceCrypto
import java.io.DataOutputStream
import java.io.EOFException
import java.io.File
import java.nio.ByteBuffer
import java.security.GeneralSecurityException
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/** What the person chose in Settings > Chat backup. */
object BackupPrefs {
    private var prefs: SharedPreferences? = null

    // Backing state is private; the public read-only properties below have only getters, so they can't
    // clash on the JVM with the explicit setXxx() functions (a `private set` still generates setXxx()).
    private var frequencyState by mutableStateOf("off")
    private var includeMediaState by mutableStateOf(true)
    private var mobileDataState by mutableStateOf(false)
    private var connectedState by mutableStateOf(false)
    private var passwordSetState by mutableStateOf(false)
    private var lastAtState by mutableLongStateOf(0L)
    private var lastSizeState by mutableLongStateOf(0L)

    /** off, daily, weekly or monthly */
    val frequency: String get() = frequencyState
    val includeMedia: Boolean get() = includeMediaState
    val mobileData: Boolean get() = mobileDataState
    val connected: Boolean get() = connectedState
    val passwordSet: Boolean get() = passwordSetState
    val lastAt: Long get() = lastAtState
    val lastSize: Long get() = lastSizeState

    fun init(context: Context) {
        val p = context.getSharedPreferences("backup", Context.MODE_PRIVATE)
        prefs = p
        frequencyState = p.getString("frequency", "off") ?: "off"
        includeMediaState = p.getBoolean("include_media", true)
        mobileDataState = p.getBoolean("mobile_data", false)
        connectedState = p.getBoolean("connected", false)
        passwordSetState = p.getBoolean("password_set", false)
        lastAtState = p.getLong("last_at", 0L)
        lastSizeState = p.getLong("last_size", 0L)
    }

    fun setFrequency(v: String) { frequencyState = v; prefs?.edit()?.putString("frequency", v)?.apply() }
    fun setIncludeMedia(v: Boolean) { includeMediaState = v; prefs?.edit()?.putBoolean("include_media", v)?.apply() }
    fun setMobileData(v: Boolean) { mobileDataState = v; prefs?.edit()?.putBoolean("mobile_data", v)?.apply() }
    fun setConnected(v: Boolean) { connectedState = v; prefs?.edit()?.putBoolean("connected", v)?.apply() }
    fun setPasswordSet(v: Boolean) { passwordSetState = v; prefs?.edit()?.putBoolean("password_set", v)?.apply() }

    fun recordBackup(at: Long, size: Long) {
        lastAtState = at
        lastSizeState = size
        prefs?.edit()?.putLong("last_at", at)?.putLong("last_size", size)?.apply()
    }

    fun reset() {
        frequencyState = "off"; includeMediaState = true; mobileDataState = false; connectedState = false
        passwordSetState = false; lastAtState = 0L; lastSizeState = 0L
        prefs?.edit()?.clear()?.apply()
    }
}

class WrongPasswordException : Exception("Wrong password")
class BadBackupException(message: String) : Exception(message)

/**
 * Backups are encrypted on the phone before they leave it, with a key made from the person's own backup
 * password (PBKDF2-HMAC-SHA256, 210,000 rounds). Google, Instants and Supabase never see the password or
 * the key, so nobody but the owner can read a backup.
 *
 * To let scheduled backups run without asking for the password each time, the derived key (not the
 * password) is also kept on the phone, wrapped by the Android Keystore.
 *
 * File layout: "INSBK1\\n", 16 byte salt, int rounds, then 1 MiB chunks. Each chunk is
 * [int length][12 byte IV][AES-256-GCM ciphertext+tag]. The chunk number and a "last chunk" flag are
 * authenticated, so chunks can't be reordered and a truncated file is detected.
 */
object BackupCrypto {
    private const val MAGIC = "INSBK1\n"
    private const val CHUNK = 1 shl 20
    private const val ROUNDS = 210_000
    private const val WRAP_ALIAS = "instants_backup_key_wrap"
    private val random = SecureRandom()
    private var prefs: SharedPreferences? = null

    fun init(context: Context) {
        prefs = context.getSharedPreferences("backup_keys", Context.MODE_PRIVATE)
    }

    private fun deriveKey(password: CharArray, salt: ByteArray, rounds: Int): ByteArray {
        val spec = PBEKeySpec(password, salt, rounds, 256)
        try {
            return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        } finally {
            spec.clearPassword()
        }
    }

    // ---- the key kept on this phone for scheduled backups ----

    fun setPassword(password: CharArray) {
        val salt = ByteArray(16).also { random.nextBytes(it) }
        val key = deriveKey(password, salt, ROUNDS)
        prefs?.edit()
            ?.putString("salt", Base64.encodeToString(salt, Base64.NO_WRAP))
            ?.putString("key", Base64.encodeToString(DeviceCrypto.encrypt(WRAP_ALIAS, key), Base64.NO_WRAP))
            ?.apply()
        BackupPrefs.setPasswordSet(true)
    }

    /** The salt and key, or null if no password has been set (or the Keystore key is gone). */
    fun storedKey(): Pair<ByteArray, ByteArray>? = try {
        val p = prefs
        val salt = p?.getString("salt", null)?.let { Base64.decode(it, Base64.NO_WRAP) }
        val wrapped = p?.getString("key", null)?.let { Base64.decode(it, Base64.NO_WRAP) }
        if (salt != null && wrapped != null) salt to DeviceCrypto.decrypt(WRAP_ALIAS, wrapped) else null
    } catch (e: Exception) {
        null
    }

    fun clearKey() {
        prefs?.edit()?.clear()?.apply()
        BackupPrefs.setPasswordSet(false)
    }

    // ---- encrypting a file ----

    fun encryptFile(src: File, dest: File, key: ByteArray, salt: ByteArray) {
        dest.outputStream().buffered().use { raw ->
            val out = DataOutputStream(raw)
            out.write(MAGIC.toByteArray())
            out.write(salt)
            out.writeInt(ROUNDS)
            src.inputStream().buffered().use { input ->
                var current = input.readNBytes(CHUNK)
                var index = 0L
                while (true) {
                    val next = if (current.size == CHUNK) input.readNBytes(CHUNK) else ByteArray(0)
                    val last = next.isEmpty()
                    val iv = ByteArray(12).also { random.nextBytes(it) }
                    val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                    cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, iv))
                    cipher.updateAAD(aad(index, last))
                    val sealed = cipher.doFinal(current)
                    out.writeInt(sealed.size)
                    out.write(iv)
                    out.write(sealed)
                    if (last) break
                    current = next
                    index++
                }
            }
            out.flush()
        }
    }

    /** Throws [WrongPasswordException] if the password doesn't open it, [BadBackupException] if the file is damaged. */
    fun decryptFile(src: File, dest: File, password: CharArray) {
        src.inputStream().buffered().use { input ->
            val magic = input.readNBytes(MAGIC.length)
            if (String(magic) != MAGIC) throw BadBackupException("This isn't an Instants backup")
            val salt = input.readNBytes(16)
            val rounds = ByteBuffer.wrap(input.readNBytes(4)).int
            if (salt.size != 16 || rounds < 10_000 || rounds > 5_000_000) throw BadBackupException("This backup is damaged")
            val key = deriveKey(password, salt, rounds)

            dest.outputStream().buffered().use { out ->
                var length = readLength(input)
                if (length < 0) throw BadBackupException("This backup is damaged")
                var index = 0L
                while (true) {
                    if (length < 16 || length > CHUNK + 16) throw BadBackupException("This backup is damaged")
                    val iv = input.readNBytes(12)
                    val sealed = input.readNBytes(length)
                    if (iv.size != 12 || sealed.size != length) throw BadBackupException("This backup is incomplete")
                    val nextLength = readLength(input)
                    val last = nextLength < 0
                    val plain = try {
                        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                        cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, iv))
                        cipher.updateAAD(aad(index, last))
                        cipher.doFinal(sealed)
                    } catch (e: GeneralSecurityException) {
                        // the very first chunk failing almost always means a wrong password
                        if (index == 0L) throw WrongPasswordException() else throw BadBackupException("This backup is damaged or incomplete")
                    }
                    out.write(plain)
                    if (last) break
                    length = nextLength
                    index++
                }
            }
        }
    }

    private fun aad(index: Long, last: Boolean): ByteArray =
        ByteBuffer.allocate(9).putLong(index).put(if (last) 1 else 0).array()

    /** -1 at the end of the file. */
    private fun readLength(input: java.io.InputStream): Int {
        val b = input.readNBytes(4)
        if (b.isEmpty()) return -1
        if (b.size < 4) throw EOFException()
        return ByteBuffer.wrap(b).int
    }
}
