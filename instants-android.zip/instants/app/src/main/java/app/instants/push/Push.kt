package app.instants.push

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.app.NotificationCompat
import app.instants.MainActivity
import app.instants.R
import app.instants.data.Api
import app.instants.data.Session
import com.google.firebase.messaging.FirebaseMessaging
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

/**
 * Push notifications. Firebase only delivers the "new message" signal to the phone;
 * accounts, chats and files all stay on Supabase.
 */
object Push {
    const val CHANNEL = "messages"
    const val EXTRA_CHAT = "chat_id"

    /** The chat that is open on screen right now. Its notifications are skipped. */
    @Volatile
    var activeChatId: String? = null

    /** A chat to open because the user tapped a notification. AppNav consumes it. */
    var pendingChat by mutableStateOf<String?>(null)

    private var prefs: SharedPreferences? = null

    fun init(context: Context) {
        prefs = context.getSharedPreferences("push", Context.MODE_PRIVATE)
        val channel = NotificationChannel(CHANNEL, "Messages", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "New messages, photos and documents"
        }
        context.getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun register(token: String) {
        prefs?.edit()?.putString("token", token)?.apply()
        if (Session.userId == null) return
        // Fire and forget: it is retried every time the app opens.
        Thread {
            try {
                Api.rpc("register_device_token", JSONObject().put("_token", token))
            } catch (_: Exception) {
            }
        }.start()
    }

    fun onNewToken(token: String) = register(token)

    /** Links this phone to the signed-in account. Safe to call as often as you like. */
    fun sync() {
        if (Session.userId == null) return
        try {
            FirebaseMessaging.getInstance().token.addOnSuccessListener { register(it) }
        } catch (_: Exception) {
        }
    }

    /** Call while still signed in, just before signing out, so the next person on this phone gets no one else's alerts. */
    suspend fun unregister() = withContext(Dispatchers.IO) {
        try {
            prefs?.getString("token", null)?.let {
                Api.rpc("unregister_device_token", JSONObject().put("_token", it))
            }
        } catch (_: Exception) {
        }
        try {
            FirebaseMessaging.getInstance().deleteToken()
        } catch (_: Exception) {
        }
        prefs?.edit()?.remove("token")?.apply()
    }

    fun show(context: Context, chatId: String, title: String, body: String) {
        val nm = context.getSystemService(NotificationManager::class.java)
        if (!nm.areNotificationsEnabled()) return
        val open = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(EXTRA_CHAT, chatId)
        }
        val pending = PendingIntent.getActivity(
            context, chatId.hashCode(), open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val n = NotificationCompat.Builder(context, CHANNEL)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(body)
            .setContentIntent(pending)
            .setAutoCancel(true)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
        nm.notify(chatId.hashCode(), n)
    }

    fun cancel(context: Context, chatId: String) {
        context.getSystemService(NotificationManager::class.java).cancel(chatId.hashCode())
    }
}
