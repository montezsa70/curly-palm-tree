package app.instants.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.instants.data.ApiException
import app.instants.data.Profile
import app.instants.data.Repo
import app.instants.data.Session
import app.instants.data.Store
import app.instants.ui.components.AboutPicker
import app.instants.ui.components.EditableAvatar
import app.instants.ui.components.GlassField
import app.instants.ui.components.PrimaryButton
import app.instants.ui.components.ScreenHeader
import app.instants.ui.components.pressable
import app.instants.ui.components.rememberPhotoPicker
import app.instants.ui.theme.Palette
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val USERNAME = Regex("^[a-z0-9_]{3,20}$")

@Composable
fun EditProfileScreen(onBack: () -> Unit) {
    val original = remember { Store.me?.profile }
    var name by remember { mutableStateOf(original?.displayName ?: "") }
    var username by remember { mutableStateOf(original?.username ?: "") }
    var about by remember { mutableStateOf(original?.about?.ifBlank { "Available" } ?: "Available") }
    var newPhoto by remember { mutableStateOf<ByteArray?>(null) }
    var removePhoto by remember { mutableStateOf(false) }
    var avail by remember { mutableStateOf<Boolean?>(true) }
    var saving by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val pickPhoto = rememberPhotoPicker { newPhoto = it; removePhoto = false }

    val u = username.trim().lowercase()
    val usernameOk = USERNAME.matches(u)
    val changed = original != null && u != original.username

    LaunchedEffect(u) {
        if (changed && usernameOk) {
            avail = null
            delay(450)
            avail = try {
                Repo.usernameAvailable(u)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                true
            }
        } else {
            avail = true
        }
    }

    fun save() {
        val base = original ?: return
        error = null
        if (name.isBlank()) { error = "Your name can’t be empty."; return }
        if (!usernameOk) { error = "Username: 3–20 letters, numbers or underscores."; return }
        scope.launch {
            saving = true
            try {
                val aboutText = about.trim().ifBlank { "Available" }
                var path: String? = if (removePhoto) null else base.avatarPath
                val photo = newPhoto
                if (photo != null) path = Repo.uploadAvatar(photo)
                Repo.updateProfile(name.trim(), u, aboutText, path, keepAvatar = false)
                val me = Store.me
                if (me != null) {
                    Store.setMe(me.copy(profile = Profile(base.id, u, name.trim(), aboutText, path)))
                }
                onBack()
            } catch (e: CancellationException) {
                throw e
            } catch (e: ApiException) {
                error = if (e.message?.contains("duplicate", true) == true) "That username is taken." else e.message
            } catch (e: Exception) {
                error = "Couldn’t save. Check your internet and try again."
            }
            saving = false
        }
    }

    Column(Modifier.fillMaxSize().background(Palette.Charcoal)) {
        ScreenHeader("Edit profile", onBack)
        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .navigationBarsPadding()
                .imePadding()
                .padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Spacer(Modifier.height(12.dp))
            EditableAvatar(
                initials = Store.me?.profile?.initials ?: "?",
                avatarPath = if (removePhoto) null else original?.avatarPath,
                localBytes = newPhoto,
                onClick = pickPhoto,
                size = 112.dp,
            )
            if (newPhoto != null || (original?.avatarPath != null && !removePhoto)) {
                Text(
                    "Remove photo",
                    color = Palette.AccentSoft,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.pressable(0.96f) { newPhoto = null; removePhoto = true }.padding(12.dp),
                )
            } else {
                Spacer(Modifier.height(16.dp))
            }

            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Label("Name")
                Field(name, { name = it }, "Your name")
                Label("Username")
                Field(username, { username = it.lowercase() }, "Username")
                val hint: Pair<String, Color>? = when {
                    !changed -> null
                    !usernameOk -> "3–20 letters, numbers or underscores" to Palette.TextSecondary
                    avail == null -> "Checking…" to Palette.TextSecondary
                    avail == true -> "@$u is available" to Palette.AccentSoft
                    else -> "@$u is taken" to Color(0xFFE29A9A)
                }
                if (hint != null) Text(hint.first, color = hint.second, fontSize = 13.sp, modifier = Modifier.padding(start = 8.dp))
                Label("About")
                AboutPicker(about) { about = it }
                Label("Email")
                Box(
                    Modifier.fillMaxWidth().height(54.dp).clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.04f))
                        .padding(horizontal = 20.dp),
                    contentAlignment = Alignment.CenterStart,
                ) {
                    Text(Session.email ?: "", color = Palette.TextSecondary, fontSize = 16.sp)
                }
            }

            error?.let {
                Spacer(Modifier.height(12.dp))
                Text(it, color = Color(0xFFE29A9A), fontSize = 13.sp)
            }
            Spacer(Modifier.height(20.dp))
            PrimaryButton(
                if (saving) "Saving…" else "Save",
                enabled = !saving && usernameOk && name.isNotBlank() && (!changed || avail == true),
            ) { save() }
            Spacer(Modifier.height(28.dp))
        }
    }
}

@Composable
private fun Label(text: String) {
    Text(
        text,
        color = Palette.TextSecondary,
        fontSize = 13.sp,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(start = 8.dp, top = 6.dp),
    )
}

@Composable
private fun Field(value: String, onChange: (String) -> Unit, placeholder: String) {
    Box(
        Modifier
            .fillMaxWidth()
            .height(54.dp)
            .clip(CircleShape)
            .background(Color.White.copy(alpha = 0.07f))
            .border(1.dp, Palette.Hairline, CircleShape)
            .padding(horizontal = 20.dp),
        contentAlignment = Alignment.CenterStart,
    ) {
        GlassField(value, onChange, placeholder, Modifier.fillMaxWidth())
    }
}
