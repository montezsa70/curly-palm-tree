package app.instants.ui.components

import android.graphics.Bitmap
import androidx.compose.foundation.layout.Box
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageShader
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.asImageBitmap
import app.instants.ui.theme.Palette
import kotlin.random.Random

/** One soft colour cloud of the wallpaper. x / y / r are fractions of the screen. */
private class Blob(val color: Long, val x: Float, val y: Float, val r: Float)

private val lightBase = Color(0xFFC6D6E6)
private val lightBlobs = listOf(
    Blob(0xFF8DAFD0, 0.08f, 0.12f, 0.80f),
    Blob(0xFFEAF2F9, 0.88f, 0.46f, 0.75f),
    Blob(0xFFA9C4DC, 0.22f, 0.84f, 0.80f),
    Blob(0xFFD6E6F2, 0.95f, 0.05f, 0.55f),
)

private val darkBase = Color(0xFF000000)
private val darkBlobs = listOf(
    Blob(0xFF222224, 0.10f, 0.14f, 0.85f),
    Blob(0xFF2A2A2D, 0.90f, 0.50f, 0.75f),
    Blob(0xFF1C1C1F, 0.25f, 0.88f, 0.80f),
    Blob(0xFF0A0A0B, 0.95f, 0.05f, 0.60f),
)

/** A small tile of random light / dark specks, repeated over the screen as film grain. */
private val grainTile: Bitmap by lazy {
    val size = 192
    val rnd = Random(7)
    val px = IntArray(size * size) {
        val a = rnd.nextInt(0, 255)
        if (rnd.nextBoolean()) (a shl 24) or 0xFFFFFF else (a shl 24)
    }
    Bitmap.createBitmap(px, size, size, Bitmap.Config.ARGB_8888)
}

/** Default chat wallpaper: soft, grainy gradient clouds. Separate looks for light and dark theme. */
@Composable
fun ChatWallpaper(modifier: Modifier = Modifier) {
    val dark = Palette.dark
    val base = if (dark) darkBase else lightBase
    val blobs = if (dark) darkBlobs else lightBlobs
    val grain = ShaderBrush(ImageShader(grainTile.asImageBitmap(), TileMode.Repeated, TileMode.Repeated))
    Box(
        modifier.drawBehind {
            drawRect(base)
            val big = maxOf(size.width, size.height)
            for (b in blobs) {
                drawRect(
                    Brush.radialGradient(
                        colors = listOf(Color(b.color), Color(b.color).copy(alpha = 0f)),
                        center = Offset(size.width * b.x, size.height * b.y),
                        radius = big * b.r,
                    ),
                )
            }
            drawRect(grain, alpha = if (dark) 0.07f else 0.09f)
        },
    )
}

/** Fine film grain drawn over a surface, the texture that makes frosted glass look frosted. */
fun Modifier.frostGrain(alpha: Float): Modifier = this.drawWithCache {
    val brush = ShaderBrush(ImageShader(grainTile.asImageBitmap(), TileMode.Repeated, TileMode.Repeated))
    onDrawWithContent {
        drawContent()
        drawRect(brush, alpha = alpha)
    }
}

/** Colour behind the glass blur so it matches the wallpaper. */
val wallpaperBase: Color get() = if (Palette.dark) darkBase else lightBase
