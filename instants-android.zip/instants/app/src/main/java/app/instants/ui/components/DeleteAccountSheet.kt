package app.instants.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.instants.data.Api
import app.instants.ui.theme.Palette
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

/** Deleting an account: says plainly what goes, asks for the password again, then deletes. [onDeleted] signs this phone out. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DeleteAccountSheet(onDeleted: () -> Unit, onDismiss: () -> Unit) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val scope = rememberCoroutineScope()
    var password by remember { mutableStateOf("") }
    var working by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    ModalBottomSheet(
        onDismissRequest = { if (!working) onDismiss() },
        sheetState = sheetState,
        containerColor = Palette.Sheet,
        contentColor = Palette.TextPrimary,
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp)
                .padding(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text("Delete your account?", color = Palette.TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            Text(
                "This permanently deletes your profile, the messages you sent, your statuses, your contacts and your call " +
                    "history from our servers. It can't be undone.",
                color = Palette.TextPrimary, fontSize = 14.sp, lineHeight = 20.sp,
            )
            Text(
                "Copies that other people already have on their phones are not deleted. A chat backup in your own Google Drive " +
                    "is not deleted either: remove it from Chat backup first if you want it gone.",
                color = Palette.TextSecondary, fontSize = 13.sp, lineHeight = 18.sp,
            )
            OutlinedTextField(
                value = password,
                onValueChange = {
                    password = it
                    error = null
                },
                label = { Text("Enter your password to confirm", color = Palette.TextSecondary) },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                enabled = !working,
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Palette.TextPrimary,
                    unfocusedTextColor = Palette.TextPrimary,
                    cursorColor = Palette.AccentSoft,
                    focusedBorderColor = Palette.AccentSoft,
                    unfocusedBorderColor = Palette.GlassBorder,
                ),
            )
            error?.let { Text(it, color = Palette.EndCall, fontSize = 13.sp) }
            SheetAction(
                when {
                    working -> "Deleting…"
                    password.isEmpty() -> "Enter your password"
                    else -> "Delete my account"
                },
                destructive = true,
            ) {
                if (!working && password.isNotEmpty()) {
                    working = true
                    error = null
                    scope.launch {
                        try {
                            Api.deleteAccount(password)
                            onDeleted()
                        } catch (e: CancellationException) {
                            throw e
                        } catch (e: Exception) {
                            error = e.message?.takeIf { it.isNotBlank() } ?: "We couldn't delete your account. Try again."
                            working = false
                        }
                    }
                }
            }
            SheetAction("Cancel", destructive = false) {
                if (!working) scope.launch { sheetState.hide() }.invokeOnCompletion { onDismiss() }
            }
        }
    }
}
