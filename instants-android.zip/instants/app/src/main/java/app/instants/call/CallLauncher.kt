package app.instants.call

import android.Manifest
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import app.instants.data.Store

private fun openCallScreen(context: Context) {
    context.startActivity(Intent(context, CallActivity::class.java))
}

private fun launchOutgoing(context: Context, chatId: String, name: String) {
    if (CallManager.phase != CallPhase.Idle) {
        openCallScreen(context) // already on a call: go back to it
        return
    }
    val avatar = Store.chats.firstOrNull { it.chatId == chatId }?.peer?.avatarPath
    if (CallManager.startOutgoing(chatId, name, avatar)) {
        openCallScreen(context)
    } else {
        Toast.makeText(context, "Can't start a call right now", Toast.LENGTH_SHORT).show()
    }
}

/** Returns a function that starts a call (chatId, name, initials), asking for the microphone first if needed. */
@Composable
fun rememberCallStarter(): (String, String, String) -> Unit {
    val context = LocalContext.current
    var pending by remember { mutableStateOf<Pair<String, String>?>(null) }
    val ask = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        val p = pending
        pending = null
        if (p != null) {
            if (result[Manifest.permission.RECORD_AUDIO] == true) {
                launchOutgoing(context, p.first, p.second)
            } else {
                Toast.makeText(context, "Allow the microphone to make calls", Toast.LENGTH_SHORT).show()
            }
        }
    }
    return remember(context) {
        { chatId: String, name: String, _: String ->
            if (hasMicPermission(context)) {
                launchOutgoing(context, chatId, name)
            } else {
                pending = chatId to name
                ask.launch(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.BLUETOOTH_CONNECT))
            }
        }
    }
}
