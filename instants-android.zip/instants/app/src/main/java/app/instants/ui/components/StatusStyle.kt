package app.instants.ui.components

import android.graphics.Typeface
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.sp

/**
 * Backgrounds for text statuses. Each one is saved on the status as "#RRGGBB,#RRGGBB" (two or three colours = a
 * gradient). Older statuses saved a single colour, which still shows as a flat background.
 */
val StatusBackgrounds = listOf(
    "#4A72B8,#8FB3F0", // sky (the app's blue)
    "#4A72B8,#7B5EA7", // dusk
    "#1F2A44,#4A72B8", // midnight
    "#2E8B7A,#4A72B8", // lagoon
    "#7B5EA7,#C95B5B", // berry
    "#D08A2E,#C95B5B", // sunset
    "#2E8B7A,#8FB3F0", // mist
    "#2A2A2D,#4A4A55", // graphite
)

private val fallbackColors = listOf(Color(0xFF4A72B8), Color(0xFF8FB3F0))

private fun statusColors(bg: String?): List<Color> {
    val parsed = bg?.split(',')?.mapNotNull {
        try { Color(android.graphics.Color.parseColor(it.trim())) } catch (e: Exception) { null }
    }.orEmpty()
    return parsed.ifEmpty { fallbackColors }
}

/** The look of a text status background: a diagonal gradient, or a flat colour for older statuses. */
fun statusBrush(bg: String?): Brush {
    val colors = statusColors(bg)
    return if (colors.size == 1) SolidColor(colors[0]) else Brush.linearGradient(colors)
}

/** A text status typeface. Only fonts that ship with Android, so nothing has to be downloaded. */
class StatusFont(
    val key: String,
    val label: String,
    val family: FontFamily,
    val weight: FontWeight,
    val scale: Float = 1f,
)

val StatusFonts = listOf(
    StatusFont("classic", "Classic", FontFamily.Default, FontWeight.SemiBold),
    StatusFont("serif", "Serif", FontFamily.Serif, FontWeight.Bold),
    StatusFont("mono", "Mono", FontFamily.Monospace, FontWeight.Medium, 0.88f),
    StatusFont("script", "Script", FontFamily.Cursive, FontWeight.Normal, 1.15f),
    StatusFont("condensed", "Condensed", FontFamily(Typeface.create("sans-serif-condensed", Typeface.BOLD)), FontWeight.Normal, 1.1f),
)

fun statusFont(key: String?): StatusFont = StatusFonts.firstOrNull { it.key == key } ?: StatusFonts[0]

/** Centered text in this font. sizeSp is the size before the font's own scale is applied. */
fun StatusFont.style(sizeSp: Float, color: Color = Color.White): TextStyle {
    val size = sizeSp * scale
    return TextStyle(
        color = color,
        fontSize = size.sp,
        fontFamily = family,
        fontWeight = weight,
        lineHeight = (size * 1.28f).sp,
        textAlign = TextAlign.Center,
    )
}
