package app.instants.data

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Presentation
import androidx.media3.transformer.AudioEncoderSettings
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.roundToInt

/**
 * Shrinks a video on the phone before it is uploaded: H.264 at up to 720p (short side) and about 1.8 Mbps, with AAC audio.
 * A 30-second clip drops from tens of megabytes to roughly 7 MB, so it uploads quickly and costs little to store and send.
 * Nothing is sent to a server for this, so the video never leaves the phone until it is already small.
 */
@androidx.annotation.OptIn(UnstableApi::class)
object VideoCompressor {
    private const val SHORT_SIDE = 720
    private const val VIDEO_BITRATE = 1_800_000
    private const val AUDIO_BITRATE = 64_000
    private const val ALREADY_SMALL_BITRATE = 2_500_000L

    /**
     * Writes a compressed copy of [source] to [dest]. A video that is already small enough is copied as it is.
     * If compressing fails and the original is within [maxBytes], the original is used instead. [onProgress] gets 0..100.
     */
    suspend fun compress(context: Context, source: Uri, dest: File, maxBytes: Long, onProgress: (Int) -> Unit) {
        val info = withContext(Dispatchers.IO) { probe(context, source) }
        if (info != null && info.shortSide <= SHORT_SIDE && info.bitrate in 1..ALREADY_SMALL_BITRATE) {
            withContext(Dispatchers.IO) { copy(context, source, dest) }
            onProgress(100)
            return
        }
        try {
            transcode(context, source, dest, info, onProgress)
            if (dest.length() <= 0L) throw IllegalStateException("empty output")
        } catch (e: CancellationException) {
            dest.delete()
            throw e
        } catch (e: Exception) {
            dest.delete()
            // Some videos (unusual formats, HDR) cannot be re-encoded here: send the original if it is small enough.
            withContext(Dispatchers.IO) { copy(context, source, dest) }
            if (dest.length() > maxBytes) {
                dest.delete()
                throw e
            }
        }
        onProgress(100)
    }

    private class Info(val width: Int, val height: Int, val rotation: Int, val bitrate: Long) {
        val displayWidth: Int get() = if (rotation % 180 == 0) width else height
        val displayHeight: Int get() = if (rotation % 180 == 0) height else width
        val shortSide: Int get() = minOf(width, height)
    }

    private fun probe(context: Context, uri: Uri): Info? {
        val mmr = MediaMetadataRetriever()
        return try {
            mmr.setDataSource(context, uri)
            fun num(key: Int) = mmr.extractMetadata(key)?.toLongOrNull()
            val w = num(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toInt() ?: return null
            val h = num(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toInt() ?: return null
            Info(w, h, (num(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION) ?: 0L).toInt(), num(MediaMetadataRetriever.METADATA_KEY_BITRATE) ?: 0L)
        } catch (e: Exception) {
            null
        } finally {
            mmr.release()
        }
    }

    private fun copy(context: Context, uri: Uri, dest: File) {
        val input = context.contentResolver.openInputStream(uri) ?: throw IllegalStateException("cannot read video")
        input.use { src -> dest.outputStream().use { src.copyTo(it) } }
    }

    private suspend fun transcode(context: Context, source: Uri, dest: File, info: Info?, onProgress: (Int) -> Unit) {
        // Transformer must be created and used on one thread that has a Looper: the main thread.
        withContext(Dispatchers.Main) {
            val videoEffects = ArrayList<Effect>()
            if (info != null && info.shortSide > SHORT_SIDE) {
                // Scale so the short side becomes 720 px; the long side follows, kept even.
                val scale = SHORT_SIDE.toFloat() / info.shortSide
                val targetHeight = ((info.displayHeight * scale).roundToInt() / 2) * 2
                videoEffects.add(Presentation.createForHeight(targetHeight))
            }
            val edited = EditedMediaItem.Builder(MediaItem.fromUri(source))
                .setEffects(Effects(emptyList<AudioProcessor>(), videoEffects))
                .build()
            val encoders = DefaultEncoderFactory.Builder(context)
                .setRequestedVideoEncoderSettings(VideoEncoderSettings.Builder().setBitrate(VIDEO_BITRATE).build())
                .setRequestedAudioEncoderSettings(AudioEncoderSettings.Builder().setBitrate(AUDIO_BITRATE).build())
                .build()

            coroutineScope {
                suspendCancellableCoroutine<Unit> { cont ->
                    val transformer = Transformer.Builder(context)
                        .setVideoMimeType(MimeTypes.VIDEO_H264)
                        .setAudioMimeType(MimeTypes.AUDIO_AAC)
                        .setEncoderFactory(encoders)
                        .addListener(object : Transformer.Listener {
                            override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                                cont.resume(Unit)
                            }

                            override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                                cont.resumeWithException(exportException)
                            }
                        })
                        .build()
                    cont.invokeOnCancellation { Handler(Looper.getMainLooper()).post { transformer.cancel() } }
                    transformer.start(edited, dest.absolutePath)

                    // Report progress while it runs
                    launch {
                        val holder = ProgressHolder()
                        while (isActive && cont.isActive) {
                            if (transformer.getProgress(holder) == Transformer.PROGRESS_STATE_AVAILABLE) onProgress(holder.progress)
                            delay(250)
                        }
                    }
                }
            }
        }
    }
}
