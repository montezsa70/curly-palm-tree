package app.instants.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.instants.ui.theme.Palette
import dev.chrisbanes.haze.HazeState
import dev.chrisbanes.haze.hazeChild
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Frosted glass: real backdrop blur (Haze) + translucent fill + hairline border. */
fun Modifier.glass(haze: HazeState, shape: Shape = RoundedCornerShape(28.dp), liquid: Boolean = false): Modifier =
    if (liquid) liquidGlass(haze, shape) else this
        .then(
            if (Palette.dark) Modifier else Modifier.shadow(
                8.dp, shape, clip = false,
                ambientColor = Color(0x14000000), spotColor = Color(0x1F000000),
            ),
        )
        .clip(shape)
        .hazeChild(state = haze) {
            // Haze 1.0.x crashes if these are left unspecified
            backgroundColor = Palette.Background
            blurRadius = 24.dp
        }
        .background(Palette.Glass)
        .border(1.dp, Palette.GlassBorder, shape)

/**
 * Liquid glass: light blur and a very clear fill so the wallpaper underneath shows through,
 * plus a bright rim that fades around the edge like light catching curved glass.
 */
fun Modifier.liquidGlass(haze: HazeState, shape: Shape): Modifier {
    val dark = Palette.dark
    val fill = Brush.verticalGradient(
        listOf(Color.White.copy(alpha = if (dark) 0.16f else 0.34f), Color.White.copy(alpha = if (dark) 0.05f else 0.10f)),
    )
    val rim = Brush.linearGradient(
        listOf(
            Color.White.copy(alpha = if (dark) 0.42f else 0.85f),
            Color.White.copy(alpha = 0.06f),
            Color.White.copy(alpha = if (dark) 0.22f else 0.50f),
        ),
    )
    return this
        .then(
            if (dark) Modifier else Modifier.shadow(
                10.dp, shape, clip = false,
                ambientColor = Color(0x10000000), spotColor = Color(0x1A1F3A5F),
            ),
        )
        .clip(shape)
        .hazeChild(state = haze) {
            backgroundColor = wallpaperBase
            blurRadius = 14.dp
        }
        .background(fill)
        .border(1.2.dp, rim, shape)
}

/**
 * Frosted glass: the content behind is blurred and softened, with only a faint neutral veil, a fine grain
 * and a thin edge. No colour cast (no blue wash) and no heavy rim, so it reads as subtle, not as a slab.
 * It follows whatever is behind it, because the blur is of the live content.
 */
fun Modifier.frostedGlass(haze: HazeState, shape: Shape): Modifier {
    val dark = Palette.dark
    val veil = if (dark) Color.White.copy(alpha = 0.07f) else Color.White.copy(alpha = 0.34f)
    val edge = Brush.linearGradient(
        if (dark) listOf(Color.White.copy(alpha = 0.20f), Color.White.copy(alpha = 0.07f), Color.White.copy(alpha = 0.14f))
        else listOf(Color.Black.copy(alpha = 0.10f), Color.Black.copy(alpha = 0.04f), Color.Black.copy(alpha = 0.08f)),
    )
    return this
        .then(
            if (dark) Modifier else Modifier.shadow(
                6.dp, shape, clip = false,
                ambientColor = Color(0x0D000000), spotColor = Color(0x14000000),
            ),
        )
        .clip(shape)
        .hazeChild(state = haze) {
            backgroundColor = Palette.Background
            blurRadius = 22.dp
        }
        .background(veil)
        .frostGrain(if (dark) 0.05f else 0.035f)
        .border(1.dp, edge, shape)
}

/** Springy press feedback (scale) + optional haptic tick. */
fun Modifier.pressable(
    scaleDown: Float = 0.96f,
    haptic: Boolean = false,
    onClick: () -> Unit,
): Modifier = composed {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) scaleDown else 1f,
        animationSpec = spring(dampingRatio = 0.55f, stiffness = 500f),
        label = "press",
    )
    val feedback = LocalHapticFeedback.current
    this
        .graphicsLayer { scaleX = scale; scaleY = scale }
        .clickable(interactionSource = source, indication = null) {
            if (haptic) feedback.performHapticFeedback(HapticFeedbackType.TextHandleMove)
            onClick()
        }
}

/** Fade + rise entrance, delayed by list position. */
fun Modifier.staggerIn(index: Int, stepMs: Int = 45, maxDelayMs: Int = 420): Modifier = composed {
    val a = remember { Animatable(0f) }
    val ty = remember { Animatable(24f) }
    LaunchedEffect(Unit) {
        delay(minOf(index * stepMs, maxDelayMs).toLong())
        launch { a.animateTo(1f, tween(380)) }
        ty.animateTo(0f, tween(420, easing = FastOutSlowInEasing))
    }
    this.graphicsLayer {
        this.alpha = a.value
        translationY = ty.value
    }
}

@Composable
fun Avatar(
    initials: String,
    size: Dp,
    modifier: Modifier = Modifier,
    ring: Boolean = false,
    fontSize: TextUnit = (size.value * 0.3f).sp,
) {
    Box(
        modifier
            .size(size)
            .clip(CircleShape)
            .background(Palette.AvatarBg)
            .border(
                width = if (ring) 2.dp else 1.dp,
                color = if (ring) Palette.Accent else Palette.GlassBorder,
                shape = CircleShape,
            ),
        contentAlignment = Alignment.Center,
    ) {
        Text(initials, color = Palette.TextSecondary, fontSize = fontSize, fontWeight = FontWeight.SemiBold)
    }
}

/** Round button. Glass when [haze] is given, solid when [solid] is given, soft translucent otherwise. */
@Composable
fun GlassIconButton(
    icon: ImageVector,
    description: String,
    modifier: Modifier = Modifier,
    haze: HazeState? = null,
    size: Dp = 52.dp,
    tint: Color = Palette.TextPrimary,
    fill: Color = Color.Transparent,
    solid: Color? = null,
    calm: Boolean = false,
    liquid: Boolean = false,
    onClick: () -> Unit,
) {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val iconScale by animateFloatAsState(
        targetValue = if (pressed) (if (calm) 0.92f else 0.8f) else 1f,
        animationSpec = if (calm) tween(90) else spring(dampingRatio = 0.5f, stiffness = 500f),
        label = "iconScale",
    )
    val flash by animateFloatAsState(if (pressed) 0.12f else 0f, tween(120), label = "flash")
    val feedback = LocalHapticFeedback.current
    val base = when {
        solid != null -> Modifier.clip(CircleShape).background(solid)
            .border(1.dp, Color.White.copy(alpha = 0.2f), CircleShape)
        haze != null -> Modifier.glass(haze, CircleShape, liquid)
        else -> Modifier.clip(CircleShape).background(Palette.Glass)
            .border(1.dp, Palette.GlassBorder, CircleShape)
    }
    Box(
        modifier
            .size(size)
            .then(base)
            .background(fill)
            .background(Palette.tint(flash))
            .clickable(interactionSource = source, indication = null) {
                feedback.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onClick()
            },
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            imageVector = icon,
            contentDescription = description,
            tint = tint,
            modifier = Modifier
                .size(size * 0.45f)
                .graphicsLayer { scaleX = iconScale; scaleY = iconScale },
        )
    }
}

@Composable
fun PlainIconButton(
    icon: ImageVector,
    description: String,
    modifier: Modifier = Modifier,
    tint: Color = Palette.TextPrimary,
    size: Dp = 44.dp,
    onClick: () -> Unit,
) {
    Box(modifier.size(size).pressable(0.82f, onClick = onClick), contentAlignment = Alignment.Center) {
        Icon(icon, description, tint = tint, modifier = Modifier.size(22.dp))
    }
}

@Composable
fun PrimaryButton(
    text: String,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    onClick: () -> Unit,
) {
    val a by animateFloatAsState(if (enabled) 1f else 0.45f, tween(200), label = "btnAlpha")
    Box(
        modifier
            .fillMaxWidth()
            .height(56.dp)
            .graphicsLayer { this.alpha = a }
            .pressable(0.97f, haptic = true) { if (enabled) onClick() }
            .clip(CircleShape)
            .background(Palette.Accent)
            .border(1.dp, Color.White.copy(alpha = 0.16f), CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun GlassField(
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    modifier: Modifier = Modifier,
    keyboardType: KeyboardType = KeyboardType.Text,
    imeAction: ImeAction = ImeAction.Done,
    visualTransformation: VisualTransformation = VisualTransformation.None,
    onImeAction: () -> Unit = {},
) {
    BasicTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = modifier,
        singleLine = true,
        visualTransformation = visualTransformation,
        textStyle = TextStyle(color = Palette.TextPrimary, fontSize = 16.sp),
        cursorBrush = SolidColor(Palette.AccentSoft),
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType, imeAction = imeAction),
        keyboardActions = KeyboardActions(onAny = { onImeAction() }),
        decorationBox = { inner ->
            Box(contentAlignment = Alignment.CenterStart) {
                if (value.isEmpty()) {
                    Text(placeholder, color = Palette.TextSecondary, fontSize = 16.sp)
                }
                inner()
            }
        },
    )
}

@Composable
fun SoftButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier
            .height(48.dp)
            .pressable(0.96f, haptic = true, onClick = onClick)
            .clip(CircleShape)
            .background(Palette.Glass)
            .border(1.dp, Palette.GlassBorder, CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = Palette.TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Medium)
    }
}
