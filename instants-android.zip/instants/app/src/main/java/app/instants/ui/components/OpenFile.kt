package app.instants.ui.components

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.core.content.FileProvider
import app.instants.data.Attachments
import app.instants.data.Msg
import app.instants.data.SafeFiles
import kotlinx.coroutines.CancellationException

/** Downloads (if needed) and opens a received document. It is opened by its extension from the safe list, never by the type the sender claims. */
suspend fun openSharedDocument(context: Context, m: Msg) {
    if (!Attachments.isDocumentSaved(m)) Toast.makeText(context, "Downloading…", Toast.LENGTH_SHORT).show()
    val file = try {
        Attachments.document(m)
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        null
    }
    if (file == null) {
        Toast.makeText(context, "Couldn't download this file", Toast.LENGTH_SHORT).show()
        return
    }
    val mime = SafeFiles.mimeFor(m.attachmentName ?: file.name)
    if (mime == null) {
        Toast.makeText(context, "For your safety, this type of file can't be opened from the chat", Toast.LENGTH_LONG).show()
        return
    }
    try {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.files", file)
        context.startActivity(
            Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION),
        )
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(context, "No app on this phone can open this file", Toast.LENGTH_LONG).show()
    } catch (e: Exception) {
        Toast.makeText(context, "Couldn't open this file", Toast.LENGTH_SHORT).show()
    }
}
