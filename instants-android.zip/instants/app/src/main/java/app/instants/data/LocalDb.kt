package app.instants.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/** AES-GCM with a key that lives in the Android Keystore, so it never leaves the phone's secure hardware. */
object DeviceCrypto {
    private const val PROVIDER = "AndroidKeyStore"

    private fun key(alias: String): SecretKey {
        val store = KeyStore.getInstance(PROVIDER).apply { load(null) }
        (store.getKey(alias, null) as? SecretKey)?.let { return it }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, PROVIDER)
        gen.init(
            KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build(),
        )
        return gen.generateKey()
    }

    /** Returns the random IV followed by the ciphertext. */
    fun encrypt(alias: String, plain: ByteArray): ByteArray {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key(alias))
        return cipher.iv + cipher.doFinal(plain)
    }

    fun decrypt(alias: String, blob: ByteArray): ByteArray {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key(alias), GCMParameterSpec(128, blob, 0, 12))
        return cipher.doFinal(blob, 12, blob.size - 12)
    }
}

/** One stored message: its chat, id, send time and the message as JSON text. */
data class StoredMsg(val chatId: String, val id: String, val createdAt: Long, val json: String)

/**
 * The phone's own copy of your chats, encrypted at rest.
 *
 * Every message and chat is sealed with AES-256-GCM before it is written. The data key is random, kept only
 * in wrapped form (the wrapping key is in the Android Keystore), and held in memory while the app runs,
 * so reading and writing stays fast. Only ids and timestamps are left readable so the database can sort and
 * look things up. If the key is ever lost (for example the phone is restored from a backup made by Android),
 * the rows simply can't be read and the app refills them from the server.
 */
object LocalDb {
    private const val WRAP_ALIAS = "instants_data_key_wrap"
    private val random = SecureRandom()

    private var helper: Helper? = null
    private var keyPrefs: android.content.SharedPreferences? = null
    private var dataKey: ByteArray? = null

    private class Helper(context: Context) : SQLiteOpenHelper(context, "instants.db", null, 1) {
        override fun onCreate(db: SQLiteDatabase) {
            db.execSQL("CREATE TABLE messages (id TEXT PRIMARY KEY, chat_id TEXT NOT NULL, created_at INTEGER NOT NULL, body BLOB NOT NULL)")
            db.execSQL("CREATE INDEX messages_by_chat ON messages (chat_id, created_at)")
            db.execSQL("CREATE TABLE chats (id TEXT PRIMARY KEY, position INTEGER NOT NULL, body BLOB NOT NULL)")
        }

        override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    }

    fun init(context: Context) {
        val app = context.applicationContext
        keyPrefs = app.getSharedPreferences("instants_keys", Context.MODE_PRIVATE)
        helper = Helper(app)
    }

    private val db: SQLiteDatabase? get() = helper?.writableDatabase

    // ---- the data key ----

    @Synchronized
    private fun key(): ByteArray {
        dataKey?.let { return it }
        val prefs = keyPrefs ?: throw IllegalStateException("LocalDb not initialised")
        val stored = prefs.getString("dek", null)
        val key = try {
            if (stored != null) DeviceCrypto.decrypt(WRAP_ALIAS, Base64.decode(stored, Base64.NO_WRAP)) else null
        } catch (e: Exception) {
            null
        } ?: ByteArray(32).also { fresh ->
            // First run, or the wrapping key is gone: start a new data key. Old rows become unreadable and are refilled.
            random.nextBytes(fresh)
            prefs.edit().putString("dek", Base64.encodeToString(DeviceCrypto.encrypt(WRAP_ALIAS, fresh), Base64.NO_WRAP)).apply()
            try { db?.run { execSQL("DELETE FROM messages"); execSQL("DELETE FROM chats") } } catch (_: Exception) { }
        }
        dataKey = key
        return key
    }

    private fun seal(plain: String, aad: String): ByteArray {
        val iv = ByteArray(12).also { random.nextBytes(it) }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key(), "AES"), GCMParameterSpec(128, iv))
        cipher.updateAAD(aad.toByteArray())
        return iv + cipher.doFinal(plain.toByteArray())
    }

    private fun unseal(blob: ByteArray, aad: String): String? = try {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(key(), "AES"), GCMParameterSpec(128, blob, 0, 12))
        cipher.updateAAD(aad.toByteArray())
        String(cipher.doFinal(blob, 12, blob.size - 12))
    } catch (e: Exception) {
        null
    }

    // ---- messages ----

    /**
     * Stores the newest window of a chat as the server just returned it. Messages in that window that the
     * server no longer has (deleted, or disappeared) are removed; older history is left alone.
     */
    fun syncThread(chatId: String, rows: List<StoredMsg>) {
        val d = db ?: return
        try {
            d.beginTransaction()
            try {
                if (rows.isEmpty()) {
                    d.delete("messages", "chat_id = ?", arrayOf(chatId))
                } else {
                    val oldest = rows.minOf { it.createdAt }
                    val keep = rows.map { it.id }.toSet()
                    val stale = ArrayList<String>()
                    d.rawQuery("SELECT id FROM messages WHERE chat_id = ? AND created_at >= ?", arrayOf(chatId, oldest.toString())).use { c ->
                        while (c.moveToNext()) {
                            val id = c.getString(0)
                            if (id !in keep) stale.add(id)
                        }
                    }
                    stale.forEach { d.delete("messages", "id = ?", arrayOf(it)) }
                    rows.forEach { put(d, it) }
                }
                d.setTransactionSuccessful()
            } finally {
                d.endTransaction()
            }
        } catch (e: Exception) {
            // the cache is only a convenience; the server stays the source of truth
        }
    }

    /** Adds messages without removing anything (used when restoring a backup). */
    fun importMessages(rows: List<StoredMsg>) {
        val d = db ?: return
        d.beginTransaction()
        try {
            rows.forEach { put(d, it) }
            d.setTransactionSuccessful()
        } finally {
            d.endTransaction()
        }
    }

    private fun put(d: SQLiteDatabase, m: StoredMsg) {
        val cv = ContentValues().apply {
            put("id", m.id)
            put("chat_id", m.chatId)
            put("created_at", m.createdAt)
            put("body", seal(m.json, m.id))
        }
        d.insertWithOnConflict("messages", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
    }

    /** The newest [limit] messages of a chat, oldest first. */
    fun loadThread(chatId: String, limit: Int = 100): List<String> {
        val d = db ?: return emptyList()
        val out = ArrayList<String>()
        try {
            d.rawQuery(
                "SELECT id, body FROM messages WHERE chat_id = ? ORDER BY created_at DESC LIMIT ?",
                arrayOf(chatId, limit.toString()),
            ).use { c ->
                while (c.moveToNext()) {
                    unseal(c.getBlob(1), c.getString(0))?.let { out.add(it) }
                }
            }
        } catch (e: Exception) {
            return emptyList()
        }
        out.reverse()
        return out
    }

    /** Every message on the phone, one at a time (used for backups, so memory stays small). */
    fun forEachMessage(block: (chatId: String, createdAt: Long, json: String) -> Unit) {
        val d = db ?: return
        d.rawQuery("SELECT id, chat_id, created_at, body FROM messages ORDER BY created_at", null).use { c ->
            while (c.moveToNext()) {
                val json = unseal(c.getBlob(3), c.getString(0)) ?: continue
                block(c.getString(1), c.getLong(2), json)
            }
        }
    }

    // ---- chat list ----

    fun replaceChats(jsons: List<String>) {
        val d = db ?: return
        try {
            d.beginTransaction()
            try {
                d.delete("chats", null, null)
                jsons.forEachIndexed { i, json ->
                    val cv = ContentValues().apply {
                        put("id", i.toString())
                        put("position", i)
                        put("body", seal(json, "chat$i"))
                    }
                    d.insertWithOnConflict("chats", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
                }
                d.setTransactionSuccessful()
            } finally {
                d.endTransaction()
            }
        } catch (e: Exception) {
        }
    }

    fun loadChats(): List<String> {
        val d = db ?: return emptyList()
        val out = ArrayList<String>()
        try {
            d.rawQuery("SELECT id, body FROM chats ORDER BY position", null).use { c ->
                while (c.moveToNext()) {
                    unseal(c.getBlob(1), "chat${c.getString(0)}")?.let { out.add(it) }
                }
            }
        } catch (e: Exception) {
            return emptyList()
        }
        return out
    }

    fun clear() {
        try {
            db?.run {
                execSQL("DELETE FROM messages")
                execSQL("DELETE FROM chats")
            }
        } catch (_: Exception) {
        }
    }
}
