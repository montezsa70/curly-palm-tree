package app.instants.data

import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.snapshots.SnapshotStateList
import java.time.LocalTime
import java.time.format.DateTimeFormatter

data class Contact(
    val id: String,
    val name: String,
    val favorite: Boolean = false,
    val isGroup: Boolean = false,
) {
    val initials: String
        get() = name.split(" ").filter { it.isNotBlank() }.take(2)
            .joinToString("") { it.first().uppercase() }
}

data class Message(
    val id: Long,
    val text: String,
    val fromMe: Boolean,
    val time: String,
    val read: Boolean = false,
)

enum class CallType { Outgoing, Incoming, Missed }

data class CallEntry(val id: Int, val contactId: String, val type: CallType, val whenLabel: String)

/** In-memory mock backend. Replace with real repositories later. */
object MockStore {
    private var nextId = 1000L

    val contacts = mutableStateListOf<Contact>()
    val chatOrder = mutableStateListOf<String>()
    val messages = mutableStateMapOf<String, SnapshotStateList<Message>>()
    val unread = mutableStateMapOf<String, Int>()
    val statuses = listOf("maya", "leo", "sofia", "amir")

    val calls = listOf(
        CallEntry(1, "maya", CallType.Outgoing, "9:41"),
        CallEntry(2, "jordan", CallType.Missed, "Yesterday"),
        CallEntry(3, "mom", CallType.Incoming, "Yesterday"),
        CallEntry(4, "amir", CallType.Outgoing, "Tuesday"),
        CallEntry(5, "sofia", CallType.Incoming, "Monday"),
        CallEntry(6, "leo", CallType.Missed, "Monday"),
        CallEntry(7, "priya", CallType.Outgoing, "Sunday"),
        CallEntry(8, "daniel", CallType.Incoming, "Saturday"),
    )

    init {
        contacts += listOf(
            Contact("maya", "Maya Chen", favorite = true),
            Contact("design", "Design Squad", isGroup = true),
            Contact("jordan", "Jordan"),
            Contact("mom", "Mom", favorite = true),
            Contact("amir", "Amir Khan"),
            Contact("sofia", "Sofia", favorite = true),
            Contact("leo", "Leo"),
            Contact("priya", "Priya"),
            Contact("daniel", "Daniel"),
        )
        seed("maya", listOf(
            Triple("Are we still on for tonight?", false, "9:38"),
            Triple("I can bring the photos from the trip", false, "9:38"),
            Triple("Yes, 8 at the usual place", true, "9:39"),
            Triple("Photos would be great", true, "9:39"),
            Triple("Perfect, see you then", false, "9:40"),
            Triple("On my way, 10 minutes", false, "9:41"),
        ))
        seed("design", listOf(
            Triple("New screens are ready for review", false, "9:05"),
            Triple("Sharing the new screens now", false, "9:12"),
        ))
        seed("jordan", listOf(Triple("See you tomorrow", true, "Yesterday")))
        seed("mom", listOf(Triple("Call me when you can", false, "Yesterday")))
        seed("amir", listOf(Triple("Sent you a photo", false, "Tuesday")))
        seed("sofia", listOf(Triple("Booked the cabin", false, "Monday")))
        seed("leo", listOf(Triple("Let me know what you think", false, "Sunday")))
        seed("priya", listOf(Triple("Thanks!", true, "Sunday")))
        seed("daniel", listOf(Triple("Sounds good", false, "Saturday")))
        unread["maya"] = 2
        unread["design"] = 5
    }

    private fun seed(id: String, items: List<Triple<String, Boolean, String>>) {
        messages[id] = mutableStateListOf<Message>().also { list ->
            items.forEach { (t, mine, time) -> list.add(Message(nextId++, t, mine, time, read = mine)) }
        }
        chatOrder.add(id)
    }

    private fun nowLabel(): String = LocalTime.now().format(DateTimeFormatter.ofPattern("H:mm"))

    fun contact(id: String): Contact = contacts.first { it.id == id }

    fun append(chatId: String, text: String, fromMe: Boolean) {
        val list = messages.getOrPut(chatId) { mutableStateListOf() }
        list.add(Message(nextId++, text, fromMe, nowLabel()))
        chatOrder.remove(chatId)
        chatOrder.add(0, chatId)
    }

    fun markRead(chatId: String) {
        unread[chatId] = 0
    }

    fun markMineRead(chatId: String) {
        val list = messages[chatId] ?: return
        for (i in list.indices) {
            if (list[i].fromMe && !list[i].read) list[i] = list[i].copy(read = true)
        }
    }

    fun addContact(name: String): String {
        val id = "c${nextId++}"
        contacts.add(Contact(id, name.trim()))
        messages[id] = mutableStateListOf()
        chatOrder.add(0, id)
        return id
    }
}
