package app.instants.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.instants.call.CallManager
import app.instants.call.CallPhase
import app.instants.data.CallEntry
import app.instants.data.CallLog
import app.instants.data.ChatItem
import app.instants.data.Realtime
import app.instants.data.Store
import app.instants.data.listLabel
import app.instants.ui.components.Ic
import app.instants.ui.components.LIcon
import app.instants.ui.components.ProfileAvatar
import app.instants.ui.components.staggerIn
import app.instants.ui.theme.Palette
import kotlinx.coroutines.delay

@Composable
fun CallsTab(bottomPadding: Dp, onCall: (ChatItem) -> Unit = {}) {
    val top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    var entries by remember { mutableStateOf<List<CallEntry>?>(null) }

    suspend fun reload() {
        try {
            entries = CallLog.load()
        } catch (_: Exception) {
            // keep what is on screen; the next call or visit tries again
        }
    }
    // On opening, and a moment after each call ends (the server writes the entry when it ends).
    val idle = CallManager.phase == CallPhase.Idle
    LaunchedEffect(idle) {
        if (idle) {
            if (entries != null) delay(700)
            reload()
        }
    }
    // Calls made or received on this phone while the tab is open
    LaunchedEffect(Unit) {
        Realtime.callEvents.collect { ev ->
            if (ev.table == "calls" || ev.table == "resync") {
                delay(400)
                reload()
            }
        }
    }

    val chats = Store.chats
    val rows = entries.orEmpty().mapNotNull { e -> chats.firstOrNull { it.chatId == e.chatId }?.let { e to it } }

    Column(Modifier.fillMaxSize().padding(top = top + 12.dp)) {
        Text(
            "Calls",
            color = Palette.TextPrimary,
            fontSize = 34.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = (-0.5).sp,
            modifier = Modifier.padding(horizontal = 20.dp).staggerIn(0),
        )
        if (rows.isEmpty()) {
            Column(
                Modifier.weight(1f).fillMaxWidth().padding(horizontal = 32.dp).padding(bottom = bottomPadding).staggerIn(1),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                Box(
                    Modifier.size(84.dp).clip(CircleShape).background(Palette.Glass)
                        .border(1.dp, Palette.GlassBorder, CircleShape),
                    contentAlignment = Alignment.Center,
                ) {
                    LIcon(Ic.Calls, Palette.AccentSoft, 34.dp)
                }
                Spacer(Modifier.height(20.dp))
                Text("No calls yet", color = Palette.TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                Text(
                    "Your call history will show up here. Tap the call button to start one.",
                    color = Palette.TextSecondary, fontSize = 15.sp, textAlign = TextAlign.Center,
                )
            }
        } else {
            LazyColumn(
                Modifier.weight(1f).fillMaxWidth().staggerIn(1),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(top = 12.dp, bottom = bottomPadding),
            ) {
                items(rows, key = { it.first.id }) { (entry, chat) -> CallRow(entry, chat) { onCall(chat) } }
            }
        }
    }
}

@Composable
private fun CallRow(entry: CallEntry, chat: ChatItem, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        ProfileAvatar(chat.initials, 48.dp, chat.peer?.avatarPath)
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(
                chat.title,
                color = if (entry.wentWrong) Palette.EndCall else Palette.TextPrimary,
                fontSize = 17.sp, fontWeight = FontWeight.SemiBold,
                maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
            Text(entry.summary, color = Palette.TextSecondary, fontSize = 14.sp, maxLines = 1)
        }
        Text(entry.startedAt.listLabel(), color = Palette.TextSecondary, fontSize = 13.sp)
        LIcon(Ic.Calls, Palette.AccentSoft, 22.dp)
    }
}
