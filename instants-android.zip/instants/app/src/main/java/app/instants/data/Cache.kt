package app.instants.data

import android.content.Context
import android.content.SharedPreferences
import android.graphics.BitmapFactory
import android.util.LruCache
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.time.Instant

/** Saves what the screens show so the app opens instantly, then refreshes in the background. */
object Cache {
    private var prefs: SharedPreferences? = null

    fun init(context: Context) {
        prefs = context.getSharedPreferences("cache", Context.MODE_PRIVATE)
    }

    private fun put(key: String, value: String) { prefs?.edit()?.putString(key, value)?.apply() }
    private fun get(key: String): String? = prefs?.getString(key, null)

    fun clear() { prefs?.edit()?.clear()?.apply() }

    /** For other stores (statuses) that keep their own JSON here. */
    fun putString(key: String, value: String) = put(key, value)
    fun getString(key: String): String? = get(key)
    fun remove(key: String) { prefs?.edit()?.remove(key)?.apply() }

    // ---- JSON helpers ----
    private fun Profile.toJson() = JSONObject().put("id", id).put("u", username).put("dn", displayName)
        .put("about", about).put("av", avatarPath ?: JSONObject.NULL)

    private fun JSONObject.toProfile() = Profile(
        getString("id"), getString("u"), getString("dn"), optString("about", ""),
        if (isNull("av")) null else getString("av"),
    )

    private fun Msg.toJson() = JSONObject().put("id", id).put("c", chatId).put("s", senderId)
        .put("b", body).put("t", createdAt.toEpochMilli()).put("k", kind)
        .put("ap", attachmentPath ?: JSONObject.NULL).put("an", attachmentName ?: JSONObject.NULL)
        .put("am", attachmentMime ?: JSONObject.NULL).put("as", attachmentSize)

    private fun JSONObject.toMsg() = Msg(
        id = getString("id"),
        chatId = getString("c"),
        senderId = getString("s"),
        body = getString("b"),
        createdAt = Instant.ofEpochMilli(getLong("t")),
        kind = optString("k", "text").ifBlank { "text" },
        attachmentPath = if (isNull("ap")) null else getString("ap"),
        attachmentName = if (isNull("an")) null else getString("an"),
        attachmentMime = if (isNull("am")) null else getString("am"),
        attachmentSize = optLong("as", 0L),
    )

    private fun ChatItem.toJson() = JSONObject()
        .put("id", chatId)
        .put("peer", peer?.toJson() ?: JSONObject.NULL)
        .put("title", title)
        .put("last", last?.toJson() ?: JSONObject.NULL)
        .put("unread", unread)
        .put("read", peerLastRead?.toEpochMilli() ?: JSONObject.NULL)
        .put("sort", sortKey.toEpochMilli())

    private fun JSONObject.toChat() = ChatItem(
        chatId = getString("id"),
        peer = if (isNull("peer")) null else getJSONObject("peer").toProfile(),
        title = getString("title"),
        last = if (isNull("last")) null else getJSONObject("last").toMsg(),
        unread = getInt("unread"),
        peerLastRead = if (isNull("read")) null else Instant.ofEpochMilli(getLong("read")),
        sortKey = Instant.ofEpochMilli(getLong("sort")),
    )

    // ---- Me ----
    fun saveMe(me: Me) {
        put(
            "me",
            JSONObject().put("profile", me.profile.toJson()).put(
                "settings",
                JSONObject().put("ls", me.settings.lastSeen).put("fm", me.settings.findMe)
                    .put("rr", me.settings.readReceipts).put("ds", me.settings.disappearSecs),
            ).toString(),
        )
    }

    fun loadMe(): Me? = try {
        get("me")?.let {
            val j = JSONObject(it)
            val s = j.getJSONObject("settings")
            Me(
                j.getJSONObject("profile").toProfile(),
                UserSettings(s.getString("ls"), s.getString("fm"), s.getBoolean("rr"), s.getInt("ds")),
            )
        }
    } catch (e: Exception) {
        null
    }

    // ---- Chats and threads ----
    fun saveChats(list: List<ChatItem>) {
        val arr = JSONArray()
        list.forEach { arr.put(it.toJson()) }
        put("chats", arr.toString())
        put("chats_loaded", "1")
    }

    fun loadChats(): List<ChatItem> = try {
        get("chats")?.let { s ->
            val arr = JSONArray(s)
            (0 until arr.length()).map { arr.getJSONObject(it).toChat() }
        } ?: emptyList()
    } catch (e: Exception) {
        emptyList()
    }

    fun chatsLoadedBefore(): Boolean = get("chats_loaded") != null

    fun saveThread(chatId: String, messages: List<Msg>) {
        val arr = JSONArray()
        messages.takeLast(100).forEach { arr.put(it.toJson()) }
        put("thread_$chatId", arr.toString())
    }

    fun loadThread(chatId: String): List<Msg> = try {
        get("thread_$chatId")?.let { s ->
            val arr = JSONArray(s)
            (0 until arr.length()).map { arr.getJSONObject(it).toMsg() }
        } ?: emptyList()
    } catch (e: Exception) {
        emptyList()
    }

    fun saveIds(key: String, ids: Set<String>) { put(key, JSONArray(ids.toList()).toString()) }

    fun loadIds(key: String): Set<String> = try {
        get(key)?.let { s ->
            val arr = JSONArray(s)
            (0 until arr.length()).map { arr.getString(it) }.toSet()
        } ?: emptySet()
    } catch (e: Exception) {
        emptySet()
    }
}

/** Profile photos: memory + disk cache, downloaded from the private bucket with the user's token. */
object Avatars {
    private val memory = LruCache<String, ImageBitmap>(40)
    private var dir: File? = null

    fun init(context: Context) {
        dir = File(context.filesDir, "avatars").also { it.mkdirs() }
    }

    private fun file(path: String): File? = dir?.let { File(it, path.replace('/', '_')) }

    fun put(path: String, bytes: ByteArray) {
        try { file(path)?.writeBytes(bytes) } catch (e: Exception) { }
    }

    suspend fun load(path: String): ImageBitmap? = withContext(Dispatchers.IO) {
        memory.get(path)?.let { return@withContext it }
        val f = file(path)
        val bytes: ByteArray = try {
            if (f != null && f.exists()) f.readBytes() else Api.downloadAvatar(path).also { f?.writeBytes(it) }
        } catch (e: Exception) {
            return@withContext null
        }
        val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.asImageBitmap()
        if (bmp != null) memory.put(path, bmp)
        bmp
    }

    fun clear() {
        memory.evictAll()
        dir?.listFiles()?.forEach { it.delete() }
    }
}
