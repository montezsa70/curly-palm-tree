package app.instants.ui.screens

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Call
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import app.instants.data.Attachments
import app.instants.data.Avatars
import app.instants.data.Cache
import app.instants.data.Msg
import app.instants.data.Repo
import app.instants.data.Store
import app.instants.data.formatSize
import app.instants.data.lastSeenLabel
import app.instants.ui.components.GlassSwitch
import app.instants.ui.components.Ic
import app.instants.ui.components.LIcon
import app.instants.ui.components.ProfileAvatar
import app.instants.ui.components.ReportSheet
import app.instants.ui.components.ScreenHeader
import app.instants.ui.components.SoftButton
import app.instants.ui.components.openSharedDocument
import app.instants.ui.components.pressable
import app.instants.ui.theme.Palette
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

private enum class SharedTab(val label: String) { Media("Media"), Documents("Documents") }

/**
 * A person's full profile page, opened from their name in the chat: a big photo (tap it to see it full screen),
 * their details, and everything shared in this chat, tidied by month.
 */
@Composable
fun ContactProfileScreen(chatId: String, onBack: () -> Unit, onCall: (name: String, initials: String) -> Unit) {
    val chat = Store.chats.firstOrNull { it.chatId == chatId }
    val peer = chat?.peer
    val title = chat?.title ?: "Contact"
    val initials = chat?.initials ?: ""
    val blocked = peer != null && peer.id in Store.blockedIds
    val closeFriend = peer != null && peer.id in Store.closeFriendIds
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    var seen by remember { mutableStateOf<Instant?>(null) }
    LaunchedEffect(peer?.id) {
        val id = peer?.id ?: return@LaunchedEffect
        seen = try {
            Repo.statuses(listOf(id))[id]
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            null
        }
    }

    // Everything saved on this phone for this chat
    val messages by produceState(emptyList<Msg>(), chatId) {
        value = withContext(Dispatchers.IO) { Cache.loadThread(chatId) }
    }
    val photos = remember(messages) {
        messages.filter { it.kind == "image" && !it.deleted && it.attachmentPath != null }.sortedByDescending { it.createdAt }
    }
    val documents = remember(messages) {
        messages.filter { it.kind == "file" && !it.deleted && it.attachmentPath != null }.sortedByDescending { it.createdAt }
    }
    var tab by rememberSaveable { mutableStateOf(SharedTab.Media) }
    var viewAvatar by remember { mutableStateOf(false) }
    var viewPhoto by remember { mutableStateOf<Int?>(null) }
    var reporting by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().background(Palette.Background)) {
        ScreenHeader("Contact", onBack)
        LazyColumn(
            Modifier.weight(1f),
            contentPadding = PaddingValues(bottom = 32.dp),
        ) {
            item(key = "head") {
                Column(Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    ProfileAvatar(
                        initials, 132.dp, peer?.avatarPath,
                        Modifier.pressable(0.97f) { if (peer?.avatarPath != null) viewAvatar = true },
                    )
                    Spacer(Modifier.height(16.dp))
                    Text(title, color = Palette.TextPrimary, fontSize = 26.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 24.dp))
                    if (peer != null) Text("@${peer.username}", color = Palette.TextSecondary, fontSize = 15.sp)
                    seen?.let {
                        Spacer(Modifier.height(6.dp))
                        Text(lastSeenLabel(it), color = Palette.AccentSoft, fontSize = 13.sp)
                    }
                    if (peer != null && peer.about.isNotBlank()) {
                        Spacer(Modifier.height(14.dp))
                        Text(
                            peer.about, color = Palette.TextPrimary, fontSize = 15.sp, lineHeight = 22.sp,
                            textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 32.dp),
                        )
                    }
                    Spacer(Modifier.height(22.dp))
                    CallPill { onCall(title, initials) }
                }
            }

            if (peer != null) {
                item(key = "close") {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .heightIn(min = 64.dp)
                            .pressable(0.99f, haptic = true) { scope.launch { Store.toggleCloseFriend(peer.id) } }
                            .padding(horizontal = 24.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text("Close friend", color = Palette.TextPrimary, fontSize = 16.sp)
                            Text("Can see your last seen and when you’re active", color = Palette.TextSecondary, fontSize = 12.sp)
                        }
                        GlassSwitch(closeFriend)
                    }
                }
            }

            item(key = "sharedHead") {
                Column(Modifier.padding(top = 20.dp)) {
                    Text(
                        "Shared in this chat", color = Palette.TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(horizontal = 24.dp),
                    )
                    Row(
                        Modifier.padding(horizontal = 24.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        FilterPill("${SharedTab.Media.label} · ${photos.size}", selected = tab == SharedTab.Media) { tab = SharedTab.Media }
                        FilterPill("${SharedTab.Documents.label} · ${documents.size}", selected = tab == SharedTab.Documents) { tab = SharedTab.Documents }
                    }
                }
            }

            if (tab == SharedTab.Media) {
                if (photos.isEmpty()) {
                    item(key = "noMedia") { EmptyShared("No photos shared yet") }
                } else {
                    val indexOf = photos.withIndex().associate { it.value.id to it.index }
                    photos.groupBy { monthLabel(it.createdAt) }.forEach { (month, inMonth) ->
                        item(key = "m-$month") { MonthLabel(month) }
                        inMonth.chunked(3).forEach { row ->
                            item(key = "r-" + row.first().id) {
                                Row(
                                    Modifier.fillMaxWidth().padding(horizontal = 24.dp).padding(bottom = 4.dp),
                                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                                ) {
                                    row.forEach { m ->
                                        Box(Modifier.weight(1f)) { PhotoTile(m) { viewPhoto = indexOf[m.id] } }
                                    }
                                    repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                                }
                            }
                        }
                    }
                }
            } else {
                if (documents.isEmpty()) {
                    item(key = "noDocs") { EmptyShared("No documents shared yet") }
                } else {
                    documents.groupBy { monthLabel(it.createdAt) }.forEach { (month, inMonth) ->
                        item(key = "dm-$month") { MonthLabel(month) }
                        inMonth.forEach { m ->
                            item(key = "d-" + m.id) {
                                DocumentRow(m) { scope.launch { openSharedDocument(context, m) } }
                            }
                        }
                    }
                }
            }

            if (peer != null) {
                item(key = "danger") {
                    Column(Modifier.padding(horizontal = 24.dp).padding(top = 28.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        SoftButton(if (blocked) "Unblock contact" else "Block contact", Modifier.fillMaxWidth()) {
                            scope.launch { Store.setBlocked(peer.id, !blocked) }
                        }
                        SoftButton("Report contact", Modifier.fillMaxWidth()) { reporting = true }
                    }
                }
            }
        }
    }

    if (viewAvatar && peer != null) {
        AvatarViewer(title, peer.avatarPath) { viewAvatar = false }
    }
    viewPhoto?.let { start ->
        PhotoPager(photos, start) { viewPhoto = null }
    }
    if (reporting && peer != null) {
        ReportSheet(
            who = peer.name,
            onSend = { reason, details, alsoBlock ->
                Repo.submitReport(peer.id, null, null, reason, details)
                if (alsoBlock) Store.setBlocked(peer.id, true)
                android.widget.Toast.makeText(context, "Report sent. Thank you.", android.widget.Toast.LENGTH_SHORT).show()
            },
            onDismiss = { reporting = false },
        )
    }
}

@Composable
private fun CallPill(onClick: () -> Unit) {
    val shape = RoundedCornerShape(24.dp)
    Row(
        Modifier
            .heightIn(min = 48.dp)
            .pressable(0.96f, haptic = true, onClick = onClick)
            .clip(shape)
            .background(Palette.tint(0.06f))
            .border(1.dp, Palette.GlassBorder, shape)
            .padding(horizontal = 24.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        androidx.compose.material3.Icon(Icons.Rounded.Call, null, tint = Palette.AccentSoft, modifier = Modifier.size(20.dp))
        Text("Call", color = Palette.TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun MonthLabel(text: String) {
    Text(
        text, color = Palette.TextSecondary, fontSize = 13.sp, fontWeight = FontWeight.Medium,
        modifier = Modifier.padding(horizontal = 24.dp).padding(top = 12.dp, bottom = 8.dp),
    )
}

@Composable
private fun EmptyShared(text: String) {
    Box(Modifier.fillMaxWidth().padding(vertical = 36.dp), contentAlignment = Alignment.Center) {
        Text(text, color = Palette.TextSecondary, fontSize = 14.sp)
    }
}

@Composable
private fun PhotoTile(m: Msg, onClick: () -> Unit) {
    val thumb by produceState<Bitmap?>(null, m.attachmentPath) { value = m.attachmentPath?.let { Attachments.thumbnail(it) } }
    Box(
        Modifier
            .fillMaxWidth()
            .aspectRatio(1f)
            .clip(RoundedCornerShape(8.dp))
            .background(Palette.tint(0.06f))
            .pressable(0.97f, onClick = onClick),
    ) {
        thumb?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
    }
}

@Composable
private fun DocumentRow(m: Msg, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .heightIn(min = 64.dp)
            .pressable(0.99f, onClick = onClick)
            .padding(horizontal = 24.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Box(Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)).background(Palette.tint(0.06f)), contentAlignment = Alignment.Center) {
            LIcon(Ic.Document, Palette.AccentSoft, 22.dp)
        }
        Column(Modifier.weight(1f)) {
            Text(m.attachmentName ?: "Document", color = Palette.TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                listOf(formatSize(m.attachmentSize), dayLabel(m.createdAt)).filter { it.isNotBlank() }.joinToString(" · "),
                color = Palette.TextSecondary, fontSize = 12.sp,
            )
        }
    }
}

/** The profile photo, full screen. Tap anywhere to close. */
@Composable
private fun AvatarViewer(name: String, avatarPath: String?, onClose: () -> Unit) {
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        val img by produceState<ImageBitmap?>(null, avatarPath) { value = avatarPath?.let { Avatars.load(it) } }
        Box(
            Modifier
                .fillMaxSize()
                .background(Color.Black)
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onClose() },
            contentAlignment = Alignment.Center,
        ) {
            img?.let { Image(it, name, Modifier.fillMaxWidth().aspectRatio(1f), contentScale = ContentScale.Fit) }
            Text(
                name, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(top = 20.dp),
            )
        }
    }
}

/** Photos from this chat, full screen, swipe sideways between them. Tap to close. */
@Composable
private fun PhotoPager(photos: List<Msg>, start: Int, onClose: () -> Unit) {
    if (photos.isEmpty()) return
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        val pager = rememberPagerState(initialPage = start.coerceIn(0, photos.lastIndex)) { photos.size }
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            HorizontalPager(pager, Modifier.fillMaxSize()) { page ->
                val m = photos[page]
                val bmp by produceState<Bitmap?>(null, m.attachmentPath) { value = m.attachmentPath?.let { Attachments.bitmap(it) } }
                Box(
                    Modifier
                        .fillMaxSize()
                        .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onClose() },
                    contentAlignment = Alignment.Center,
                ) {
                    bmp?.let { Image(it.asImageBitmap(), "Photo", Modifier.fillMaxSize(), contentScale = ContentScale.Fit) }
                }
            }
            Text(
                "${pager.currentPage + 1} of ${photos.size}",
                color = Color.White.copy(alpha = 0.85f), fontSize = 14.sp, fontWeight = FontWeight.Medium,
                modifier = Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(top = 20.dp),
            )
        }
    }
}

private val monthFormat = DateTimeFormatter.ofPattern("MMMM yyyy", Locale.getDefault())
private val dayFormat = DateTimeFormatter.ofPattern("d MMM yyyy", Locale.getDefault())

private fun monthLabel(at: Instant): String = monthFormat.format(at.atZone(ZoneId.systemDefault()))
private fun dayLabel(at: Instant): String = dayFormat.format(at.atZone(ZoneId.systemDefault()))
