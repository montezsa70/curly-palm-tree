package app.instants.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.PersonAdd
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.instants.data.ChatItem
import app.instants.data.Session
import app.instants.data.Store
import app.instants.data.listLabel
import app.instants.ui.components.Avatar
import app.instants.ui.components.GlassField
import app.instants.ui.components.PrimaryButton
import app.instants.ui.components.pressable
import app.instants.ui.components.staggerIn
import app.instants.ui.theme.Palette
import kotlinx.coroutines.delay

@Composable
fun ChatsTab(onOpenChat: (String) -> Unit, onInvite: () -> Unit, bottomPadding: Dp) {
    var query by rememberSaveable { mutableStateOf("") }
    var unreadOnly by rememberSaveable { mutableStateOf(false) }
    val top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()

    // Simple live updates: refresh every few seconds while this tab is visible.
    LaunchedEffect(Unit) {
        while (true) {
            Store.refreshChats()
            delay(4000)
        }
    }

    val all = Store.chats
    val chats = all.filter { it.title.contains(query.trim(), ignoreCase = true) && (!unreadOnly || it.unread > 0) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(top = top + 12.dp, bottom = bottomPadding),
    ) {
        item(key = "title") {
            Text(
                "Instants",
                color = Palette.TextPrimary,
                fontSize = 34.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = (-0.5).sp,
                modifier = Modifier.padding(horizontal = 20.dp).staggerIn(0),
            )
        }
        if (Store.loaded && all.isEmpty()) {
            item(key = "empty") {
                EmptyChats(onInvite, Modifier.fillParentMaxHeight(0.7f).staggerIn(1))
            }
        }
        if (all.isNotEmpty()) {
            item(key = "search") {
                Row(
                    Modifier
                        .padding(horizontal = 20.dp, vertical = 12.dp)
                        .fillMaxWidth()
                        .heightIn(min = 44.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.07f))
                        .border(1.dp, Palette.Hairline, CircleShape)
                        .padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Icon(Icons.Rounded.Search, null, tint = Palette.TextSecondary, modifier = Modifier.size(18.dp))
                    GlassField(
                        value = query,
                        onValueChange = { query = it },
                        placeholder = "Search",
                        modifier = Modifier.weight(1f).padding(vertical = 12.dp),
                        imeAction = ImeAction.Search,
                    )
                }
            }
            item(key = "chips") {
                Row(
                    Modifier
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 20.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    FilterPill("All", selected = !unreadOnly) { unreadOnly = false }
                    FilterPill("Unread", selected = unreadOnly) { unreadOnly = true }
                }
            }
            if (chats.isEmpty()) {
                item(key = "none") {
                    Box(Modifier.fillMaxWidth().padding(top = 48.dp), contentAlignment = Alignment.Center) {
                        Text("No chats found", color = Palette.TextSecondary, fontSize = 15.sp)
                    }
                }
            }
        }
        itemsIndexed(chats, key = { _, c -> c.chatId }) { index, chat ->
            val row = Modifier.animateItem().let { if (index < 8) it.staggerIn(index + 2) else it }
            ChatRow(chat, row) { onOpenChat(chat.chatId) }
        }
    }
}

@Composable
private fun EmptyChats(onInvite: () -> Unit, modifier: Modifier) {
    Column(
        modifier.fillMaxWidth().padding(horizontal = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Box(
            Modifier.size(84.dp).clip(CircleShape).background(Palette.Glass)
                .border(1.dp, Palette.GlassBorder, CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Rounded.PersonAdd, null, tint = Palette.AccentSoft, modifier = Modifier.size(34.dp))
        }
        Spacer(Modifier.height(20.dp))
        Text("No chats yet", color = Palette.TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        Text(
            "Instants is for the people you know. Invite a friend to start chatting.",
            color = Palette.TextSecondary,
            fontSize = 15.sp,
            lineHeight = 21.sp,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(24.dp))
        PrimaryButton("Invite contacts", Modifier.width(220.dp)) { onInvite() }
    }
}

@Composable
private fun FilterPill(label: String, selected: Boolean, onClick: () -> Unit) {
    val bg by animateColorAsState(
        if (selected) Palette.Accent else Color.White.copy(alpha = 0.05f), tween(250), label = "pillBg",
    )
    val fg by animateColorAsState(
        if (selected) Color.White else Color(0xFFC9CCD1), tween(250), label = "pillFg",
    )
    val shape = RoundedCornerShape(18.dp)
    Box(
        Modifier
            .heightIn(min = 36.dp)
            .pressable(0.94f, haptic = true, onClick = onClick)
            .clip(shape)
            .background(bg)
            .border(1.dp, if (selected) Palette.Accent else Palette.GlassBorder, shape)
            .padding(horizontal = 16.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, color = fg, fontSize = 14.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun ChatRow(chat: ChatItem, modifier: Modifier, onClick: () -> Unit) {
    val last = chat.last
    val read = chat.peerLastRead
    val preview = when {
        last == null -> "Say hi"
        last.senderId == Session.userId ->
            (if (read != null && read >= last.createdAt) "✓✓ " else "✓ ") + last.body
        else -> last.body
    }
    Row(
        modifier
            .fillMaxWidth()
            .pressable(0.985f, onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 10.dp)
            .heightIn(min = 44.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Avatar(chat.initials, 48.dp)
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(
                chat.title, color = Palette.TextPrimary, fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
            Text(
                preview, color = Palette.TextSecondary, fontSize = 14.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
        }
        Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
                last?.createdAt?.listLabel() ?: "",
                color = if (chat.unread > 0) Palette.AccentSoft else Palette.TextSecondary,
                fontSize = 12.sp,
            )
            AnimatedVisibility(
                visible = chat.unread > 0,
                enter = scaleIn(spring(dampingRatio = 0.5f)) + fadeIn(),
                exit = scaleOut() + fadeOut(),
            ) {
                Box(
                    Modifier.heightIn(min = 20.dp).widthIn(min = 20.dp)
                        .clip(CircleShape).background(Palette.Accent).padding(horizontal = 6.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text("${chat.unread}", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}
