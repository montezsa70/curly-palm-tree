package app.instants.ui.screens

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.togetherWith
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import app.instants.ui.components.ChatRowSkeleton
import app.instants.ui.components.PullRefresh
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.PersonAdd
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import app.instants.data.Cache
import app.instants.data.ChatPrefs
import app.instants.data.Drafts
import app.instants.ui.components.SwipeAction
import app.instants.ui.components.SwipeRevealRow
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.instants.data.ChatItem
import app.instants.data.Msg
import app.instants.data.callLabel
import app.instants.data.Tick
import app.instants.ui.components.Ic
import app.instants.ui.components.LIcon
import app.instants.data.Session
import app.instants.data.Store
import app.instants.data.listLabel
import app.instants.ui.components.ProfileAvatar
import app.instants.ui.components.GlassField
import app.instants.ui.components.PrimaryButton
import app.instants.ui.components.pressable
import app.instants.ui.components.staggerIn
import app.instants.ui.theme.Palette
import kotlinx.coroutines.delay

@Composable
fun ChatsTab(
    onOpenChat: (String) -> Unit,
    onInvite: () -> Unit,
    bottomPadding: Dp,
) {
    var query by rememberSaveable { mutableStateOf("") }
    var unreadOnly by rememberSaveable { mutableStateOf(false) }
    var showArchived by rememberSaveable { mutableStateOf(false) }
    var openId by remember { mutableStateOf<String?>(null) }
    var hits by remember { mutableStateOf<List<Msg>>(emptyList()) }
    val context = LocalContext.current
    val top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()

    // Simple live updates: refresh every few seconds while this tab is visible.
    LaunchedEffect(Unit) {
        while (true) {
            Store.refreshChats()
            delay(30_000) // safety net only; live changes arrive through Realtime
        }
    }

    // Search the messages kept on this phone too (they are encrypted, so this runs off the main thread).
    LaunchedEffect(query) {
        val q = query.trim()
        if (q.length < 2) {
            hits = emptyList()
        } else {
            delay(250)
            hits = withContext(Dispatchers.Default) { Cache.searchMessages(q) }
        }
    }
    BackHandler(enabled = showArchived) { showArchived = false }

    val all = Store.chats
    val archivedChats = all.filter { ChatPrefs.isArchived(it) }
    val searching = query.isNotBlank()
    val base = when {
        searching -> all
        showArchived -> archivedChats
        else -> all.filter { !ChatPrefs.isArchived(it) }
    }
    val chats = base
        .filter { it.title.contains(query.trim(), ignoreCase = true) && (!unreadOnly || it.unread > 0) }
        .sortedWith(
            compareByDescending<ChatItem> { !showArchived && ChatPrefs.isPinned(it.chatId) }.thenByDescending { it.sortKey },
        )
    val showArchiveEntry = !searching && !showArchived && archivedChats.isNotEmpty()

    PullRefresh(topPadding = top, onRefresh = { Store.refreshChats() }) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(top = top + 12.dp, bottom = bottomPadding),
    ) {
        item(key = "title") {
            if (showArchived && !searching) {
                Row(
                    Modifier.padding(horizontal = 12.dp).pressable(0.97f) { showArchived = false },
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    LIcon(Ic.ChevronLeft, Palette.TextPrimary, 28.dp, Modifier.padding(8.dp))
                    Text(
                        "Archived",
                        color = Palette.TextPrimary,
                        fontSize = 34.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = (-0.5).sp,
                    )
                }
            } else {
                Text(
                    "Instants",
                    color = Palette.TextPrimary,
                    fontSize = 34.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = (-0.5).sp,
                    modifier = Modifier.padding(horizontal = 20.dp).staggerIn(0),
                )
            }
        }
        if (!Store.loaded && all.isEmpty()) {
            items(7, key = { "skeleton$it" }) { i ->
                ChatRowSkeleton(0.42f + (i % 3) * 0.16f, Modifier.staggerIn(i))
            }
        }
        if (Store.loaded && all.isEmpty()) {
            item(key = "empty") {
                EmptyChats(onInvite, Modifier.fillParentMaxHeight(0.7f).staggerIn(1))
            }
        }
        if (all.isNotEmpty()) {
            item(key = "search") {
                Row(
                    Modifier
                        .padding(horizontal = 20.dp, vertical = 12.dp)
                        .fillMaxWidth()
                        .heightIn(min = 44.dp)
                        .clip(CircleShape)
                        .background(Palette.tint(0.07f))
                        .border(1.dp, Palette.Hairline, CircleShape)
                        .padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Icon(Icons.Rounded.Search, null, tint = Palette.TextSecondary, modifier = Modifier.size(18.dp))
                    GlassField(
                        value = query,
                        onValueChange = { query = it },
                        placeholder = "Search",
                        modifier = Modifier.weight(1f).padding(vertical = 12.dp),
                        imeAction = ImeAction.Search,
                    )
                }
            }
            item(key = "chips") {
                Row(
                    Modifier
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 20.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    FilterPill("All", selected = !unreadOnly) { unreadOnly = false }
                    FilterPill("Unread", selected = unreadOnly) { unreadOnly = true }
                }
            }
            if (showArchiveEntry) {
                item(key = "archived_entry") {
                    ArchivedEntry(archivedChats.size, Modifier.animateItem()) { showArchived = true }
                }
            }
            if (chats.isEmpty() && hits.isEmpty() && !showArchiveEntry) {
                item(key = "none") {
                    Box(Modifier.fillMaxWidth().padding(top = 48.dp), contentAlignment = Alignment.Center) {
                        Text(
                            if (showArchived && !searching) "No archived chats" else "No chats found",
                            color = Palette.TextSecondary, fontSize = 15.sp,
                        )
                    }
                }
            }
        }
        itemsIndexed(chats, key = { _, c -> c.chatId }) { index, chat ->
            val row = Modifier.animateItem().let { if (index < 8) it.staggerIn(index + 2) else it }
            val pinned = ChatPrefs.isPinned(chat.chatId)
            val muted = ChatPrefs.isMuted(chat.chatId)
            val archived = ChatPrefs.isArchived(chat)
            SwipeRevealRow(
                open = openId == chat.chatId,
                onOpenChange = { openId = if (it) chat.chatId else null },
                onDragStart = { if (openId != chat.chatId) openId = null },
                actionsWidth = 216.dp,
                modifier = row,
                actions = {
                    SwipeAction(Ic.Pin, if (pinned) "Unpin" else "Pin", active = pinned) {
                        if (!ChatPrefs.togglePin(chat.chatId)) {
                            Toast.makeText(context, "You can pin up to ${ChatPrefs.MAX_PINNED} chats", Toast.LENGTH_SHORT).show()
                        }
                        openId = null
                    }
                    SwipeAction(if (muted) Ic.Bell else Ic.BellOff, if (muted) "Unmute" else "Mute", active = muted) {
                        ChatPrefs.toggleMute(chat.chatId)
                        openId = null
                    }
                    SwipeAction(Ic.Archive, if (archived) "Unarchive" else "Archive") {
                        ChatPrefs.toggleArchive(chat)
                        openId = null
                    }
                },
            ) {
                ChatRow(chat, Modifier, pinned = pinned, muted = muted) {
                    if (openId != null) openId = null else onOpenChat(chat.chatId)
                }
            }
        }
        if (hits.isNotEmpty()) {
            item(key = "messages_header") {
                Text(
                    "Messages", color = Palette.TextSecondary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 20.dp, bottom = 4.dp),
                )
            }
            items(hits, key = { "hit_${it.id}" }) { m ->
                val chat = all.firstOrNull { it.chatId == m.chatId }
                if (chat != null) MessageHitRow(chat, m, query.trim()) { onOpenChat(chat.chatId) }
            }
        }
    }
    }
}

@Composable
private fun EmptyChats(onInvite: () -> Unit, modifier: Modifier) {
    Column(
        modifier.fillMaxWidth().padding(horizontal = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Box(
            Modifier.size(84.dp).clip(CircleShape).background(Palette.Glass)
                .border(1.dp, Palette.GlassBorder, CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Rounded.PersonAdd, null, tint = Palette.AccentSoft, modifier = Modifier.size(34.dp))
        }
        Spacer(Modifier.height(20.dp))
        Text("No chats yet", color = Palette.TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        Text(
            "Instants is for the people you know. Invite a friend to start chatting.",
            color = Palette.TextSecondary,
            fontSize = 15.sp,
            lineHeight = 21.sp,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(24.dp))
        PrimaryButton("Invite contacts", Modifier.width(220.dp)) { onInvite() }
    }
}

@Composable
internal fun FilterPill(label: String, selected: Boolean, onClick: () -> Unit) {
    val bg by animateColorAsState(
        if (selected) Palette.Accent else Palette.tint(0.05f), tween(250), label = "pillBg",
    )
    val fg by animateColorAsState(
        if (selected) Color.White else Palette.ChipText, tween(250), label = "pillFg",
    )
    val shape = RoundedCornerShape(18.dp)
    Box(
        Modifier
            .heightIn(min = 36.dp)
            .pressable(0.94f, haptic = true, onClick = onClick)
            .clip(shape)
            .background(bg)
            .border(1.dp, if (selected) Palette.Accent else Palette.GlassBorder, shape)
            .padding(horizontal = 16.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, color = fg, fontSize = 14.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun ChatRow(chat: ChatItem, modifier: Modifier, pinned: Boolean = false, muted: Boolean = false, onClick: () -> Unit) {
    val last = chat.last
    val draft = Drafts.get(chat.chatId)
    val tick = if (last != null) chat.tickFor(last, Session.userId) else null
    Row(
        modifier
            .fillMaxWidth()
            .pressable(0.985f, onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 10.dp)
            .heightIn(min = 44.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        ProfileAvatar(chat.initials, 48.dp, chat.peer?.avatarPath)
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(
                chat.title, color = Palette.TextPrimary, fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
            PreviewLine(last, tick, draft)
        }
        Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
                last?.createdAt?.listLabel() ?: "",
                color = if (chat.unread > 0 && !muted) Palette.AccentSoft else Palette.TextSecondary,
                fontSize = 12.sp,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
                if (muted) LIcon(Ic.BellOff, Palette.TextSecondary, 14.dp)
                if (pinned) LIcon(Ic.Pin, Palette.TextSecondary, 14.dp)
            AnimatedVisibility(
                visible = chat.unread > 0,
                enter = scaleIn(spring(dampingRatio = 0.5f)) + fadeIn(),
                exit = scaleOut() + fadeOut(),
            ) {
                Box(
                    Modifier.heightIn(min = 20.dp).widthIn(min = 20.dp)
                        .clip(CircleShape).background(if (muted) Palette.tint(0.25f) else Palette.Accent).padding(horizontal = 6.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text("${chat.unread}", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                }
            }
            }
        }
    }
}

/** "tick  icon  text": the tick shows my message's state, the icon tells photos, voice notes and documents apart. */
@Composable
private fun PreviewLine(last: Msg?, tickIn: Tick?, draft: String = "") {
    if (draft.isNotBlank()) {
        Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            Text("Draft:", color = Palette.EndCall, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1)
            Text(
                draft.replace('\n', ' '), color = Palette.TextSecondary, fontSize = 14.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false),
            )
        }
        return
    }
    val isCall = last?.kind == "call"
    val tick = if (isCall) null else tickIn
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        if (tick != null) {
            val tickColor by animateColorAsState(
                if (tick == Tick.Read) Palette.AccentSoft else Palette.TextSecondary, tween(300), label = "tickColor",
            )
            AnimatedContent(
                targetState = tick,
                transitionSpec = {
                    (scaleIn(spring(dampingRatio = 0.5f), initialScale = 0.4f) + fadeIn(tween(160))) togetherWith
                        (scaleOut(targetScale = 0.6f) + fadeOut(tween(120)))
                },
                label = "tick",
            ) { t ->
                LIcon(if (t == Tick.Sent) Ic.Sent else Ic.Delivered, tickColor, 17.dp)
            }
        }
        val typeIcon = when (last?.kind) {
            "voice" -> Ic.Mic
            "image" -> Ic.Photo
            "file" -> Ic.Document
            "call" -> Ic.Calls
            else -> null
        }
        if (typeIcon != null) LIcon(typeIcon, Palette.TextSecondary, 16.dp)
        Text(
            if (last != null && isCall) last.callLabel(app.instants.data.Session.userId) else last?.preview ?: "Say hi", color = Palette.TextSecondary, fontSize = 14.sp,
            maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false),
        )
    }
}

/** "Archived  3" entry at the top of the list. */
@Composable
private fun ArchivedEntry(count: Int, modifier: Modifier, onClick: () -> Unit) {
    Row(
        modifier.fillMaxWidth().pressable(0.985f, onClick = onClick).padding(horizontal = 20.dp, vertical = 10.dp).heightIn(min = 44.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Box(Modifier.size(48.dp), contentAlignment = Alignment.Center) { LIcon(Ic.Archive, Palette.TextSecondary, 22.dp) }
        Text("Archived", color = Palette.TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
        Text("$count", color = Palette.TextSecondary, fontSize = 14.sp)
    }
}

/** A message found by search: who it is with, a snippet with the match highlighted, and when. */
@Composable
private fun MessageHitRow(chat: ChatItem, m: Msg, query: String, onClick: () -> Unit) {
    val text = (if (m.kind == "file") m.attachmentName.orEmpty().ifBlank { m.body } else m.body).replace('\n', ' ')
    val at = text.indexOf(query, ignoreCase = true).coerceAtLeast(0)
    val start = (at - 24).coerceAtLeast(0)
    val shown = (if (start > 0) "…" else "") + text.substring(start)
    val matchAt = shown.indexOf(query, ignoreCase = true)
    val snippet = buildAnnotatedString {
        if (matchAt < 0) {
            append(shown)
        } else {
            append(shown.substring(0, matchAt))
            withStyle(SpanStyle(color = Palette.AccentSoft, fontWeight = FontWeight.SemiBold)) {
                append(shown.substring(matchAt, matchAt + query.length))
            }
            append(shown.substring(matchAt + query.length))
        }
    }
    Row(
        Modifier.fillMaxWidth().pressable(0.985f, onClick = onClick).padding(horizontal = 20.dp, vertical = 10.dp).heightIn(min = 44.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        ProfileAvatar(chat.initials, 40.dp, chat.peer?.avatarPath)
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(chat.title, color = Palette.TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(snippet, color = Palette.TextSecondary, fontSize = 14.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
        Text(m.createdAt.listLabel(), color = Palette.TextSecondary, fontSize = 12.sp)
    }
}
