package app.instants.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import app.instants.data.Api
import app.instants.data.Session
import app.instants.data.StatusStore
import app.instants.data.Store
import app.instants.ui.screens.AuthScreen
import app.instants.ui.screens.BlockedScreen
import app.instants.ui.screens.ChatScreen
import app.instants.ui.screens.CloseFriendsScreen
import app.instants.ui.screens.EditProfileScreen
import app.instants.ui.screens.InCallScreen
import app.instants.ui.screens.MainShell
import app.instants.ui.screens.StatusComposerScreen
import app.instants.ui.screens.StatusViewerScreen
import app.instants.ui.theme.Palette

@Composable
fun AppNav() {
    val nav = rememberNavController()
    val ease = FastOutSlowInEasing
    val start = remember { if (Session.userId != null) "main" else "auth" }

    NavHost(
        navController = nav,
        startDestination = start,
        modifier = Modifier.fillMaxSize().background(Palette.Background),
        enterTransition = { slideInHorizontally(tween(380, easing = ease)) { it / 3 } + fadeIn(tween(300)) },
        exitTransition = { slideOutHorizontally(tween(380, easing = ease)) { -it / 6 } + fadeOut(tween(250)) },
        popEnterTransition = { slideInHorizontally(tween(380, easing = ease)) { -it / 6 } + fadeIn(tween(300)) },
        popExitTransition = { slideOutHorizontally(tween(380, easing = ease)) { it / 3 } + fadeOut(tween(250)) },
    ) {
        composable(
            route = "auth",
            enterTransition = { fadeIn(tween(300)) },
            exitTransition = { fadeOut(tween(300)) },
        ) {
            AuthScreen(onDone = {
                nav.navigate("main") { popUpTo("auth") { inclusive = true } }
            })
        }
        composable(
            route = "main",
            enterTransition = { fadeIn(tween(300)) },
            popEnterTransition = { slideInHorizontally(tween(380, easing = ease)) { -it / 6 } + fadeIn(tween(300)) },
        ) {
            MainShell(
                onOpenChat = { nav.navigate("chat/$it") },
                onNavigate = { nav.navigate(it) },
                onSignOut = {
                    Api.signOut()
                    Store.clear()
                    StatusStore.clear()
                    nav.navigate("auth") { popUpTo("main") { inclusive = true } }
                },
            )
        }
        composable(
            route = "chat/{id}",
            arguments = listOf(navArgument("id") { type = NavType.StringType }),
        ) { entry ->
            val id = entry.arguments?.getString("id") ?: return@composable
            ChatScreen(
                chatId = id,
                onBack = { nav.popBackStack() },
                onCall = { name, initials ->
                    Store.callTarget = name to initials
                    nav.navigate("call")
                },
            )
        }
        composable("statusAdd") { StatusComposerScreen(onBack = { nav.popBackStack() }) }
        composable(
            route = "status/{id}",
            arguments = listOf(navArgument("id") { type = NavType.StringType }),
            enterTransition = { fadeIn(tween(250)) },
            exitTransition = { fadeOut(tween(200)) },
            popEnterTransition = { fadeIn(tween(200)) },
            popExitTransition = { fadeOut(tween(200)) },
        ) { entry ->
            val id = entry.arguments?.getString("id") ?: return@composable
            StatusViewerScreen(
                userId = id,
                // The viewer can ask to close twice (timer end + tap); only pop while it is the current screen.
                onClose = {
                    if (nav.currentBackStackEntry?.destination?.route == "status/{id}") nav.popBackStack()
                },
            )
        }
        composable("editProfile") { EditProfileScreen(onBack = { nav.popBackStack() }) }
        composable("closeFriends") { CloseFriendsScreen(onBack = { nav.popBackStack() }) }
        composable("blocked") { BlockedScreen(onBack = { nav.popBackStack() }) }
        composable(
            route = "call",
            enterTransition = { slideInVertically(tween(450, easing = ease)) { it / 6 } + fadeIn(tween(400)) },
            exitTransition = { fadeOut(tween(250)) },
            popEnterTransition = { fadeIn(tween(300)) },
            popExitTransition = { slideOutVertically(tween(350, easing = ease)) { it / 6 } + fadeOut(tween(300)) },
        ) {
            val target = Store.callTarget ?: ("" to "")
            InCallScreen(name = target.first, initials = target.second, onEnd = { nav.popBackStack() })
        }
    }
}
