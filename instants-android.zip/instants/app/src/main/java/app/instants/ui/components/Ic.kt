package app.instants.ui.components

import androidx.compose.foundation.layout.size
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import app.instants.R

/** The app's outline icon set (Lucide, 24x24, 2px round stroke) as vector drawables in res/drawable. */
object Ic {
    val Chats = R.drawable.ic_message_circle_text
    val Spotlight = R.drawable.ic_circle_fading_plus
    val Calls = R.drawable.ic_phone
    val Settings = R.drawable.ic_settings
    val Plus = R.drawable.ic_plus
    val Photo = R.drawable.ic_image
    val Document = R.drawable.ic_file
    val Mic = R.drawable.ic_mic
    val Sent = R.drawable.ic_check
    val Delivered = R.drawable.ic_check_check
    val Read = R.drawable.ic_check_check
    val Reply = R.drawable.ic_reply
    val Forward = R.drawable.ic_forward
    val Copy = R.drawable.ic_copy
    val Info = R.drawable.ic_info
    val Trash = R.drawable.ic_trash_2
    val Ban = R.drawable.ic_ban
    val Eye = R.drawable.ic_eye
    val X = R.drawable.ic_x
    val Pin = R.drawable.ic_pin
    val Bell = R.drawable.ic_bell
    val BellOff = R.drawable.ic_bell_off
    val Archive = R.drawable.ic_archive
    val ChevronLeft = R.drawable.ic_chevron_left
}

@Composable
fun LIcon(res: Int, tint: Color, size: Dp = 22.dp, modifier: Modifier = Modifier, description: String? = null) {
    Icon(painterResource(res), description, tint = tint, modifier = modifier.size(size))
}
