package app.instants.ui.components

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.instants.data.ChatItem
import app.instants.data.Msg
import app.instants.data.clock
import app.instants.data.detailLabel
import app.instants.ui.theme.Palette
import dev.chrisbanes.haze.HazeState
import dev.chrisbanes.haze.hazeChild
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** What the long-press menu can do with a message. The order here is the order on screen. */
enum class MessageAction { Reply, Forward, Copy, Info, Report, Delete }

/** The message that was long-pressed and where its bubble is on screen (in root coordinates). */
class MenuTarget(val msg: Msg, val mine: Boolean, val bounds: Rect)

private val BubbleShape = RoundedCornerShape(20.dp)
private val CardShape = RoundedCornerShape(28.dp)

/**
 * Long-press menu, WhatsApp iOS style: everything behind blurs and dims, the pressed bubble lifts up (moving
 * if it needs room), and a card of actions slides in under it. [haze] must be the HazeState of the layer
 * that holds the chat, so that layer is what gets blurred. [bubble] draws a copy of the message bubble.
 */
@Composable
fun MessageMenuOverlay(
    target: MenuTarget,
    haze: HazeState,
    actions: List<MessageAction>,
    onAction: (MessageAction) -> Unit,
    onDismiss: () -> Unit,
    bubble: @Composable () -> Unit,
) {
    val scope = rememberCoroutineScope()
    val density = LocalDensity.current
    var entered by remember { mutableStateOf(false) }
    var origin by remember { mutableStateOf(Offset.Zero) }
    LaunchedEffect(Unit) { entered = true }

    /** Play the closing animation, then do what was asked. */
    fun close(then: () -> Unit) {
        if (!entered) return
        entered = false
        scope.launch {
            delay(200)
            then()
        }
    }
    BackHandler { close(onDismiss) }

    val p by animateFloatAsState(if (entered) 1f else 0f, tween(220, easing = FastOutSlowInEasing), label = "menuIn")
    val topInset = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val bottomInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()

    BoxWithConstraints(Modifier.fillMaxSize().onGloballyPositioned { origin = it.positionInRoot() }) {
        // Blur and dim everything behind; a tap anywhere outside closes the menu
        Box(
            Modifier
                .fillMaxSize()
                .graphicsLayer { alpha = p }
                .hazeChild(state = haze) {
                    backgroundColor = Palette.Background
                    blurRadius = 26.dp
                }
                .background(Color.Black.copy(alpha = if (Palette.dark) 0.42f else 0.26f))
                .pointerInput(Unit) { detectTapGestures { close(onDismiss) } },
        )

        // Where the bubble is now, and where it needs to be so bubble + card both fit on screen
        val bLeft = with(density) { (target.bounds.left - origin.x).toDp() }
        val bTop = with(density) { (target.bounds.top - origin.y).toDp() }
        val bw = with(density) { target.bounds.width.toDp() }
        val bh = with(density) { target.bounds.height.toDp() }
        val menuW = 232.dp
        val menuH = 40.dp + 52.dp * actions.size + 8.dp
        val gap = 10.dp
        val minTop = topInset + 12.dp
        val maxBottom = maxHeight - bottomInset - 12.dp
        var ty = bTop
        if (ty + bh + gap + menuH > maxBottom) ty = maxBottom - (bh + gap + menuH)
        if (ty < minTop) ty = minTop
        val y by animateDpAsState(if (entered) ty else bTop, tween(300, easing = FastOutSlowInEasing), label = "menuY")

        val side = if (target.mine) 1f else 0f
        val lift = 1f + 0.035f * p
        Box(
            Modifier
                .offset(x = bLeft, y = y)
                .graphicsLayer {
                    scaleX = lift
                    scaleY = lift
                    transformOrigin = TransformOrigin(side, 0f)
                }
                .shadow(20.dp * p, BubbleShape, clip = false, ambientColor = Color(0x33000000), spotColor = Color(0x55000000)),
        ) { bubble() }

        val menuX = (if (target.mine) bLeft + bw - menuW else bLeft).coerceIn(12.dp, maxWidth - menuW - 12.dp)
        val menuY = (y + bh + gap).coerceAtMost(maxBottom - menuH)
        Column(
            Modifier
                .offset(x = menuX, y = menuY)
                .width(menuW)
                .graphicsLayer {
                    alpha = p
                    val s = 0.88f + 0.12f * p
                    scaleX = s
                    scaleY = s
                    transformOrigin = TransformOrigin(side, 0f)
                }
                .shadow(16.dp, CardShape, clip = false, ambientColor = Color(0x33000000), spotColor = Color(0x44000000))
                .clip(CardShape)
                .background(Palette.Sheet)
                .border(1.dp, Palette.GlassBorder, CardShape)
                .padding(bottom = 8.dp),
        ) {
            Text(
                target.msg.createdAt.clock(),
                color = Palette.TextSecondary,
                fontSize = 13.sp,
                modifier = Modifier.padding(start = 20.dp, top = 16.dp, bottom = 6.dp),
            )
            actions.forEach { a -> MenuRow(a) { close { onAction(a) } } }
        }
    }
}

@Composable
private fun MenuRow(action: MessageAction, onClick: () -> Unit) {
    val (icon, label) = when (action) {
        MessageAction.Reply -> Ic.Reply to "Reply"
        MessageAction.Forward -> Ic.Forward to "Forward"
        MessageAction.Copy -> Ic.Copy to "Copy"
        MessageAction.Info -> Ic.Info to "Info"
        MessageAction.Report -> Ic.Ban to "Report"
        MessageAction.Delete -> Ic.Trash to "Delete"
    }
    val tint = if (action == MessageAction.Delete || action == MessageAction.Report) Palette.EndCall else Palette.TextPrimary
    Row(
        Modifier
            .fillMaxWidth()
            .height(52.dp)
            .pressable(0.98f, haptic = true, onClick = onClick)
            .padding(horizontal = 20.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        LIcon(icon, tint, 22.dp)
        Text(label, color = tint, fontSize = 17.sp)
    }
}

// ---------------------------------------------------------------------------------------------
// Delete
// ---------------------------------------------------------------------------------------------

@Composable
internal fun SheetAction(text: String, destructive: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .fillMaxWidth()
            .height(52.dp)
            .pressable(0.97f, haptic = true, onClick = onClick)
            .clip(CircleShape)
            .background(Palette.Glass)
            .border(1.dp, Palette.GlassBorder, CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text,
            color = if (destructive) Palette.EndCall else Palette.TextPrimary,
            fontSize = 16.sp,
            fontWeight = FontWeight.Medium,
        )
    }
}

/** "Delete for everyone" (only my own messages) and "Delete for me". */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DeleteSheet(
    canDeleteForEveryone: Boolean,
    onDeleteForMe: () -> Unit,
    onDeleteForEveryone: () -> Unit,
    onDismiss: () -> Unit,
) {
    val sheetState = rememberModalBottomSheetState()
    val scope = rememberCoroutineScope()
    fun hideThen(block: () -> Unit) {
        scope.launch { sheetState.hide() }.invokeOnCompletion {
            block()
            onDismiss()
        }
    }
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = Palette.Sheet,
        contentColor = Palette.TextPrimary,
    ) {
        Column(
            Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 24.dp).padding(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text("Delete message?", color = Palette.TextPrimary, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
            Text(
                if (canDeleteForEveryone) "Delete for everyone removes it for both of you. Delete for me only removes it here."
                else "This only removes the message from your phone. The other person still has it.",
                color = Palette.TextSecondary,
                fontSize = 13.sp,
                lineHeight = 18.sp,
                modifier = Modifier.padding(bottom = 4.dp),
            )
            if (canDeleteForEveryone) SheetAction("Delete for everyone", destructive = true) { hideThen(onDeleteForEveryone) }
            SheetAction("Delete for me", destructive = true) { hideThen(onDeleteForMe) }
            SheetAction("Cancel", destructive = false) { hideThen { } }
        }
    }
}

/** Report a message or a person: pick a reason, add a note if you like, and block them at the same time if you want. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportSheet(
    who: String,
    onSend: suspend (reason: String, details: String, alsoBlock: Boolean) -> Unit,
    onDismiss: () -> Unit,
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val scope = rememberCoroutineScope()
    var reason by remember { mutableStateOf<String?>(null) }
    var details by remember { mutableStateOf("") }
    var alsoBlock by remember { mutableStateOf(false) }
    var sending by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val reasons = listOf(
        "spam" to "Spam",
        "harassment" to "Harassment or bullying",
        "inappropriate" to "Inappropriate content",
        "other" to "Something else",
    )
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = Palette.Sheet,
        contentColor = Palette.TextPrimary,
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp)
                .padding(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Text("Report $who", color = Palette.TextPrimary, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
            Text(
                "Your report is private: $who won't be told. We review reports and can remove content or accounts that break the rules.",
                color = Palette.TextSecondary, fontSize = 13.sp, lineHeight = 18.sp,
            )
            reasons.forEach { (key, label) ->
                Row(
                    Modifier.fillMaxWidth().heightIn(min = 48.dp).pressable(0.99f, onClick = { reason = key }),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    androidx.compose.material3.RadioButton(
                        selected = reason == key,
                        onClick = null,
                        colors = androidx.compose.material3.RadioButtonDefaults.colors(
                            selectedColor = Palette.AccentSoft,
                            unselectedColor = Palette.TextSecondary,
                        ),
                    )
                    Spacer(Modifier.width(12.dp))
                    Text(label, color = Palette.TextPrimary, fontSize = 16.sp)
                }
            }
            androidx.compose.material3.OutlinedTextField(
                value = details,
                onValueChange = { if (it.length <= 1000) details = it },
                placeholder = { Text("Add details (optional)", color = Palette.TextSecondary) },
                minLines = 2,
                maxLines = 4,
                modifier = Modifier.fillMaxWidth(),
                colors = androidx.compose.material3.OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Palette.TextPrimary,
                    unfocusedTextColor = Palette.TextPrimary,
                    cursorColor = Palette.AccentSoft,
                    focusedBorderColor = Palette.AccentSoft,
                    unfocusedBorderColor = Palette.GlassBorder,
                ),
            )
            Row(
                Modifier.fillMaxWidth().heightIn(min = 48.dp).pressable(0.99f, onClick = { alsoBlock = !alsoBlock }),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                androidx.compose.material3.Checkbox(
                    checked = alsoBlock,
                    onCheckedChange = null,
                    colors = androidx.compose.material3.CheckboxDefaults.colors(
                        checkedColor = Palette.AccentSoft,
                        uncheckedColor = Palette.TextSecondary,
                    ),
                )
                Spacer(Modifier.width(12.dp))
                Text("Also block $who", color = Palette.TextPrimary, fontSize = 16.sp)
            }
            error?.let { Text(it, color = Palette.EndCall, fontSize = 13.sp) }
            SheetAction(
                when {
                    sending -> "Sending…"
                    reason == null -> "Choose a reason"
                    else -> "Send report"
                },
                destructive = true,
            ) {
                val chosen = reason
                if (!sending && chosen != null) {
                    sending = true
                    error = null
                    scope.launch {
                        try {
                            onSend(chosen, details.trim(), alsoBlock)
                            sheetState.hide()
                            onDismiss()
                        } catch (e: kotlinx.coroutines.CancellationException) {
                            throw e
                        } catch (e: Exception) {
                            error = e.message?.takeIf { it.isNotBlank() } ?: "Couldn't send the report. Try again."
                            sending = false
                        }
                    }
                }
            }
            SheetAction("Cancel", destructive = false) { scope.launch { sheetState.hide() }.invokeOnCompletion { onDismiss() } }
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Info
// ---------------------------------------------------------------------------------------------

/** When a message of mine was sent, delivered and read. [bubble] draws a copy of the message on top. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InfoSheet(msg: Msg, onDismiss: () -> Unit, bubble: @Composable () -> Unit) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val shape = RoundedCornerShape(20.dp)
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = Palette.Sheet,
        contentColor = Palette.TextPrimary,
    ) {
        Column(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 24.dp).padding(bottom = 24.dp)) {
            Text("Message info", color = Palette.TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(16.dp))
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.CenterEnd) { bubble() }
            Spacer(Modifier.height(20.dp))
            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(shape)
                    .background(Palette.tint(0.06f))
                    .border(1.dp, Palette.Hairline, shape),
            ) {
                InfoRow(Ic.Read, Palette.AccentSoft, "Read", msg.readAt?.detailLabel())
                InfoDivider()
                InfoRow(Ic.Delivered, Palette.TextSecondary, "Delivered", msg.deliveredAt?.detailLabel())
                InfoDivider()
                InfoRow(Ic.Sent, Palette.TextSecondary, "Sent", msg.createdAt.detailLabel())
            }
        }
    }
}

@Composable
private fun InfoDivider() {
    Box(Modifier.fillMaxWidth().height(1.dp).background(Palette.tint(0.08f)))
}

@Composable
private fun InfoRow(icon: Int, tint: Color, label: String, value: String?) {
    Row(
        Modifier.fillMaxWidth().heightIn(min = 54.dp).padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        LIcon(icon, if (value != null) tint else Palette.TextSecondary.copy(alpha = 0.5f), 20.dp)
        Text(label, color = Palette.TextPrimary, fontSize = 16.sp, modifier = Modifier.weight(1f))
        Text(value ?: "—", color = Palette.TextSecondary, fontSize = 14.sp)
    }
}

// ---------------------------------------------------------------------------------------------
// Forward
// ---------------------------------------------------------------------------------------------

/** Pick one or more chats to send a message on to. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ForwardSheet(chats: List<ChatItem>, onSend: (List<ChatItem>) -> Unit, onDismiss: () -> Unit) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val scope = rememberCoroutineScope()
    val selected = remember { mutableStateListOf<String>() }
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = Palette.Sheet,
        contentColor = Palette.TextPrimary,
    ) {
        Column(Modifier.fillMaxWidth().navigationBarsPadding()) {
            Text(
                "Forward to",
                color = Palette.TextPrimary,
                fontSize = 20.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(horizontal = 24.dp).padding(bottom = 8.dp),
            )
            if (chats.isEmpty()) {
                Text(
                    "No chats to forward to yet.",
                    color = Palette.TextSecondary,
                    fontSize = 15.sp,
                    modifier = Modifier.padding(horizontal = 24.dp, vertical = 24.dp),
                )
            }
            LazyColumn(Modifier.heightIn(max = 380.dp)) {
                items(chats, key = { it.chatId }) { c ->
                    val on = c.chatId in selected
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .pressable(0.985f, haptic = true) {
                                if (on) selected.remove(c.chatId) else selected.add(c.chatId)
                            }
                            .padding(horizontal = 24.dp, vertical = 8.dp)
                            .heightIn(min = 48.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        ProfileAvatar(c.initials, 44.dp, c.peer?.avatarPath)
                        Text(
                            c.title, color = Palette.TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Medium,
                            maxLines = 1, modifier = Modifier.weight(1f),
                        )
                        Box(
                            Modifier
                                .size(24.dp)
                                .clip(CircleShape)
                                .background(if (on) Palette.Accent else Color.Transparent)
                                .border(1.5.dp, if (on) Palette.Accent else Palette.GlassBorder, CircleShape),
                            contentAlignment = Alignment.Center,
                        ) {
                            if (on) LIcon(Ic.Sent, Color.White, 15.dp)
                        }
                    }
                }
            }
            Box(Modifier.padding(horizontal = 24.dp, vertical = 14.dp)) {
                PrimaryButton(
                    if (selected.isEmpty()) "Choose a chat" else "Send to ${selected.size}",
                    enabled = selected.isNotEmpty(),
                ) {
                    val picked = chats.filter { it.chatId in selected }
                    scope.launch { sheetState.hide() }.invokeOnCompletion {
                        onSend(picked)
                        onDismiss()
                    }
                }
            }
        }
    }
}
