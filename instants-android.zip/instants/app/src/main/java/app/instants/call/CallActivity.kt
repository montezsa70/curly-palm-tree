package app.instants.call

import android.Manifest
import android.content.Context
import android.content.Intent
import android.graphics.Color as AndroidColor
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.core.view.WindowCompat
import app.instants.ui.screens.InCallScreen
import app.instants.ui.screens.IncomingCallScreen
import app.instants.ui.theme.InstantsTheme
import app.instants.ui.theme.Palette

/**
 * The call screen, as its own activity so it can sit over the lock screen like a phone call
 * (it does not go through the app lock: it only ever shows the call).
 */
class CallActivity : ComponentActivity() {
    private var answerRequested by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setShowWhenLocked(true)
        setTurnScreenOn(true)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.light(AndroidColor.TRANSPARENT, AndroidColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.light(AndroidColor.TRANSPARENT, AndroidColor.TRANSPARENT),
        )
        readIntent(intent)
        setContent {
            InstantsTheme {
                val dark = Palette.dark
                SideEffect {
                    val controller = WindowCompat.getInsetsController(window, window.decorView)
                    controller.isAppearanceLightStatusBars = !dark
                    controller.isAppearanceLightNavigationBars = !dark
                }
                CallRoot(
                    answerRequested = answerRequested,
                    onAnswerHandled = { answerRequested = false },
                    onFinish = { finish() },
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        readIntent(intent)
    }

    private fun readIntent(i: Intent?) {
        if (i?.action == ACTION_ANSWER) answerRequested = true
    }

    companion object {
        const val ACTION_ANSWER = "app.instants.call.ANSWER"
    }
}

@Composable
private fun CallRoot(answerRequested: Boolean, onAnswerHandled: () -> Unit, onFinish: () -> Unit) {
    val context: Context = LocalContext.current
    val phase = CallManager.phase

    val askMic = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) CallManager.accept() else CallManager.decline()
    }
    val askProjection = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val data = result.data
        if (result.resultCode == android.app.Activity.RESULT_OK && data != null) CallManager.startScreenShare(data)
    }

    fun answer() {
        if (hasMicPermission(context)) CallManager.accept() else askMic.launch(Manifest.permission.RECORD_AUDIO)
    }

    // "Answer" on the notification opens this screen with the request attached.
    LaunchedEffect(answerRequested, phase) {
        if (answerRequested && phase == CallPhase.Incoming) {
            onAnswerHandled()
            answer()
        }
    }
    // Nothing (left) to show: close.
    LaunchedEffect(phase) {
        if (phase == CallPhase.Idle) onFinish()
    }

    when (phase) {
        CallPhase.Incoming -> IncomingCallScreen(onAccept = { answer() }, onDecline = { CallManager.decline() })
        CallPhase.Idle -> Unit
        else -> InCallScreen(
            onShareRequest = {
                val manager = context.getSystemService(MediaProjectionManager::class.java)
                askProjection.launch(manager.createScreenCaptureIntent())
            },
        )
    }
}
