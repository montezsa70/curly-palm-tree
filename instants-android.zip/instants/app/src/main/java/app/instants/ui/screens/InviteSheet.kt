package app.instants.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.instants.data.Repo
import app.instants.data.Store
import app.instants.ui.components.GlassField
import app.instants.ui.components.PrimaryButton
import app.instants.ui.components.SoftButton
import app.instants.ui.theme.Palette
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InviteSheet(onDismiss: () -> Unit, onJoined: (String) -> Unit) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    var code by remember { mutableStateOf<String?>(null) }
    var creating by remember { mutableStateOf(false) }
    var joinCode by remember { mutableStateOf("") }
    var joining by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    fun close(then: () -> Unit = {}) {
        scope.launch { sheetState.hide() }.invokeOnCompletion {
            onDismiss()
            then()
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = Palette.Sheet,
        contentColor = Palette.TextPrimary,
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Text("Invite contacts", color = Palette.TextPrimary, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
            Text(
                "Instants is private. People can only connect with you through an invite code.",
                color = Palette.TextSecondary, fontSize = 14.sp,
            )

            val c = code
            if (c == null) {
                PrimaryButton(if (creating) "Creating…" else "Create invite code", enabled = !creating) {
                    scope.launch {
                        creating = true
                        error = null
                        try {
                            code = Repo.createInvite()
                        } catch (e: CancellationException) {
                            throw e
                        } catch (e: Exception) {
                            error = e.message ?: "Couldn’t create the invite."
                        }
                        creating = false
                    }
                }
            } else {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(20.dp))
                        .background(Palette.tint(0.07f))
                        .border(1.dp, Palette.Hairline, RoundedCornerShape(20.dp))
                        .padding(vertical = 18.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        c, color = Palette.TextPrimary, fontSize = 26.sp,
                        fontFamily = FontFamily.Monospace, letterSpacing = 3.sp, textAlign = TextAlign.Center,
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    SoftButton("Copy", Modifier.weight(1f)) {
                        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        cm.setPrimaryClip(ClipData.newPlainText("invite", c))
                        Toast.makeText(context, "Copied", Toast.LENGTH_SHORT).show()
                    }
                    SoftButton("Share", Modifier.weight(1f)) {
                        val send = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(
                                Intent.EXTRA_TEXT,
                                "Join me on Instants. Open the app, tap + and enter my invite code: $c",
                            )
                        }
                        context.startActivity(Intent.createChooser(send, null))
                    }
                }
                Text("Works once and expires in 7 days.", color = Palette.TextSecondary, fontSize = 12.sp)
            }

            Box(Modifier.fillMaxWidth().height(1.dp).background(Palette.tint(0.08f)))

            Text("Have a code?", color = Palette.TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .clip(CircleShape)
                    .background(Palette.tint(0.07f))
                    .border(1.dp, Palette.Hairline, CircleShape)
                    .padding(horizontal = 20.dp),
                contentAlignment = Alignment.CenterStart,
            ) {
                GlassField(joinCode, { joinCode = it }, "Enter invite code", Modifier.fillMaxWidth())
            }
            PrimaryButton(
                if (joining) "Joining…" else "Join",
                enabled = joinCode.isNotBlank() && !joining,
            ) {
                scope.launch {
                    joining = true
                    error = null
                    try {
                        val chatId = Repo.redeemInvite(joinCode)
                        Store.refreshChats()
                        close { onJoined(chatId) }
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        error = e.message ?: "That code didn’t work."
                    }
                    joining = false
                }
            }
            error?.let { Text(it, color = Palette.Error, fontSize = 13.sp) }
        }
    }
}
