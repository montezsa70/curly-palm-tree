package app.instants.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Call
import androidx.compose.material.icons.rounded.ChatBubbleOutline
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.instants.ui.components.GlassField
import app.instants.ui.components.GlassIconButton
import app.instants.ui.components.PrimaryButton
import app.instants.ui.components.glass
import app.instants.ui.components.pressable
import app.instants.ui.theme.Palette
import dev.chrisbanes.haze.HazeState
import dev.chrisbanes.haze.haze
import kotlinx.coroutines.launch

enum class Tab(val label: String, val icon: ImageVector) {
    Chats("Chats", Icons.Rounded.ChatBubbleOutline),
    Calls("Calls", Icons.Rounded.Call),
    Settings("Settings", Icons.Rounded.Settings),
}

@Composable
fun MainShell(onOpenChat: (String) -> Unit, onSignOut: () -> Unit) {
    var tab by rememberSaveable { mutableStateOf(Tab.Chats) }
    var showInvite by remember { mutableStateOf(false) }
    val haze = remember { HazeState() }
    val navBottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val tabBarSpace = navBottom + 68.dp + 20.dp + 24.dp

    Box(Modifier.fillMaxSize().background(Palette.Charcoal)) {
        AnimatedContent(
            targetState = tab,
            modifier = Modifier.fillMaxSize().haze(haze),
            transitionSpec = {
                val dir = if (targetState.ordinal > initialState.ordinal) 1 else -1
                (fadeIn(tween(280, delayMillis = 60)) +
                    slideInHorizontally(tween(340, easing = FastOutSlowInEasing)) { dir * it / 10 }) togetherWith
                    (fadeOut(tween(160)) +
                        slideOutHorizontally(tween(300, easing = FastOutSlowInEasing)) { -dir * it / 10 })
            },
            label = "tabs",
        ) { current ->
            when (current) {
                Tab.Chats -> ChatsTab(onOpenChat, onInvite = { showInvite = true }, bottomPadding = tabBarSpace)
                Tab.Calls -> CallsTab(tabBarSpace)
                Tab.Settings -> SettingsTab(onSignOut, tabBarSpace)
            }
        }

        AnimatedVisibility(
            visible = tab == Tab.Chats,
            enter = scaleIn(spring(dampingRatio = 0.55f)) + fadeIn(),
            exit = scaleOut() + fadeOut(),
            modifier = Modifier.align(Alignment.BottomEnd).padding(end = 20.dp, bottom = navBottom + 20.dp + 68.dp + 16.dp),
        ) {
            GlassIconButton(
                icon = Icons.Rounded.Add,
                description = "Invite contacts",
                size = 56.dp,
                solid = Palette.Accent,
                tint = Color.White,
                onClick = { showInvite = true },
            )
        }

        Row(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 12.dp)
                .padding(bottom = 20.dp)
                .height(68.dp)
                .glass(haze, RoundedCornerShape(30.dp))
                .padding(6.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            Tab.entries.forEach { t ->
                TabItem(t, selected = tab == t) { tab = t }
            }
        }
    }

    if (showInvite) InviteSheet(onDismiss = { showInvite = false }, onJoined = onOpenChat)
}

@Composable
private fun RowScope.TabItem(tab: Tab, selected: Boolean, onClick: () -> Unit) {
    val bg by animateColorAsState(
        if (selected) Color.White.copy(alpha = 0.08f) else Color.Transparent, tween(250), label = "tabBg",
    )
    val tint by animateColorAsState(
        if (selected) Palette.AccentSoft else Palette.TextSecondary, tween(250), label = "tabTint",
    )
    val bounce by animateFloatAsState(
        targetValue = if (selected) 1.08f else 1f,
        animationSpec = spring(dampingRatio = 0.4f, stiffness = 400f),
        label = "tabBounce",
    )
    val feedback = LocalHapticFeedback.current
    Column(
        Modifier
            .weight(1f)
            .fillMaxHeight()
            .pressable(0.94f) {
                if (!selected) feedback.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onClick()
            }
            .clip(RoundedCornerShape(24.dp))
            .background(bg),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(
            tab.icon, tab.label, tint = tint,
            modifier = Modifier.size(22.dp).graphicsLayer { scaleX = bounce; scaleY = bounce },
        )
        Spacer(Modifier.height(3.dp))
        Text(tab.label, color = tint, fontSize = 11.sp, fontWeight = FontWeight.Medium)
    }
}
