package app.instants.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import app.instants.push.Push
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.instants.data.Store
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.width
import app.instants.data.StatusStore
import app.instants.ui.components.Ic
import app.instants.ui.components.LIcon
import androidx.compose.ui.unit.Dp
import kotlinx.coroutines.delay
import app.instants.ui.components.GlassField
import app.instants.ui.components.GlassIconButton
import app.instants.ui.components.PrimaryButton
import app.instants.ui.components.frostedGlass
import app.instants.ui.components.glass
import app.instants.ui.components.pressable
import app.instants.ui.theme.Palette
import dev.chrisbanes.haze.HazeState
import dev.chrisbanes.haze.haze
import kotlinx.coroutines.launch

enum class Tab(val label: String, val icon: Int) {
    Chats("Chats", Ic.Chats),
    Spotlight("Spotlight", Ic.Spotlight),
    Calls("Calls", Ic.Calls),
    Settings("Settings", Ic.Settings),
}

private val NavItemWidth = 52.dp
private val NavItemHeight = 44.dp
private val NavGap = 2.dp
private val NavPad = 6.dp
private val BarHeight = NavItemHeight + NavPad * 2   // 56dp, the (+) button matches it

@Composable
fun MainShell(onOpenChat: (String) -> Unit, onSignOut: () -> Unit, onNavigate: (String) -> Unit) {
    var tab by rememberSaveable { mutableStateOf(Tab.Chats) }
    var showInvite by remember { mutableStateOf(false) }
    var showNewCall by remember { mutableStateOf(false) }
    val haze = remember { HazeState() }
    val navBottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    LaunchedEffect(Unit) {
        Store.refreshMe()
        Store.refreshSocial()
    }
    // Live updates: new messages, receipts and new chats arrive over one socket instead of polling
    LaunchedEffect(Unit) { app.instants.data.Realtime.start() }
    // Statuses live on the Spotlight tab, but keep them fresh (and the unseen dot accurate) from anywhere
    LaunchedEffect(Unit) {
        while (true) {
            StatusStore.refresh()
            delay(30_000)
        }
    }

    // Message alerts: link this phone to the account and ask for permission to show notifications
    val context = LocalContext.current
    val askNotifications = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        Push.sync()
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            askNotifications.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }
    val tabBarSpace = navBottom + BarHeight + 20.dp + 24.dp
    val unseenSpotlight = StatusStore.groups.any { StatusStore.hasUnseen(it) }

    Box(Modifier.fillMaxSize().background(Palette.Background)) {
        AnimatedContent(
            targetState = tab,
            modifier = Modifier.fillMaxSize().haze(haze),
            transitionSpec = {
                val dir = if (targetState.ordinal > initialState.ordinal) 1 else -1
                (fadeIn(tween(280, delayMillis = 60)) +
                    slideInHorizontally(tween(340, easing = FastOutSlowInEasing)) { dir * it / 10 }) togetherWith
                    (fadeOut(tween(160)) +
                        slideOutHorizontally(tween(300, easing = FastOutSlowInEasing)) { -dir * it / 10 })
            },
            label = "tabs",
        ) { current ->
            when (current) {
                Tab.Chats -> ChatsTab(onOpenChat, onInvite = { showInvite = true }, bottomPadding = tabBarSpace)
                Tab.Spotlight -> SpotlightTab(
                    bottomPadding = tabBarSpace,
                    onOpenStatus = { onNavigate("status/$it") },
                    onAddStatus = { onNavigate("statusAdd") },
                )
                Tab.Calls -> CallsTab(tabBarSpace)
                Tab.Settings -> SettingsTab(onSignOut, onNavigate, tabBarSpace)
            }
        }

        // Short pill + round action button beside it, centred together at the bottom
        Row(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(bottom = 20.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            NavPill(tab, haze, unseenSpotlight) { tab = it }
            AnimatedVisibility(
                visible = tab != Tab.Settings,
                enter = expandHorizontally(spring(dampingRatio = 0.75f, stiffness = 380f)) +
                    scaleIn(spring(dampingRatio = 0.55f, stiffness = 420f)) + fadeIn(tween(200)),
                exit = shrinkHorizontally(tween(260, easing = FastOutSlowInEasing)) + scaleOut(tween(200)) + fadeOut(tween(160)),
            ) {
                Box(Modifier.padding(start = 10.dp)) {
                    ActionButton(tab) {
                        when (tab) {
                            Tab.Chats -> showInvite = true
                            Tab.Spotlight -> onNavigate("statusAdd")
                            Tab.Calls -> showNewCall = true
                            Tab.Settings -> Unit
                        }
                    }
                }
            }
        }
    }

    if (showInvite) InviteSheet(onDismiss = { showInvite = false }, onJoined = onOpenChat)
    if (showNewCall) {
        NewCallSheet(
            onDismiss = { showNewCall = false },
            onCall = { chat ->
                Store.callTarget = chat.title to chat.initials
                onNavigate("call")
            },
        )
    }
}

/** The blue round button. Chats: invite contacts. Spotlight: add status. Calls: start a new call. */
@Composable
private fun ActionButton(tab: Tab, onClick: () -> Unit) {
    val feedback = LocalHapticFeedback.current
    Box(
        Modifier
            .size(BarHeight)
            .pressable(0.9f) {
                feedback.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onClick()
            }
            .clip(CircleShape)
            .background(Palette.Accent)
            .border(1.dp, Color.White.copy(alpha = 0.2f), CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        AnimatedContent(
            targetState = tab,
            transitionSpec = {
                (scaleIn(spring(dampingRatio = 0.5f, stiffness = 500f), initialScale = 0.3f) + fadeIn(tween(140))) togetherWith
                    (scaleOut(tween(120), targetScale = 0.3f) + fadeOut(tween(100)))
            },
            label = "actionIcon",
        ) { t ->
            LIcon(if (t == Tab.Calls) Ic.Calls else Ic.Plus, Color.White, 24.dp)
        }
    }
}

@Composable
private fun NavPill(tab: Tab, haze: HazeState, unseenSpotlight: Boolean, onSelect: (Tab) -> Unit) {
    val shape = RoundedCornerShape(BarHeight / 2)
    // The highlight glides (with a little springiness) to whichever icon is selected
    val slide by animateDpAsState(
        (NavItemWidth + NavGap) * tab.ordinal,
        spring(dampingRatio = 0.72f, stiffness = 420f),
        label = "navSlide",
    )
    Box(
        Modifier
            .height(BarHeight)
            .frostedGlass(haze, shape)
            .padding(NavPad),
    ) {
        Box(
            Modifier
                .offset(x = slide)
                .size(NavItemWidth, NavItemHeight)
                .clip(RoundedCornerShape(NavItemHeight / 2))
                .background(Palette.tint(0.12f))
                .border(1.dp, Palette.tint(0.10f), RoundedCornerShape(NavItemHeight / 2)),
        )
        Row(horizontalArrangement = Arrangement.spacedBy(NavGap)) {
            Tab.entries.forEach { t ->
                TabItem(t, selected = tab == t, dot = t == Tab.Spotlight && unseenSpotlight && tab != t) { onSelect(t) }
            }
        }
    }
}

@Composable
private fun TabItem(tab: Tab, selected: Boolean, dot: Boolean, onClick: () -> Unit) {
    val tint by animateColorAsState(
        if (selected) Palette.AccentSoft else Palette.TextSecondary, tween(250), label = "tabTint",
    )
    val bounce by animateFloatAsState(
        targetValue = if (selected) 1.1f else 1f,
        animationSpec = spring(dampingRatio = 0.4f, stiffness = 400f),
        label = "tabBounce",
    )
    val feedback = LocalHapticFeedback.current
    Box(
        Modifier
            .size(NavItemWidth, NavItemHeight)
            .pressable(0.88f) {
                if (!selected) feedback.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onClick()
            },
        contentAlignment = Alignment.Center,
    ) {
        LIcon(
            tab.icon, tint, 24.dp, description = tab.label,
            modifier = Modifier.graphicsLayer { scaleX = bounce; scaleY = bounce },
        )
        AnimatedVisibility(
            visible = dot,
            enter = scaleIn(spring(dampingRatio = 0.4f)) + fadeIn(),
            exit = scaleOut() + fadeOut(),
            modifier = Modifier.align(Alignment.TopEnd).padding(top = 8.dp, end = 10.dp),
        ) {
            Box(Modifier.size(9.dp).clip(CircleShape).background(Palette.Accent).border(1.5.dp, Palette.Background, CircleShape))
        }
    }
}
