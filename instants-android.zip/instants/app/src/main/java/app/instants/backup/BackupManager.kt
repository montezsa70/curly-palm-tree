package app.instants.backup

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import app.instants.data.Attachments
import app.instants.data.LocalDb
import app.instants.data.Session
import app.instants.data.StoredMsg
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedReader
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStreamReader
import java.io.OutputStream
import java.time.Instant
import java.util.concurrent.TimeUnit
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

class BackupException(message: String) : Exception(message)

data class RestoreResult(val messages: Int, val files: Int, val backupName: String)

/**
 * Backs the phone's chats (and optionally its photos, voice notes and documents) up to the person's own
 * Google Drive, encrypted with their backup password, and restores them on a new phone.
 *
 * Texts are also kept on the server, but photos, voice notes and documents are deleted from it once they
 * reach the other phone, so this backup is how those survive a lost phone.
 */
object BackupManager {
    var running by mutableStateOf(false)
        private set
    var status by mutableStateOf("")
        private set

    private fun workDir(context: Context): File =
        File(context.cacheDir, "backup").also { it.deleteRecursively(); it.mkdirs() }

    private suspend fun silentToken(context: Context): String =
        when (val a = DriveClient.authorize(context)) {
            is DriveClient.Auth.Token -> a.token
            is DriveClient.Auth.NeedsConsent -> throw NeedsSignInException()
        }

    suspend fun listBackups(token: String): List<RemoteBackup> = withContext(Dispatchers.IO) { DriveClient.list(token) }

    /** Makes a backup now. Pass a token from the consent screen, or leave it null to use the saved Google permission. */
    suspend fun backupNow(context: Context, token: String? = null) {
        withContext(Dispatchers.IO) { runBackup(context, token) }
    }

    private suspend fun runBackup(context: Context, token: String?) {
        if (running) return
        running = true
        val work = workDir(context)
        try {
            val (salt, key) = BackupCrypto.storedKey() ?: throw BackupException("Set a backup password first")
            status = "Connecting to Google Drive…"
            val t = token ?: silentToken(context)

            status = "Collecting your chats…"
            val zip = File(work, "backup.zip")
            buildArchive(zip)

            status = "Encrypting…"
            val enc = File(work, "backup.bin")
            BackupCrypto.encryptFile(zip, enc, key, salt)
            zip.delete()

            status = "Uploading to Google Drive…"
            val stamp = Instant.now().toString().replace(':', '-').substringBefore('.')
            DriveClient.upload(t, "instants-backup-${stamp}Z.bin", enc)

            // Keep the newest two backups, so a bad one never replaces the last good one.
            try {
                DriveClient.list(t).drop(2).forEach { DriveClient.delete(t, it.id) }
            } catch (_: Exception) {
            }
            BackupPrefs.recordBackup(System.currentTimeMillis(), enc.length())
            BackupPrefs.setConnected(true)
            status = "Backed up"
        } catch (e: Exception) {
            status = e.message ?: "Backup failed"
            throw e
        } finally {
            work.deleteRecursively()
            running = false
        }
    }

    private fun buildArchive(out: File) {
        ZipOutputStream(FileOutputStream(out).buffered()).use { zip ->
            zip.setLevel(1) // photos and voice notes are already compressed
            fun entry(name: String, write: (OutputStream) -> Unit) {
                zip.putNextEntry(ZipEntry(name))
                write(zip)
                zip.closeEntry()
            }

            entry("meta.json") {
                it.write(
                    JSONObject().put("version", 1).put("createdAt", Instant.now().toString())
                        .put("user", Session.userId ?: "").toString().toByteArray(),
                )
            }
            entry("messages.jsonl") { os ->
                val w = os.bufferedWriter()
                LocalDb.forEachMessage { chat, at, json ->
                    w.write(JSONObject().put("chat", chat).put("at", at).put("msg", json).toString())
                    w.write("\n")
                }
                w.flush() // not closed, that would close the zip
            }
            if (BackupPrefs.includeMedia) {
                val dir = Attachments.mediaDir()
                if (dir != null) {
                    dir.walkTopDown().filter { it.isFile && !it.name.endsWith(".part") }.forEach { f ->
                        entry("media/" + f.relativeTo(dir).path.replace('\\', '/')) { os ->
                            f.inputStream().use { it.copyTo(os) }
                        }
                    }
                }
            }
        }
    }

    /** Downloads the newest backup, decrypts it with [password] and puts everything back on this phone. */
    suspend fun restore(context: Context, password: CharArray): RestoreResult = withContext(Dispatchers.IO) {
        if (running) throw BackupException("A backup is already running")
        running = true
        val work = workDir(context)
        try {
            status = "Connecting to Google Drive…"
            val token = silentToken(context)
            val latest = DriveClient.list(token).firstOrNull() ?: throw BackupException("No backup found in Google Drive")

            status = "Downloading…"
            val enc = File(work, "backup.bin")
            DriveClient.download(token, latest.id, enc)

            status = "Decrypting…"
            val zip = File(work, "backup.zip")
            BackupCrypto.decryptFile(enc, zip, password)
            enc.delete()

            status = "Restoring…"
            var messages = 0
            var files = 0
            val mediaDir = Attachments.mediaDir()
            ZipInputStream(BufferedInputStream(FileInputStream(zip))).use { zin ->
                var e = zin.nextEntry
                while (e != null) {
                    val name = e.name
                    if (name == "messages.jsonl") {
                        val reader = BufferedReader(InputStreamReader(zin)) // not closed, that would close the zip
                        val batch = ArrayList<StoredMsg>()
                        while (true) {
                            val line = reader.readLine() ?: break
                            if (line.isBlank()) continue
                            val o = JSONObject(line)
                            val json = o.getString("msg")
                            batch.add(StoredMsg(o.getString("chat"), JSONObject(json).getString("id"), o.getLong("at"), json))
                            if (batch.size >= 200) {
                                LocalDb.importMessages(batch)
                                messages += batch.size
                                batch.clear()
                            }
                        }
                        if (batch.isNotEmpty()) {
                            LocalDb.importMessages(batch)
                            messages += batch.size
                        }
                    } else if (name.startsWith("media/") && mediaDir != null) {
                        val target = File(mediaDir, name.removePrefix("media/")).canonicalFile
                        val safe = target.path.startsWith(mediaDir.canonicalPath + File.separator) // never write outside the media folder
                        if (safe && !(target.exists() && target.length() > 0)) {
                            target.parentFile?.mkdirs()
                            target.outputStream().use { zin.copyTo(it) }
                            files++
                        }
                    }
                    zin.closeEntry()
                    e = zin.nextEntry
                }
            }
            status = "Restored"
            RestoreResult(messages, files, latest.name)
        } catch (e: Exception) {
            status = e.message ?: "Restore failed"
            throw e
        } finally {
            work.deleteRecursively()
            running = false
        }
    }

    /** On sign out: stop the schedule and forget the backup settings and key for this account. */
    fun reset(context: Context) {
        WorkManager.getInstance(context).cancelUniqueWork(BackupSchedule.NAME)
        BackupCrypto.clearKey()
        BackupPrefs.reset()
        status = ""
    }
}

/** Runs the automatic backup (daily, weekly or monthly, as chosen in Settings). */
class BackupWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result = try {
        BackupManager.backupNow(applicationContext)
        Result.success()
    } catch (e: NeedsSignInException) {
        Result.failure() // the person has to reconnect in Settings; retrying can't fix that
    } catch (e: BackupException) {
        Result.failure()
    } catch (e: Exception) {
        if (runAttemptCount < 3) Result.retry() else Result.failure()
    }
}

object BackupSchedule {
    const val NAME = "drive_backup"

    /** Applies the chosen frequency. Safe to call as often as needed. */
    fun apply(context: Context) {
        val wm = WorkManager.getInstance(context)
        val days = when (BackupPrefs.frequency) {
            "daily" -> 1L
            "weekly" -> 7L
            "monthly" -> 30L
            else -> 0L
        }
        if (days == 0L || !BackupPrefs.connected || !BackupPrefs.passwordSet) {
            wm.cancelUniqueWork(NAME)
            return
        }
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(if (BackupPrefs.mobileData) NetworkType.CONNECTED else NetworkType.UNMETERED)
            .setRequiresBatteryNotLow(true)
            .build()
        val request = PeriodicWorkRequestBuilder<BackupWorker>(days, TimeUnit.DAYS)
            .setConstraints(constraints)
            .build()
        wm.enqueueUniquePeriodicWork(NAME, ExistingPeriodicWorkPolicy.UPDATE, request)
    }
}
