package app.instants.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.instants.data.Config

/** "By creating an account you agree to the Terms of Service and Privacy Policy", with both as links. */
@Composable
fun LegalNote(textColor: Color, linkColor: Color, modifier: Modifier = Modifier) {
    val uri = LocalUriHandler.current
    fun open(url: String) {
        try {
            uri.openUri(url)
        } catch (_: Exception) {
        }
    }
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text("By creating an account you agree to our", color = textColor, fontSize = 12.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(
                "Terms of Service",
                color = linkColor, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                textDecoration = TextDecoration.Underline,
                modifier = Modifier.clickable { open(Config.TERMS_URL) }.padding(vertical = 4.dp),
            )
            Text("and", color = textColor, fontSize = 12.sp, modifier = Modifier.padding(vertical = 4.dp))
            Text(
                "Privacy Policy",
                color = linkColor, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                textDecoration = TextDecoration.Underline,
                modifier = Modifier.clickable { open(Config.PRIVACY_URL) }.padding(vertical = 4.dp),
            )
        }
    }
}
