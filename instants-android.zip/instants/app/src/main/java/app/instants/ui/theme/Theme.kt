package app.instants.ui.theme

import android.content.Context
import android.content.SharedPreferences
import android.content.res.Configuration
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color

/** Colours follow the current theme. Reading them inside a composable makes the UI update when the theme changes. */
object Palette {
    /** Derived from the saved choice; nothing is written during composition. */
    val dark: Boolean
        get() = when (ThemePrefs.mode) {
            "dark" -> true
            "system" -> ThemePrefs.systemDark
            else -> false
        }

    private fun pick(d: Long, l: Long) = Color(if (dark) d else l)

    val Background: Color get() = pick(0xFF1B1C1F, 0xFFFFFFFF)
    val AvatarBg: Color get() = pick(0xFF2C2E33, 0xFFE8ECF3)
    val TextPrimary: Color get() = pick(0xFFF4F5F7, 0xFF0F1115)
    val TextSecondary: Color get() = pick(0xFFA3A7AE, 0xFF667085)
    val Accent = Color(0xFF4A72B8)                       // soft blue (sent bubbles, primary actions)
    val AccentSoft: Color get() = if (dark) Color(0xFF8FB3F0) else Accent
    val BubbleIn: Color get() = pick(0x1AFFFFFF, 0xFFEEF1F6)
    val Glass: Color get() = pick(0x14FFFFFF, 0x99FFFFFF)
    val GlassBorder: Color get() = pick(0x24FFFFFF, 0x1A000000)
    val Hairline: Color get() = pick(0x1AFFFFFF, 0x14000000)
    val EndCall = Color(0xFFC95B5B)
    val Error: Color get() = pick(0xFFE29A9A, 0xFFC0392B)
    val Sheet: Color get() = pick(0xFF232427, 0xFFFFFFFF)
    val ChipText: Color get() = pick(0xFFC9CCD1, 0xFF3D4452)

    /** A faint overlay that works on both themes (white on dark, black on light). */
    fun tint(alpha: Float): Color =
        if (dark) Color.White.copy(alpha = alpha) else Color.Black.copy(alpha = alpha * 0.7f)
}

/**
 * Saved choice: "light" (default), "dark" or "system".
 * A new non-light choice must survive a few seconds of use before it is kept ("verified").
 * If the app dies before that, the next launch falls back to light so you are never locked out.
 */
object ThemePrefs {
    private var prefs: SharedPreferences? = null

    var mode by mutableStateOf("light")
        private set
    var systemDark by mutableStateOf(false)

    fun init(context: Context) {
        val p = context.getSharedPreferences("theme", Context.MODE_PRIVATE)
        prefs = p
        val night = context.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK
        systemDark = night == Configuration.UI_MODE_NIGHT_YES
        var saved = p.getString("mode", "light") ?: "light"
        if (saved != "light" && !p.getBoolean("verified", false)) {
            saved = "light"
            p.edit().putString("mode", "light").apply()
        }
        mode = saved
    }

    fun set(value: String) {
        mode = value
        prefs?.edit()?.putString("mode", value)?.putBoolean("verified", value == "light")?.apply()
    }

    fun markStable() {
        prefs?.edit()?.putBoolean("verified", true)?.apply()
    }
}

@Composable
fun InstantsTheme(content: @Composable () -> Unit) {
    val system = isSystemInDarkTheme()
    SideEffect { ThemePrefs.systemDark = system }
    val dark = Palette.dark
    val scheme = if (dark) {
        darkColorScheme(
            primary = Palette.Accent,
            background = Palette.Background,
            surface = Palette.Background,
            onBackground = Palette.TextPrimary,
            onSurface = Palette.TextPrimary,
        )
    } else {
        lightColorScheme(
            primary = Palette.Accent,
            background = Palette.Background,
            surface = Palette.Background,
            onBackground = Palette.TextPrimary,
            onSurface = Palette.TextPrimary,
        )
    }
    MaterialTheme(colorScheme = scheme, content = content)
}
