package app.instants.ui.theme

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color

/** Colours follow the current theme. Reading them inside a composable makes the UI update when the theme changes. */
object Palette {
    var dark by mutableStateOf(false)

    private fun pick(d: Long, l: Long) = Color(if (dark) d else l)

    val Background: Color get() = pick(0xFF1B1C1F, 0xFFFFFFFF)
    val AvatarBg: Color get() = pick(0xFF2C2E33, 0xFFE8ECF3)
    val TextPrimary: Color get() = pick(0xFFF4F5F7, 0xFF0F1115)
    val TextSecondary: Color get() = pick(0xFFA3A7AE, 0xFF667085)
    val Accent = Color(0xFF4A72B8)                       // soft blue (sent bubbles, primary actions)
    val AccentSoft: Color get() = if (dark) Color(0xFF8FB3F0) else Accent
    val BubbleIn: Color get() = pick(0x1AFFFFFF, 0xFFEEF1F6)
    val Glass: Color get() = pick(0x14FFFFFF, 0x99FFFFFF)
    val GlassBorder: Color get() = pick(0x24FFFFFF, 0x1A000000)
    val Hairline: Color get() = pick(0x1AFFFFFF, 0x14000000)
    val EndCall = Color(0xFFC95B5B)
    val Error: Color get() = pick(0xFFE29A9A, 0xFFC0392B)
    val Sheet: Color get() = pick(0xFF232427, 0xFFFFFFFF)
    val ChipText: Color get() = pick(0xFFC9CCD1, 0xFF3D4452)

    /** A faint overlay that works on both themes (white on dark, black on light). */
    fun tint(alpha: Float): Color =
        if (dark) Palette.tint(alpha) else Color.Black.copy(alpha = alpha * 0.7f)
}

/** Saved choice: "light" (default), "dark" or "system". */
object ThemePrefs {
    private var prefs: SharedPreferences? = null

    var mode by mutableStateOf("light")
        private set

    fun init(context: Context) {
        prefs = context.getSharedPreferences("theme", Context.MODE_PRIVATE)
        mode = prefs?.getString("mode", "light") ?: "light"
    }

    fun set(value: String) {
        mode = value
        prefs?.edit()?.putString("mode", value)?.apply()
    }
}

@Composable
fun InstantsTheme(content: @Composable () -> Unit) {
    val system = isSystemInDarkTheme()
    val dark = when (ThemePrefs.mode) {
        "dark" -> true
        "system" -> system
        else -> false
    }
    Palette.dark = dark
    val scheme = if (dark) {
        darkColorScheme(
            primary = Palette.Accent,
            background = Palette.Background,
            surface = Palette.Background,
            onBackground = Palette.TextPrimary,
            onSurface = Palette.TextPrimary,
        )
    } else {
        lightColorScheme(
            primary = Palette.Accent,
            background = Palette.Background,
            surface = Palette.Background,
            onBackground = Palette.TextPrimary,
            onSurface = Palette.TextPrimary,
        )
    }
    MaterialTheme(colorScheme = scheme, content = content)
}
