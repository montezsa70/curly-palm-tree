package app.instants

import android.content.ClipData
import android.content.ClipboardManager
import android.graphics.Color as AndroidColor
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import app.instants.data.Repo
import app.instants.data.Session
import app.instants.ui.LockGate
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import app.instants.ui.AppNav
import app.instants.ui.theme.InstantsTheme
import java.io.File

class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // If the previous launch crashed, show the error instead of the app.
        val crashFile = File(filesDir, InstantsApp.CRASH_FILE)
        if (crashFile.exists()) {
            showCrash(crashFile)
            return
        }

        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT),
        )
        setContent {
            InstantsTheme { LockGate(this) { AppNav() } }
        }

        // "Active now" heartbeat while the app is on screen
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                while (true) {
                    if (Session.userId != null) {
                        try {
                            Repo.touchPresence()
                        } catch (e: Exception) {
                        }
                    }
                    delay(30_000)
                }
            }
        }
    }

    private fun showCrash(file: File) {
        val text = file.readText()
        val pad = (16 * resources.displayMetrics.density).toInt()

        val title = TextView(this).apply {
            this.text = "Instants crashed on the last launch"
            setTextColor(AndroidColor.WHITE)
            textSize = 18f
        }
        val copy = Button(this).apply {
            this.text = "Copy error"
            setOnClickListener {
                val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("crash", text))
                Toast.makeText(this@MainActivity, "Copied", Toast.LENGTH_SHORT).show()
            }
        }
        val retry = Button(this).apply {
            this.text = "Clear and try again"
            setOnClickListener {
                file.delete()
                recreate()
            }
        }
        val body = TextView(this).apply {
            this.text = text
            setTextColor(0xFFCFD2D8.toInt())
            textSize = 11f
            typeface = android.graphics.Typeface.MONOSPACE
            setTextIsSelectable(true)
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.START
            setBackgroundColor(0xFF1B1C1F.toInt())
            setPadding(pad, pad * 3, pad, pad)
            addView(title)
            addView(copy)
            addView(retry)
            addView(ScrollView(this@MainActivity).apply { addView(body) })
        }
        setContentView(root)
    }
}
