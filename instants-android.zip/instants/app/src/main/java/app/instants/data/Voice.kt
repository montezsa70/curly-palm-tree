package app.instants.data

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CancellationException
import java.io.File
import kotlin.math.ln

/** A finished recording, ready to upload. */
class RecordedVoice(val file: File, val durationMs: Int, val waveform: String)

object VoiceLimits {
    const val MAX_MS = 10 * 60 * 1000L   // 10 minutes
    const val MIN_MS = 700L              // anything shorter is treated as an accidental tap
    const val BARS = 40                  // bars stored with each message
}

/** Records AAC audio (.m4a) from the microphone and reports a live loudness level. */
class VoiceRecorder(private val context: Context) {
    private var recorder: MediaRecorder? = null
    private var file: File? = null
    private var startedAt = 0L

    val isRecording: Boolean get() = recorder != null

    fun start(): Boolean {
        cancel()
        return try {
            val dir = File(context.cacheDir, "outgoing").also { it.mkdirs() }
            val f = File(dir, "voice_${System.currentTimeMillis()}.m4a")
            val r = MediaRecorder(context)
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioChannels(1)
            r.setAudioSamplingRate(44100)
            r.setAudioEncodingBitRate(64000)
            r.setMaxDuration(VoiceLimits.MAX_MS.toInt() + 2000)
            r.setOutputFile(f.absolutePath)
            r.prepare()
            r.start()
            recorder = r
            file = f
            startedAt = SystemClock.elapsedRealtime()
            true
        } catch (e: Exception) {
            cancel()
            false
        }
    }

    fun elapsedMs(): Long = if (recorder == null) 0L else SystemClock.elapsedRealtime() - startedAt

    /** Loudness right now, 0..1. Quiet room is near 0, normal speech around 0.5-0.8. */
    fun level(): Float {
        val amp = try { recorder?.maxAmplitude ?: 0 } catch (e: Exception) { 0 }
        val n = (ln(1.0 + amp) / ln(32768.0)).toFloat()
        return ((n - 0.35f) / 0.65f).coerceIn(0f, 1f)
    }

    /** Stops and returns the file with its length, or null if nothing usable was recorded. */
    fun stop(): Pair<File, Long>? {
        val r = recorder ?: return null
        val f = file
        val ms = elapsedMs()
        recorder = null
        file = null
        return try {
            r.stop()
            r.release()
            if (f != null && f.length() > 0) f to ms else null
        } catch (e: Exception) {
            try { r.release() } catch (_: Exception) { }
            f?.delete()
            null
        }
    }

    /** Stops and throws the recording away. */
    fun cancel() {
        val r = recorder
        val f = file
        recorder = null
        file = null
        if (r != null) {
            try { r.stop() } catch (_: Exception) { }
            try { r.release() } catch (_: Exception) { }
        }
        f?.delete()
    }
}

/** Squeezes the loudness history into [bars] peaks and encodes them as "12,40,88,...". */
fun encodeWaveform(levels: List<Float>, bars: Int = VoiceLimits.BARS): String {
    if (levels.isEmpty()) return List(bars) { 8 }.joinToString(",")
    val out = IntArray(bars)
    for (i in 0 until bars) {
        val from = (i * levels.size) / bars
        val to = maxOf(from + 1, ((i + 1) * levels.size) / bars).coerceAtMost(levels.size)
        var peak = 0f
        for (j in from until to) if (levels[j] > peak) peak = levels[j]
        out[i] = (peak * 99f).toInt().coerceIn(6, 99)
    }
    return out.joinToString(",")
}

fun decodeWaveform(s: String?, bars: Int = VoiceLimits.BARS): List<Float> {
    val parsed = s?.split(',')?.mapNotNull { it.trim().toIntOrNull() }?.map { (it / 99f).coerceIn(0.06f, 1f) }
    return if (parsed.isNullOrEmpty()) List(bars) { 0.3f } else parsed
}

/** One voice note plays at a time. Starting another (or leaving the chat) stops the current one. */
object VoicePlayer {
    var currentId by mutableStateOf<String?>(null)
        private set
    var isPlaying by mutableStateOf(false)
        private set
    var loading by mutableStateOf(false)
        private set
    var positionMs by mutableIntStateOf(0)
        private set

    private var player: MediaPlayer? = null
    private var token = 0

    /** Play / pause this message. Returns false if the audio could not be loaded. */
    suspend fun toggle(msg: Msg): Boolean {
        val p = player
        if (currentId == msg.id && p != null) {
            try {
                if (p.isPlaying) {
                    p.pause()
                    isPlaying = false
                } else {
                    p.start()
                    isPlaying = true
                }
                return true
            } catch (e: Exception) {
                stop()
            }
        }
        stop()
        val mine = ++token
        currentId = msg.id
        loading = true
        val file = try {
            Attachments.voice(msg)
        } catch (e: CancellationException) {
            if (token == mine) { loading = false; currentId = null }
            throw e
        } catch (e: Exception) {
            null
        }
        if (token != mine) return true // another note was started while this one downloaded
        loading = false
        if (file == null) {
            currentId = null
            return false
        }
        return try {
            val mp = MediaPlayer()
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .build(),
            )
            mp.setDataSource(file.absolutePath)
            mp.prepare()
            mp.setOnCompletionListener {
                isPlaying = false
                positionMs = 0
                try { it.seekTo(0) } catch (_: Exception) { }
            }
            mp.setOnErrorListener { _, _, _ -> stop(); true }
            player = mp
            mp.start()
            isPlaying = true
            true
        } catch (e: Exception) {
            stop()
            false
        }
    }

    /** Jump to a point of the note that is currently loaded (0..1). */
    fun seekTo(msgId: String, fraction: Float, durationMs: Int) {
        val p = player ?: return
        if (currentId != msgId) return
        try {
            val target = (fraction.coerceIn(0f, 1f) * (p.duration.takeIf { it > 0 } ?: durationMs)).toInt()
            p.seekTo(target)
            positionMs = target
        } catch (_: Exception) { }
    }

    /** Called about 20 times a second by the note that is playing. */
    fun refresh() {
        val p = player ?: return
        try { if (p.isPlaying) positionMs = p.currentPosition } catch (_: Exception) { }
    }

    fun stop() {
        token++
        val p = player
        player = null
        try { p?.stop() } catch (_: Exception) { }
        try { p?.release() } catch (_: Exception) { }
        currentId = null
        isPlaying = false
        loading = false
        positionMs = 0
    }
}
