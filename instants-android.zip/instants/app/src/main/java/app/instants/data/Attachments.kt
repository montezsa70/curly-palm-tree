package app.instants.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.net.Uri
import android.provider.OpenableColumns
import android.util.LruCache
import android.webkit.MimeTypeMap
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File

/** A picked photo or document, copied to a temp file and ready to upload. */
class PreparedAttachment(
    val file: File,
    val name: String,
    val mime: String,
    val size: Long,
    val isImage: Boolean,
)

/** Chat photos and documents. Downloaded once, then opened from the phone's own storage. */
object Attachments {
    const val BUCKET = "attachments"
    const val MAX_BYTES = 25L * 1024 * 1024

    private var dir: File? = null
    private var tmp: File? = null
    private val bitmaps = LruCache<String, Bitmap>(30)

    fun init(context: Context) {
        dir = File(context.filesDir, "attachments").also { it.mkdirs() }
        tmp = File(context.cacheDir, "outgoing").also { it.mkdirs() }
    }

    private fun safe(name: String): String = name.replace(Regex("[^A-Za-z0-9._ -]"), "_").take(80).ifBlank { "file" }

    private fun displayName(context: Context, uri: Uri): String? = try {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        }
    } catch (e: Exception) {
        null
    }

    /** Photos are shrunk to about 1600 px and saved as JPEG. */
    suspend fun prepareImage(context: Context, uri: Uri): Result<PreparedAttachment> = withContext(Dispatchers.IO) {
        try {
            val src = ImageDecoder.createSource(context.contentResolver, uri)
            val bmp = ImageDecoder.decodeBitmap(src) { decoder, info, _ ->
                decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                decoder.setTargetSampleSize(maxOf(1, maxOf(info.size.width, info.size.height) / 1600))
            }
            val out = ByteArrayOutputStream().also { bmp.compress(Bitmap.CompressFormat.JPEG, 85, it) }.toByteArray()
            val f = File(tmp ?: context.cacheDir, "img_${System.currentTimeMillis()}.jpg")
            f.writeBytes(out)
            Result.success(PreparedAttachment(f, "photo.jpg", "image/jpeg", f.length(), true))
        } catch (e: Exception) {
            Result.failure(Exception("Couldn't open that photo"))
        }
    }

    /** Any document, up to 25 MB. */
    suspend fun prepareDocument(context: Context, uri: Uri): Result<PreparedAttachment> = withContext(Dispatchers.IO) {
        try {
            val name = safe(displayName(context, uri) ?: "document")
            val mime = context.contentResolver.getType(uri)
                ?: MimeTypeMap.getSingleton().getMimeTypeFromExtension(name.substringAfterLast('.', "").lowercase())
                ?: "application/octet-stream"
            val f = File(tmp ?: context.cacheDir, "doc_${System.currentTimeMillis()}_$name")
            val input = context.contentResolver.openInputStream(uri) ?: return@withContext Result.failure(Exception("Couldn't read that file"))
            input.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
            if (f.length() > MAX_BYTES) {
                f.delete()
                return@withContext Result.failure(Exception("That file is too large (25 MB max)"))
            }
            if (f.length() == 0L) {
                f.delete()
                return@withContext Result.failure(Exception("That file is empty"))
            }
            Result.success(PreparedAttachment(f, name, mime, f.length(), false))
        } catch (e: Exception) {
            Result.failure(Exception("Couldn't read that file"))
        }
    }

    /** Remember what I just sent, so my own photo shows instantly and isn't downloaded back. */
    fun storeSent(msgId: String, path: String, source: File, name: String, isImage: Boolean) {
        try {
            val target = if (isImage) imageFile(path) else docFile(msgId, name)
            target?.parentFile?.mkdirs()
            if (target != null) source.copyTo(target, overwrite = true)
        } catch (_: Exception) { }
    }

    private fun voiceFile(path: String): File? = dir?.let { File(it, "voice_" + path.replace('/', '_')) }

    /** Keep my own voice note on the phone so it plays instantly and isn't downloaded back. */
    fun storeSentVoice(path: String, source: File) {
        try {
            val target = voiceFile(path)
            target?.parentFile?.mkdirs()
            if (target != null) source.copyTo(target, overwrite = true)
        } catch (_: Exception) { }
    }

    /** The voice note's audio file: from the phone if saved, otherwise downloaded once. */
    suspend fun voice(msg: Msg): File? = withContext(Dispatchers.IO) {
        val path = msg.attachmentPath ?: return@withContext null
        val target = voiceFile(path) ?: return@withContext null
        fetch(path, target)
    }

    private fun imageFile(path: String): File? = dir?.let { File(it, "img_" + path.replace('/', '_')) }
    private fun docFile(msgId: String, name: String): File? = dir?.let { File(File(it, "doc_$msgId"), safe(name)) }

    private fun fetch(path: String, target: File): File? {
        if (target.exists() && target.length() > 0) return target
        target.parentFile?.mkdirs()
        val part = File(target.parentFile, target.name + ".part")
        return try {
            Api.downloadObjectToFile(BUCKET, path, part)
            if (part.renameTo(target)) target else null
        } catch (e: CancellationException) {
            part.delete()
            throw e
        } catch (e: Exception) {
            part.delete()
            null
        }
    }

    suspend fun bitmap(path: String): Bitmap? = withContext(Dispatchers.IO) {
        bitmaps.get(path)?.let { return@withContext it }
        val f = imageFile(path)?.let { fetch(path, it) } ?: return@withContext null
        val bmp = BitmapFactory.decodeFile(f.path)
        if (bmp == null) f.delete() else bitmaps.put(path, bmp)
        bmp
    }

    fun isDocumentSaved(msg: Msg): Boolean {
        val f = docFile(msg.id, msg.attachmentName ?: "file")
        return f != null && f.exists() && f.length() > 0
    }

    suspend fun document(msg: Msg): File? = withContext(Dispatchers.IO) {
        val path = msg.attachmentPath ?: return@withContext null
        val target = docFile(msg.id, msg.attachmentName ?: "file") ?: return@withContext null
        fetch(path, target)
    }

    fun clear() {
        bitmaps.evictAll()
        dir?.deleteRecursively()
        dir?.mkdirs()
    }
}

fun formatSize(bytes: Long): String = when {
    bytes < 1024 -> "$bytes B"
    bytes < 1024 * 1024 -> "${bytes / 1024} KB"
    else -> String.format("%.1f MB", bytes / 1048576.0)
}

/** "0:07", "1:23" */
fun formatDuration(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "${s / 60}:${(s % 60).toString().padStart(2, '0')}"
}
