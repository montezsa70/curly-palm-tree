package app.instants.data

import android.content.Context
import android.net.ConnectivityManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.net.Uri
import android.provider.OpenableColumns
import android.util.LruCache
import android.webkit.MimeTypeMap
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.time.Instant

/** A picked photo or document, copied to a temp file and ready to upload. */
class PreparedAttachment(
    val file: File,
    val name: String,
    val mime: String,
    val size: Long,
    val isImage: Boolean,
)

/** Chat photos and documents. Downloaded once, then opened from the phone's own storage. */
object Attachments {
    const val BUCKET = "attachments"
    const val MAX_BYTES = 25L * 1024 * 1024

    /** On mobile data, documents bigger than this wait until the person taps them (or Wi-Fi). */
    private const val AUTO_MOBILE_MAX_BYTES = 5L * 1024 * 1024

    private var dir: File? = null
    private var tmp: File? = null
    private var connectivity: ConnectivityManager? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val inFlight = java.util.Collections.synchronizedSet(mutableSetOf<String>())
    private val bitmaps = LruCache<String, Bitmap>(30)

    fun init(context: Context) {
        dir = File(context.filesDir, "attachments").also { it.mkdirs() }
        tmp = File(context.cacheDir, "outgoing").also { it.mkdirs() }
        connectivity = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
    }

    private fun safe(name: String): String = name.replace(Regex("[^A-Za-z0-9._ -]"), "_").take(80).ifBlank { "file" }

    private fun displayName(context: Context, uri: Uri): String? = try {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        }
    } catch (e: Exception) {
        null
    }

    /** Photos are shrunk to about 1600 px and saved as JPEG. */
    suspend fun prepareImage(context: Context, uri: Uri): Result<PreparedAttachment> = withContext(Dispatchers.IO) {
        try {
            val src = ImageDecoder.createSource(context.contentResolver, uri)
            val bmp = ImageDecoder.decodeBitmap(src) { decoder, info, _ ->
                decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                decoder.setTargetSampleSize(maxOf(1, maxOf(info.size.width, info.size.height) / 1600))
            }
            val out = ByteArrayOutputStream().also { bmp.compress(Bitmap.CompressFormat.JPEG, 85, it) }.toByteArray()
            val f = File(tmp ?: context.cacheDir, "img_${System.currentTimeMillis()}.jpg")
            f.writeBytes(out)
            Result.success(PreparedAttachment(f, "photo.jpg", "image/jpeg", f.length(), true))
        } catch (e: Exception) {
            Result.failure(Exception("Couldn't open that photo"))
        }
    }

    /** Any document, up to 25 MB. */
    suspend fun prepareDocument(context: Context, uri: Uri): Result<PreparedAttachment> = withContext(Dispatchers.IO) {
        try {
            val name = safe(displayName(context, uri) ?: "document")
            val mime = context.contentResolver.getType(uri)
                ?: MimeTypeMap.getSingleton().getMimeTypeFromExtension(name.substringAfterLast('.', "").lowercase())
                ?: "application/octet-stream"
            val f = File(tmp ?: context.cacheDir, "doc_${System.currentTimeMillis()}_$name")
            val input = context.contentResolver.openInputStream(uri) ?: return@withContext Result.failure(Exception("Couldn't read that file"))
            input.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
            if (f.length() > MAX_BYTES) {
                f.delete()
                return@withContext Result.failure(Exception("That file is too large (25 MB max)"))
            }
            if (f.length() == 0L) {
                f.delete()
                return@withContext Result.failure(Exception("That file is empty"))
            }
            Result.success(PreparedAttachment(f, name, mime, f.length(), false))
        } catch (e: Exception) {
            Result.failure(Exception("Couldn't read that file"))
        }
    }

    /** Remember what I just sent, so my own photo shows instantly and isn't downloaded back. */
    fun storeSent(msgId: String, path: String, source: File, name: String, isImage: Boolean) {
        try {
            val target = if (isImage) imageFile(path) else docFile(msgId, name)
            target?.parentFile?.mkdirs()
            if (target != null) source.copyTo(target, overwrite = true)
        } catch (_: Exception) { }
    }

    private fun voiceFile(path: String): File? = dir?.let { File(it, "voice_" + path.replace('/', '_')) }

    /** Keep my own voice note on the phone so it plays instantly and isn't downloaded back. */
    fun storeSentVoice(path: String, source: File) {
        try {
            val target = voiceFile(path)
            target?.parentFile?.mkdirs()
            if (target != null) source.copyTo(target, overwrite = true)
        } catch (_: Exception) { }
    }

    /** The voice note's audio file: from the phone if saved, otherwise downloaded once. */
    suspend fun voice(msg: Msg): File? = withContext(Dispatchers.IO) {
        val path = msg.attachmentPath ?: return@withContext null
        val target = voiceFile(path) ?: return@withContext null
        fetch(path, target)
    }

    private fun imageFile(path: String): File? = dir?.let { File(it, "img_" + path.replace('/', '_')) }
    private fun docFile(msgId: String, name: String): File? = dir?.let { File(File(it, "doc_$msgId"), safe(name)) }

    private fun fetch(path: String, target: File): File? {
        if (target.exists() && target.length() > 0) return target
        target.parentFile?.mkdirs()
        val part = File(target.parentFile, target.name + ".part")
        return try {
            Api.downloadObjectToFile(BUCKET, path, part)
            if (part.renameTo(target)) {
                ack(path)
                target
            } else {
                null
            }
        } catch (e: CancellationException) {
            part.delete()
            throw e
        } catch (e: Exception) {
            part.delete()
            null
        }
    }

    /** Where received and sent files are kept on this phone (for backups). */
    fun mediaDir(): File? = dir

    /** The phone has the file now, so the server can delete its copy. If this fails, the 14 day expiry cleans up. */
    private fun ack(path: String) {
        try { Api.ackObject(BUCKET, path) } catch (_: Exception) { }
    }

    private fun localTarget(msg: Msg): File? = when (msg.kind) {
        "image" -> msg.attachmentPath?.let { imageFile(it) }
        "voice" -> msg.attachmentPath?.let { voiceFile(it) }
        else -> docFile(msg.id, msg.attachmentName ?: "file")
    }

    /** Photos and voice notes are small, so always. Big documents wait for Wi-Fi. */
    private fun wantsAutoDownload(msg: Msg): Boolean {
        val metered = connectivity?.isActiveNetworkMetered != false
        return !metered || msg.kind == "image" || msg.kind == "voice" || msg.attachmentSize <= AUTO_MOBILE_MAX_BYTES
    }

    private fun incomingToSave(msgs: List<Msg>): List<Msg> {
        val me = Session.userId ?: return emptyList()
        val cutoff = Instant.now().minusSeconds(3L * 86400)
        return msgs
            .filter { it.senderId != me && it.attachmentPath != null && it.kind in setOf("image", "voice", "file") && it.createdAt > cutoff }
            .sortedByDescending { it.createdAt }
            .take(20)
    }

    private suspend fun saveMissing(todo: List<Msg>) = withContext(Dispatchers.IO) {
        for (m in todo) {
            val target = localTarget(m) ?: continue
            if (target.exists() && target.length() > 0) continue
            if (!wantsAutoDownload(m)) continue
            val key = m.attachmentPath ?: continue
            if (!inFlight.add(key)) continue
            try {
                fetch(key, target)
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
            } finally {
                inFlight.remove(key)
            }
        }
    }

    /** Quietly saves new incoming photos, voice notes and documents to the phone (the server copy is then deleted). */
    fun saveIncoming(msgs: List<Msg>) {
        val todo = incomingToSave(msgs)
        if (todo.isNotEmpty()) scope.launch { saveMissing(todo) }
    }

    /** Same, for the push service: waits until the downloads are done. */
    suspend fun saveIncomingIn(chatId: String) {
        saveMissing(incomingToSave(Repo.loadThread(chatId).messages.takeLast(10)))
    }

    suspend fun bitmap(path: String): Bitmap? = withContext(Dispatchers.IO) {
        bitmaps.get(path)?.let { return@withContext it }
        val f = imageFile(path)?.let { fetch(path, it) } ?: return@withContext null
        // Read the picture's size first: refuse absurd dimensions and decode a screen-sized copy, not the full image.
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0 || bounds.outWidth.toLong() * bounds.outHeight > 50_000_000L) {
            f.delete()
            return@withContext null
        }
        var sample = 1
        while (bounds.outWidth / sample > 2048 || bounds.outHeight / sample > 2048) sample *= 2
        val bmp = BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = sample })
        if (bmp == null) f.delete() else bitmaps.put(path, bmp)
        bmp
    }

    fun isDocumentSaved(msg: Msg): Boolean {
        val f = docFile(msg.id, msg.attachmentName ?: "file")
        return f != null && f.exists() && f.length() > 0
    }

    suspend fun document(msg: Msg): File? = withContext(Dispatchers.IO) {
        val path = msg.attachmentPath ?: return@withContext null
        val target = docFile(msg.id, msg.attachmentName ?: "file") ?: return@withContext null
        fetch(path, target)
    }

    /** Removes this phone's copy of a message's file once the message has been deleted for everyone. */
    fun forget(msg: Msg) {
        val path = msg.attachmentPath ?: return
        try {
            when (msg.kind) {
                "image" -> {
                    imageFile(path)?.delete()
                    bitmaps.remove(path)
                }
                "voice" -> voiceFile(path)?.delete()
                "file" -> docFile(msg.id, msg.attachmentName ?: "file")?.parentFile?.deleteRecursively()
            }
        } catch (_: Exception) { }
    }

    /** A temporary copy of a saved photo or document, ready to send to another chat (null if it can't be read). */
    suspend fun prepareForward(msg: Msg): PreparedAttachment? = withContext(Dispatchers.IO) {
        val path = msg.attachmentPath ?: return@withContext null
        val src: File = when (msg.kind) {
            "image" -> imageFile(path)?.let { fetch(path, it) }
            "file" -> document(msg)
            else -> null
        } ?: return@withContext null
        val folder = tmp ?: return@withContext null
        val out = File(folder, "fwd_${System.currentTimeMillis()}_${safe(msg.attachmentName ?: "file")}")
        try {
            src.copyTo(out, overwrite = true)
        } catch (e: Exception) {
            return@withContext null
        }
        PreparedAttachment(out, msg.attachmentName ?: "file", msg.attachmentMime ?: "application/octet-stream", out.length(), msg.kind == "image")
    }

    /** Same for a voice note. */
    suspend fun prepareForwardVoice(msg: Msg): RecordedVoice? = withContext(Dispatchers.IO) {
        val src = voice(msg) ?: return@withContext null
        val folder = tmp ?: return@withContext null
        val out = File(folder, "fwd_${System.currentTimeMillis()}.m4a")
        try {
            src.copyTo(out, overwrite = true)
        } catch (e: Exception) {
            return@withContext null
        }
        RecordedVoice(out, msg.voiceDurationMs, msg.voiceWaveform ?: "")
    }

    fun clear() {
        bitmaps.evictAll()
        dir?.deleteRecursively()
        dir?.mkdirs()
    }
}

fun formatSize(bytes: Long): String = when {
    bytes < 1024 -> "$bytes B"
    bytes < 1024 * 1024 -> "${bytes / 1024} KB"
    else -> String.format("%.1f MB", bytes / 1048576.0)
}

/** "0:07", "1:23" */
fun formatDuration(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "${s / 60}:${(s % 60).toString().padStart(2, '0')}"
}
