package app.instants.ui.screens

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.graphics.SurfaceTexture
import android.media.MediaPlayer
import android.view.Surface
import android.view.TextureView
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.AnimationVector1D
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import app.instants.data.Session
import android.widget.Toast
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.ImeAction
import app.instants.data.Repo
import app.instants.data.Store
import app.instants.ui.components.Ic
import app.instants.ui.components.LIcon
import app.instants.ui.components.StatusBackgrounds
import app.instants.ui.components.StatusFonts
import app.instants.ui.components.statusBrush
import app.instants.ui.components.statusFont
import app.instants.ui.components.style
import app.instants.data.StatusItem
import app.instants.data.StatusMedia
import app.instants.data.StatusRepo
import app.instants.data.StatusStore
import app.instants.data.listLabel
import app.instants.ui.components.PrimaryButton
import app.instants.ui.components.ProfileAvatar
import app.instants.ui.components.pressable
import app.instants.ui.theme.Palette
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File

private const val STILL_MS = 5000 // how long a text or photo status stays up

// ---------------------------------------------------------------------------------------------
// Status row on the chats tab
// ---------------------------------------------------------------------------------------------

@Composable
fun StatusRow(onAdd: () -> Unit, onOpen: (String) -> Unit) {
    LaunchedEffect(Unit) {
        while (true) {
            StatusStore.refresh()
            delay(30_000)
        }
    }
    val mine = StatusStore.mine
    Row(
        Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        StatusCard("Add status", "", null, ring = null, plus = true, onClick = onAdd)
        if (mine != null) {
            StatusCard("You", mine.initials, mine.profile?.avatarPath, ring = Palette.AccentSoft, plus = false, latest = mine.items.lastOrNull()) {
                Session.userId?.let(onOpen)
            }
        }
        StatusStore.groups.forEach { g ->
            val ring = if (StatusStore.hasUnseen(g)) Palette.Accent else null
            StatusCard(g.name, g.initials, g.profile?.avatarPath, ring, plus = false, latest = g.items.lastOrNull()) { onOpen(g.userId) }
        }
    }
}

@Composable
private fun StatusCard(
    label: String,
    initials: String,
    avatarPath: String?,
    ring: Color?,
    plus: Boolean,
    latest: StatusItem? = null,
    onClick: () -> Unit,
) {
    val shape = RoundedCornerShape(20.dp)
    val base = Modifier
        .width(88.dp)
        .height(124.dp)
        .pressable(0.94f, haptic = true, onClick = onClick)
        .clip(shape)

    if (plus || latest == null) {
        Column(
            base.background(Palette.Glass).border(1.dp, Palette.GlassBorder, shape).padding(horizontal = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            if (plus) {
                Box(Modifier.size(44.dp).clip(CircleShape).background(Palette.Accent), contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.Add, null, tint = Color.White, modifier = Modifier.size(22.dp))
                }
            } else {
                Box(Modifier.size(50.dp).border(2.dp, ring ?: Palette.Hairline, CircleShape).padding(3.dp)) {
                    ProfileAvatar(initials, 44.dp, avatarPath)
                }
            }
            Spacer(Modifier.height(6.dp))
            Text(
                label, color = Palette.TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Medium,
                maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
        }
        return
    }

    // A card that shows what the latest status looks like
    val loaded by produceState<Bitmap?>(null, latest.id, StatusMedia.tick) { value = StatusMedia.preview(latest) }
    val preview = loaded
    val textBg = remember(latest.bgColor) { statusBrush(latest.bgColor) }
    Box(
        (if (latest.kind == "text") base.background(textBg) else base.background(Color(0xFF1C1C1E)))
            .border(1.dp, Palette.GlassBorder, shape),
    ) {
        when {
            latest.kind == "text" -> Text(
                latest.body, style = statusFont(latest.font).style(11f), maxLines = 5, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.align(Alignment.Center).padding(horizontal = 8.dp),
            )
            preview != null -> Image(preview.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        }
        if (latest.kind == "video") {
            Box(
                Modifier.align(Alignment.Center).size(28.dp).clip(CircleShape).background(Color.Black.copy(0.4f)),
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Rounded.PlayArrow, null, tint = Color.White, modifier = Modifier.size(18.dp))
            }
        }
        Box(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(0.65f))))
                .padding(start = 8.dp, end = 8.dp, top = 18.dp, bottom = 8.dp),
        ) {
            Text(label, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Box(
            Modifier
                .align(Alignment.TopStart)
                .padding(6.dp)
                .size(34.dp)
                .border(2.dp, ring ?: Color.White.copy(0.65f), CircleShape)
                .padding(2.dp),
        ) {
            ProfileAvatar(initials, 30.dp, avatarPath)
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Viewer
// ---------------------------------------------------------------------------------------------

/** The system bar icons are dark on the light theme; flip them to white while a dark full-screen page is open. */
@Composable
private fun LightSystemIcons() {
    val view = LocalView.current
    DisposableEffect(Unit) {
        val activity = generateSequence(view.context) { (it as? ContextWrapper)?.baseContext }
            .filterIsInstance<Activity>().firstOrNull()
        val controller = activity?.window?.let { WindowCompat.getInsetsController(it, view) }
        controller?.isAppearanceLightStatusBars = false
        controller?.isAppearanceLightNavigationBars = false
        onDispose {
            controller?.isAppearanceLightStatusBars = !Palette.dark
            controller?.isAppearanceLightNavigationBars = !Palette.dark
        }
    }
}

@Composable
fun StatusViewerScreen(userId: String, onClose: () -> Unit) {
    val group = if (userId == Session.userId) StatusStore.mine else StatusStore.groups.firstOrNull { it.userId == userId }
    if (group == null || group.items.isEmpty()) {
        LaunchedEffect(Unit) { onClose() }
        Box(Modifier.fillMaxSize().background(Color.Black))
        return
    }
    LightSystemIcons()

    val scope = rememberCoroutineScope()
    var index by remember(userId) {
        mutableIntStateOf(
            if (group.mine) 0 else group.items.indexOfFirst { it.id !in StatusStore.viewed }.coerceAtLeast(0),
        )
    }
    val i = index.coerceIn(0, group.items.lastIndex)
    val item = group.items[i]
    var pressing by remember { mutableStateOf(false) }
    var replyFocused by remember { mutableStateOf(false) }
    val focusManager = LocalFocusManager.current
    // Holding the screen or typing a reply freezes the timer and the video
    val paused = pressing || replyFocused
    var ready by remember(item.id) { mutableStateOf(false) }
    val progress = remember(item.id) { Animatable(0f) }

    val goNext = rememberUpdatedState<() -> Unit> { if (i < group.items.lastIndex) index = i + 1 else onClose() }
    val goPrev = rememberUpdatedState<() -> Unit> { index = maxOf(0, i - 1) }

    LaunchedEffect(item.id) {
        if (!group.mine) StatusStore.markViewed(item.id)
    }

    // Text and photos run on a 5 second timer; videos drive the bar themselves.
    LaunchedEffect(item.id, ready, paused) {
        if (!ready || paused || item.kind == "video") return@LaunchedEffect
        val remaining = ((1f - progress.value) * STILL_MS).toInt().coerceAtLeast(1)
        progress.animateTo(1f, tween(remaining, easing = LinearEasing))
        goNext.value()
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        key(item.id) {
            StatusContent(item, paused, progress, onReady = { ready = true }, onVideoDone = { goNext.value() })
        }

        // Tap right = next, tap left = previous, hold = pause
        Box(
            Modifier.fillMaxSize().pointerInput(Unit) {
                detectTapGestures(
                    onPress = {
                        pressing = true
                        tryAwaitRelease()
                        pressing = false
                    },
                    onTap = { o ->
                        // First tap while typing only closes the keyboard
                        if (replyFocused) focusManager.clearFocus()
                        else if (o.x < size.width * 0.33f) goPrev.value() else goNext.value()
                    },
                )
            },
        )

        // Top: progress segments and who posted
        Column(
            Modifier
                .fillMaxWidth()
                .background(Brush.verticalGradient(listOf(Color.Black.copy(0.45f), Color.Transparent)))
                .statusBarsPadding()
                .padding(horizontal = 10.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                group.items.forEachIndexed { j, _ ->
                    val frac = when {
                        j < i -> 1f
                        j == i -> progress.value
                        else -> 0f
                    }
                    Box(Modifier.weight(1f).height(3.dp).clip(CircleShape).background(Color.White.copy(0.3f))) {
                        Box(Modifier.fillMaxHeight().fillMaxWidth(frac).background(Color.White))
                    }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ProfileAvatar(group.initials, 36.dp, group.profile?.avatarPath)
                Column(Modifier.weight(1f)) {
                    Text(group.name, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                    Text(item.createdAt.listLabel(), color = Color.White.copy(0.75f), fontSize = 12.sp)
                }
                if (group.mine) {
                    IconTap(Icons.Rounded.Delete, "Delete status") {
                        scope.launch {
                            try {
                                StatusRepo.delete(item)
                                StatusStore.refresh()
                            } catch (e: CancellationException) {
                                throw e
                            } catch (e: Exception) {
                            }
                        }
                    }
                }
                IconTap(Icons.Rounded.Close, "Close", onClose)
            }
        }

        // Bottom: caption, then the reply pill (others) or the view count (mine)
        val showCaption = item.kind != "text" && item.body.isNotBlank()
        var reply by remember(item.id) { mutableStateOf("") }
        var sending by remember { mutableStateOf(false) }
        val context = LocalContext.current
        fun sendReply() {
            val body = reply.trim()
            if (body.isEmpty() || sending) return
            val chat = Store.chats.firstOrNull { it.peer?.id == group.userId }
            if (chat == null) {
                Toast.makeText(context, "Open a chat with ${group.name} first", Toast.LENGTH_SHORT).show()
                return
            }
            sending = true
            scope.launch {
                try {
                    Repo.send(chat.chatId, body, statusQuote = item.toQuote())
                    reply = ""
                    focusManager.clearFocus()
                    Store.refreshChats()
                    Toast.makeText(context, "Reply sent", Toast.LENGTH_SHORT).show()
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    Toast.makeText(context, "Couldn't send the reply", Toast.LENGTH_SHORT).show()
                } finally {
                    sending = false
                }
            }
        }
        // Keep the view count fresh while my own status is open
        if (group.mine) {
            LaunchedEffect(item.id) {
                while (true) {
                    try { StatusStore.refreshCounts() } catch (e: CancellationException) { throw e } catch (e: Exception) { }
                    delay(8_000)
                }
            }
        }
        Column(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(0.6f))))
                .navigationBarsPadding()
                .imePadding()
                .padding(horizontal = 16.dp)
                .padding(top = 24.dp, bottom = 14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            if (showCaption) {
                Text(
                    item.body, color = Color.White, fontSize = 16.sp, lineHeight = 22.sp,
                    modifier = Modifier.padding(horizontal = 4.dp),
                )
            }
            if (group.mine) {
                val n = StatusStore.viewCounts[item.id] ?: 0
                Row(
                    Modifier
                        .heightIn(min = 46.dp)
                        .clip(RoundedCornerShape(22.dp))
                        .background(Color.White.copy(0.16f))
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    LIcon(Ic.Eye, Color.White, 18.dp)
                    Text(if (n == 1) "1 view" else "$n views", color = Color.White, fontSize = 16.sp)
                }
            } else {
                StatusPill(
                    value = reply,
                    onValueChange = { if (it.length <= 1000) reply = it },
                    placeholder = "Reply to ${group.name}…",
                    onFocus = { replyFocused = it },
                    onSend = ::sendReply,
                    sendEnabled = !sending,
                )
            }
        }
    }
}

/**
 * The one text pill used under every status: the caption field in the composer and the reply field in the viewer.
 * Pass onSend to get the send button.
 */
@Composable
private fun StatusPill(
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    modifier: Modifier = Modifier,
    onFocus: (Boolean) -> Unit = {},
    onSend: (() -> Unit)? = null,
    sendEnabled: Boolean = true,
) {
    Row(
        modifier
            .fillMaxWidth()
            .heightIn(min = 46.dp)
            .clip(RoundedCornerShape(22.dp))
            .background(Color.White.copy(0.16f))
            .padding(start = 16.dp, end = if (onSend != null) 6.dp else 16.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        BasicTextField(
            value = value,
            onValueChange = onValueChange,
            textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
            cursorBrush = SolidColor(Color.White),
            maxLines = 4,
            keyboardOptions = if (onSend != null) KeyboardOptions(imeAction = ImeAction.Send) else KeyboardOptions.Default,
            keyboardActions = KeyboardActions(onSend = { onSend?.invoke() }),
            modifier = Modifier.weight(1f).padding(vertical = 6.dp).onFocusChanged { onFocus(it.isFocused) },
            decorationBox = { inner ->
                Box {
                    if (value.isEmpty()) Text(placeholder, color = Color.White.copy(0.6f), fontSize = 16.sp)
                    inner()
                }
            },
        )
        if (onSend != null && value.isNotBlank()) {
            Box(
                Modifier
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(Palette.Accent)
                    .pressable(0.9f, haptic = true) { if (sendEnabled) onSend() },
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Rounded.ArrowUpward, "Send", tint = Color.White, modifier = Modifier.size(20.dp))
            }
        }
    }
}

@Composable
private fun IconTap(icon: androidx.compose.ui.graphics.vector.ImageVector, description: String, onClick: () -> Unit) {
    Box(
        Modifier.size(40.dp).clip(CircleShape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, description, tint = Color.White, modifier = Modifier.size(22.dp))
    }
}

@Composable
private fun StatusContent(
    item: StatusItem,
    paused: Boolean,
    progress: Animatable<Float, AnimationVector1D>,
    onReady: () -> Unit,
    onVideoDone: () -> Unit,
) {
    when (item.kind) {
        "text" -> {
            LaunchedEffect(Unit) { onReady() }
            val bg = remember(item.bgColor) { statusBrush(item.bgColor) }
            Box(Modifier.fillMaxSize().background(bg), contentAlignment = Alignment.Center) {
                Text(
                    item.body, style = statusFont(item.font).style(28f),
                    modifier = Modifier.padding(start = 32.dp, end = 32.dp, bottom = 80.dp),
                )
            }
        }
        "photo" -> {
            val result by produceState<Any?>(null, item.mediaPath) {
                value = item.mediaPath?.let { StatusMedia.photo(it) } ?: "fail"
            }
            val r = result
            LaunchedEffect(r) { if (r != null) onReady() }
            when (r) {
                is Bitmap -> Image(r.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                null -> Loading()
                else -> Failed()
            }
        }
        else -> VideoContent(item.mediaPath, item.thumbPath, paused, progress, onReady, onVideoDone)
    }
}

@Composable
private fun VideoContent(
    path: String?,
    thumbPath: String?,
    paused: Boolean,
    progress: Animatable<Float, AnimationVector1D>,
    onReady: () -> Unit,
    onDone: () -> Unit,
) {
    val file by produceState<Any?>(null, path) { value = path?.let { StatusMedia.video(it) } ?: "fail" }
    val f = file
    val poster by produceState<Bitmap?>(null, thumbPath) { value = thumbPath?.let { StatusMedia.photo(it) } }
    var pos by remember { mutableFloatStateOf(0f) }
    var failed by remember { mutableStateOf(false) }
    LaunchedEffect(pos) { progress.snapTo(pos) }

    when {
        f == null -> Box(Modifier.fillMaxSize()) {
            // Show the thumbnail right away instead of a black screen while the video arrives
            poster?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit) }
            Loading()
        }
        f is File && !failed -> VideoPlayer(
            file = f,
            playing = !paused,
            modifier = Modifier.fillMaxSize(),
            onReady = onReady,
            onProgress = { pos = it },
            onDone = onDone,
            onFailed = {
                failed = true
                f.delete() // a bad download should be fetched again next time
            },
        )
        else -> {
            LaunchedEffect(Unit) {
                onReady()
                delay(STILL_MS.toLong())
                onDone()
            }
            Failed()
        }
    }
}

/**
 * Plays a local MP4 on a TextureView. (VideoView draws on a SurfaceView, which often shows
 * a black rectangle when it sits inside Compose.)
 */
@Composable
private fun VideoPlayer(
    file: File,
    playing: Boolean,
    modifier: Modifier = Modifier.fillMaxSize(),
    loop: Boolean = false,
    onReady: () -> Unit = {},
    onProgress: (Float) -> Unit = {},
    onDone: () -> Unit = {},
    onFailed: () -> Unit = {},
) {
    var player by remember(file.path) { mutableStateOf<MediaPlayer?>(null) }
    var ready by remember(file.path) { mutableStateOf(false) }
    var ratio by remember(file.path) { mutableFloatStateOf(9f / 16f) }
    val surfaceRef = remember(file.path) { arrayOfNulls<Surface>(1) }
    val playingNow by rememberUpdatedState(playing)
    val readyCb by rememberUpdatedState(onReady)
    val progressCb by rememberUpdatedState(onProgress)
    val doneCb by rememberUpdatedState(onDone)
    val failedCb by rememberUpdatedState(onFailed)

    fun release() {
        try { player?.release() } catch (_: Exception) { }
        try { surfaceRef[0]?.release() } catch (_: Exception) { }
        player = null
        surfaceRef[0] = null
        ready = false
    }

    DisposableEffect(file.path) { onDispose { release() } }

    // Play / pause whenever the caller asks
    LaunchedEffect(player, ready, playing) {
        val p = player ?: return@LaunchedEffect
        if (!ready) return@LaunchedEffect
        try {
            if (playing) {
                if (!p.isPlaying) p.start()
            } else if (p.isPlaying) {
                p.pause()
            }
        } catch (_: IllegalStateException) { }
    }

    // Report how far along the video is
    LaunchedEffect(player, ready) {
        val p = player ?: return@LaunchedEffect
        if (!ready) return@LaunchedEffect
        while (true) {
            try {
                val d = p.duration
                if (d > 0) progressCb(p.currentPosition / d.toFloat())
            } catch (_: IllegalStateException) {
                break
            }
            delay(50)
        }
    }

    Box(modifier, contentAlignment = Alignment.Center) {
        AndroidView(
            modifier = Modifier.aspectRatio(ratio),
            factory = { ctx ->
                TextureView(ctx).apply {
                    surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                        override fun onSurfaceTextureAvailable(st: SurfaceTexture, width: Int, height: Int) {
                            release()
                            val mp = MediaPlayer()
                            try {
                                val surface = Surface(st)
                                surfaceRef[0] = surface
                                mp.setSurface(surface)
                                mp.setDataSource(file.path)
                                mp.isLooping = loop
                                mp.setOnVideoSizeChangedListener { _, vw, vh ->
                                    if (vw > 0 && vh > 0) ratio = vw.toFloat() / vh
                                }
                                mp.setOnPreparedListener {
                                    ready = true
                                    if (playingNow) it.start()
                                    readyCb()
                                }
                                mp.setOnCompletionListener { doneCb() }
                                mp.setOnErrorListener { _, _, _ ->
                                    failedCb()
                                    true
                                }
                                mp.prepareAsync()
                                player = mp
                            } catch (e: Exception) {
                                try { mp.release() } catch (_: Exception) { }
                                failedCb()
                            }
                        }

                        override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, width: Int, height: Int) {}

                        override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean {
                            release()
                            return true
                        }

                        override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
                    }
                }
            },
        )
    }
}

@Composable
private fun Loading() {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        CircularProgressIndicator(color = Color.White, strokeWidth = 2.dp, modifier = Modifier.size(28.dp))
    }
}

@Composable
private fun Failed() {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text("Couldn't load this status", color = Color.White.copy(0.8f), fontSize = 15.sp)
    }
}

// ---------------------------------------------------------------------------------------------
// Composer
// ---------------------------------------------------------------------------------------------

private class PickedVideo(val file: File, val durationSecs: Double, val thumb: Bitmap?)

/** A small JPEG of the video's first frame, uploaded with the video so previews show instantly. */
private fun thumbJpeg(src: Bitmap): ByteArray? = try {
    val scale = 480f / maxOf(src.width, src.height)
    val b = if (scale >= 1f) {
        src
    } else {
        Bitmap.createScaledBitmap(src, (src.width * scale).toInt().coerceAtLeast(1), (src.height * scale).toInt().coerceAtLeast(1), true)
    }
    ByteArrayOutputStream().also { b.compress(Bitmap.CompressFormat.JPEG, 80, it) }.toByteArray()
} catch (e: Exception) {
    null
}

/** Photos are shrunk to at most ~2000 px and saved as JPEG. */
private fun loadStatusJpeg(context: Context, uri: Uri): ByteArray? = try {
    val src = ImageDecoder.createSource(context.contentResolver, uri)
    val bmp = ImageDecoder.decodeBitmap(src) { decoder, info, _ ->
        decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
        decoder.setTargetSampleSize(maxOf(1, maxOf(info.size.width, info.size.height) / 1600))
    }
    ByteArrayOutputStream().also { bmp.compress(Bitmap.CompressFormat.JPEG, 85, it) }.toByteArray()
} catch (e: Exception) {
    null
}

/** Checks a picked video (MP4, 30 seconds or less, 50 MB or less) and copies it to a temp file for upload. */
private fun inspectVideo(context: Context, uri: Uri): Result<PickedVideo> {
    if (context.contentResolver.getType(uri) != "video/mp4") {
        return Result.failure(Exception("Only MP4 videos are supported"))
    }
    val mmr = MediaMetadataRetriever()
    try {
        mmr.setDataSource(context, uri)
        val ms = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
            ?: return Result.failure(Exception("Couldn't read that video"))
        if (ms > 30_500) {
            return Result.failure(Exception("That video is ${ms / 1000} seconds. Statuses can be up to 30 seconds."))
        }
        val thumb = mmr.getFrameAtTime(0)
        val dir = File(context.cacheDir, "status").also { it.mkdirs() }
        val out = File(dir, "upload_${System.currentTimeMillis()}.mp4")
        val input = context.contentResolver.openInputStream(uri)
            ?: return Result.failure(Exception("Couldn't read that video"))
        input.use { src -> out.outputStream().use { src.copyTo(it) } }
        if (out.length() > StatusRepo.MAX_VIDEO_BYTES) {
            out.delete()
            return Result.failure(Exception("That video is too large (50 MB max)"))
        }
        return Result.success(PickedVideo(out, minOf(ms / 1000.0, StatusRepo.MAX_VIDEO_SECS), thumb))
    } catch (e: Exception) {
        return Result.failure(Exception("Couldn't read that video"))
    } finally {
        mmr.release()
    }
}

@Composable
fun StatusComposerScreen(onBack: () -> Unit) {
    LightSystemIcons()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var mode by remember { mutableStateOf("text") }
    var text by remember { mutableStateOf("") }
    var colorIdx by remember { mutableIntStateOf(0) }
    var fontIdx by remember { mutableIntStateOf(0) }
    var photo by remember { mutableStateOf<ByteArray?>(null) }
    var video by remember { mutableStateOf<PickedVideo?>(null) }
    var caption by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val focus = remember { FocusRequester() }

    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            scope.launch {
                busy = true
                val bytes = withContext(Dispatchers.IO) { loadStatusJpeg(context, uri) }
                busy = false
                if (bytes != null) {
                    video?.file?.delete()
                    video = null
                    photo = bytes
                    mode = "photo"
                    error = null
                } else {
                    error = "Couldn't open that photo"
                }
            }
        }
    }
    val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            scope.launch {
                busy = true
                val r = withContext(Dispatchers.IO) { inspectVideo(context, uri) }
                busy = false
                r.onSuccess {
                    video?.file?.delete()
                    video = it
                    photo = null
                    mode = "video"
                    error = null
                }.onFailure { error = it.message }
            }
        }
    }

    LaunchedEffect(mode) { if (mode == "text") focus.requestFocus() }

    val canPost = !busy && when (mode) {
        "text" -> text.isNotBlank()
        "photo" -> photo != null
        else -> video != null
    }

    fun post() {
        scope.launch {
            busy = true
            error = null
            try {
                when (mode) {
                    "text" -> StatusRepo.postText(text, StatusBackgrounds[colorIdx], StatusFonts[fontIdx].key)
                    "photo" -> StatusRepo.postPhoto(photo!!, caption)
                    else -> {
                        val tb = video!!.thumb?.let { withContext(Dispatchers.Default) { thumbJpeg(it) } }
                        StatusRepo.postVideo(video!!.file, video!!.durationSecs, caption, tb)
                    }
                }
                video?.file?.delete()
                StatusStore.refresh()
                onBack()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                error = e.message ?: "Couldn't post. Try again."
            } finally {
                busy = false
            }
        }
    }

    val bgBrush: Brush = if (mode == "text") statusBrush(StatusBackgrounds[colorIdx]) else SolidColor(Color.Black)
    val textFont = StatusFonts[fontIdx]

    var previewPlaying by remember { mutableStateOf(true) }

    // One column: top bar, content, controls. The content gets only the space that is left,
    // so text can never run underneath the controls or the keyboard.
    Column(
        Modifier
            .fillMaxSize()
            .background(bgBrush)
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding(),
    ) {
        // Top bar: close + title
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconTap(Icons.Rounded.Close, "Cancel", onBack)
            Spacer(Modifier.width(6.dp))
            Text("New status", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.weight(1f))
        }

        // Content
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when (mode) {
                "text" -> BoxWithConstraints(Modifier.fillMaxSize()) {
                    val minH = maxHeight
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .verticalScroll(rememberScrollState())
                            .heightIn(min = minH)
                            .padding(horizontal = 28.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        BasicTextField(
                            value = text,
                            onValueChange = { if (it.length <= 700) text = it },
                            textStyle = textFont.style(28f),
                            cursorBrush = SolidColor(Color.White),
                            modifier = Modifier.fillMaxWidth().focusRequester(focus),
                            decorationBox = { inner ->
                                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                                    if (text.isEmpty()) {
                                        Text("Type a status", style = textFont.style(28f, Color.White.copy(0.6f)))
                                    }
                                    inner()
                                }
                            },
                        )
                    }
                }
                "photo" -> {
                    val bmp = remember(photo) { photo?.let { BitmapFactory.decodeByteArray(it, 0, it.size)?.asImageBitmap() } }
                    if (bmp != null) Image(bmp, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                }
                else -> Box(
                    Modifier
                        .fillMaxSize()
                        .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                            previewPlaying = !previewPlaying
                        },
                    contentAlignment = Alignment.Center,
                ) {
                    video?.let { v ->
                        VideoPlayer(
                            file = v.file,
                            playing = previewPlaying,
                            loop = true,
                            modifier = Modifier.fillMaxSize(),
                            onFailed = { error = "Couldn't preview this video on this phone" },
                        )
                        Text(
                            "${v.durationSecs.toInt()}s", color = Color.White, fontSize = 13.sp,
                            modifier = Modifier.align(Alignment.TopEnd).padding(top = 8.dp, end = 20.dp),
                        )
                    }
                    if (!previewPlaying) {
                        Box(Modifier.size(64.dp).clip(CircleShape).background(Color.Black.copy(0.45f)), contentAlignment = Alignment.Center) {
                            Icon(Icons.Rounded.PlayArrow, null, tint = Color.White, modifier = Modifier.size(36.dp))
                        }
                    }
                }
            }
        }

        // Bottom controls
        Column(
            Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            error?.let {
                Text(it, color = Color(0xFFFFB4B4), fontSize = 14.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            }
            if (mode != "text") {
                StatusPill(
                    value = caption,
                    onValueChange = { if (it.length <= 300) caption = it },
                    placeholder = "Add a caption",
                )
            } else {
                // Backgrounds, then fonts
                Row(
                    Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    StatusBackgrounds.forEachIndexed { j, bgs ->
                        Box(
                            Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(statusBrush(bgs))
                                .border(if (j == colorIdx) 2.5.dp else 1.dp, if (j == colorIdx) Color.White else Color.White.copy(0.4f), CircleShape)
                                .pressable(0.88f, haptic = true) { colorIdx = j },
                        )
                    }
                }
                Row(
                    Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    StatusFonts.forEachIndexed { j, f ->
                        val on = j == fontIdx
                        Box(
                            Modifier
                                .height(36.dp)
                                .clip(RoundedCornerShape(18.dp))
                                .background(if (on) Color.White else Color.White.copy(0.16f))
                                .pressable(0.94f, haptic = true) { fontIdx = j }
                                .padding(horizontal = 16.dp),
                            contentAlignment = Alignment.Center,
                        ) {
                            Text(
                                f.label, color = if (on) Color.Black else Color.White, fontSize = 15.sp,
                                fontFamily = f.family, fontWeight = f.weight,
                            )
                        }
                    }
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally)) {
                ModePill("Text", mode == "text") { mode = "text"; error = null }
                ModePill("Photo", mode == "photo") {
                    photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                }
                ModePill("Video", mode == "video") {
                    videoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly))
                }
            }
            Text(
                "Visible to your contacts for 24 hours" + if (mode == "video") " · videos up to 30 seconds" else "",
                color = Color.White.copy(0.7f), fontSize = 12.sp, textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth(),
            )
            PrimaryButton(if (busy) "Please wait…" else "Post status", enabled = canPost) { post() }
        }
    }
}

@Composable
private fun ModePill(label: String, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    Box(
        Modifier
            .height(36.dp)
            .pressable(0.94f, haptic = true, onClick = onClick)
            .clip(shape)
            .background(if (selected) Color.White else Color.White.copy(0.16f))
            .padding(horizontal = 18.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            label, fontSize = 14.sp, fontWeight = FontWeight.Medium,
            color = if (selected) Color.Black else Color.White,
        )
    }
}
