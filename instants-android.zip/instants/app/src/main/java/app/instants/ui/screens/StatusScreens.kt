package app.instants.ui.screens

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.widget.VideoView
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.AnimationVector1D
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import app.instants.data.Session
import app.instants.data.StatusColors
import app.instants.data.StatusItem
import app.instants.data.StatusMedia
import app.instants.data.StatusRepo
import app.instants.data.StatusStore
import app.instants.data.listLabel
import app.instants.ui.components.PrimaryButton
import app.instants.ui.components.ProfileAvatar
import app.instants.ui.components.pressable
import app.instants.ui.theme.Palette
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File

private const val STILL_MS = 5000 // how long a text or photo status stays up

// ---------------------------------------------------------------------------------------------
// Status row on the chats tab
// ---------------------------------------------------------------------------------------------

@Composable
fun StatusRow(onAdd: () -> Unit, onOpen: (String) -> Unit) {
    LaunchedEffect(Unit) {
        while (true) {
            StatusStore.refresh()
            delay(30_000)
        }
    }
    val mine = StatusStore.mine
    Row(
        Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        StatusCard("Add status", "", null, ring = null, plus = true, onClick = onAdd)
        if (mine != null) {
            StatusCard("You", mine.initials, mine.profile?.avatarPath, ring = Palette.AccentSoft, plus = false) {
                Session.userId?.let(onOpen)
            }
        }
        StatusStore.groups.forEach { g ->
            val ring = if (StatusStore.hasUnseen(g)) Palette.Accent else null
            StatusCard(g.name, g.initials, g.profile?.avatarPath, ring, plus = false) { onOpen(g.userId) }
        }
    }
}

@Composable
private fun StatusCard(
    label: String,
    initials: String,
    avatarPath: String?,
    ring: Color?,
    plus: Boolean,
    onClick: () -> Unit,
) {
    val shape = RoundedCornerShape(20.dp)
    Column(
        Modifier
            .width(76.dp)
            .height(96.dp)
            .pressable(0.94f, haptic = true, onClick = onClick)
            .clip(shape)
            .background(Palette.Glass)
            .border(1.dp, Palette.GlassBorder, shape)
            .padding(horizontal = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        if (plus) {
            Box(Modifier.size(44.dp).clip(CircleShape).background(Palette.Accent), contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.Add, null, tint = Color.White, modifier = Modifier.size(22.dp))
            }
        } else {
            Box(Modifier.size(50.dp).border(2.dp, ring ?: Palette.Hairline, CircleShape).padding(3.dp)) {
                ProfileAvatar(initials, 44.dp, avatarPath)
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(
            label, color = Palette.TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Medium,
            maxLines = 1, overflow = TextOverflow.Ellipsis,
        )
    }
}

// ---------------------------------------------------------------------------------------------
// Viewer
// ---------------------------------------------------------------------------------------------

/** The system bar icons are dark on the light theme; flip them to white while a dark full-screen page is open. */
@Composable
private fun LightSystemIcons() {
    val view = LocalView.current
    DisposableEffect(Unit) {
        val activity = generateSequence(view.context) { (it as? ContextWrapper)?.baseContext }
            .filterIsInstance<Activity>().firstOrNull()
        val controller = activity?.window?.let { WindowCompat.getInsetsController(it, view) }
        controller?.isAppearanceLightStatusBars = false
        controller?.isAppearanceLightNavigationBars = false
        onDispose {
            controller?.isAppearanceLightStatusBars = !Palette.dark
            controller?.isAppearanceLightNavigationBars = !Palette.dark
        }
    }
}

@Composable
fun StatusViewerScreen(userId: String, onClose: () -> Unit) {
    val group = if (userId == Session.userId) StatusStore.mine else StatusStore.groups.firstOrNull { it.userId == userId }
    if (group == null || group.items.isEmpty()) {
        LaunchedEffect(Unit) { onClose() }
        Box(Modifier.fillMaxSize().background(Color.Black))
        return
    }
    LightSystemIcons()

    val scope = rememberCoroutineScope()
    var index by remember(userId) {
        mutableIntStateOf(
            if (group.mine) 0 else group.items.indexOfFirst { it.id !in StatusStore.viewed }.coerceAtLeast(0),
        )
    }
    val i = index.coerceIn(0, group.items.lastIndex)
    val item = group.items[i]
    var paused by remember { mutableStateOf(false) }
    var ready by remember(item.id) { mutableStateOf(false) }
    val progress = remember(item.id) { Animatable(0f) }

    val goNext = rememberUpdatedState<() -> Unit> { if (i < group.items.lastIndex) index = i + 1 else onClose() }
    val goPrev = rememberUpdatedState<() -> Unit> { index = maxOf(0, i - 1) }

    LaunchedEffect(item.id) {
        if (!group.mine) StatusStore.markViewed(item.id)
    }

    // Text and photos run on a 5 second timer; videos drive the bar themselves.
    LaunchedEffect(item.id, ready, paused) {
        if (!ready || paused || item.kind == "video") return@LaunchedEffect
        val remaining = ((1f - progress.value) * STILL_MS).toInt().coerceAtLeast(1)
        progress.animateTo(1f, tween(remaining, easing = LinearEasing))
        goNext.value()
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        key(item.id) {
            StatusContent(item, paused, progress, onReady = { ready = true }, onVideoDone = { goNext.value() })
        }

        // Tap right = next, tap left = previous, hold = pause
        Box(
            Modifier.fillMaxSize().pointerInput(Unit) {
                detectTapGestures(
                    onPress = {
                        paused = true
                        tryAwaitRelease()
                        paused = false
                    },
                    onTap = { o -> if (o.x < size.width * 0.33f) goPrev.value() else goNext.value() },
                )
            },
        )

        // Top: progress segments and who posted
        Column(
            Modifier
                .fillMaxWidth()
                .background(Brush.verticalGradient(listOf(Color.Black.copy(0.45f), Color.Transparent)))
                .statusBarsPadding()
                .padding(horizontal = 10.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                group.items.forEachIndexed { j, _ ->
                    val frac = when {
                        j < i -> 1f
                        j == i -> progress.value
                        else -> 0f
                    }
                    Box(Modifier.weight(1f).height(3.dp).clip(CircleShape).background(Color.White.copy(0.3f))) {
                        Box(Modifier.fillMaxHeight().fillMaxWidth(frac).background(Color.White))
                    }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ProfileAvatar(group.initials, 36.dp, group.profile?.avatarPath)
                Column(Modifier.weight(1f)) {
                    Text(group.name, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                    Text(item.createdAt.listLabel(), color = Color.White.copy(0.75f), fontSize = 12.sp)
                }
                if (group.mine) {
                    IconTap(Icons.Rounded.Delete, "Delete status") {
                        scope.launch {
                            try {
                                StatusRepo.delete(item)
                                StatusStore.refresh()
                            } catch (e: CancellationException) {
                                throw e
                            } catch (e: Exception) {
                            }
                        }
                    }
                }
                IconTap(Icons.Rounded.Close, "Close", onClose)
            }
        }

        // Bottom: caption and (for my own) the view count
        val showCaption = item.kind != "text" && item.body.isNotBlank()
        if (showCaption || group.mine) {
            Column(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(0.6f))))
                    .navigationBarsPadding()
                    .padding(horizontal = 20.dp, vertical = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                if (showCaption) {
                    Text(item.body, color = Color.White, fontSize = 16.sp, lineHeight = 22.sp)
                }
                if (group.mine) {
                    val n = StatusStore.viewCounts[item.id] ?: 0
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Icon(Icons.Rounded.Visibility, null, tint = Color.White.copy(0.85f), modifier = Modifier.size(18.dp))
                        Text(
                            if (n == 1) "1 view" else "$n views",
                            color = Color.White.copy(0.85f), fontSize = 13.sp,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun IconTap(icon: androidx.compose.ui.graphics.vector.ImageVector, description: String, onClick: () -> Unit) {
    Box(
        Modifier.size(40.dp).clip(CircleShape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, description, tint = Color.White, modifier = Modifier.size(22.dp))
    }
}

@Composable
private fun StatusContent(
    item: StatusItem,
    paused: Boolean,
    progress: Animatable<Float, AnimationVector1D>,
    onReady: () -> Unit,
    onVideoDone: () -> Unit,
) {
    when (item.kind) {
        "text" -> {
            LaunchedEffect(Unit) { onReady() }
            val bg = remember(item.bgColor) {
                try { Color(android.graphics.Color.parseColor(item.bgColor ?: StatusColors[0])) } catch (e: Exception) { Color(0xFF4A72B8) }
            }
            Box(Modifier.fillMaxSize().background(bg), contentAlignment = Alignment.Center) {
                Text(
                    item.body, color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.SemiBold,
                    lineHeight = 36.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 32.dp),
                )
            }
        }
        "photo" -> {
            val result by produceState<Any?>(null, item.mediaPath) {
                value = item.mediaPath?.let { StatusMedia.photo(it) } ?: "fail"
            }
            val r = result
            LaunchedEffect(r) { if (r != null) onReady() }
            when (r) {
                is Bitmap -> Image(r.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                null -> Loading()
                else -> Failed()
            }
        }
        else -> VideoContent(item.mediaPath, paused, progress, onReady, onVideoDone)
    }
}

@Composable
private fun VideoContent(
    path: String?,
    paused: Boolean,
    progress: Animatable<Float, AnimationVector1D>,
    onReady: () -> Unit,
    onDone: () -> Unit,
) {
    val file by produceState<Any?>(null, path) { value = path?.let { StatusMedia.video(it) } ?: "fail" }
    val f = file
    var view by remember { mutableStateOf<VideoView?>(null) }

    LaunchedEffect(view) {
        val v = view ?: return@LaunchedEffect
        while (true) {
            val d = v.duration
            if (d > 0) progress.snapTo((v.currentPosition / d.toFloat()).coerceIn(0f, 1f))
            delay(40)
        }
    }
    DisposableEffect(view) { onDispose { view?.stopPlayback() } }

    when (f) {
        null -> Loading()
        is File -> AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                VideoView(ctx).apply {
                    setVideoPath(f.path)
                    setOnPreparedListener { mp ->
                        mp.isLooping = false
                        view = this
                        onReady()
                    }
                    setOnCompletionListener { onDone() }
                    setOnErrorListener { _, _, _ ->
                        onDone()
                        true
                    }
                }
            },
            update = { v ->
                if (paused) {
                    if (v.isPlaying) v.pause()
                } else if (!v.isPlaying) {
                    v.start()
                }
            },
        )
        else -> {
            LaunchedEffect(Unit) {
                onReady()
                delay(STILL_MS.toLong())
                onDone()
            }
            Failed()
        }
    }
}

@Composable
private fun Loading() {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        CircularProgressIndicator(color = Color.White, strokeWidth = 2.dp, modifier = Modifier.size(28.dp))
    }
}

@Composable
private fun Failed() {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text("Couldn't load this status", color = Color.White.copy(0.8f), fontSize = 15.sp)
    }
}

// ---------------------------------------------------------------------------------------------
// Composer
// ---------------------------------------------------------------------------------------------

private class PickedVideo(val file: File, val durationSecs: Double, val thumb: Bitmap?)

/** Photos are shrunk to at most ~2000 px and saved as JPEG. */
private fun loadStatusJpeg(context: Context, uri: Uri): ByteArray? = try {
    val src = ImageDecoder.createSource(context.contentResolver, uri)
    val bmp = ImageDecoder.decodeBitmap(src) { decoder, info, _ ->
        decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
        decoder.setTargetSampleSize(maxOf(1, maxOf(info.size.width, info.size.height) / 1600))
    }
    ByteArrayOutputStream().also { bmp.compress(Bitmap.CompressFormat.JPEG, 85, it) }.toByteArray()
} catch (e: Exception) {
    null
}

/** Checks a picked video (MP4, 30 seconds or less, 50 MB or less) and copies it to a temp file for upload. */
private fun inspectVideo(context: Context, uri: Uri): Result<PickedVideo> {
    if (context.contentResolver.getType(uri) != "video/mp4") {
        return Result.failure(Exception("Only MP4 videos are supported"))
    }
    val mmr = MediaMetadataRetriever()
    try {
        mmr.setDataSource(context, uri)
        val ms = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
            ?: return Result.failure(Exception("Couldn't read that video"))
        if (ms > 30_500) {
            return Result.failure(Exception("That video is ${ms / 1000} seconds. Statuses can be up to 30 seconds."))
        }
        val thumb = mmr.getFrameAtTime(0)
        val dir = File(context.cacheDir, "status").also { it.mkdirs() }
        val out = File(dir, "upload_${System.currentTimeMillis()}.mp4")
        val input = context.contentResolver.openInputStream(uri)
            ?: return Result.failure(Exception("Couldn't read that video"))
        input.use { src -> out.outputStream().use { src.copyTo(it) } }
        if (out.length() > StatusRepo.MAX_VIDEO_BYTES) {
            out.delete()
            return Result.failure(Exception("That video is too large (50 MB max)"))
        }
        return Result.success(PickedVideo(out, minOf(ms / 1000.0, StatusRepo.MAX_VIDEO_SECS), thumb))
    } catch (e: Exception) {
        return Result.failure(Exception("Couldn't read that video"))
    } finally {
        mmr.release()
    }
}

@Composable
fun StatusComposerScreen(onBack: () -> Unit) {
    LightSystemIcons()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var mode by remember { mutableStateOf("text") }
    var text by remember { mutableStateOf("") }
    var colorIdx by remember { mutableIntStateOf(0) }
    var photo by remember { mutableStateOf<ByteArray?>(null) }
    var video by remember { mutableStateOf<PickedVideo?>(null) }
    var caption by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val focus = remember { FocusRequester() }

    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            scope.launch {
                busy = true
                val bytes = withContext(Dispatchers.IO) { loadStatusJpeg(context, uri) }
                busy = false
                if (bytes != null) {
                    video?.file?.delete()
                    video = null
                    photo = bytes
                    mode = "photo"
                    error = null
                } else {
                    error = "Couldn't open that photo"
                }
            }
        }
    }
    val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            scope.launch {
                busy = true
                val r = withContext(Dispatchers.IO) { inspectVideo(context, uri) }
                busy = false
                r.onSuccess {
                    video?.file?.delete()
                    video = it
                    photo = null
                    mode = "video"
                    error = null
                }.onFailure { error = it.message }
            }
        }
    }

    LaunchedEffect(mode) { if (mode == "text") focus.requestFocus() }

    val canPost = !busy && when (mode) {
        "text" -> text.isNotBlank()
        "photo" -> photo != null
        else -> video != null
    }

    fun post() {
        scope.launch {
            busy = true
            error = null
            try {
                when (mode) {
                    "text" -> StatusRepo.postText(text, StatusColors[colorIdx])
                    "photo" -> StatusRepo.postPhoto(photo!!, caption)
                    else -> StatusRepo.postVideo(video!!.file, video!!.durationSecs, caption)
                }
                video?.file?.delete()
                StatusStore.refresh()
                onBack()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                error = e.message ?: "Couldn't post. Try again."
            } finally {
                busy = false
            }
        }
    }

    val bg = if (mode == "text") {
        Color(android.graphics.Color.parseColor(StatusColors[colorIdx]))
    } else {
        Color.Black
    }

    Box(Modifier.fillMaxSize().background(bg)) {
        // Content
        when (mode) {
            "text" -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                BasicTextField(
                    value = text,
                    onValueChange = { if (it.length <= 700) text = it },
                    textStyle = TextStyle(
                        color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.SemiBold,
                        lineHeight = 36.sp, textAlign = TextAlign.Center,
                    ),
                    cursorBrush = SolidColor(Color.White),
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 28.dp).focusRequester(focus),
                    decorationBox = { inner ->
                        Box(contentAlignment = Alignment.Center) {
                            if (text.isEmpty()) {
                                Text(
                                    "Type a status", color = Color.White.copy(0.6f), fontSize = 28.sp,
                                    fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center,
                                )
                            }
                            inner()
                        }
                    },
                )
            }
            "photo" -> {
                val bmp = remember(photo) { photo?.let { BitmapFactory.decodeByteArray(it, 0, it.size)?.asImageBitmap() } }
                if (bmp != null) Image(bmp, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
            }
            else -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                video?.thumb?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit) }
                Box(Modifier.size(64.dp).clip(CircleShape).background(Color.Black.copy(0.45f)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.PlayArrow, null, tint = Color.White, modifier = Modifier.size(36.dp))
                }
                video?.let {
                    Text(
                        "${it.durationSecs.toInt()}s", color = Color.White, fontSize = 13.sp,
                        modifier = Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(top = 64.dp, end = 20.dp),
                    )
                }
            }
        }

        // Top bar
        Row(
            Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconTap(Icons.Rounded.Close, "Cancel", onBack)
            Spacer(Modifier.width(6.dp))
            Text("New status", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
        }

        // Bottom controls
        Column(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .navigationBarsPadding()
                .imePadding()
                .padding(horizontal = 20.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            error?.let {
                Text(it, color = Color(0xFFFFB4B4), fontSize = 14.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            }
            if (mode == "text") {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                    StatusColors.forEachIndexed { idx, hex ->
                        Box(
                            Modifier
                                .padding(horizontal = 5.dp)
                                .size(28.dp)
                                .clip(CircleShape)
                                .background(Color(android.graphics.Color.parseColor(hex)))
                                .border(2.dp, if (idx == colorIdx) Color.White else Color.White.copy(0.25f), CircleShape)
                                .clickable { colorIdx = idx },
                        )
                    }
                }
            } else {
                BasicTextField(
                    value = caption,
                    onValueChange = { if (it.length <= 300) caption = it },
                    textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
                    cursorBrush = SolidColor(Color.White),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(22.dp))
                        .background(Color.White.copy(0.16f))
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    decorationBox = { inner ->
                        Box {
                            if (caption.isEmpty()) Text("Add a caption", color = Color.White.copy(0.6f), fontSize = 16.sp)
                            inner()
                        }
                    },
                )
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally)) {
                ModePill("Text", mode == "text") { mode = "text"; error = null }
                ModePill("Photo", mode == "photo") {
                    photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                }
                ModePill("Video", mode == "video") {
                    videoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly))
                }
            }
            if (mode == "video" || mode == "photo" || mode == "text") {
                Text(
                    "Visible to your contacts for 24 hours" + if (mode == "video") " · videos up to 30 seconds" else "",
                    color = Color.White.copy(0.7f), fontSize = 12.sp, textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            PrimaryButton(if (busy) "Please wait…" else "Post status", enabled = canPost) { post() }
        }
    }
}

@Composable
private fun ModePill(label: String, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    Box(
        Modifier
            .height(36.dp)
            .pressable(0.94f, haptic = true, onClick = onClick)
            .clip(shape)
            .background(if (selected) Color.White else Color.White.copy(0.16f))
            .padding(horizontal = 18.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            label, fontSize = 14.sp, fontWeight = FontWeight.Medium,
            color = if (selected) Color.Black else Color.White,
        )
    }
}
