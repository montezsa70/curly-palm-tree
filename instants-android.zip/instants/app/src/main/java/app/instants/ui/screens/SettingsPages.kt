package app.instants.ui.screens

import android.text.format.DateUtils
import android.text.format.Formatter
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.instants.backup.BackupCrypto
import app.instants.backup.BackupManager
import app.instants.backup.BackupPrefs
import app.instants.backup.BackupSchedule
import app.instants.backup.DriveClient
import app.instants.backup.NeedsSignInException
import app.instants.backup.RemoteBackup
import app.instants.backup.WrongPasswordException
import app.instants.data.Store
import app.instants.data.UserSettings
import app.instants.ui.AppLock
import app.instants.ui.components.ChoiceSheet
import app.instants.ui.components.PrimaryButton
import app.instants.ui.components.ScreenHeader
import app.instants.ui.components.staggerIn
import app.instants.ui.theme.Palette
import app.instants.ui.theme.ThemePrefs
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.Instant

/** The frame every settings page shares: a header with a back arrow and a scrolling body. */
@Composable
private fun SettingsPage(title: String, onBack: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().background(Palette.Background)) {
        ScreenHeader(title, onBack)
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .navigationBarsPadding()
                .padding(horizontal = 20.dp)
                .padding(bottom = 24.dp),
            content = content,
        )
    }
}

@Composable
private fun Footnote(text: String) {
    Text(
        text,
        color = Palette.TextSecondary,
        fontSize = 12.sp,
        lineHeight = 17.sp,
        modifier = Modifier.padding(start = 4.dp, end = 4.dp, top = 8.dp),
    )
}

// ---------------------------------------------------------------------------------------------
// Privacy
// ---------------------------------------------------------------------------------------------

@Composable
fun PrivacyPage(onBack: () -> Unit, onNavigate: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    var sheet by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(Unit) {
        Store.refreshMe()
        Store.refreshSocial()
    }
    val s = Store.me?.settings ?: UserSettings()
    fun update(next: UserSettings) { scope.launch { Store.updateSettings(next) } }

    SettingsPage("Privacy", onBack) {
        SettingsGroup("WHO CAN SEE WHAT", 0) {
            NavRow("Last seen & active status", labelOf(lastSeenOptions, s.lastSeen)) { sheet = "lastSeen" }
            Divider()
            NavRow("Close friends", "${Store.closeFriendIds.size}") { onNavigate("closeFriends") }
            Divider()
            NavRow("Who can find me", labelOf(findMeOptions, s.findMe)) { sheet = "findMe" }
        }
        SettingsGroup("MESSAGING", 1) {
            ToggleRow("Read receipts", s.readReceipts) { update(s.copy(readReceipts = it)) }
            Divider()
            NavRow("Blocked contacts", "${Store.blockedIds.size}") { onNavigate("blocked") }
        }
        Footnote("If you hide your last seen or turn off read receipts, you won’t see theirs either.")
    }

    when (sheet) {
        "lastSeen" -> ChoiceSheet(
            title = "Last seen & active status",
            options = lastSeenOptions,
            selected = s.lastSeen,
            footer = "Applies to both. If you hide yours from someone, you won’t see theirs either.",
            onSelect = { update(s.copy(lastSeen = it)) },
            onDismiss = { sheet = null },
        )
        "findMe" -> ChoiceSheet(
            title = "Who can find me",
            options = findMeOptions,
            selected = s.findMe,
            footer = "With “Nobody”, your invite codes stop working until you switch back.",
            onSelect = { update(s.copy(findMe = it)) },
            onDismiss = { sheet = null },
        )
    }
}

// ---------------------------------------------------------------------------------------------
// Security, Chats, Appearance
// ---------------------------------------------------------------------------------------------

@Composable
fun SecurityPage(onBack: () -> Unit) {
    val context = LocalContext.current
    SettingsPage("Security", onBack) {
        SettingsGroup("LOCK", 0) {
            ToggleRow("App lock", AppLock.enabled) { on ->
                if (on && !AppLock.canUse(context)) {
                    Toast.makeText(context, "Set up a screen lock or fingerprint on your phone first.", Toast.LENGTH_LONG).show()
                } else {
                    AppLock.set(on)
                }
            }
        }
        Footnote("Ask for your fingerprint, face or screen lock when you open Instants.")
    }
}

@Composable
fun ChatsSettingsPage(onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    var sheet by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(Unit) { Store.refreshMe() }
    val s = Store.me?.settings ?: UserSettings()

    SettingsPage("Chats", onBack) {
        SettingsGroup("MESSAGES", 0) {
            NavRow("Disappearing messages", labelOf(disappearOptions, s.disappearSecs.toString())) { sheet = "disappear" }
        }
    }

    if (sheet == "disappear") {
        ChoiceSheet(
            title = "Disappearing messages",
            options = disappearOptions,
            selected = s.disappearSecs.toString(),
            footer = "Messages you send are deleted after this time. Messages already sent aren’t affected.",
            onSelect = { scope.launch { Store.updateSettings(s.copy(disappearSecs = it.toInt())) } },
            onDismiss = { sheet = null },
        )
    }
}

@Composable
fun AppearancePage(onBack: () -> Unit) {
    var sheet by remember { mutableStateOf(false) }
    SettingsPage("Appearance", onBack) {
        SettingsGroup("LOOK", 0) {
            NavRow("Theme", labelOf(themeOptions, ThemePrefs.mode)) { sheet = true }
        }
    }
    if (sheet) {
        ChoiceSheet(
            title = "Theme",
            options = themeOptions,
            selected = ThemePrefs.mode,
            onSelect = { ThemePrefs.set(it) },
            onDismiss = { sheet = false },
        )
    }
}

// ---------------------------------------------------------------------------------------------
// Chat backup
// ---------------------------------------------------------------------------------------------

private fun friendly(e: Exception): String = when {
    e is NeedsSignInException -> "Reconnect Google Drive to continue."
    e is WrongPasswordException -> "That password doesn’t open this backup."
    // 10 is Google’s "developer error": the app’s signature isn’t registered for Google sign-in yet
    e is com.google.android.gms.common.api.ApiException && e.statusCode == 10 ->
        "Google Drive isn’t set up for this build yet (the app’s signing fingerprint isn’t registered)."
    e is com.google.android.gms.common.api.ApiException && e.statusCode == 12501 -> "Connecting to Google Drive was cancelled."
    else -> e.message ?: "Something went wrong."
}

@Composable
fun BackupPage(onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var sheet by remember { mutableStateOf(false) }
    var dialog by remember { mutableStateOf<String?>(null) } // "password" or "restore"
    var restoreInfo by remember { mutableStateOf<RemoteBackup?>(null) }
    var message by remember { mutableStateOf<String?>(null) }
    var pending by remember { mutableStateOf<(suspend (String) -> Unit)?>(null) }

    // Google's consent screen, shown the first time (or if the permission was removed)
    val consent = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result ->
        val action = pending
        pending = null
        scope.launch {
            try {
                val token = DriveClient.tokenFrom(context, result.data)
                BackupPrefs.setConnected(true)
                BackupSchedule.apply(context)
                message = null
                action?.invoke(token)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                message = friendly(e)
            }
        }
    }

    /** Runs [action] with a Google access token, asking for permission first if needed. */
    fun withDrive(action: suspend (String) -> Unit) {
        scope.launch {
            try {
                message = null
                when (val a = DriveClient.authorize(context)) {
                    is DriveClient.Auth.Token -> {
                        BackupPrefs.setConnected(true)
                        BackupSchedule.apply(context)
                        action(a.token)
                    }
                    is DriveClient.Auth.NeedsConsent -> {
                        pending = action
                        consent.launch(IntentSenderRequest.Builder(a.intent.intentSender).build())
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                message = friendly(e)
            }
        }
    }

    val running = BackupManager.running
    val lastBackup = if (BackupPrefs.lastAt == 0L) {
        "Never"
    } else {
        DateUtils.formatDateTime(
            context, BackupPrefs.lastAt,
            DateUtils.FORMAT_SHOW_DATE or DateUtils.FORMAT_SHOW_TIME or DateUtils.FORMAT_ABBREV_MONTH,
        ) + " · " + Formatter.formatShortFileSize(context, BackupPrefs.lastSize)
    }

    SettingsPage("Chat backup", onBack) {
        SettingsGroup("GOOGLE DRIVE", 0) {
            NavRow("Google Drive", if (BackupPrefs.connected) "Connected" else "Connect") { withDrive { } }
            Divider()
            NavRow("Backup password", if (BackupPrefs.passwordSet) "Change" else "Set") { dialog = "password" }
        }
        Footnote("Backups are locked with your backup password on this phone, then saved in a hidden folder in your own Google Drive. Instants can’t read them.")

        SettingsGroup("BACK UP", 1) {
            NavRow("Last backup", lastBackup) { }
            Divider()
            NavRow("Back up automatically", labelOf(backupFrequencyOptions, BackupPrefs.frequency)) { sheet = true }
            Divider()
            ToggleRow("Include photos, voice notes & documents", BackupPrefs.includeMedia) { BackupPrefs.setIncludeMedia(it) }
            Divider()
            ToggleRow("Back up over mobile data", BackupPrefs.mobileData) {
                BackupPrefs.setMobileData(it)
                BackupSchedule.apply(context)
            }
        }
        Footnote("Automatic backups run when the phone is on Wi-Fi (unless you allow mobile data) and the battery isn’t low.")

        Spacer(Modifier.height(16.dp))
        PrimaryButton(if (running) "Backing up…" else "Back up now", Modifier.staggerIn(2), enabled = !running) {
            if (!BackupPrefs.passwordSet) {
                message = "Set a backup password first."
            } else {
                withDrive { token ->
                    BackupManager.backupNow(context, token)
                    BackupSchedule.apply(context)
                    message = "Backup complete."
                }
            }
        }

        val note = message ?: BackupManager.status.takeIf { it.isNotBlank() }
        if (note != null) {
            Text(
                note,
                color = Palette.TextSecondary,
                fontSize = 13.sp,
                lineHeight = 18.sp,
                modifier = Modifier.padding(start = 4.dp, end = 4.dp, top = 10.dp),
            )
        }

        SettingsGroup("RESTORE", 3) {
            NavRow("Restore from Google Drive", "") {
                if (running) return@NavRow
                withDrive { token ->
                    val latest = BackupManager.listBackups(token).firstOrNull()
                    if (latest == null) {
                        message = "No backup found in this Google account."
                    } else {
                        restoreInfo = latest
                        dialog = "restore"
                    }
                }
            }
        }
        Footnote(
            "Photos, voice notes and documents are removed from our servers once they reach the other person’s phone, " +
                "so a backup is how you keep them on a new phone. If you forget the password, a backup can’t be opened.",
        )
    }

    if (sheet) {
        ChoiceSheet(
            title = "Back up automatically",
            options = backupFrequencyOptions,
            selected = BackupPrefs.frequency,
            footer = "Needs Google Drive connected and a backup password.",
            onSelect = { v ->
                if (v != "off" && !(BackupPrefs.connected && BackupPrefs.passwordSet)) {
                    message = "Connect Google Drive and set a backup password first."
                } else {
                    BackupPrefs.setFrequency(v)
                    BackupSchedule.apply(context)
                }
            },
            onDismiss = { sheet = false },
        )
    }

    when (dialog) {
        "password" -> PasswordDialog(
            title = if (BackupPrefs.passwordSet) "Change backup password" else "Set a backup password",
            message = "You’ll need this to restore a backup on a new phone. Instants can’t recover it, so keep it somewhere safe.",
            confirm = true,
            action = "Save",
            onSubmit = { pw ->
                dialog = null
                scope.launch {
                    withContext(Dispatchers.Default) { BackupCrypto.setPassword(pw.toCharArray()) }
                    BackupSchedule.apply(context)
                    message = "Backup password saved. Backups made before this still need the old password."
                }
            },
            onDismiss = { dialog = null },
        )
        "restore" -> PasswordDialog(
            title = "Restore from Google Drive",
            message = "Latest backup: ${describe(context, restoreInfo)}. Enter the backup password you used.",
            confirm = false,
            action = "Restore",
            onSubmit = { pw ->
                dialog = null
                scope.launch {
                    message = try {
                        val r = BackupManager.restore(context, pw.toCharArray())
                        "Restored ${r.messages} messages and ${r.files} files."
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        friendly(e)
                    }
                }
            },
            onDismiss = { dialog = null },
        )
    }
}

private fun describe(context: android.content.Context, b: RemoteBackup?): String {
    if (b == null) return "unknown"
    val whenText = try {
        DateUtils.formatDateTime(
            context, Instant.parse(b.modified).toEpochMilli(),
            DateUtils.FORMAT_SHOW_DATE or DateUtils.FORMAT_SHOW_TIME or DateUtils.FORMAT_ABBREV_MONTH,
        )
    } catch (e: Exception) {
        b.name
    }
    return whenText + " · " + Formatter.formatShortFileSize(context, b.size)
}

@Composable
private fun PasswordDialog(
    title: String,
    message: String,
    confirm: Boolean,
    action: String,
    onSubmit: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    var pw by remember { mutableStateOf("") }
    var again by remember { mutableStateOf("") }
    val tooShort = confirm && pw.isNotEmpty() && pw.length < 8
    val mismatch = confirm && again.isNotEmpty() && pw != again
    val valid = pw.isNotEmpty() && (!confirm || (pw.length >= 8 && pw == again))
    val fieldColors = OutlinedTextFieldDefaults.colors(
        focusedTextColor = Palette.TextPrimary,
        unfocusedTextColor = Palette.TextPrimary,
        focusedBorderColor = Palette.Accent,
        unfocusedBorderColor = Palette.Hairline,
        focusedLabelColor = Palette.TextSecondary,
        unfocusedLabelColor = Palette.TextSecondary,
        cursorColor = Palette.Accent,
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Palette.Background,
        title = { Text(title, color = Palette.TextPrimary) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(message, color = Palette.TextSecondary, fontSize = 14.sp, lineHeight = 20.sp)
                OutlinedTextField(
                    value = pw,
                    onValueChange = { pw = it },
                    label = { Text("Password") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    colors = fieldColors,
                )
                if (confirm) {
                    OutlinedTextField(
                        value = again,
                        onValueChange = { again = it },
                        label = { Text("Confirm password") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        colors = fieldColors,
                    )
                }
                if (tooShort) Text("Use at least 8 characters.", color = Palette.EndCall, fontSize = 13.sp)
                if (mismatch) Text("The passwords don’t match.", color = Palette.EndCall, fontSize = 13.sp)
            }
        },
        confirmButton = {
            TextButton(onClick = { onSubmit(pw) }, enabled = valid) { Text(action, color = if (valid) Palette.Accent else Palette.TextSecondary) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel", color = Palette.TextSecondary) }
        },
    )
}
