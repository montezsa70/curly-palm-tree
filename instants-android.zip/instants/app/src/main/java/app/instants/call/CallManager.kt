package app.instants.call

import android.Manifest
import android.app.Application
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.ToneGenerator
import android.media.projection.MediaProjection
import android.os.SystemClock
import android.util.Log
import android.view.WindowManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import app.instants.data.Api
import app.instants.data.CallEntry
import app.instants.data.CallLog
import app.instants.data.ApiException
import app.instants.data.Realtime
import app.instants.data.Session
import app.instants.data.initialsOf
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONArray
import org.json.JSONObject
import org.webrtc.AudioSource
import org.webrtc.AudioTrack
import org.webrtc.DefaultVideoDecoderFactory
import org.webrtc.DefaultVideoEncoderFactory
import org.webrtc.EglBase
import org.webrtc.IceCandidate
import org.webrtc.MediaConstraints
import org.webrtc.MediaStream
import org.webrtc.MediaStreamTrack
import org.webrtc.PeerConnection
import org.webrtc.PeerConnectionFactory
import org.webrtc.RtpReceiver
import org.webrtc.RtpSender
import org.webrtc.RtpTransceiver
import org.webrtc.ScreenCapturerAndroid
import org.webrtc.SdpObserver
import org.webrtc.SessionDescription
import org.webrtc.SurfaceTextureHelper
import org.webrtc.VideoSource
import org.webrtc.VideoTrack
import org.webrtc.audio.JavaAudioDeviceModule
import java.util.TreeMap
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

enum class CallPhase { Idle, Outgoing, Incoming, Connecting, Connected, Ended }

fun hasMicPermission(context: Context): Boolean =
    ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

/**
 * One voice call at a time (with optional screen sharing), peer to peer over WebRTC.
 *
 *  - Signaling (offer / answer / ICE / "I'm sharing my screen") goes through Supabase: the `call_signal` function writes it,
 *    Supabase Realtime delivers it ([Realtime.callEvents]). A 4 s poll of the same rows covers a dropped socket.
 *  - Media goes directly between the phones, or through the Cloudflare TURN relay (credentials from the `turn-credentials` function).
 *  - The other phone is woken with a high-priority Firebase push (`call-push` function) and shows [IncomingCallScreen].
 *
 * Screen sharing needs no renegotiation: the first offer already contains a send+receive video line with no track on it,
 * and sharing just puts a screen track on it (and taking it off again stops it).
 */
object CallManager {
    private const val TAG = "CallManager"
    private const val RING_TIMEOUT_MS = 45_000L
    private const val INCOMING_TIMEOUT_MS = 50_000L
    private const val CONNECT_TIMEOUT_MS = 25_000L

    // ---- state the screens read -------------------------------------------------------------

    var phase by mutableStateOf(CallPhase.Idle)
        private set
    var peerName by mutableStateOf("")
        private set
    var peerAvatarPath by mutableStateOf<String?>(null)
        private set
    var muted by mutableStateOf(false)
        private set
    var speakerOn by mutableStateOf(false)
        private set
    var reconnecting by mutableStateOf(false)
        private set
    var sharingScreen by mutableStateOf(false)
        private set
    var peerSharing by mutableStateOf(false)
        private set
    var remoteVideo by mutableStateOf<VideoTrack?>(null)
        private set
    var connectedAtMs by mutableLongStateOf(0L)
        private set
    var endText by mutableStateOf("Call ended")
        private set

    /** True from the moment screen capture was allowed until it stops. The service reads it to add the projection type. */
    var projectionActive by mutableStateOf(false)
        private set

    val peerInitials: String get() = initialsOf(peerName)
    var chatId: String? = null
        private set
    val currentCallId: String? get() = callId

    /** Shared with the video renderers. */
    val eglBase: EglBase by lazy { EglBase.create() }

    // ---- internals ---------------------------------------------------------------------------

    private lateinit var app: Application
    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var callScope: CoroutineScope? = null

    private var callId: String? = null
    private var incoming = false
    private var isCaller = false
    private var accepting = false
    private var ending = false

    private var factory: PeerConnectionFactory? = null
    private var audioModule: JavaAudioDeviceModule? = null
    private var pc: PeerConnection? = null
    private var audioSource: AudioSource? = null
    private var audioTrack: AudioTrack? = null
    private var videoSender: RtpSender? = null

    private var screenCapturer: ScreenCapturerAndroid? = null
    private var screenHelper: SurfaceTextureHelper? = null
    private var screenSource: VideoSource? = null
    private var screenTrack: VideoTrack? = null
    private var pendingProjection: Intent? = null

    @Volatile private var remoteSet = false
    @Volatile private var tracksReady = false
    @Volatile private var iceUp = false
    @Volatile private var canSendIce = false
    private val pendingIce = ArrayList<IceCandidate>()

    private val signalBuffer = TreeMap<Long, Pair<String, JSONObject>>()
    private val appliedSignals = HashSet<Long>()
    private val drainLock = Mutex()

    private var outbox = Channel<Pair<String, JSONObject>>(Channel.UNLIMITED)
    private val iceOut = ArrayList<JSONObject>()
    private var iceFlushScheduled = false

    private var ringJob: Job? = null
    private var connectJob: Job? = null
    private var pollJob: Job? = null
    private var recoverJob: Job? = null

    private var tone: ToneGenerator? = null
    private var focus: AudioFocusRequest? = null

    fun init(application: Application) {
        app = application
    }

    // ---- starting and answering ---------------------------------------------------------------

    /** Starts calling the other person in this one-to-one chat. False if a call is already going. */
    @Synchronized
    fun startOutgoing(chat: String, name: String, avatarPath: String? = null): Boolean {
        if (phase != CallPhase.Idle || Session.userId == null) return false
        beginCall(incomingCall = false, id = null, chat = chat, name = name, avatar = avatarPath)
        changePhase(CallPhase.Outgoing)
        CallService.start(app, CallService.ACTION_SYNC)
        val scope = callScope ?: return false
        scope.launch { runOutgoing(chat) }
        return true
    }

    /** A "incoming_call" push arrived (the app may have been closed a second ago). */
    fun onIncomingPush(data: Map<String, String>) {
        val id = data["call_id"] ?: return
        if (Session.userId == null) return
        var busy = false
        synchronized(this) {
            if (phase != CallPhase.Idle) {
                busy = true
            } else {
                val name = data["caller_name"]?.takeIf { it.isNotBlank() } ?: "Instants"
                val avatar = data["avatar_path"]?.takeIf { it.isNotBlank() }
                beginCall(incomingCall = true, id = id, chat = data["chat_id"], name = name, avatar = avatar)
                changePhase(CallPhase.Incoming)
            }
        }
        if (busy) {
            // Already on another call: tell the caller we are busy (unless this is the call we are already in).
            if (id != callId) {
                appScope.launch {
                    try {
                        Api.rpc("end_call", JSONObject().put("_call_id", id).put("_status", "busy"))
                    } catch (_: Exception) {
                    }
                }
            }
            return
        }
        CallService.start(app, CallService.ACTION_SYNC)
        Realtime.start()
        subscribeEvents()
        val scope = callScope ?: return
        ringJob = scope.launch {
            delay(INCOMING_TIMEOUT_MS)
            if (phase == CallPhase.Incoming) remoteGaveUp()
        }
        scope.launch {
            // The push can arrive late, or the caller may already have given up: check before ringing on.
            try {
                if (fetchStatus(id) != "ringing") {
                    remoteGaveUp()
                    return@launch
                }
            } catch (_: Exception) {
            }
            startPolling()
        }
    }

    /** A "call_cancelled" push arrived. */
    fun onCancelPush(id: String?) {
        if (id != null && id == callId && phase == CallPhase.Incoming) remoteGaveUp()
    }

    /** The person tapped Accept (microphone permission must already be granted). */
    fun accept() {
        synchronized(this) {
            if (phase != CallPhase.Incoming || accepting) return
            accepting = true
            changePhase(CallPhase.Connecting)
        }
        ringJob?.cancel()
        val scope = callScope ?: return
        scope.launch {
            try {
                val id = callId ?: return@launch
                Api.rpc("answer_call", JSONObject().put("_call_id", id))
                enterCallAudio()
                val ice = loadIceServers(id)
                buildPeer(ice)
                catchUpSignals()
                drain()
                connectJob = scope.launch {
                    delay(CONNECT_TIMEOUT_MS)
                    if (phase == CallPhase.Connecting) endCall("Couldn't connect", "failed", pushCancel = false)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                fail(e)
            }
        }
    }

    fun decline() {
        if (phase != CallPhase.Incoming) return
        endCall("Declined", "declined", pushCancel = false, quick = true)
    }

    fun hangUp() {
        when (phase) {
            CallPhase.Incoming -> decline()
            CallPhase.Outgoing -> endCall("Call ended", "cancelled", pushCancel = true)
            CallPhase.Connecting, CallPhase.Connected -> endCall("Call ended", "ended", pushCancel = false)
            else -> Unit
        }
    }

    /**
     * Muting is done in the audio device, which keeps the microphone running and just sends silence. Switching the
     * track off instead makes WebRTC stop and restart the recorder, and Android then re-picks the audio route
     * (often the loudspeaker), which is what made the ringing suddenly louder.
     */
    fun toggleMute() {
        muted = !muted
        applyMute()
        reapplyRouteSoon()
    }

    fun toggleSpeaker() {
        speakerOn = !speakerOn
        applySpeaker()
        reapplyRouteSoon()
    }

    private fun applyMute() {
        try {
            audioModule?.setMicrophoneMute(muted)
        } catch (_: Exception) {
        }
    }

    /** Audio changes can move the route a moment later; say again where the sound should go. */
    private fun reapplyRouteSoon() {
        callScope?.launch {
            delay(250)
            applySpeaker()
            delay(900)
            applySpeaker()
        }
    }

    // ---- outgoing flow ------------------------------------------------------------------------

    private suspend fun runOutgoing(chat: String) {
        try {
            Realtime.start()
            val id = Api.rpc("start_call", JSONObject().put("_chat_id", chat)).trim().trim('"')
            callId = id
            if (phase != CallPhase.Outgoing) {
                // Hung up before the server even answered: close the call that was just created.
                try {
                    Api.rpc("end_call", JSONObject().put("_call_id", id).put("_status", "cancelled"))
                } catch (_: Exception) {
                }
                return
            }
            val scope = callScope ?: return
            enterCallAudio()
            startRingback()
            subscribeEvents()
            startPolling()
            // Wake the other phone while the connection is being prepared.
            scope.launch { pushCall(id, "ring") }
            ringJob = scope.launch {
                delay(RING_TIMEOUT_MS)
                if (phase == CallPhase.Outgoing) endCall("No answer", "missed", pushCancel = true)
            }

            val ice = loadIceServers(id)
            buildPeer(ice)
            val p = pc ?: return
            val offer = p.awaitOffer()
            p.awaitSetLocal(offer)
            sendSignal("offer", JSONObject().put("sdp", offer.description))
            localDescriptionSent()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            fail(e)
        }
    }

    private fun onAccepted() {
        if (phase != CallPhase.Outgoing) return
        ringJob?.cancel()
        stopRingback()
        changePhase(CallPhase.Connecting)
        val scope = callScope ?: return
        connectJob = scope.launch {
            delay(CONNECT_TIMEOUT_MS)
            if (phase == CallPhase.Connecting) endCall("Couldn't connect", "failed", pushCancel = false)
        }
    }

    // ---- server events (Realtime + polling) ---------------------------------------------------

    private fun subscribeEvents() {
        val scope = callScope ?: return
        // UNDISPATCHED: the collector is registered before this returns, so nothing emitted after it is missed.
        scope.launch(start = CoroutineStart.UNDISPATCHED) {
            Realtime.callEvents.collect { onEvent(it) }
        }
    }

    private fun onEvent(ev: Realtime.CallEvent) {
        when (ev.table) {
            "calls" -> {
                if (ev.record.optString("id") == callId) applyStatus(ev.record.optString("status"))
            }
            "call_signals" -> {
                if (ev.type != "INSERT") return
                val r = ev.record
                if (r.optString("call_id") != callId) return
                val payload = r.optJSONObject("payload") ?: return
                queueSignal(r.optLong("id", -1L), r.optString("kind"), payload)
            }
            "resync" -> callScope?.launch { pollOnce() }
        }
    }

    private fun applyStatus(status: String) {
        when (status) {
            "accepted" -> if (isCaller) onAccepted()
            "declined" -> endCall("Declined", null, pushCancel = false)
            "busy" -> endCall("Busy", null, pushCancel = false)
            "missed", "cancelled" ->
                if (incoming && phase == CallPhase.Incoming) remoteGaveUp()
                else endCall(if (status == "missed") "No answer" else "Call ended", null, pushCancel = false)
            "ended" -> endCall("Call ended", null, pushCancel = false)
        }
    }

    private fun startPolling() {
        val scope = callScope ?: return
        pollJob?.cancel()
        pollJob = scope.launch {
            while (isActive) {
                delay(4_000)
                pollOnce()
            }
        }
    }

    private fun pollOnce() {
        val id = callId ?: return
        try {
            val status = fetchStatus(id)
            if (status.isNotEmpty()) applyStatus(status)
            if (pc != null && !remoteSet) catchUpSignals()
        } catch (_: Exception) {
        }
    }

    private fun fetchStatus(id: String): String {
        val rows = JSONArray(Api.call("GET", "/rest/v1/calls?id=eq.$id&select=status"))
        return if (rows.length() > 0) rows.getJSONObject(0).optString("status") else ""
    }

    private fun catchUpSignals() {
        val id = callId ?: return
        val rows = JSONArray(Api.call("GET", "/rest/v1/call_signals?call_id=eq.$id&select=id,kind,payload&order=id.asc"))
        for (i in 0 until rows.length()) {
            val r = rows.getJSONObject(i)
            val payload = r.optJSONObject("payload") ?: continue
            if (payload.length() == 0) continue // wiped after the call ended
            queueSignal(r.getLong("id"), r.getString("kind"), payload)
        }
    }

    // ---- signals in -------------------------------------------------------------------------

    private fun queueSignal(id: Long, kind: String, payload: JSONObject) {
        if (id < 0) return
        synchronized(signalBuffer) {
            if (id in appliedSignals || signalBuffer.containsKey(id)) return
            signalBuffer[id] = kind to payload
        }
        drain()
    }

    /** Applies buffered signals in order. Before the peer connection exists (callee still ringing) they simply wait. */
    private fun drain() {
        if (pc == null) return
        val scope = callScope ?: return
        scope.launch {
            drainLock.withLock {
                while (true) {
                    val entry = synchronized(signalBuffer) {
                        val e = signalBuffer.pollFirstEntry()
                        if (e != null) appliedSignals.add(e.key)
                        e
                    } ?: break
                    try {
                        handleSignal(entry.value.first, entry.value.second)
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        Log.w(TAG, "signal ${entry.value.first} failed: ${e.message}")
                    }
                }
            }
        }
    }

    private suspend fun handleSignal(kind: String, payload: JSONObject) {
        when (kind) {
            "offer" -> if (!isCaller) handleOffer(payload.getString("sdp"))
            "answer" -> if (isCaller) handleAnswer(payload.getString("sdp"))
            "ice" -> handleIce(payload.optJSONArray("c"))
            "screen" -> peerSharing = payload.optBoolean("on", false)
        }
    }

    private suspend fun handleOffer(sdp: String) {
        val p = pc ?: return
        p.awaitSetRemote(SessionDescription(SessionDescription.Type.OFFER, sdp))
        remoteSet = true
        flushPendingIce(p)
        if (!tracksReady) {
            audioTrack?.let { p.addTrack(it, listOf("instants")) }
            p.transceivers.firstOrNull { it.mediaType == MediaStreamTrack.MediaType.MEDIA_TYPE_VIDEO }?.let {
                it.setDirection(RtpTransceiver.RtpTransceiverDirection.SEND_RECV)
                videoSender = it.sender
            }
            tracksReady = true
        }
        val answer = p.awaitAnswer()
        p.awaitSetLocal(answer)
        sendSignal("answer", JSONObject().put("sdp", answer.description))
        localDescriptionSent()
    }

    private suspend fun handleAnswer(sdp: String) {
        val p = pc ?: return
        if (p.signalingState() != PeerConnection.SignalingState.HAVE_LOCAL_OFFER) return
        p.awaitSetRemote(SessionDescription(SessionDescription.Type.ANSWER, sdp))
        remoteSet = true
        flushPendingIce(p)
    }

    private fun handleIce(list: JSONArray?) {
        val p = pc ?: return
        if (list == null) return
        for (i in 0 until list.length()) {
            val o = list.optJSONObject(i) ?: continue
            val cand = IceCandidate(o.optString("m"), o.optInt("i"), o.optString("c"))
            if (remoteSet) p.addIceCandidate(cand) else synchronized(pendingIce) { pendingIce.add(cand) }
        }
    }

    private fun flushPendingIce(p: PeerConnection) {
        val list = synchronized(pendingIce) {
            val copy = ArrayList(pendingIce)
            pendingIce.clear()
            copy
        }
        list.forEach { p.addIceCandidate(it) }
    }

    // ---- signals out ------------------------------------------------------------------------

    private fun startSender() {
        val scope = callScope ?: return
        val channel = outbox
        scope.launch {
            for ((kind, payload) in channel) {
                val id = callId ?: continue
                var tries = 0
                while (tries < 2) {
                    try {
                        Api.rpc(
                            "call_signal",
                            JSONObject().put("_call_id", id).put("_kind", kind).put("_payload", payload),
                        )
                        break
                    } catch (e: ApiException) {
                        if (e.code in 400..499) break // call is over or the request is wrong: retrying will not help
                        tries++
                        delay(500)
                    } catch (e: CancellationException) {
                        throw e
                    } catch (_: Exception) {
                        tries++
                        delay(500)
                    }
                }
            }
        }
    }

    private fun sendSignal(kind: String, payload: JSONObject) {
        outbox.trySend(kind to payload)
    }

    private fun queueLocalIce(c: IceCandidate) {
        val o = JSONObject().put("m", c.sdpMid).put("i", c.sdpMLineIndex).put("c", c.sdp)
        synchronized(iceOut) { iceOut.add(o) }
        scheduleIceFlush()
    }

    private fun scheduleIceFlush() {
        if (!canSendIce) return
        synchronized(iceOut) {
            if (iceFlushScheduled || iceOut.isEmpty()) return
            iceFlushScheduled = true
        }
        callScope?.launch {
            delay(120) // candidates come in bursts: send them together
            val batch = JSONArray()
            synchronized(iceOut) {
                iceOut.forEach { batch.put(it) }
                iceOut.clear()
                iceFlushScheduled = false
            }
            if (batch.length() > 0) sendSignal("ice", JSONObject().put("c", batch))
        }
    }

    /** Candidates only go out after the offer / answer they belong to. */
    private fun localDescriptionSent() {
        canSendIce = true
        scheduleIceFlush()
    }

    private fun pushCall(id: String, event: String) {
        try {
            Api.call("POST", "/functions/v1/call-push", JSONObject().put("call_id", id).put("event", event))
        } catch (e: Exception) {
            Log.w(TAG, "call-push $event failed: ${e.message}")
        }
    }

    // ---- WebRTC -----------------------------------------------------------------------------

    @Synchronized
    private fun ensureFactory(): PeerConnectionFactory {
        val existing = factory
        if (existing != null) return existing
        PeerConnectionFactory.initialize(
            PeerConnectionFactory.InitializationOptions.builder(app).createInitializationOptions(),
        )
        val audio = JavaAudioDeviceModule.builder(app).createAudioDeviceModule()
        audioModule = audio
        val f = PeerConnectionFactory.builder()
            .setAudioDeviceModule(audio)
            .setVideoEncoderFactory(DefaultVideoEncoderFactory(eglBase.eglBaseContext, true, true))
            .setVideoDecoderFactory(DefaultVideoDecoderFactory(eglBase.eglBaseContext))
            .createPeerConnectionFactory()
        factory = f
        return f
    }

    private fun loadIceServers(id: String): List<PeerConnection.IceServer> {
        val servers = ArrayList<PeerConnection.IceServer>()
        try {
            val res = JSONObject(Api.call("POST", "/functions/v1/turn-credentials", JSONObject().put("call_id", id)))
            val arr = res.getJSONArray("iceServers")
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val urls = ArrayList<String>()
                val raw = o.opt("urls")
                if (raw is JSONArray) {
                    for (j in 0 until raw.length()) urls.add(raw.getString(j))
                } else if (raw is String) {
                    urls.add(raw)
                }
                if (urls.isEmpty()) continue
                val b = PeerConnection.IceServer.builder(urls)
                val user = o.optString("username", "")
                val cred = o.optString("credential", "")
                if (user.isNotEmpty()) b.setUsername(user)
                if (cred.isNotEmpty()) b.setPassword(cred)
                servers.add(b.createIceServer())
            }
        } catch (e: Exception) {
            Log.w(TAG, "TURN credentials unavailable, using STUN only: ${e.message}")
        }
        if (servers.isEmpty()) {
            servers.add(PeerConnection.IceServer.builder("stun:stun.cloudflare.com:3478").createIceServer())
        }
        return servers
    }

    private fun buildPeer(ice: List<PeerConnection.IceServer>) {
        val f = ensureFactory()
        val config = PeerConnection.RTCConfiguration(ice).apply {
            sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
            continualGatheringPolicy = PeerConnection.ContinualGatheringPolicy.GATHER_CONTINUALLY
            bundlePolicy = PeerConnection.BundlePolicy.MAXBUNDLE
            rtcpMuxPolicy = PeerConnection.RtcpMuxPolicy.REQUIRE
        }
        val peer = f.createPeerConnection(config, observer)
            ?: throw IllegalStateException("Could not start the call")
        val source = f.createAudioSource(MediaConstraints())
        val track = f.createAudioTrack("instants-audio", source)
        track.setEnabled(true)
        audioSource = source
        audioTrack = track
        if (isCaller) {
            peer.addTrack(track, listOf("instants"))
            val video = peer.addTransceiver(
                MediaStreamTrack.MediaType.MEDIA_TYPE_VIDEO,
                RtpTransceiver.RtpTransceiverInit(RtpTransceiver.RtpTransceiverDirection.SEND_RECV),
            )
            videoSender = video.sender
        }
        pc = peer
        applyMute()
        reapplyRouteSoon()
    }

    private val observer = object : PeerConnection.Observer {
        override fun onSignalingChange(state: PeerConnection.SignalingState?) {}

        override fun onIceConnectionChange(state: PeerConnection.IceConnectionState?) {
            onIceState(state)
        }

        override fun onIceConnectionReceivingChange(receiving: Boolean) {}
        override fun onIceGatheringChange(state: PeerConnection.IceGatheringState?) {}

        override fun onIceCandidate(candidate: IceCandidate?) {
            if (candidate != null) queueLocalIce(candidate)
        }

        override fun onIceCandidatesRemoved(candidates: Array<out IceCandidate>?) {}
        override fun onAddStream(stream: MediaStream?) {}
        override fun onRemoveStream(stream: MediaStream?) {}
        override fun onDataChannel(channel: org.webrtc.DataChannel?) {}
        override fun onRenegotiationNeeded() {}
        override fun onAddTrack(receiver: RtpReceiver?, streams: Array<out MediaStream>?) {}

        override fun onTrack(transceiver: RtpTransceiver?) {
            val t = transceiver?.receiver?.track()
            if (t is VideoTrack) {
                t.setEnabled(true)
                remoteVideo = t
            }
        }
    }

    private fun onIceState(state: PeerConnection.IceConnectionState?) {
        when (state) {
            PeerConnection.IceConnectionState.CONNECTED,
            PeerConnection.IceConnectionState.COMPLETED -> onMediaUp()
            PeerConnection.IceConnectionState.DISCONNECTED -> onMediaDown(4_000)
            PeerConnection.IceConnectionState.FAILED -> onMediaDown(0)
            else -> Unit
        }
    }

    private fun onMediaUp() {
        iceUp = true
        recoverJob?.cancel()
        reconnecting = false
        if (phase == CallPhase.Outgoing || phase == CallPhase.Connecting) {
            ringJob?.cancel()
            connectJob?.cancel()
            stopRingback()
            connectedAtMs = SystemClock.elapsedRealtime()
            changePhase(CallPhase.Connected)
            // Lets the server time the call (the chat entry shows how long it lasted) and tell it from one that never connected.
            val id = callId
            if (id != null) {
                callScope?.launch {
                    try {
                        Api.rpc("call_connected", JSONObject().put("_call_id", id))
                    } catch (_: Exception) {
                    }
                }
            }
            applySpeaker()
        }
    }

    /**
     * The network dropped or switched (Wi-Fi to mobile data, say). The caller restarts ICE with a fresh offer every 8 s;
     * the other side answers. If nothing works within about 25 s the call ends.
     */
    private fun onMediaDown(waitMs: Long) {
        iceUp = false
        if (phase == CallPhase.Connected) reconnecting = true
        if (recoverJob?.isActive == true) return
        val scope = callScope ?: return
        recoverJob = scope.launch {
            delay(waitMs)
            var tries = 0
            while (isActive && !iceUp) {
                if (isCaller) restartIceOffer()
                tries++
                delay(8_000)
                if (!iceUp && tries >= 3) {
                    endCall("Connection lost", "ended", pushCancel = false)
                    return@launch
                }
            }
        }
    }

    private suspend fun restartIceOffer() {
        val p = pc ?: return
        drainLock.withLock {
            if (p.signalingState() == PeerConnection.SignalingState.STABLE) {
                p.restartIce()
                val offer = p.awaitOffer()
                p.awaitSetLocal(offer)
                sendSignal("offer", JSONObject().put("sdp", offer.description))
            }
        }
    }

    private open class SdpAdapter : SdpObserver {
        override fun onCreateSuccess(sdp: SessionDescription?) {}
        override fun onSetSuccess() {}
        override fun onCreateFailure(error: String?) {}
        override fun onSetFailure(error: String?) {}
    }

    private suspend fun PeerConnection.awaitOffer(): SessionDescription = suspendCancellableCoroutine { cont ->
        createOffer(
            object : SdpAdapter() {
                override fun onCreateSuccess(sdp: SessionDescription?) {
                    if (sdp != null) cont.resume(sdp) else cont.resumeWithException(IllegalStateException("empty offer"))
                }

                override fun onCreateFailure(error: String?) {
                    cont.resumeWithException(IllegalStateException("offer failed: $error"))
                }
            },
            MediaConstraints(),
        )
    }

    private suspend fun PeerConnection.awaitAnswer(): SessionDescription = suspendCancellableCoroutine { cont ->
        createAnswer(
            object : SdpAdapter() {
                override fun onCreateSuccess(sdp: SessionDescription?) {
                    if (sdp != null) cont.resume(sdp) else cont.resumeWithException(IllegalStateException("empty answer"))
                }

                override fun onCreateFailure(error: String?) {
                    cont.resumeWithException(IllegalStateException("answer failed: $error"))
                }
            },
            MediaConstraints(),
        )
    }

    private suspend fun PeerConnection.awaitSetLocal(sdp: SessionDescription): Unit = suspendCancellableCoroutine { cont ->
        setLocalDescription(
            object : SdpAdapter() {
                override fun onSetSuccess() {
                    cont.resume(Unit)
                }

                override fun onSetFailure(error: String?) {
                    cont.resumeWithException(IllegalStateException("local description failed: $error"))
                }
            },
            sdp,
        )
    }

    private suspend fun PeerConnection.awaitSetRemote(sdp: SessionDescription): Unit = suspendCancellableCoroutine { cont ->
        setRemoteDescription(
            object : SdpAdapter() {
                override fun onSetSuccess() {
                    cont.resume(Unit)
                }

                override fun onSetFailure(error: String?) {
                    cont.resumeWithException(IllegalStateException("remote description failed: $error"))
                }
            },
            sdp,
        )
    }

    // ---- screen sharing ---------------------------------------------------------------------

    /** Called with the result of the system "start recording / casting" dialog. */
    fun startScreenShare(permission: Intent) {
        synchronized(this) {
            if (phase != CallPhase.Connected || sharingScreen || projectionActive) return
            pendingProjection = permission
            projectionActive = true
        }
        // The service must be in the foreground with the media projection type before capture can begin;
        // it calls beginCapture() once it is.
        CallService.start(app, CallService.ACTION_PROJECTION)
    }

    fun beginCapture() {
        val data = pendingProjection ?: return
        pendingProjection = null
        val f = factory
        val sender = videoSender
        if (f == null || sender == null || phase != CallPhase.Connected) {
            abortCapture()
            return
        }
        val scope = callScope ?: return
        scope.launch {
            try {
                val bounds = app.getSystemService(WindowManager::class.java).maximumWindowMetrics.bounds
                val scale = minOf(1f, 1280f / maxOf(bounds.width(), bounds.height()))
                val w = (bounds.width() * scale).toInt() and -2
                val h = (bounds.height() * scale).toInt() and -2

                val helper = SurfaceTextureHelper.create("instants-screen", eglBase.eglBaseContext)
                val source = f.createVideoSource(true)
                val capturer = ScreenCapturerAndroid(
                    data,
                    object : MediaProjection.Callback() {
                        override fun onStop() {
                            stopScreenShare()
                        }
                    },
                )
                capturer.initialize(helper, app, source.capturerObserver)
                capturer.startCapture(w, h, 15)
                val track = f.createVideoTrack("instants-screen", source)
                track.setEnabled(true)
                sender.setTrack(track, false)
                capSendBitrate(sender)

                screenHelper = helper
                screenSource = source
                screenCapturer = capturer
                screenTrack = track
                sharingScreen = true
                sendSignal("screen", JSONObject().put("on", true))
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.w(TAG, "screen capture failed: ${e.message}")
                stopScreenInternal(signal = false)
            }
        }
    }

    fun abortCapture() {
        pendingProjection = null
        projectionActive = false
        CallService.sync()
    }

    fun stopScreenShare() {
        appScope.launch { stopScreenInternal(signal = phase != CallPhase.Ended) }
    }

    @Synchronized
    private fun stopScreenInternal(signal: Boolean) {
        if (screenCapturer == null && screenTrack == null && !projectionActive) return
        try { videoSender?.setTrack(null, false) } catch (_: Exception) { }
        try { screenCapturer?.stopCapture() } catch (_: Exception) { }
        try { screenCapturer?.dispose() } catch (_: Exception) { }
        try { screenTrack?.dispose() } catch (_: Exception) { }
        try { screenSource?.dispose() } catch (_: Exception) { }
        try { screenHelper?.dispose() } catch (_: Exception) { }
        screenCapturer = null
        screenTrack = null
        screenSource = null
        screenHelper = null
        pendingProjection = null
        val wasSharing = sharingScreen
        sharingScreen = false
        projectionActive = false
        if (signal && wasSharing) sendSignal("screen", JSONObject().put("on", false))
        CallService.sync()
    }

    private fun capSendBitrate(sender: RtpSender) {
        try {
            val params = sender.parameters
            params.encodings.forEach { it.maxBitrateBps = 2_500_000 }
            sender.setParameters(params)
        } catch (_: Exception) {
        }
    }

    // ---- audio ------------------------------------------------------------------------------

    private val headsetTypes = setOf(
        AudioDeviceInfo.TYPE_BLE_HEADSET,
        AudioDeviceInfo.TYPE_BLUETOOTH_SCO,
        AudioDeviceInfo.TYPE_WIRED_HEADSET,
        AudioDeviceInfo.TYPE_WIRED_HEADPHONES,
        AudioDeviceInfo.TYPE_USB_HEADSET,
    )

    private fun enterCallAudio() {
        try {
            val am = app.getSystemService(AudioManager::class.java)
            am.mode = AudioManager.MODE_IN_COMMUNICATION
            val request = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build(),
                )
                .setOnAudioFocusChangeListener { }
                .build()
            focus = request
            am.requestAudioFocus(request)
            applySpeaker()
        } catch (e: Exception) {
            Log.w(TAG, "audio setup failed: ${e.message}")
        }
    }

    /** Speaker when switched on; otherwise a connected headset, otherwise the earpiece. */
    private fun applySpeaker() {
        try {
            val am = app.getSystemService(AudioManager::class.java)
            val devices = am.availableCommunicationDevices
            val wanted = if (speakerOn) {
                devices.firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER }
            } else {
                devices.firstOrNull { it.type in headsetTypes }
                    ?: devices.firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_EARPIECE }
            }
            val routed = wanted != null && am.setCommunicationDevice(wanted)
            if (!routed) {
                @Suppress("DEPRECATION")
                am.isSpeakerphoneOn = speakerOn
            }
        } catch (_: Exception) {
        }
    }

    private fun exitCallAudio() {
        try {
            val am = app.getSystemService(AudioManager::class.java)
            am.clearCommunicationDevice()
            focus?.let { am.abandonAudioFocusRequest(it) }
            focus = null
            am.mode = AudioManager.MODE_NORMAL
        } catch (_: Exception) {
        }
    }

    private fun startRingback() {
        try {
            val t = ToneGenerator(AudioManager.STREAM_VOICE_CALL, 60)
            t.startTone(ToneGenerator.TONE_SUP_RINGTONE)
            tone = t
        } catch (_: Exception) {
        }
    }

    private fun stopRingback() {
        try {
            tone?.stopTone()
            tone?.release()
        } catch (_: Exception) {
        }
        tone = null
    }

    // ---- ending -----------------------------------------------------------------------------

    private fun fail(e: Exception) {
        Log.w(TAG, "call failed: ${e.message}", e)
        val text = if (e is ApiException && e.message?.isNotBlank() == true) e.message!! else "Call failed"
        endCall(text, "failed", pushCancel = false)
    }

    /** The caller gave up (or never got through) while this phone was still ringing. */
    private fun remoteGaveUp() {
        if (phase != CallPhase.Incoming) return
        val name = peerName
        val chat = chatId
        endCall("Missed call", null, pushCancel = false, quick = true)
        CallService.notifyMissed(app, name, chat)
    }

    /**
     * serverStatus: what to tell the server (null = the server already knows). pushCancel: also push "call_cancelled"
     * to the other phone. quick: close the screen right away instead of showing "Call ended" for a moment.
     */
    private fun endCall(text: String, serverStatus: String?, pushCancel: Boolean, quick: Boolean = false) {
        var id: String? = null
        synchronized(this) {
            if (phase == CallPhase.Idle || phase == CallPhase.Ended || ending) return
            ending = true
            id = callId
            endText = text
            changePhase(CallPhase.Ended)
        }
        val finishedId = id
        rememberInHistory(finishedId, text, serverStatus)
        callScope?.cancel()

        if (finishedId != null && (serverStatus != null || pushCancel)) {
            appScope.launch {
                if (serverStatus != null) {
                    try {
                        Api.rpc("end_call", JSONObject().put("_call_id", finishedId).put("_status", serverStatus))
                    } catch (_: Exception) {
                    }
                }
                if (pushCancel) pushCall(finishedId, "cancel")
            }
        }
        appScope.launch {
            cleanupMedia()
            if (!quick) delay(900)
            synchronized(this@CallManager) {
                resetFields()
                changePhase(CallPhase.Idle)
            }
        }
    }

    /** Puts the call in the history right away; the server's copy replaces this one a moment later. */
    private fun rememberInHistory(id: String?, text: String, serverStatus: String?) {
        val chat = chatId ?: return
        if (id == null) return
        val connectedFor = if (connectedAtMs > 0) ((SystemClock.elapsedRealtime() - connectedAtMs) / 1000).toInt() else -1
        val status = when {
            connectedFor >= 0 -> "ended"
            serverStatus != null -> serverStatus
            text == "Declined" -> "declined"
            text == "Busy" -> "busy"
            text == "No answer" -> "missed"
            text == "Missed call" -> "missed"
            else -> return
        }
        CallLog.addLocal(
            CallEntry(
                id = id, chatId = chat, outgoing = !incoming, status = status,
                startedAt = java.time.Instant.now(), seconds = connectedFor.coerceAtLeast(0),
            ),
        )
    }

    private fun cleanupMedia() {
        stopScreenInternal(signal = false)
        stopRingback()
        try { pc?.close() } catch (_: Exception) { }
        try { pc?.dispose() } catch (_: Exception) { }
        pc = null
        try { audioTrack?.dispose() } catch (_: Exception) { }
        try { audioSource?.dispose() } catch (_: Exception) { }
        try { audioModule?.setMicrophoneMute(false) } catch (_: Exception) { }
        audioTrack = null
        audioSource = null
        videoSender = null
        remoteVideo = null
        outbox.close()
        exitCallAudio()
    }

    // ---- bookkeeping ------------------------------------------------------------------------

    private fun beginCall(incomingCall: Boolean, id: String?, chat: String?, name: String, avatar: String?) {
        resetFields()
        peerAvatarPath = avatar
        incoming = incomingCall
        isCaller = !incomingCall
        callId = id
        chatId = chat
        peerName = name
        outbox = Channel(Channel.UNLIMITED)
        callScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        startSender()
    }

    private fun resetFields() {
        callScope?.cancel()
        callScope = null
        callId = null
        chatId = null
        incoming = false
        isCaller = false
        accepting = false
        ending = false
        muted = false
        speakerOn = false
        reconnecting = false
        sharingScreen = false
        peerSharing = false
        projectionActive = false
        remoteVideo = null
        connectedAtMs = 0L
        endText = "Call ended"
        peerName = ""
        peerAvatarPath = null
        remoteSet = false
        tracksReady = false
        iceUp = false
        canSendIce = false
        iceFlushScheduled = false
        pendingProjection = null
        synchronized(pendingIce) { pendingIce.clear() }
        synchronized(iceOut) { iceOut.clear() }
        synchronized(signalBuffer) {
            signalBuffer.clear()
            appliedSignals.clear()
        }
        ringJob = null
        connectJob = null
        pollJob = null
        recoverJob = null
    }

    @Synchronized
    private fun changePhase(next: CallPhase) {
        phase = next
        CallService.sync()
    }
}
