package app.instants.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.time.Duration
import java.time.Instant
import java.time.OffsetDateTime

/** One finished call, from my point of view. */
data class CallEntry(
    val id: String,
    val chatId: String,
    val outgoing: Boolean,
    val status: String, // ended | missed | cancelled | declined | busy | failed
    val startedAt: Instant,
    val seconds: Int,
) {
    val wentWrong: Boolean get() = status == "failed" || (!outgoing && status in setOf("missed", "cancelled", "busy"))

    /** "Outgoing · 1:33", "Missed", "No answer", "Couldn't connect"... */
    val summary: String
        get() = when (status) {
            "ended" -> (if (outgoing) "Outgoing" else "Incoming") + " · " + formatDuration(seconds * 1000L)
            "declined" -> "Declined"
            "cancelled" -> if (outgoing) "Cancelled" else "Missed"
            "missed" -> if (outgoing) "No answer" else "Missed"
            "busy" -> if (outgoing) "Busy" else "Missed"
            "failed" -> "Couldn't connect"
            else -> "Call"
        }
}

object CallLog {
    /** My finished calls, newest first. The server only returns calls I was on. */
    suspend fun load(): List<CallEntry> = withContext(Dispatchers.IO) {
        val me = Session.userId ?: return@withContext emptyList()
        val rows = JSONArray(
            Api.call(
                "GET",
                "/rest/v1/calls?select=id,chat_id,caller_id,status,created_at,connected_at,ended_at" +
                    "&status=not.in.(ringing,accepted)&order=created_at.desc&limit=100",
            ),
        )
        val out = ArrayList<CallEntry>()
        for (i in 0 until rows.length()) {
            val r = rows.getJSONObject(i)
            val started = OffsetDateTime.parse(r.getString("created_at")).toInstant()
            val seconds = if (!r.isNull("connected_at") && !r.isNull("ended_at")) {
                Duration.between(
                    OffsetDateTime.parse(r.getString("connected_at")).toInstant(),
                    OffsetDateTime.parse(r.getString("ended_at")).toInstant(),
                ).seconds.toInt().coerceAtLeast(0)
            } else {
                0
            }
            out.add(
                CallEntry(
                    id = r.getString("id"),
                    chatId = r.getString("chat_id"),
                    outgoing = r.getString("caller_id") == me,
                    status = r.getString("status"),
                    startedAt = started,
                    seconds = seconds,
                ),
            )
        }
        out
    }
}
