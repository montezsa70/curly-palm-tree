package app.instants.data

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.time.Duration
import java.time.Instant
import java.time.OffsetDateTime

/** One finished call, from my point of view. */
data class CallEntry(
    val id: String,
    val chatId: String,
    val outgoing: Boolean,
    val status: String, // ended | missed | cancelled | declined | busy | failed
    val startedAt: Instant,
    val seconds: Int,
) {
    val wentWrong: Boolean get() = status == "failed" || (!outgoing && status in setOf("missed", "cancelled", "busy"))

    /** "Outgoing · 1:33", "Missed", "No answer", "Couldn't connect"... */
    val summary: String
        get() = when (status) {
            "ended" -> (if (outgoing) "Outgoing" else "Incoming") + " · " + formatDuration(seconds * 1000L)
            "declined" -> "Declined"
            "cancelled" -> if (outgoing) "Cancelled" else "Missed"
            "missed" -> if (outgoing) "No answer" else "Missed"
            "busy" -> if (outgoing) "Busy" else "Missed"
            "failed" -> "Couldn't connect"
            else -> "Call"
        }
}

/**
 * Call history: the copy on this phone (so the Calls tab opens instantly, with no empty flash) and the one on the server,
 * which is fetched quietly in the background and replaces the local copy when it arrives.
 */
object CallLog {
    private const val KEY = "call_log"
    private const val MAX = 100

    /** null = never loaded on this phone yet; otherwise the last known history, newest first. */
    var entries by mutableStateOf<List<CallEntry>?>(null)
        private set

    @Volatile private var lastRefreshMs = 0L

    fun init() {
        entries = Cache.getString(KEY)?.let { decode(it) }
    }

    fun clear() {
        entries = null
        lastRefreshMs = 0L
    }

    /** Fetches from the server unless that was done a moment ago. Keeps showing the local copy if the network fails. */
    suspend fun refresh(force: Boolean = false) {
        if (!force && System.currentTimeMillis() - lastRefreshMs < 15_000) return
        try {
            val fresh = load()
            lastRefreshMs = System.currentTimeMillis()
            entries = fresh
            Cache.putString(KEY, encode(fresh))
        } catch (_: Exception) {
        }
    }

    /** A call that just ended is shown right away; the next refresh replaces it with the server's version. */
    fun addLocal(entry: CallEntry) {
        val next = (listOf(entry) + entries.orEmpty().filter { it.id != entry.id }).take(MAX)
        entries = next
        Cache.putString(KEY, encode(next))
    }

    private fun encode(list: List<CallEntry>): String {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject().put("id", it.id).put("c", it.chatId).put("o", it.outgoing)
                    .put("s", it.status).put("t", it.startedAt.toEpochMilli()).put("d", it.seconds),
            )
        }
        return arr.toString()
    }

    private fun decode(json: String): List<CallEntry>? = try {
        val arr = JSONArray(json)
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            CallEntry(
                id = o.getString("id"), chatId = o.getString("c"), outgoing = o.getBoolean("o"),
                status = o.getString("s"), startedAt = Instant.ofEpochMilli(o.getLong("t")), seconds = o.optInt("d", 0),
            )
        }
    } catch (_: Exception) {
        null
    }

    /** My finished calls, newest first. The server only returns calls I was on. */
    private suspend fun load(): List<CallEntry> = withContext(Dispatchers.IO) {
        val me = Session.userId ?: return@withContext emptyList()
        val rows = JSONArray(
            Api.call(
                "GET",
                "/rest/v1/calls?select=id,chat_id,caller_id,status,created_at,connected_at,ended_at" +
                    "&status=not.in.(ringing,accepted)&order=created_at.desc&limit=100",
            ),
        )
        val out = ArrayList<CallEntry>()
        for (i in 0 until rows.length()) {
            val r = rows.getJSONObject(i)
            val started = OffsetDateTime.parse(r.getString("created_at")).toInstant()
            val seconds = if (!r.isNull("connected_at") && !r.isNull("ended_at")) {
                Duration.between(
                    OffsetDateTime.parse(r.getString("connected_at")).toInstant(),
                    OffsetDateTime.parse(r.getString("ended_at")).toInstant(),
                ).seconds.toInt().coerceAtLeast(0)
            } else {
                0
            }
            out.add(
                CallEntry(
                    id = r.getString("id"),
                    chatId = r.getString("chat_id"),
                    outgoing = r.getString("caller_id") == me,
                    status = r.getString("status"),
                    startedAt = started,
                    seconds = seconds,
                ),
            )
        }
        out
    }
}
