package app.instants.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.instants.data.Session
import app.instants.data.StatusGroup
import app.instants.data.StatusStore
import app.instants.data.listLabel
import app.instants.ui.components.Ic
import app.instants.ui.components.LIcon
import app.instants.ui.components.ProfileAvatar
import app.instants.ui.components.PullRefresh
import app.instants.ui.components.pressable
import app.instants.ui.components.staggerIn
import app.instants.ui.theme.Palette

/** Where statuses live: my own status on top, then contacts' updates (new ones first, viewed ones below). */
@Composable
fun SpotlightTab(
    bottomPadding: Dp,
    onOpenStatus: (String) -> Unit,
    onAddStatus: () -> Unit,
) {
    val top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val groups = StatusStore.groups
    val fresh = groups.filter { StatusStore.hasUnseen(it) }
    val viewed = groups.filter { !StatusStore.hasUnseen(it) }

    PullRefresh(topPadding = top, onRefresh = { StatusStore.refresh() }) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(top = top + 12.dp, bottom = bottomPadding),
    ) {
        item(key = "title") {
            Text(
                "Spotlight",
                color = Palette.TextPrimary,
                fontSize = 34.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = (-0.5).sp,
                modifier = Modifier.padding(horizontal = 20.dp).staggerIn(0),
            )
        }
        item(key = "mine") {
            MyStatusCard(
                onClick = { if (StatusStore.mine != null) Session.userId?.let(onOpenStatus) else onAddStatus() },
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 16.dp).staggerIn(1),
            )
        }
        if (groups.isEmpty()) {
            item(key = "empty") { EmptySpotlight(Modifier.staggerIn(2)) }
        }
        if (fresh.isNotEmpty()) {
            item(key = "h-recent") { SectionLabel("Recent updates") }
            items(fresh, key = { "r-" + it.userId }) { g ->
                UpdateRow(g, Modifier.staggerIn(2)) { onOpenStatus(g.userId) }
            }
        }
        if (viewed.isNotEmpty()) {
            item(key = "h-viewed") { SectionLabel("Viewed") }
            items(viewed, key = { "v-" + it.userId }) { g ->
                UpdateRow(g, Modifier.staggerIn(3)) { onOpenStatus(g.userId) }
            }
        }
    }
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(
        text, color = Palette.TextSecondary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
        letterSpacing = 0.3.sp, modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 10.dp, bottom = 4.dp),
    )
}

@Composable
private fun MyStatusCard(onClick: () -> Unit, modifier: Modifier) {
    val mine = StatusStore.mine
    val shape = RoundedCornerShape(24.dp)
    val profile = mine?.profile ?: app.instants.data.Store.me?.profile
    val initials = profile?.initials ?: "?"
    Row(
        modifier
            .fillMaxWidth()
            .pressable(0.97f, haptic = true, onClick = onClick)
            .clip(shape)
            .background(Palette.Glass)
            .border(1.dp, Palette.GlassBorder, shape)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Box(Modifier.size(56.dp)) {
            if (mine != null) {
                StatusRing(mine, 56.dp)
                Box(Modifier.align(Alignment.Center)) { ProfileAvatar(initials, 46.dp, profile?.avatarPath) }
            } else {
                Box(Modifier.align(Alignment.Center)) { ProfileAvatar(initials, 52.dp, profile?.avatarPath) }
                Box(
                    Modifier.align(Alignment.BottomEnd).size(22.dp).clip(CircleShape).background(Palette.Accent)
                        .border(2.dp, Palette.Background, CircleShape),
                    contentAlignment = Alignment.Center,
                ) { LIcon(Ic.Plus, Color.White, 13.dp) }
            }
        }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text("My status", color = Palette.TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            val views = mine?.items?.sumOf { StatusStore.viewCounts[it.id] ?: 0 } ?: 0
            Text(
                when {
                    mine == null -> "Tap to add a status update"
                    views > 0 -> "${mine.items.last().createdAt.listLabel()} · $views ${if (views == 1) "view" else "views"}"
                    else -> mine.items.last().createdAt.listLabel()
                },
                color = Palette.TextSecondary, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

@Composable
private fun UpdateRow(group: StatusGroup, modifier: Modifier, onClick: () -> Unit) {
    Row(
        modifier
            .fillMaxWidth()
            .pressable(0.985f, onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Box(Modifier.size(58.dp)) {
            StatusRing(group, 58.dp)
            Box(Modifier.align(Alignment.Center)) { ProfileAvatar(group.initials, 48.dp, group.profile?.avatarPath) }
        }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(
                group.name, color = Palette.TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.SemiBold,
                maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
            Text(group.latest.listLabel(), color = Palette.TextSecondary, fontSize = 14.sp)
        }
    }
}

/** A ring split into one arc per status: blue for new ones, faint for ones already viewed. */
@Composable
private fun StatusRing(group: StatusGroup, size: Dp) {
    val seen = group.items.map { it.id in StatusStore.viewed }
    val fresh = Palette.AccentSoft
    val old = Palette.tint(0.22f)
    Canvas(Modifier.size(size)) {
        val n = seen.size.coerceAtLeast(1)
        val stroke = 2.5.dp.toPx()
        val inset = stroke / 2
        val gap = if (n > 1) 10f else 0f
        val sweep = 360f / n - gap
        for (i in 0 until n) {
            drawArc(
                color = if (seen.getOrElse(i) { true }) old else fresh,
                startAngle = -90f + i * (360f / n) + gap / 2,
                sweepAngle = if (n == 1) 360f else sweep,
                useCenter = false,
                topLeft = Offset(inset, inset),
                size = Size(this.size.width - stroke, this.size.height - stroke),
                style = Stroke(width = stroke, cap = if (n == 1) StrokeCap.Butt else StrokeCap.Round),
            )
        }
    }
}

@Composable
private fun EmptySpotlight(modifier: Modifier) {
    Column(
        modifier.fillMaxWidth().padding(horizontal = 32.dp, vertical = 56.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            Modifier.size(84.dp).clip(CircleShape).background(Palette.Glass).border(1.dp, Palette.GlassBorder, CircleShape),
            contentAlignment = Alignment.Center,
        ) { LIcon(Ic.Spotlight, Palette.AccentSoft, 34.dp) }
        Spacer(Modifier.height(20.dp))
        Text("No updates yet", color = Palette.TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        Text(
            "Status updates from your contacts show up here and disappear after 24 hours.",
            color = Palette.TextSecondary, fontSize = 15.sp, lineHeight = 21.sp, textAlign = TextAlign.Center,
        )
    }
}
