package app.instants.ui.components

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.instants.data.Avatars
import app.instants.ui.theme.Palette
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream

// ---------- Photos ----------

/** Centre-crops to a square, shrinks to 512 px and returns JPEG bytes. */
fun loadSquareJpeg(context: Context, uri: Uri): ByteArray? = try {
    val src = ImageDecoder.createSource(context.contentResolver, uri)
    val bmp = ImageDecoder.decodeBitmap(src) { decoder, info, _ ->
        decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
        val side = minOf(info.size.width, info.size.height)
        decoder.setTargetSampleSize(maxOf(1, side / 1024))
    }
    val side = minOf(bmp.width, bmp.height)
    val square = Bitmap.createBitmap(bmp, (bmp.width - side) / 2, (bmp.height - side) / 2, side, side)
    val scaled = Bitmap.createScaledBitmap(square, 512, 512, true)
    ByteArrayOutputStream().also { scaled.compress(Bitmap.CompressFormat.JPEG, 85, it) }.toByteArray()
} catch (e: Exception) {
    null
}

/** Returns a function that opens the system photo picker (no storage permission needed). */
@Composable
fun rememberPhotoPicker(onPicked: (ByteArray) -> Unit): () -> Unit {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            scope.launch {
                val bytes = withContext(Dispatchers.IO) { loadSquareJpeg(context, uri) }
                if (bytes != null) onPicked(bytes)
            }
        }
    }
    return { launcher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }
}

// ---------- Avatars ----------

@Composable
fun ProfileAvatar(
    initials: String,
    size: Dp,
    avatarPath: String?,
    modifier: Modifier = Modifier,
    localBytes: ByteArray? = null,
) {
    val remote by produceState<ImageBitmap?>(initialValue = null, avatarPath) {
        value = if (avatarPath == null) null else Avatars.load(avatarPath)
    }
    val local = remember(localBytes) {
        localBytes?.let { BitmapFactory.decodeByteArray(it, 0, it.size)?.asImageBitmap() }
    }
    val img = local ?: remote
    Box(
        modifier
            .size(size)
            .clip(CircleShape)
            .background(Palette.AvatarBg)
            .border(1.dp, Palette.GlassBorder, CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        if (img != null) {
            Image(bitmap = img, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        } else {
            Text(initials, color = Palette.TextSecondary, fontSize = (size.value * 0.3f).sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

/** Big avatar with a small camera badge; tap to change. */
@Composable
fun EditableAvatar(
    initials: String,
    avatarPath: String?,
    localBytes: ByteArray?,
    onClick: () -> Unit,
    size: Dp = 96.dp,
) {
    Box(
        Modifier
            .size(size)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick),
    ) {
        ProfileAvatar(initials, size, avatarPath, localBytes = localBytes)
        Box(
            Modifier.align(Alignment.BottomEnd).size(30.dp).clip(CircleShape).background(Palette.Accent)
                .border(2.dp, Palette.Background, CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Rounded.CameraAlt, "Change photo", tint = Color.White, modifier = Modifier.size(16.dp))
        }
    }
}

// ---------- Small shared controls ----------

@Composable
fun GlassSwitch(checked: Boolean) {
    val bg by animateColorAsState(
        if (checked) Palette.Accent else Palette.tint(0.14f), tween(250), label = "swBg",
    )
    val x by animateDpAsState(
        targetValue = if (checked) 21.dp else 3.dp,
        animationSpec = spring(dampingRatio = 0.6f, stiffness = 500f),
        label = "swX",
    )
    Box(Modifier.size(46.dp, 28.dp).clip(CircleShape).background(bg)) {
        Box(Modifier.offset(x = x, y = 3.dp).size(22.dp).clip(CircleShape).background(Color.White))
    }
}

@Composable
fun PillChip(label: String, selected: Boolean, onClick: () -> Unit) {
    val bg by animateColorAsState(
        if (selected) Palette.Accent else Palette.tint(0.05f), tween(250), label = "chipBg",
    )
    val fg by animateColorAsState(
        if (selected) Color.White else Palette.ChipText, tween(250), label = "chipFg",
    )
    Box(
        Modifier
            .heightIn(min = 36.dp)
            .pressable(0.95f, haptic = true, onClick = onClick)
            .clip(CircleShape)
            .background(bg)
            .border(1.dp, if (selected) Palette.Accent else Palette.GlassBorder, CircleShape)
            .padding(horizontal = 14.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, color = fg, fontSize = 14.sp, fontWeight = FontWeight.Medium)
    }
}

val AboutTemplates = listOf(
    "Available", "Busy", "At work", "In a meeting", "At the gym", "Sleeping",
    "Can’t talk, message only", "Battery about to die", "Urgent only",
)

/** Pick a template or type your own (up to 100 characters). */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AboutPicker(value: String, onChange: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(54.dp)
                .clip(CircleShape)
                .background(Palette.tint(0.07f))
                .border(1.dp, Palette.Hairline, CircleShape)
                .padding(horizontal = 20.dp),
            contentAlignment = Alignment.CenterStart,
        ) {
            GlassField(value, { if (it.length <= 100) onChange(it) }, "About", Modifier.fillMaxWidth())
        }
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            AboutTemplates.forEach { t -> PillChip(t, selected = value == t) { onChange(t) } }
        }
    }
}

/** Bottom sheet with a single-choice list. Options are (key, label). */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChoiceSheet(
    title: String,
    options: List<Pair<String, String>>,
    selected: String,
    footer: String? = null,
    onSelect: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val scope = rememberCoroutineScope()
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = Palette.Sheet,
        contentColor = Palette.TextPrimary,
    ) {
        Column(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 20.dp).padding(bottom = 24.dp)) {
            Text(title, color = Palette.TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
            Box(Modifier.height(8.dp))
            options.forEach { (key, label) ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .heightIn(min = 52.dp)
                        .pressable(0.99f, haptic = true) {
                            onSelect(key)
                            scope.launch { sheetState.hide() }.invokeOnCompletion { onDismiss() }
                        },
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(label, color = Palette.TextPrimary, fontSize = 16.sp, modifier = Modifier.weight(1f))
                    if (key == selected) {
                        Icon(Icons.Rounded.Check, null, tint = Palette.AccentSoft, modifier = Modifier.size(20.dp))
                    }
                }
            }
            if (footer != null) {
                Box(Modifier.height(10.dp))
                Text(footer, color = Palette.TextSecondary, fontSize = 13.sp, lineHeight = 18.sp)
            }
        }
    }
}

/** Back button + title for full-screen pages. */
@Composable
fun ScreenHeader(title: String, onBack: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        GlassIconButton(
            icon = Icons.AutoMirrored.Rounded.ArrowBack,
            description = "Back",
            size = 48.dp,
            calm = true,
            onClick = onBack,
        )
        Text(title, color = Palette.TextPrimary, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
    }
}
