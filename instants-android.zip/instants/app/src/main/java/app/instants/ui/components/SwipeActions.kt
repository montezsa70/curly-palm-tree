package app.instants.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.instants.ui.theme.Palette
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/**
 * A row that slides left to reveal [actions] underneath it. Whether it is open is owned by the caller
 * ([open] / [onOpenChange]) so that only one row is open at a time.
 */
@Composable
fun SwipeRevealRow(
    open: Boolean,
    onOpenChange: (Boolean) -> Unit,
    onDragStart: () -> Unit,
    actionsWidth: Dp,
    actions: @Composable RowScope.() -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit,
) {
    val maxPx = with(LocalDensity.current) { actionsWidth.toPx() }
    val offset = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    val openNow by rememberUpdatedState(open)
    val snap = spring<Float>(dampingRatio = 0.8f, stiffness = 400f)

    LaunchedEffect(open) { offset.animateTo(if (open) -maxPx else 0f, snap) }

    Box(modifier.fillMaxWidth().clipToBounds()) {
        // The actions sit underneath, pinned to the right edge.
        Row(Modifier.matchParentSize(), horizontalArrangement = Arrangement.End) {
            Row(Modifier.width(actionsWidth).fillMaxHeight(), verticalAlignment = Alignment.CenterVertically, content = actions)
        }
        Box(
            Modifier
                .fillMaxWidth()
                .offset { IntOffset(offset.value.roundToInt(), 0) }
                .background(Palette.Background)
                .pointerInput(maxPx) {
                    detectHorizontalDragGestures(
                        onDragStart = { onDragStart() },
                        onDragEnd = {
                            val target = if (offset.value < -maxPx * 0.4f) -maxPx else 0f
                            scope.launch { offset.animateTo(target, snap) }
                            onOpenChange(target != 0f)
                        },
                        onDragCancel = {
                            scope.launch { offset.animateTo(if (openNow) -maxPx else 0f, snap) }
                        },
                        onHorizontalDrag = { change, dx ->
                            change.consume()
                            scope.launch { offset.snapTo((offset.value + dx).coerceIn(-maxPx, 0f)) }
                        },
                    )
                },
        ) { content() }
    }
}

/** One round action with a tiny label, used inside [SwipeRevealRow]. */
@Composable
fun RowScope.SwipeAction(icon: Int, label: String, active: Boolean = false, onClick: () -> Unit) {
    Column(
        Modifier.weight(1f).fillMaxHeight().pressable(0.9f, haptic = true, onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Box(
            Modifier.size(44.dp).clip(CircleShape).background(if (active) Palette.Accent else Palette.tint(0.09f)),
            contentAlignment = Alignment.Center,
        ) {
            LIcon(icon, if (active) androidx.compose.ui.graphics.Color.White else Palette.TextPrimary, 20.dp)
        }
        Spacer(Modifier.height(5.dp))
        Text(label, color = Palette.TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Medium, maxLines = 1)
    }
}
