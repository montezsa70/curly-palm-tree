package app.instants.data

import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.conflate
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

/**
 * Live updates: one WebSocket to Supabase Realtime. The server pushes a message the moment a row in
 * `messages` or `chat_members` (read / delivered receipts, new chats) changes, so nothing has to poll.
 * Row level security still applies: only changes to my own chats arrive.
 *
 * Screens listen to [changes] and re-read what they show. A slow safety refresh stays in the screens
 * in case the connection drops, and a "resync" change is sent every time the socket (re)connects so
 * anything missed while offline is picked up.
 */
object Realtime {
    /** table is "messages", "chat_members" or "resync". chatId is null when unknown (or for resync). */
    data class Change(val table: String, val type: String, val chatId: String?)

    private val _changes = MutableSharedFlow<Change>(extraBufferCapacity = 128, onBufferOverflow = BufferOverflow.DROP_OLDEST)
    val changes: SharedFlow<Change> = _changes

    private const val TOPIC = "realtime:instants"
    private val http = OkHttpClient.Builder().pingInterval(25, TimeUnit.SECONDS).build()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var connectionJob: Job? = null
    private var chatListJob: Job? = null
    private val refCounter = AtomicInteger(1)

    @Synchronized
    fun start() {
        if (Session.userId == null) return
        if (connectionJob?.isActive != true) connectionJob = scope.launch { keepConnected() }
        if (chatListJob?.isActive != true) {
            // The chat list updates itself from here, whichever screen is open
            chatListJob = scope.launch {
                changes.conflate().collect {
                    Store.refreshChats()
                    delay(250)
                }
            }
        }
    }

    @Synchronized
    fun stop() {
        connectionJob?.cancel()
        chatListJob?.cancel()
        connectionJob = null
        chatListJob = null
    }

    private suspend fun keepConnected() {
        var wait = 1000L
        while (currentCoroutineContext().isActive) {
            val worked = connectOnce()
            wait = if (worked) 1000L else (wait * 2).coerceAtMost(15_000L)
            delay(wait)
        }
    }

    /** Runs one connection until it closes. True if it got as far as subscribing. */
    private suspend fun connectOnce(): Boolean {
        val token = withContext(Dispatchers.IO) { Api.freshToken() } ?: return false
        val url = Config.SUPABASE_URL.replace("https://", "wss://") +
            "/realtime/v1/websocket?apikey=${Config.SUPABASE_KEY}&vsn=1.0.0"
        val finished = CompletableDeferred<Unit>()
        val subscribed = AtomicBoolean(false)

        val socket = http.newWebSocket(
            Request.Builder().url(url).build(),
            object : WebSocketListener() {
                override fun onOpen(webSocket: WebSocket, response: Response) {
                    webSocket.send(joinMessage(token))
                }

                override fun onMessage(webSocket: WebSocket, text: String) {
                    try {
                        handle(webSocket, text, subscribed)
                    } catch (_: Exception) {
                    }
                }

                override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                    webSocket.close(1000, null)
                    finished.complete(Unit)
                }

                override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                    finished.complete(Unit)
                }

                override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                    finished.complete(Unit)
                }
            },
        )

        val heartbeat = scope.launch {
            var sentToken = token
            while (isActive) {
                delay(25_000)
                socket.send(JSONObject().put("topic", "phoenix").put("event", "heartbeat")
                    .put("payload", JSONObject()).put("ref", refCounter.incrementAndGet().toString()).toString())
                // A refreshed sign-in token has to be handed to the channel too
                val current = Session.accessToken
                if (current != null && current != sentToken) {
                    sentToken = current
                    socket.send(JSONObject().put("topic", TOPIC).put("event", "access_token")
                        .put("payload", JSONObject().put("access_token", current))
                        .put("ref", refCounter.incrementAndGet().toString()).toString())
                }
            }
        }
        try {
            finished.await()
        } finally {
            heartbeat.cancel()
            socket.cancel()
        }
        return subscribed.get()
    }

    private fun joinMessage(token: String): String {
        fun table(name: String) = JSONObject().put("event", "*").put("schema", "public").put("table", name)
        val config = JSONObject()
            .put("broadcast", JSONObject().put("ack", false).put("self", false))
            .put("presence", JSONObject().put("key", ""))
            .put("postgres_changes", org.json.JSONArray().put(table("messages")).put(table("chat_members")))
            .put("private", false)
        return JSONObject()
            .put("topic", TOPIC)
            .put("event", "phx_join")
            .put("payload", JSONObject().put("config", config).put("access_token", token))
            .put("ref", "1")
            .put("join_ref", "1")
            .toString()
    }

    private fun handle(socket: WebSocket, text: String, subscribed: AtomicBoolean) {
        val msg = JSONObject(text)
        val payload = msg.optJSONObject("payload") ?: JSONObject()
        when (msg.optString("event")) {
            "phx_reply" -> if (msg.optString("topic") == TOPIC && msg.optString("ref") == "1") {
                if (payload.optString("status") == "ok") {
                    subscribed.set(true)
                    _changes.tryEmit(Change("resync", "", null))
                } else {
                    socket.close(1000, "join refused")
                }
            }
            "postgres_changes" -> {
                val data = payload.optJSONObject("data") ?: return
                val record = data.optJSONObject("record") ?: data.optJSONObject("old_record")
                val chatId = record?.optString("chat_id")?.takeIf { it.isNotBlank() && it != "null" }
                _changes.tryEmit(Change(data.optString("table"), data.optString("type"), chatId))
            }
            "system" -> if (payload.optString("status") == "error") socket.close(1000, "subscribe failed")
            "phx_error", "phx_close" -> if (msg.optString("topic") == TOPIC) socket.close(1000, "channel closed")
        }
    }
}
