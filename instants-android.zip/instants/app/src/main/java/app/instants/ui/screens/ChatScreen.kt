package app.instants.ui.screens

import android.widget.Toast
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.Call
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.instants.data.Cache
import app.instants.data.Msg
import app.instants.data.Profile
import app.instants.data.Repo
import app.instants.data.Session
import app.instants.data.Store
import app.instants.data.clock
import app.instants.data.dayKey
import app.instants.data.dayLabel
import app.instants.data.initialsOf
import app.instants.data.lastSeenLabel
import app.instants.ui.components.GlassField
import app.instants.ui.components.GlassIconButton
import app.instants.ui.components.GlassSwitch
import app.instants.ui.components.PlainIconButton
import app.instants.ui.components.ProfileAvatar
import app.instants.ui.components.SoftButton
import app.instants.ui.components.glass
import app.instants.ui.components.pressable
import app.instants.ui.theme.Palette
import dev.chrisbanes.haze.HazeState
import dev.chrisbanes.haze.haze
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.Instant

/** Chat screen. Intentionally calm: no bouncing, popping or sliding when messages arrive. */
@Composable
fun ChatScreen(chatId: String, onBack: () -> Unit, onCall: (String, String) -> Unit) {
    val me = Session.userId.orEmpty()
    val chat = Store.chats.firstOrNull { it.chatId == chatId }
    val peer = chat?.peer
    val peerId = peer?.id
    val title = chat?.title ?: "Chat"
    val initials = chat?.initials ?: initialsOf(title)
    val blocked = peerId != null && peerId in Store.blockedIds
    val closeFriend = peerId != null && peerId in Store.closeFriendIds

    val haze = remember { HazeState() }
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    var text by remember { mutableStateOf("") }
    // Start from the saved copy so the conversation is there instantly
    var messages by remember { mutableStateOf(Cache.loadThread(chatId)) }
    var peerRead by remember { mutableStateOf<Instant?>(null) }
    var peerSeen by remember { mutableStateOf<Instant?>(null) }
    var showContact by remember { mutableStateOf(false) }
    val statusTop = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val navBottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()

    // New messages: every 2 seconds. Marks incoming ones as read.
    LaunchedEffect(chatId) {
        var marked: Instant = Instant.EPOCH
        while (true) {
            try {
                val t = Repo.loadThread(chatId)
                messages = t.messages
                peerRead = t.peerLastRead
                Cache.saveThread(chatId, t.messages)
                val newest = t.messages.lastOrNull { it.senderId != me }?.createdAt
                if (newest != null && newest > marked) {
                    Repo.markRead(chatId)
                    marked = newest
                    Store.refreshChats()
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // try again on the next tick
            }
            delay(2000)
        }
    }

    // Last seen / active status (only returned if both of you allow it)
    LaunchedEffect(peerId) {
        while (true) {
            if (peerId != null) {
                try {
                    peerSeen = Repo.statuses(listOf(peerId))[peerId]
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                }
            }
            delay(15_000)
        }
    }

    // Jump (no animation) to the newest message.
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) listState.scrollToItem(messages.size - 1)
    }

    fun send() {
        val body = text.trim()
        if (body.isEmpty()) return
        text = ""
        scope.launch {
            try {
                val sent = Repo.send(chatId, body)
                messages = (messages + sent).distinctBy { it.id }.sortedBy { it.createdAt }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                text = body
                Toast.makeText(context, "Message not sent", Toast.LENGTH_SHORT).show()
            }
        }
    }

    val subtitle = peerSeen?.let { lastSeenLabel(it) } ?: peer?.let { "@${it.username}" }

    Box(Modifier.fillMaxSize().background(Palette.Charcoal).imePadding()) {
        LazyColumn(
            modifier = Modifier.fillMaxSize().haze(haze),
            state = listState,
            contentPadding = PaddingValues(top = statusTop + 80.dp, bottom = navBottom + 100.dp),
            verticalArrangement = Arrangement.spacedBy(3.dp, Alignment.Bottom),
        ) {
            itemsIndexed(messages, key = { _, m -> m.id }) { index, m ->
                val prev = messages.getOrNull(index - 1)
                val next = messages.getOrNull(index + 1)
                val mine = m.senderId == me
                Column {
                    if (prev == null || prev.createdAt.dayKey() != m.createdAt.dayKey()) {
                        DayPill(m.createdAt.dayLabel())
                    }
                    Bubble(
                        msg = m,
                        mine = mine,
                        gapTop = if (prev == null || prev.senderId != m.senderId) 11.dp else 0.dp,
                        showTime = next == null || next.senderId != m.senderId,
                        read = mine && peerRead.let { it != null && it >= m.createdAt },
                    )
                }
            }
        }

        if (messages.isEmpty()) {
            Text(
                "Say hi to $title",
                color = Palette.TextSecondary,
                fontSize = 15.sp,
                modifier = Modifier.align(Alignment.Center),
            )
        }

        // Floating glass header: round back button + long pill (tap the pill for contact info)
        Row(
            Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 12.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            GlassIconButton(
                icon = Icons.AutoMirrored.Rounded.ArrowBack,
                description = "Back",
                haze = haze,
                size = 52.dp,
                calm = true,
                onClick = onBack,
            )
            Row(
                Modifier
                    .weight(1f)
                    .height(56.dp)
                    .glass(haze, RoundedCornerShape(28.dp))
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                        if (peer != null) showContact = true
                    }
                    .padding(start = 8.dp, end = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                ProfileAvatar(initials, 40.dp, peer?.avatarPath)
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(1.dp)) {
                    Text(title, color = Palette.TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                    if (subtitle != null) {
                        Text(subtitle, color = Palette.TextSecondary, fontSize = 12.sp, maxLines = 1)
                    }
                }
                PlainIconButton(
                    Icons.Rounded.Call, "Call $title", tint = Palette.AccentSoft,
                    onClick = { onCall(title, initials) },
                )
            }
        }

        // Floating glass composer (or a notice if you blocked this contact)
        if (blocked && peerId != null) {
            Row(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(horizontal = 12.dp)
                    .padding(bottom = 24.dp)
                    .heightIn(min = 60.dp)
                    .glass(haze, RoundedCornerShape(30.dp))
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Text("You blocked this contact.", color = Palette.TextSecondary, fontSize = 14.sp, modifier = Modifier.weight(1f))
                SoftButton("Unblock", Modifier.widthIn(min = 96.dp)) { scope.launch { Store.setBlocked(peerId, false) } }
            }
        } else {
            val canSend = text.isNotBlank()
            val sendAlpha by animateFloatAsState(if (canSend) 1f else 0.45f, tween(150), label = "sendAlpha")
            Row(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(horizontal = 12.dp)
                    .padding(bottom = 24.dp)
                    .height(60.dp)
                    .glass(haze, RoundedCornerShape(30.dp))
                    .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                PlainIconButton(Icons.Rounded.Add, "Attach", tint = Palette.TextPrimary) { }
                GlassField(
                    value = text,
                    onValueChange = { text = it },
                    placeholder = "Message",
                    modifier = Modifier.weight(1f),
                    imeAction = ImeAction.Send,
                    onImeAction = { send() },
                )
                GlassIconButton(
                    icon = Icons.Rounded.ArrowUpward,
                    description = "Send",
                    modifier = Modifier.graphicsLayer { alpha = sendAlpha },
                    size = 44.dp,
                    solid = Palette.Accent,
                    tint = Color.White,
                    calm = true,
                    onClick = { send() },
                )
            }
        }
    }

    if (showContact && peer != null) {
        ContactSheet(
            peer = peer,
            status = peerSeen?.let { lastSeenLabel(it) },
            blocked = blocked,
            closeFriend = closeFriend,
            onToggleClose = { scope.launch { Store.toggleCloseFriend(peer.id) } },
            onToggleBlock = { scope.launch { Store.setBlocked(peer.id, !blocked) } },
            onDismiss = { showContact = false },
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ContactSheet(
    peer: Profile,
    status: String?,
    blocked: Boolean,
    closeFriend: Boolean,
    onToggleClose: () -> Unit,
    onToggleBlock: () -> Unit,
    onDismiss: () -> Unit,
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = Color(0xFF232427),
        contentColor = Palette.TextPrimary,
    ) {
        Column(
            Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 24.dp).padding(bottom = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            ProfileAvatar(peer.initials, 88.dp, peer.avatarPath)
            Spacer(Modifier.height(12.dp))
            Text(peer.name, color = Palette.TextPrimary, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
            Text("@${peer.username}", color = Palette.TextSecondary, fontSize = 14.sp)
            if (status != null) {
                Spacer(Modifier.height(6.dp))
                Text(status, color = Palette.AccentSoft, fontSize = 13.sp)
            }
            if (peer.about.isNotBlank()) {
                Spacer(Modifier.height(12.dp))
                Text(peer.about, color = Palette.TextPrimary, fontSize = 15.sp, textAlign = TextAlign.Center)
            }
            Spacer(Modifier.height(20.dp))
            Row(
                Modifier
                    .fillMaxWidth()
                    .heightIn(min = 52.dp)
                    .pressable(0.99f, haptic = true, onClick = onToggleClose),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text("Close friend", color = Palette.TextPrimary, fontSize = 16.sp)
                    Text("Can see your last seen and when you’re active", color = Palette.TextSecondary, fontSize = 12.sp)
                }
                GlassSwitch(closeFriend)
            }
            Spacer(Modifier.height(12.dp))
            SoftButton(if (blocked) "Unblock contact" else "Block contact", Modifier.fillMaxWidth(), onClick = onToggleBlock)
        }
    }
}

@Composable
private fun DayPill(label: String) {
    val shape = RoundedCornerShape(14.dp)
    Box(Modifier.fillMaxWidth().padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
        Text(
            label,
            color = Palette.TextSecondary,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier
                .clip(shape)
                .background(Color.White.copy(alpha = 0.07f))
                .border(1.dp, Color.White.copy(alpha = 0.08f), shape)
                .padding(horizontal = 14.dp, vertical = 5.dp),
        )
    }
}

@Composable
private fun Bubble(msg: Msg, mine: Boolean, gapTop: Dp, showTime: Boolean, read: Boolean) {
    val shape = RoundedCornerShape(20.dp)
    Column(
        Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = gapTop),
        horizontalAlignment = if (mine) Alignment.End else Alignment.Start,
    ) {
        Box(
            Modifier
                .widthIn(max = 270.dp)
                .clip(shape)
                .background(if (mine) Palette.Accent else Palette.BubbleIn)
                .border(
                    1.dp,
                    if (mine) Color.White.copy(alpha = 0.16f) else Color.White.copy(alpha = 0.08f),
                    shape,
                )
                .padding(horizontal = 15.dp, vertical = 10.dp),
        ) {
            Text(
                msg.body,
                color = if (mine) Color.White else Color(0xFFECEEF1),
                fontSize = 16.sp,
                lineHeight = 21.sp,
            )
        }
        if (showTime) {
            Text(
                msg.createdAt.clock() + if (read) " · Read" else "",
                color = Palette.TextSecondary,
                fontSize = 11.sp,
                modifier = Modifier.padding(start = 6.dp, end = 6.dp, top = 3.dp),
            )
        }
    }
}
