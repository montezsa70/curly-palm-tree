package app.instants.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.StartOffset
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.Call
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.instants.data.Message
import app.instants.data.MockStore
import app.instants.ui.components.Avatar
import app.instants.ui.components.GlassField
import app.instants.ui.components.GlassIconButton
import app.instants.ui.components.PlainIconButton
import app.instants.ui.components.glass
import app.instants.ui.theme.Palette
import dev.chrisbanes.haze.HazeState
import dev.chrisbanes.haze.haze
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val canned = listOf(
    "Haha yes!", "Sounds good to me", "Give me a sec", "Perfect, see you then", "Love that", "On it",
)

@Composable
fun ChatScreen(chatId: String, onBack: () -> Unit, onCall: () -> Unit) {
    val contact = MockStore.contact(chatId)
    val messages: List<Message> = MockStore.messages[chatId] ?: emptyList()
    val haze = remember { HazeState() }
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    var text by remember { mutableStateOf("") }
    var typing by remember { mutableStateOf(false) }
    var firstScroll by remember { mutableStateOf(true) }
    val knownIds = remember { messages.map { it.id }.toSet() }
    val statusTop = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val navBottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()

    LaunchedEffect(Unit) { MockStore.markRead(chatId) }
    LaunchedEffect(messages.size, typing) {
        val last = messages.size + 1
        if (firstScroll) {
            listState.scrollToItem(last)
            firstScroll = false
        } else {
            listState.animateScrollToItem(last)
        }
    }

    fun send() {
        val t = text.trim()
        if (t.isEmpty()) return
        text = ""
        MockStore.append(chatId, t, fromMe = true)
        scope.launch {
            delay(800)
            MockStore.markMineRead(chatId)
            typing = true
            delay(1700)
            typing = false
            MockStore.append(chatId, canned.random(), fromMe = false)
        }
    }

    Box(Modifier.fillMaxSize().background(Palette.Charcoal).imePadding()) {
        LazyColumn(
            modifier = Modifier.fillMaxSize().haze(haze),
            state = listState,
            contentPadding = PaddingValues(top = statusTop + 80.dp, bottom = navBottom + 100.dp),
            verticalArrangement = Arrangement.spacedBy(3.dp, Alignment.Bottom),
        ) {
            item(key = "day") { DayPill() }
            itemsIndexed(messages, key = { _, m -> m.id }) { index, m ->
                val prev = messages.getOrNull(index - 1)
                val next = messages.getOrNull(index + 1)
                Bubble(
                    msg = m,
                    animate = m.id !in knownIds,
                    gapTop = if (prev == null || prev.fromMe != m.fromMe) 11.dp else 0.dp,
                    showTime = next == null || next.fromMe != m.fromMe,
                    modifier = Modifier.animateItem(),
                )
            }
            item(key = "typing") {
                AnimatedVisibility(
                    visible = typing,
                    enter = fadeIn(tween(200)) + scaleIn(
                        spring(dampingRatio = 0.6f), transformOrigin = TransformOrigin(0f, 1f),
                    ),
                    exit = fadeOut(tween(150)),
                ) { TypingBubble() }
            }
        }

        // Floating glass header: round back button + long pill
        Row(
            Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 12.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            GlassIconButton(
                icon = Icons.AutoMirrored.Rounded.ArrowBack,
                description = "Back",
                haze = haze,
                size = 52.dp,
                onClick = onBack,
            )
            Row(
                Modifier
                    .weight(1f)
                    .height(56.dp)
                    .glass(haze, RoundedCornerShape(28.dp))
                    .padding(start = 8.dp, end = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Avatar(contact.initials, 40.dp)
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(1.dp)) {
                    Text(contact.name, color = Palette.TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                    AnimatedContent(
                        targetState = if (typing) "typing…" else "Active now",
                        transitionSpec = { fadeIn(tween(200)) togetherWith fadeOut(tween(150)) },
                        label = "status",
                    ) { s -> Text(s, color = Palette.TextSecondary, fontSize = 12.sp) }
                }
                PlainIconButton(Icons.Rounded.Call, "Call ${contact.name}", tint = Palette.AccentSoft, onClick = onCall)
            }
        }

        // Floating glass composer
        val canSend = text.isNotBlank()
        val sendAlpha by animateFloatAsState(if (canSend) 1f else 0.45f, tween(180), label = "sendAlpha")
        val sendScale by animateFloatAsState(
            if (canSend) 1f else 0.9f, spring(dampingRatio = 0.5f, stiffness = 500f), label = "sendScale",
        )
        Row(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 12.dp)
                .padding(bottom = 24.dp)
                .height(60.dp)
                .glass(haze, RoundedCornerShape(30.dp))
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            PlainIconButton(Icons.Rounded.Add, "Attach", tint = Palette.TextPrimary)  { }
            GlassField(
                value = text,
                onValueChange = { text = it },
                placeholder = "Message",
                modifier = Modifier.weight(1f),
                imeAction = ImeAction.Send,
                onImeAction = { send() },
            )
            GlassIconButton(
                icon = Icons.Rounded.ArrowUpward,
                description = "Send",
                modifier = Modifier.graphicsLayer { alpha = sendAlpha; scaleX = sendScale; scaleY = sendScale },
                size = 44.dp,
                solid = Palette.Accent,
                tint = Color.White,
                onClick = { send() },
            )
        }
    }
}

@Composable
private fun DayPill() {
    Box(Modifier.fillMaxWidth().padding(bottom = 6.dp), contentAlignment = Alignment.Center) {
        Text(
            "Today",
            color = Palette.TextSecondary,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier
                .clip(RoundedCornerShape(14.dp))
                .background(Color.White.copy(alpha = 0.07f))
                .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(14.dp))
                .padding(horizontal = 14.dp, vertical = 5.dp),
        )
    }
}

@Composable
private fun Bubble(msg: Message, animate: Boolean, gapTop: Dp, showTime: Boolean, modifier: Modifier) {
    val scale = remember { Animatable(if (animate) 0.85f else 1f) }
    val fade = remember { Animatable(if (animate) 0f else 1f) }
    LaunchedEffect(Unit) {
        if (animate) {
            launch { fade.animateTo(1f, tween(220)) }
            scale.animateTo(1f, spring(dampingRatio = 0.6f, stiffness = 500f))
        }
    }
    val shape = RoundedCornerShape(20.dp)
    Column(
        modifier
            .fillMaxWidth()
            .padding(start = 16.dp, end = 16.dp, top = gapTop)
            .graphicsLayer {
                scaleX = scale.value
                scaleY = scale.value
                alpha = fade.value
                transformOrigin = TransformOrigin(if (msg.fromMe) 1f else 0f, 1f)
            },
        horizontalAlignment = if (msg.fromMe) Alignment.End else Alignment.Start,
    ) {
        Box(
            Modifier
                .widthIn(max = 270.dp)
                .clip(shape)
                .background(if (msg.fromMe) Palette.Accent else Palette.BubbleIn)
                .border(1.dp, if (msg.fromMe) Color.White.copy(alpha = 0.16f) else Color.White.copy(alpha = 0.08f), shape)
                .padding(horizontal = 15.dp, vertical = 10.dp),
        ) {
            Text(
                msg.text,
                color = if (msg.fromMe) Color.White else Color(0xFFECEEF1),
                fontSize = 16.sp,
                lineHeight = 21.sp,
            )
        }
        if (showTime) {
            Text(
                msg.time + if (msg.fromMe && msg.read) " · Read" else "",
                color = Palette.TextSecondary,
                fontSize = 11.sp,
                modifier = Modifier.padding(start = 6.dp, end = 6.dp, top = 3.dp),
            )
        }
    }
}

@Composable
private fun TypingBubble() {
    val inf = rememberInfiniteTransition(label = "typing")
    val shape = RoundedCornerShape(20.dp)
    Row(
        Modifier
            .padding(start = 16.dp, top = 8.dp)
            .clip(shape)
            .background(Palette.BubbleIn)
            .border(1.dp, Color.White.copy(alpha = 0.08f), shape)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        horizontalArrangement = Arrangement.spacedBy(5.dp),
    ) {
        repeat(3) { i ->
            val v by inf.animateFloat(
                initialValue = 0f,
                targetValue = 1f,
                animationSpec = infiniteRepeatable(
                    animation = tween(500, easing = FastOutSlowInEasing),
                    repeatMode = RepeatMode.Reverse,
                    initialStartOffset = StartOffset(i * 150),
                ),
                label = "dot$i",
            )
            Box(
                Modifier
                    .size(7.dp)
                    .graphicsLayer { translationY = -4.dp.toPx() * v; alpha = 0.4f + 0.6f * v }
                    .clip(CircleShape)
                    .background(Palette.TextPrimary),
            )
        }
    }
}
