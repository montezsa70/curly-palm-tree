package app.instants.ui.screens

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.pm.PackageManager
import androidx.activity.ComponentActivity
import androidx.compose.animation.Crossfade
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.mutableStateListOf
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import app.instants.data.RecordedVoice
import app.instants.data.VoiceLimits
import app.instants.data.VoicePlayer
import app.instants.data.VoiceRecorder
import app.instants.data.encodeWaveform
import app.instants.ui.components.RecordingContent
import app.instants.ui.components.VoiceMessage
import android.content.Intent
import android.graphics.Bitmap
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.runtime.produceState
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.FileProvider
import app.instants.data.Attachments
import app.instants.push.Push
import app.instants.data.PreparedAttachment
import app.instants.data.formatSize
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.Call
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.animation.animateColorAsState
import app.instants.data.Realtime
import app.instants.data.Tick
import app.instants.ui.components.Ic
import app.instants.ui.components.LIcon
import kotlinx.coroutines.flow.conflate
import kotlinx.coroutines.flow.filter
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import app.instants.ui.components.ChatWallpaper
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.instants.data.Cache
import app.instants.data.Msg
import app.instants.data.Profile
import app.instants.data.Repo
import app.instants.data.Session
import app.instants.data.Store
import app.instants.data.clock
import app.instants.data.dayKey
import app.instants.data.dayLabel
import app.instants.data.initialsOf
import app.instants.data.lastSeenLabel
import app.instants.ui.components.GlassField
import app.instants.ui.components.GlassIconButton
import app.instants.ui.components.GlassSwitch
import app.instants.ui.components.PlainIconButton
import app.instants.ui.components.ProfileAvatar
import app.instants.ui.components.SoftButton
import app.instants.ui.components.glass
import app.instants.ui.components.pressable
import app.instants.ui.theme.Palette
import dev.chrisbanes.haze.HazeState
import dev.chrisbanes.haze.haze
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.Instant
import androidx.compose.foundation.layout.fillMaxHeight
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontStyle
import app.instants.data.ChatItem
import app.instants.ui.components.DeleteSheet
import app.instants.ui.components.ForwardSheet
import app.instants.ui.components.InfoSheet
import app.instants.ui.components.MenuTarget
import app.instants.ui.components.MessageAction
import app.instants.ui.components.MessageMenuOverlay
import app.instants.ui.components.statusBrush

/** Chat screen. Intentionally calm: no bouncing, popping or sliding when messages arrive. */
@Composable
fun ChatScreen(chatId: String, onBack: () -> Unit, onCall: (String, String) -> Unit) {
    val me = Session.userId.orEmpty()
    val chat = Store.chats.firstOrNull { it.chatId == chatId }
    val peer = chat?.peer
    val peerId = peer?.id
    val title = chat?.title ?: "Chat"
    val initials = chat?.initials ?: initialsOf(title)
    val blocked = peerId != null && peerId in Store.blockedIds
    val closeFriend = peerId != null && peerId in Store.closeFriendIds

    val haze = remember { HazeState() }
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    var text by remember { mutableStateOf("") }
    // Start from the saved copy so the conversation is there instantly
    var messages by remember { mutableStateOf(Cache.loadThread(chatId)) }
    var peerRead by remember { mutableStateOf<Instant?>(null) }
    var peerSeen by remember { mutableStateOf<Instant?>(null) }
    var showContact by remember { mutableStateOf(false) }
    var showAttach by remember { mutableStateOf(false) }
    var uploading by remember { mutableStateOf(false) }
    var viewImage by remember { mutableStateOf<Msg?>(null) }
    // Long-press menu and what it opens
    var replyingTo by remember { mutableStateOf<Msg?>(null) }
    var menu by remember { mutableStateOf<MenuTarget?>(null) }
    var deleting by remember { mutableStateOf<Msg?>(null) }
    var forwarding by remember { mutableStateOf<Msg?>(null) }
    var infoFor by remember { mutableStateOf<Msg?>(null) }
    // Messages I just deleted: until the server confirms, a refresh must not bring them back
    val hiding = remember { mutableSetOf<String>() }
    val tombstones = remember { mutableMapOf<String, Msg>() }
    val composerFocus = remember { FocusRequester() }
    val keyboard = LocalSoftwareKeyboardController.current
    val haptic = LocalHapticFeedback.current
    val statusTop = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val navBottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()

    // While this chat is open, its notifications are not shown (and any waiting ones are cleared)
    androidx.compose.runtime.DisposableEffect(chatId) {
        Push.activeChatId = chatId
        Push.cancel(context, chatId)
        onDispose { if (Push.activeChatId == chatId) Push.activeChatId = null }
    }

    // Live: new messages and read receipts arrive over the realtime socket. Incoming ones are marked read.
    LaunchedEffect(chatId) {
        var marked: Instant = Instant.EPOCH
        suspend fun sync() {
            try {
                val t = Repo.loadThread(chatId)
                // Keep anything I just sent that the server copy doesn't include yet
                val newestFetched = t.messages.lastOrNull()?.createdAt ?: Instant.EPOCH
                val pending = messages.filter { m -> m.createdAt > newestFetched && t.messages.none { it.id == m.id } }
                val merged = (t.messages + pending)
                    .filter { it.id !in hiding }
                    .map { tombstones[it.id] ?: it }
                    .sortedBy { it.createdAt }
                // Deleted for everyone by the other person: drop this phone's copy of the file too
                val before = messages.associateBy { it.id }
                merged.forEach { n ->
                    if (n.deleted) {
                        before[n.id]?.takeIf { it.attachmentPath != null }?.let { old ->
                            if (VoicePlayer.currentId == old.id) VoicePlayer.stop()
                            Attachments.forget(old)
                        }
                    }
                }
                messages = merged
                peerRead = t.peerLastRead
                Cache.saveThread(chatId, t.messages)
                val newest = t.messages.lastOrNull { it.senderId != me }?.createdAt
                if (newest != null && newest > marked) {
                    marked = newest
                    Repo.markRead(chatId)
                    Store.refreshChats()
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // the next change (or the safety refresh) tries again
            }
        }
        Realtime.start()
        sync()
        launch {
            Realtime.changes
                .filter { it.chatId == null || it.chatId == chatId }
                .conflate()
                .collect {
                    sync()
                    delay(150)
                }
        }
        while (true) {
            delay(30_000) // safety net in case the socket was down
            sync()
        }
    }

    // Last seen / active status (only returned if both of you allow it)
    LaunchedEffect(peerId) {
        while (true) {
            if (peerId != null) {
                try {
                    peerSeen = Repo.statuses(listOf(peerId))[peerId]
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                }
            }
            delay(15_000)
        }
    }

    // The list is anchored to the bottom (reverseLayout), so photos loading, the keyboard opening
    // and new messages never push the newest message out of view. Only a new message needs a nudge.
    val newestId = messages.lastOrNull()?.id
    LaunchedEffect(newestId) {
        if (newestId != null && (listState.firstVisibleItemIndex <= 2 || messages.lastOrNull()?.senderId == me)) {
            listState.scrollToItem(0)
        }
    }

    fun send() {
        val body = text.trim()
        if (body.isEmpty()) return
        val replyTarget = replyingTo
        text = ""
        replyingTo = null
        scope.launch {
            try {
                val sent = Repo.send(chatId, body, replyTo = replyTarget?.id)
                messages = (messages + sent).distinctBy { it.id }.sortedBy { it.createdAt }
                Store.refreshChats()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                text = body
                replyingTo = replyTarget
                Toast.makeText(context, "Message not sent", Toast.LENGTH_SHORT).show()
            }
        }
    }

    /** Uploads a picked photo or document and adds it to the conversation. */
    suspend fun deliver(prepared: Result<PreparedAttachment>, replyId: String? = null) {
        val a = prepared.getOrElse {
            Toast.makeText(context, it.message ?: "Couldn't attach that", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val sent = Repo.sendAttachment(chatId, a, replyId)
            messages = (messages + sent).distinctBy { it.id }.sortedBy { it.createdAt }
            Store.refreshChats()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Toast.makeText(context, "Couldn't send: ${e.message ?: "try again"}", Toast.LENGTH_LONG).show()
        } finally {
            a.file.delete()
        }
    }

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            val rid = replyingTo?.id
            replyingTo = null
            scope.launch {
                uploading = true
                deliver(Attachments.prepareImage(context, uri), rid)
                uploading = false
            }
        }
    }
    val docPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val rid = replyingTo?.id
            replyingTo = null
            scope.launch {
                uploading = true
                deliver(Attachments.prepareDocument(context, uri), rid)
                uploading = false
            }
        }
    }

    // ---- Voice notes ----
    val recorder = remember { VoiceRecorder(context) }
    val levels = remember { mutableStateListOf<Float>() }
    var recording by remember { mutableStateOf(false) }
    var elapsed by remember { mutableStateOf(0L) }

    /** Ends the recording: send = upload it as a voice note, otherwise throw it away. */
    fun finishRecording(send: Boolean) {
        if (!recording) return
        recording = false
        val result = recorder.stop()
        val snapshot = levels.toList()
        levels.clear()
        if (!send) {
            result?.first?.delete()
            return
        }
        if (result == null || result.second < VoiceLimits.MIN_MS) {
            result?.first?.delete()
            Toast.makeText(context, "Voice message too short", Toast.LENGTH_SHORT).show()
            return
        }
        val voice = RecordedVoice(result.first, result.second.toInt(), encodeWaveform(snapshot))
        val replyId = replyingTo?.id
        replyingTo = null
        scope.launch {
            uploading = true
            try {
                val sent = Repo.sendVoice(chatId, voice, replyId)
                messages = (messages + sent).distinctBy { it.id }.sortedBy { it.createdAt }
                Store.refreshChats()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Toast.makeText(context, "Couldn't send: ${e.message ?: "try again"}", Toast.LENGTH_LONG).show()
            } finally {
                voice.file.delete()
                uploading = false
            }
        }
    }

    fun startRecording() {
        VoicePlayer.stop()
        if (recorder.start()) {
            levels.clear()
            elapsed = 0L
            recording = true
        } else {
            Toast.makeText(context, "Couldn't start recording", Toast.LENGTH_SHORT).show()
        }
    }

    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startRecording()
        else Toast.makeText(context, "Allow microphone access to record voice messages", Toast.LENGTH_LONG).show()
    }

    fun onMic() {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startRecording()
        } else {
            micPermission.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    fun toggleVoice(m: Msg) {
        scope.launch {
            val ok = try {
                VoicePlayer.toggle(m)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                false
            }
            if (!ok) Toast.makeText(context, "Couldn't play this voice message", Toast.LENGTH_SHORT).show()
        }
    }

    // Live loudness + timer while recording; stop on its own at the 10 minute limit
    LaunchedEffect(recording) {
        while (recording) {
            delay(60)
            if (!recording) break
            levels.add(recorder.level())
            elapsed = recorder.elapsedMs()
            if (elapsed >= VoiceLimits.MAX_MS) {
                finishRecording(true)
                break
            }
        }
    }

    // Android blocks the microphone once the app is in the background, so a recording can't continue there
    val lifecycle = (context as? ComponentActivity)?.lifecycle
    DisposableEffect(lifecycle) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_STOP && recording) {
                finishRecording(false)
                Toast.makeText(context, "Recording cancelled", Toast.LENGTH_SHORT).show()
            }
        }
        lifecycle?.addObserver(observer)
        onDispose { lifecycle?.removeObserver(observer) }
    }
    DisposableEffect(Unit) {
        onDispose {
            recorder.cancel()
            VoicePlayer.stop()
        }
    }

    fun openDocument(m: Msg) {
        scope.launch {
            if (!Attachments.isDocumentSaved(m)) Toast.makeText(context, "Downloading…", Toast.LENGTH_SHORT).show()
            val f = try {
                Attachments.document(m)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                null
            }
            if (f == null) {
                Toast.makeText(context, "Couldn't download this file", Toast.LENGTH_SHORT).show()
                return@launch
            }
            try {
                val uri = FileProvider.getUriForFile(context, "${context.packageName}.files", f)
                val intent = Intent(Intent.ACTION_VIEW)
                    .setDataAndType(uri, m.attachmentMime ?: "*/*")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                context.startActivity(intent)
            } catch (e: ActivityNotFoundException) {
                Toast.makeText(context, "No app on this phone can open this file", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                Toast.makeText(context, "Couldn't open this file", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // ---- Long-press menu actions ----

    fun actionsFor(m: Msg, mine: Boolean): List<MessageAction> = buildList {
        if (!m.deleted) {
            add(MessageAction.Reply)
            add(MessageAction.Forward)
            if ((m.kind == "text" || m.kind == "image") && m.body.isNotBlank()) add(MessageAction.Copy)
            if (mine) add(MessageAction.Info)
        }
        add(MessageAction.Delete)
    }

    fun quoteFor(m: Msg): QuoteInfo? {
        if (m.deleted) return null
        m.statusQuote?.let { q ->
            val label = q.text.ifBlank {
                when (q.kind) {
                    "photo" -> "Photo"
                    "video" -> "Video"
                    else -> "Status"
                }
            }
            return QuoteInfo("Status", label, bg = q.bg)
        }
        val id = m.replyTo ?: return null
        val orig = messages.firstOrNull { it.id == id }
            ?: return QuoteInfo("Message", "Original message unavailable")
        return QuoteInfo(if (orig.senderId == me) "You" else title, orig.preview, targetId = orig.id)
    }

    fun deleteForMe(m: Msg) {
        hiding.add(m.id)
        messages = messages.filter { it.id != m.id }
        if (replyingTo?.id == m.id) replyingTo = null
        scope.launch {
            try {
                Repo.hideMessage(m.id)
                Attachments.forget(m)
                Store.refreshChats()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                messages = (messages + m).distinctBy { it.id }.sortedBy { it.createdAt }
                Toast.makeText(context, "Couldn't delete the message", Toast.LENGTH_SHORT).show()
            } finally {
                hiding.remove(m.id)
            }
        }
    }

    fun deleteForEveryone(m: Msg) {
        val stone = m.copy(
            body = "", kind = "text", attachmentPath = null, attachmentName = null, attachmentMime = null,
            attachmentSize = 0L, voiceDurationMs = 0, voiceWaveform = null, replyTo = null, statusQuote = null,
            deletedAt = Instant.now(),
        )
        tombstones[m.id] = stone
        messages = messages.map { if (it.id == m.id) stone else it }
        if (replyingTo?.id == m.id) replyingTo = null
        if (VoicePlayer.currentId == m.id) VoicePlayer.stop()
        scope.launch {
            try {
                Repo.deleteForEveryone(m.id)
                Attachments.forget(m)
                Store.refreshChats()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                messages = messages.map { if (it.id == m.id) m else it }
                Toast.makeText(context, "Couldn't delete for everyone", Toast.LENGTH_SHORT).show()
            } finally {
                tombstones.remove(m.id)
            }
        }
    }

    fun forward(m: Msg, targets: List<ChatItem>) {
        scope.launch {
            var failed = 0
            for (c in targets) {
                try {
                    val sent: Msg = when (m.kind) {
                        "image", "file" -> {
                            val a = Attachments.prepareForward(m) ?: throw IllegalStateException("not on this phone")
                            try { Repo.sendAttachment(c.chatId, a) } finally { a.file.delete() }
                        }
                        "voice" -> {
                            val v = Attachments.prepareForwardVoice(m) ?: throw IllegalStateException("not on this phone")
                            try { Repo.sendVoice(c.chatId, v) } finally { v.file.delete() }
                        }
                        else -> Repo.send(c.chatId, m.body)
                    }
                    if (c.chatId == chatId) messages = (messages + sent).distinctBy { it.id }.sortedBy { it.createdAt }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    failed++
                }
            }
            Store.refreshChats()
            val note = when {
                failed == 0 -> "Forwarded"
                failed == targets.size -> "Couldn't forward"
                else -> "Couldn't forward to $failed chats"
            }
            Toast.makeText(context, note, Toast.LENGTH_SHORT).show()
        }
    }

    fun runAction(m: Msg, action: MessageAction) {
        when (action) {
            MessageAction.Reply -> replyingTo = m
            MessageAction.Forward -> forwarding = m
            MessageAction.Copy -> {
                val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("Message", m.body))
            }
            MessageAction.Info -> infoFor = m
            MessageAction.Delete -> deleting = m
        }
    }

    // Replying opens the keyboard so you can type straight away
    LaunchedEffect(replyingTo?.id) {
        if (replyingTo != null) {
            delay(60)
            try {
                composerFocus.requestFocus()
                keyboard?.show()
            } catch (e: Exception) {
            }
        }
    }

    val subtitle = peerSeen?.let { lastSeenLabel(it) } ?: peer?.let { "@${it.username}" }

    // Real height of the composer (bar + its margins), so messages always stop a fixed gap above it
    var composerPx by remember { mutableStateOf(0) }
    val composerDp = with(LocalDensity.current) { composerPx.toDp() }
    val listBottom = if (composerPx > 0) composerDp + 14.dp else navBottom + 100.dp
    val shown = remember(messages) { messages.asReversed() }

    Box(Modifier.fillMaxSize().background(Palette.Background)) {
        // Wallpaper + messages: this whole layer is what the glass pills blur and reflect
        Box(Modifier.fillMaxSize().haze(haze)) {
            ChatWallpaper(Modifier.fillMaxSize())
            // Messages fade out under the header pill and above the composer instead of running past them.
            // The mask is applied to the list only, so the wallpaper stays untouched.
            val fadeTop = with(LocalDensity.current) { (statusTop + 28.dp).toPx() }
            val fadeTopEnd = with(LocalDensity.current) { (statusTop + 92.dp).toPx() }
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .imePadding()
                    .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
                    .drawWithContent {
                        drawContent()
                        val h = size.height
                        val bottomSolid = (h - composerPx - 24.dp.toPx()).coerceAtLeast(fadeTopEnd + 1f)
                        val bottomClear = (h - composerPx * 0.6f).coerceAtLeast(bottomSolid + 1f)
                        drawRect(
                            brush = Brush.verticalGradient(
                                0f to Color.Transparent,
                                (fadeTop / h).coerceIn(0f, 1f) to Color.Transparent,
                                (fadeTopEnd / h).coerceIn(0f, 1f) to Color.Black,
                                (bottomSolid / h).coerceIn(0f, 1f) to Color.Black,
                                (bottomClear / h).coerceIn(0f, 1f) to Color.Transparent,
                                1f to Color.Transparent,
                            ),
                            blendMode = BlendMode.DstIn,
                        )
                    },
                state = listState,
                reverseLayout = true,
                contentPadding = PaddingValues(top = statusTop + 80.dp, bottom = listBottom),
                verticalArrangement = Arrangement.spacedBy(3.dp),
            ) {
                itemsIndexed(shown, key = { _, m -> m.id }) { index, m ->
                    val prev = shown.getOrNull(index + 1)
                    val next = shown.getOrNull(index - 1)
                    val mine = m.senderId == me
                    Column {
                        if (prev == null || prev.createdAt.dayKey() != m.createdAt.dayKey()) {
                            DayPill(m.createdAt.dayLabel())
                        }
                        Bubble(
                            msg = m,
                            mine = mine,
                            gapTop = if (prev == null || prev.senderId != m.senderId) 11.dp else 0.dp,
                            showTime = next == null || next.senderId != m.senderId,
                            tick = if (!mine || m.deleted) null else when {
                                m.readAt != null || (peerRead != null && peerRead!! >= m.createdAt) -> Tick.Read
                                m.deliveredAt != null || (chat?.peerLastDelivered != null && chat.peerLastDelivered >= m.createdAt) -> Tick.Delivered
                                else -> Tick.Sent
                            },
                            quote = quoteFor(m),
                            hidden = menu?.msg?.id == m.id,
                            onImage = { viewImage = m },
                            onFile = { openDocument(m) },
                            onVoice = { toggleVoice(m) },
                            onQuote = { id ->
                                val at = shown.indexOfFirst { it.id == id }
                                if (at >= 0) scope.launch { listState.animateScrollToItem(at) }
                            },
                            onLongPress = { bounds ->
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                keyboard?.hide()
                                menu = MenuTarget(m, mine, bounds)
                            },
                        )
                    }
                }
            }
        }

        // Floating layer (header + composer) rides above the keyboard
        Box(Modifier.fillMaxSize().imePadding()) {
        if (messages.isEmpty()) {
            Text(
                "Say hi to $title",
                color = Palette.TextSecondary,
                fontSize = 15.sp,
                modifier = Modifier.align(Alignment.Center),
            )
        }

        // Floating glass header: round back button + long pill (tap the pill for contact info)
        Row(
            Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 12.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            GlassIconButton(
                icon = Icons.AutoMirrored.Rounded.ArrowBack,
                description = "Back",
                haze = haze,
                size = 52.dp,
                calm = true,
                liquid = true,
                onClick = onBack,
            )
            Row(
                Modifier
                    .weight(1f)
                    .height(56.dp)
                    .glass(haze, RoundedCornerShape(28.dp), liquid = true)
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                        if (peer != null) showContact = true
                    }
                    .padding(start = 8.dp, end = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                ProfileAvatar(initials, 40.dp, peer?.avatarPath)
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(1.dp)) {
                    Text(title, color = Palette.TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                    if (subtitle != null) {
                        Text(subtitle, color = Palette.TextSecondary, fontSize = 12.sp, maxLines = 1)
                    }
                }
                PlainIconButton(
                    Icons.Rounded.Call, "Call $title", tint = Palette.AccentSoft,
                    onClick = { onCall(title, initials) },
                )
            }
        }

        if (uploading) {
            Text(
                "Sending…",
                color = Palette.TextSecondary,
                fontSize = 13.sp,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .navigationBarsPadding()
                    .padding(bottom = 92.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Palette.tint(0.07f))
                    .padding(horizontal = 14.dp, vertical = 5.dp),
            )
        }

        // Floating glass composer (or a notice if you blocked this contact)
        if (blocked && peerId != null) {
            Row(
                Modifier
                    .align(Alignment.BottomCenter)
                    .onSizeChanged { composerPx = it.height }
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(horizontal = 12.dp)
                    .padding(bottom = 24.dp)
                    .heightIn(min = 60.dp)
                    .glass(haze, RoundedCornerShape(30.dp), liquid = true)
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Text("You blocked this contact.", color = Palette.TextSecondary, fontSize = 14.sp, modifier = Modifier.weight(1f))
                SoftButton("Unblock", Modifier.widthIn(min = 96.dp)) { scope.launch { Store.setBlocked(peerId, false) } }
            }
        } else {
            val canSend = text.isNotBlank()
            val sendAlpha by animateFloatAsState(if (canSend) 1f else 0.45f, tween(150), label = "sendAlpha")
            Column(
                Modifier
                    .align(Alignment.BottomCenter)
                    .onSizeChanged { composerPx = it.height }
                    .fillMaxWidth(),
            ) {
            replyingTo?.let { r ->
                ReplyBar(
                    name = if (r.senderId == me) "yourself" else title,
                    text = r.preview,
                    haze = haze,
                    onClose = { replyingTo = null },
                )
            }
            Row(
                Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(horizontal = 12.dp)
                    .padding(bottom = 24.dp)
                    .height(60.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                // The message bar shrinks to the left; while recording it becomes the waveform bar
                Box(Modifier.weight(1f).fillMaxHeight()) {
                    Crossfade(recording, animationSpec = tween(180), label = "composerBar") { rec ->
                        if (rec) {
                            Box(Modifier.fillMaxSize().glass(haze, RoundedCornerShape(30.dp), liquid = true)) {
                                RecordingContent(levels, elapsed, onCancel = { finishRecording(false) })
                            }
                        } else {
                            Row(
                                Modifier
                                    .fillMaxSize()
                                    .glass(haze, RoundedCornerShape(30.dp), liquid = true)
                                    .padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                            ) {
                                PlainIconButton(Icons.Rounded.Add, "Attach", tint = Palette.TextPrimary) { showAttach = true }
                                GlassField(
                                    value = text,
                                    onValueChange = { text = it },
                                    placeholder = "Message",
                                    modifier = Modifier.weight(1f).focusRequester(composerFocus),
                                    imeAction = ImeAction.Send,
                                    onImeAction = { send() },
                                )
                                GlassIconButton(
                                    icon = Icons.Rounded.ArrowUpward,
                                    description = "Send",
                                    modifier = Modifier.graphicsLayer { alpha = sendAlpha },
                                    size = 44.dp,
                                    solid = Palette.Accent,
                                    tint = Color.White,
                                    calm = true,
                                    onClick = { send() },
                                )
                            }
                        }
                    }
                }
                // Standalone liquid-glass mic; turns into the send button while recording
                if (recording) {
                    GlassIconButton(
                        icon = Icons.Rounded.ArrowUpward,
                        description = "Send voice message",
                        size = 60.dp,
                        solid = Palette.Accent,
                        tint = Color.White,
                        calm = true,
                        onClick = { finishRecording(true) },
                    )
                } else {
                    GlassIconButton(
                        icon = Icons.Rounded.Mic,
                        description = "Record voice message",
                        haze = haze,
                        size = 60.dp,
                        calm = true,
                        liquid = true,
                        onClick = { onMic() },
                    )
                }
            }
            }
        }
        } // floating layer

        // Long-press menu: everything blurs, the bubble lifts, actions slide in under it
        menu?.let { t ->
            MessageMenuOverlay(
                target = t,
                haze = haze,
                actions = actionsFor(t.msg, t.mine),
                onAction = { a ->
                    menu = null
                    runAction(t.msg, a)
                },
                onDismiss = { menu = null },
                bubble = { BubbleBody(t.msg, t.mine, quoteFor(t.msg)) },
            )
        }
    }

    deleting?.let { m ->
        DeleteSheet(
            canDeleteForEveryone = m.senderId == me && !m.deleted,
            onDeleteForMe = { deleteForMe(m) },
            onDeleteForEveryone = { deleteForEveryone(m) },
            onDismiss = { deleting = null },
        )
    }

    forwarding?.let { m ->
        ForwardSheet(
            chats = Store.chats.filter { it.peer?.id !in Store.blockedIds },
            onSend = { targets -> forward(m, targets) },
            onDismiss = { forwarding = null },
        )
    }

    infoFor?.let { m ->
        val live = messages.firstOrNull { it.id == m.id } ?: m
        InfoSheet(live, onDismiss = { infoFor = null }) { BubbleBody(live, true, quoteFor(live)) }
    }

    if (showAttach) {
        AttachSheet(
            onPhoto = {
                showAttach = false
                imagePicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
            },
            onDocument = {
                showAttach = false
                docPicker.launch(arrayOf("*/*"))
            },
            onDismiss = { showAttach = false },
        )
    }

    viewImage?.let { m ->
        Dialog(onDismissRequest = { viewImage = null }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
            val bmp by produceState<Bitmap?>(null, m.attachmentPath) { value = m.attachmentPath?.let { Attachments.bitmap(it) } }
            Box(
                Modifier.fillMaxSize().background(Color.Black).clickable { viewImage = null },
                contentAlignment = Alignment.Center,
            ) {
                bmp?.let { Image(it.asImageBitmap(), "Photo", Modifier.fillMaxSize(), contentScale = ContentScale.Fit) }
            }
        }
    }

    if (showContact && peer != null) {
        ContactSheet(
            peer = peer,
            status = peerSeen?.let { lastSeenLabel(it) },
            blocked = blocked,
            closeFriend = closeFriend,
            onToggleClose = { scope.launch { Store.toggleCloseFriend(peer.id) } },
            onToggleBlock = { scope.launch { Store.setBlocked(peer.id, !blocked) } },
            onDismiss = { showContact = false },
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ContactSheet(
    peer: Profile,
    status: String?,
    blocked: Boolean,
    closeFriend: Boolean,
    onToggleClose: () -> Unit,
    onToggleBlock: () -> Unit,
    onDismiss: () -> Unit,
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = Palette.Sheet,
        contentColor = Palette.TextPrimary,
    ) {
        Column(
            Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 24.dp).padding(bottom = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            ProfileAvatar(peer.initials, 88.dp, peer.avatarPath)
            Spacer(Modifier.height(12.dp))
            Text(peer.name, color = Palette.TextPrimary, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
            Text("@${peer.username}", color = Palette.TextSecondary, fontSize = 14.sp)
            if (status != null) {
                Spacer(Modifier.height(6.dp))
                Text(status, color = Palette.AccentSoft, fontSize = 13.sp)
            }
            if (peer.about.isNotBlank()) {
                Spacer(Modifier.height(12.dp))
                Text(peer.about, color = Palette.TextPrimary, fontSize = 15.sp, textAlign = TextAlign.Center)
            }
            Spacer(Modifier.height(20.dp))
            Row(
                Modifier
                    .fillMaxWidth()
                    .heightIn(min = 52.dp)
                    .pressable(0.99f, haptic = true, onClick = onToggleClose),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text("Close friend", color = Palette.TextPrimary, fontSize = 16.sp)
                    Text("Can see your last seen and when you’re active", color = Palette.TextSecondary, fontSize = 12.sp)
                }
                GlassSwitch(closeFriend)
            }
            Spacer(Modifier.height(12.dp))
            SoftButton(if (blocked) "Unblock contact" else "Block contact", Modifier.fillMaxWidth(), onClick = onToggleBlock)
        }
    }
}

@Composable
private fun DayPill(label: String) {
    val shape = RoundedCornerShape(14.dp)
    Box(Modifier.fillMaxWidth().padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
        Text(
            label,
            color = Palette.TextSecondary,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier
                .clip(shape)
                .background(Palette.tint(0.07f))
                .border(1.dp, Palette.tint(0.08f), shape)
                .padding(horizontal = 14.dp, vertical = 5.dp),
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AttachSheet(onPhoto: () -> Unit, onDocument: () -> Unit, onDismiss: () -> Unit) {
    val sheetState = rememberModalBottomSheetState()
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = Palette.Sheet,
        contentColor = Palette.TextPrimary,
    ) {
        Column(
            Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 24.dp).padding(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            AttachRow(Icons.Rounded.Image, "Photo", "Send a picture from your gallery", onPhoto)
            AttachRow(Icons.Rounded.Description, "Document", "PDF, Word, Excel, ZIP or any file up to 25 MB", onDocument)
        }
    }
}

@Composable
private fun AttachRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().heightIn(min = 60.dp).pressable(0.99f, haptic = true, onClick = onClick),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Box(
            Modifier.size(44.dp).clip(RoundedCornerShape(22.dp)).background(Palette.Accent),
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, null, tint = Color.White, modifier = Modifier.size(22.dp))
        }
        Column(Modifier.weight(1f)) {
            Text(title, color = Palette.TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Medium)
            Text(subtitle, color = Palette.TextSecondary, fontSize = 12.sp)
        }
    }
}

/** What a quoted block at the top of a bubble shows. */
private class QuoteInfo(val name: String, val text: String, val bg: String? = null, val targetId: String? = null)

@Composable
private fun Bubble(
    msg: Msg,
    mine: Boolean,
    gapTop: Dp,
    showTime: Boolean,
    tick: Tick?,
    quote: QuoteInfo?,
    hidden: Boolean,
    onImage: () -> Unit,
    onFile: () -> Unit,
    onVoice: () -> Unit,
    onQuote: (String) -> Unit,
    onLongPress: (Rect) -> Unit,
) {
    var bounds by remember { mutableStateOf(Rect.Zero) }
    var pressed by remember { mutableStateOf(false) }
    val press by animateFloatAsState(if (pressed) 0.97f else 1f, tween(120), label = "bubblePress")
    val longPress by rememberUpdatedState(onLongPress)
    val tap by rememberUpdatedState<() -> Unit>(
        when {
            msg.deleted -> ({})
            msg.kind == "image" -> onImage
            msg.kind == "file" -> onFile
            msg.kind == "voice" -> onVoice
            else -> ({})
        },
    )
    Column(
        Modifier
            .fillMaxWidth()
            .padding(start = 16.dp, end = 16.dp, top = gapTop)
            .graphicsLayer { alpha = if (hidden) 0f else 1f },
        horizontalAlignment = if (mine) Alignment.End else Alignment.Start,
    ) {
        BubbleBody(
            msg = msg,
            mine = mine,
            quote = quote,
            modifier = Modifier
                .onGloballyPositioned { bounds = it.boundsInRoot() }
                .graphicsLayer {
                    scaleX = press
                    scaleY = press
                }
                .pointerInput(msg.id) {
                    detectTapGestures(
                        onPress = {
                            pressed = true
                            tryAwaitRelease()
                            pressed = false
                        },
                        onLongPress = { longPress(bounds) },
                        onTap = { tap() },
                    )
                },
            onQuote = onQuote,
            onVoice = onVoice,
            onVoiceLongPress = { longPress(bounds) },
        )
        if (showTime) {
            Row(
                Modifier.padding(start = 6.dp, end = 6.dp, top = 3.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                Text(msg.createdAt.clock(), color = Palette.TextSecondary, fontSize = 11.sp)
                if (tick != null) {
                    val tickColor by animateColorAsState(
                        if (tick == Tick.Read) Palette.AccentSoft else Palette.TextSecondary, tween(300), label = "bubbleTick",
                    )
                    LIcon(if (tick == Tick.Sent) Ic.Sent else Ic.Delivered, tickColor, 15.dp)
                }
            }
        }
    }
}

/** The coloured bubble itself. The long-press menu draws a second copy of it, so it has no behaviour of its own. */
@Composable
private fun BubbleBody(
    msg: Msg,
    mine: Boolean,
    quote: QuoteInfo?,
    modifier: Modifier = Modifier,
    onQuote: (String) -> Unit = {},
    onVoice: () -> Unit = {},
    onVoiceLongPress: () -> Unit = {},
) {
    val shape = RoundedCornerShape(20.dp)
    val fg = if (mine) Color.White else Palette.TextPrimary
    Box(
        modifier
            .widthIn(max = 270.dp)
            .clip(shape)
            .background(if (mine) Palette.Accent else Palette.BubbleIn)
            .border(
                1.dp,
                if (mine) Color.White.copy(alpha = 0.16f) else Palette.tint(0.08f),
                shape,
            )
            .padding(
                when {
                    msg.deleted -> PaddingValues(horizontal = 15.dp, vertical = 10.dp)
                    msg.kind == "image" -> PaddingValues(3.dp)
                    msg.kind == "voice" -> PaddingValues(horizontal = 12.dp, vertical = 9.dp)
                    else -> PaddingValues(horizontal = 15.dp, vertical = 10.dp)
                },
            ),
    ) {
        if (msg.deleted) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                LIcon(Ic.Ban, fg.copy(alpha = 0.7f), 16.dp)
                Text(
                    "This message was deleted", color = fg.copy(alpha = 0.75f), fontSize = 15.sp,
                    fontStyle = FontStyle.Italic,
                )
            }
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                if (quote != null) {
                    QuoteBlock(quote, mine, fg, onQuote, if (msg.kind == "image") Modifier.padding(6.dp) else Modifier)
                }
                when (msg.kind) {
                    "image" -> Column {
                        ImageAttachment(msg)
                        if (msg.body.isNotBlank()) {
                            Text(
                                msg.body, color = fg, fontSize = 16.sp, lineHeight = 21.sp,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                            )
                        }
                    }
                    "file" -> FileAttachment(msg, fg)
                    "voice" -> VoiceMessage(msg, fg, onVoice, onVoiceLongPress)
                    else -> Text(msg.body, color = fg, fontSize = 16.sp, lineHeight = 21.sp)
                }
            }
        }
    }
}

/** "Replying to ..." strip above the composer, in the same glass as the composer. */
@Composable
private fun ReplyBar(name: String, text: String, haze: HazeState, onClose: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp)
            .padding(bottom = 8.dp)
            .height(56.dp)
            .glass(haze, RoundedCornerShape(24.dp), liquid = true)
            .padding(start = 16.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Box(Modifier.width(3.dp).height(32.dp).clip(CircleShape).background(Palette.Accent))
        Column(Modifier.weight(1f)) {
            Text(
                "Replying to $name", color = Palette.AccentSoft, fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold, maxLines = 1,
            )
            Text(text, color = Palette.TextSecondary, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Box(
            Modifier.size(44.dp).pressable(0.82f, haptic = true, onClick = onClose),
            contentAlignment = Alignment.Center,
        ) { LIcon(Ic.X, Palette.TextSecondary, 20.dp) }
    }
}

/** The quoted message (or status) at the top of a reply bubble. Tap it to jump to the original. */
@Composable
private fun QuoteBlock(q: QuoteInfo, mine: Boolean, fg: Color, onClick: (String) -> Unit, modifier: Modifier = Modifier) {
    val target = q.targetId
    Row(
        modifier
            .widthIn(min = 140.dp)
            .height(IntrinsicSize.Min)
            .clip(RoundedCornerShape(10.dp))
            .background(fg.copy(alpha = 0.14f))
            .let { m ->
                if (target != null) m.pointerInput(target) { detectTapGestures(onTap = { onClick(target) }) } else m
            },
    ) {
        Box(
            Modifier
                .width(4.dp)
                .fillMaxHeight()
                .background(if (q.bg != null) statusBrush(q.bg) else SolidColor(if (mine) Color.White else Palette.Accent)),
        )
        Column(Modifier.padding(horizontal = 10.dp, vertical = 6.dp)) {
            Text(
                q.name, color = if (mine) Color.White else Palette.AccentSoft, fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold, maxLines = 1,
            )
            Text(
                q.text, color = fg.copy(alpha = 0.85f), fontSize = 13.sp, lineHeight = 17.sp,
                maxLines = 2, overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

@Composable
private fun ImageAttachment(msg: Msg) {
    val shape = RoundedCornerShape(17.dp)
    val result by produceState<Any?>(null, msg.attachmentPath) {
        value = msg.attachmentPath?.let { Attachments.bitmap(it) } ?: "fail"
    }
    val r = result
    if (r is Bitmap) {
        val ratio = (r.width.toFloat() / r.height).coerceIn(0.6f, 1.8f)
        Image(
            r.asImageBitmap(), "Photo",
            Modifier.width(240.dp).aspectRatio(ratio).clip(shape),
            contentScale = ContentScale.Crop,
        )
    } else {
        Box(
            Modifier.width(240.dp).height(170.dp).clip(shape).background(Palette.tint(0.06f)),
            contentAlignment = Alignment.Center,
        ) {
            if (r == null) {
                CircularProgressIndicator(color = Palette.TextSecondary, strokeWidth = 2.dp, modifier = Modifier.size(24.dp))
            } else {
                Text("Photo unavailable", color = Palette.TextSecondary, fontSize = 13.sp)
            }
        }
    }
}

@Composable
private fun FileAttachment(msg: Msg, fg: Color) {
    Row(
        Modifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Box(
            Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(fg.copy(alpha = 0.16f)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Rounded.Description, null, tint = fg, modifier = Modifier.size(22.dp))
        }
        Column(Modifier.widthIn(max = 180.dp)) {
            Text(
                msg.attachmentName ?: "Document", color = fg, fontSize = 15.sp, fontWeight = FontWeight.Medium,
                maxLines = 2, overflow = TextOverflow.Ellipsis,
            )
            Text(formatSize(msg.attachmentSize), color = fg.copy(alpha = 0.75f), fontSize = 12.sp)
        }
    }
}
