package app.instants.ui.screens

import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Bitmap
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.runtime.produceState
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.FileProvider
import app.instants.data.Attachments
import app.instants.push.Push
import app.instants.data.PreparedAttachment
import app.instants.data.formatSize
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.Call
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import app.instants.ui.components.ChatWallpaper
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.instants.data.Cache
import app.instants.data.Msg
import app.instants.data.Profile
import app.instants.data.Repo
import app.instants.data.Session
import app.instants.data.Store
import app.instants.data.clock
import app.instants.data.dayKey
import app.instants.data.dayLabel
import app.instants.data.initialsOf
import app.instants.data.lastSeenLabel
import app.instants.ui.components.GlassField
import app.instants.ui.components.GlassIconButton
import app.instants.ui.components.GlassSwitch
import app.instants.ui.components.PlainIconButton
import app.instants.ui.components.ProfileAvatar
import app.instants.ui.components.SoftButton
import app.instants.ui.components.glass
import app.instants.ui.components.pressable
import app.instants.ui.theme.Palette
import dev.chrisbanes.haze.HazeState
import dev.chrisbanes.haze.haze
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.Instant

/** Chat screen. Intentionally calm: no bouncing, popping or sliding when messages arrive. */
@Composable
fun ChatScreen(chatId: String, onBack: () -> Unit, onCall: (String, String) -> Unit) {
    val me = Session.userId.orEmpty()
    val chat = Store.chats.firstOrNull { it.chatId == chatId }
    val peer = chat?.peer
    val peerId = peer?.id
    val title = chat?.title ?: "Chat"
    val initials = chat?.initials ?: initialsOf(title)
    val blocked = peerId != null && peerId in Store.blockedIds
    val closeFriend = peerId != null && peerId in Store.closeFriendIds

    val haze = remember { HazeState() }
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    var text by remember { mutableStateOf("") }
    // Start from the saved copy so the conversation is there instantly
    var messages by remember { mutableStateOf(Cache.loadThread(chatId)) }
    var peerRead by remember { mutableStateOf<Instant?>(null) }
    var peerSeen by remember { mutableStateOf<Instant?>(null) }
    var showContact by remember { mutableStateOf(false) }
    var showAttach by remember { mutableStateOf(false) }
    var uploading by remember { mutableStateOf(false) }
    var viewImage by remember { mutableStateOf<Msg?>(null) }
    val statusTop = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val navBottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()

    // While this chat is open, its notifications are not shown (and any waiting ones are cleared)
    androidx.compose.runtime.DisposableEffect(chatId) {
        Push.activeChatId = chatId
        Push.cancel(context, chatId)
        onDispose { if (Push.activeChatId == chatId) Push.activeChatId = null }
    }

    // New messages: every 2 seconds. Marks incoming ones as read.
    LaunchedEffect(chatId) {
        var marked: Instant = Instant.EPOCH
        while (true) {
            try {
                val t = Repo.loadThread(chatId)
                messages = t.messages
                peerRead = t.peerLastRead
                Cache.saveThread(chatId, t.messages)
                val newest = t.messages.lastOrNull { it.senderId != me }?.createdAt
                if (newest != null && newest > marked) {
                    Repo.markRead(chatId)
                    marked = newest
                    Store.refreshChats()
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // try again on the next tick
            }
            delay(2000)
        }
    }

    // Last seen / active status (only returned if both of you allow it)
    LaunchedEffect(peerId) {
        while (true) {
            if (peerId != null) {
                try {
                    peerSeen = Repo.statuses(listOf(peerId))[peerId]
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                }
            }
            delay(15_000)
        }
    }

    // The list is anchored to the bottom (reverseLayout), so photos loading, the keyboard opening
    // and new messages never push the newest message out of view. Only a new message needs a nudge.
    val newestId = messages.lastOrNull()?.id
    LaunchedEffect(newestId) {
        if (newestId != null && (listState.firstVisibleItemIndex <= 2 || messages.lastOrNull()?.senderId == me)) {
            listState.scrollToItem(0)
        }
    }

    fun send() {
        val body = text.trim()
        if (body.isEmpty()) return
        text = ""
        scope.launch {
            try {
                val sent = Repo.send(chatId, body)
                messages = (messages + sent).distinctBy { it.id }.sortedBy { it.createdAt }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                text = body
                Toast.makeText(context, "Message not sent", Toast.LENGTH_SHORT).show()
            }
        }
    }

    /** Uploads a picked photo or document and adds it to the conversation. */
    suspend fun deliver(prepared: Result<PreparedAttachment>) {
        val a = prepared.getOrElse {
            Toast.makeText(context, it.message ?: "Couldn't attach that", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val sent = Repo.sendAttachment(chatId, a)
            messages = (messages + sent).distinctBy { it.id }.sortedBy { it.createdAt }
            Store.refreshChats()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Toast.makeText(context, "Couldn't send: ${e.message ?: "try again"}", Toast.LENGTH_LONG).show()
        } finally {
            a.file.delete()
        }
    }

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            scope.launch {
                uploading = true
                deliver(Attachments.prepareImage(context, uri))
                uploading = false
            }
        }
    }
    val docPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                uploading = true
                deliver(Attachments.prepareDocument(context, uri))
                uploading = false
            }
        }
    }

    fun openDocument(m: Msg) {
        scope.launch {
            if (!Attachments.isDocumentSaved(m)) Toast.makeText(context, "Downloading…", Toast.LENGTH_SHORT).show()
            val f = try {
                Attachments.document(m)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                null
            }
            if (f == null) {
                Toast.makeText(context, "Couldn't download this file", Toast.LENGTH_SHORT).show()
                return@launch
            }
            try {
                val uri = FileProvider.getUriForFile(context, "${context.packageName}.files", f)
                val intent = Intent(Intent.ACTION_VIEW)
                    .setDataAndType(uri, m.attachmentMime ?: "*/*")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                context.startActivity(intent)
            } catch (e: ActivityNotFoundException) {
                Toast.makeText(context, "No app on this phone can open this file", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                Toast.makeText(context, "Couldn't open this file", Toast.LENGTH_SHORT).show()
            }
        }
    }

    val subtitle = peerSeen?.let { lastSeenLabel(it) } ?: peer?.let { "@${it.username}" }

    // Real height of the composer (bar + its margins), so messages always stop a fixed gap above it
    var composerPx by remember { mutableStateOf(0) }
    val composerDp = with(LocalDensity.current) { composerPx.toDp() }
    val listBottom = if (composerPx > 0) composerDp + 14.dp else navBottom + 100.dp
    val shown = remember(messages) { messages.asReversed() }

    Box(Modifier.fillMaxSize().background(Palette.Background)) {
        // Wallpaper + messages: this whole layer is what the glass pills blur and reflect
        Box(Modifier.fillMaxSize().haze(haze)) {
            ChatWallpaper(Modifier.fillMaxSize())
            LazyColumn(
                modifier = Modifier.fillMaxSize().imePadding(),
                state = listState,
                reverseLayout = true,
                contentPadding = PaddingValues(top = statusTop + 80.dp, bottom = listBottom),
                verticalArrangement = Arrangement.spacedBy(3.dp),
            ) {
                itemsIndexed(shown, key = { _, m -> m.id }) { index, m ->
                    val prev = shown.getOrNull(index + 1)
                    val next = shown.getOrNull(index - 1)
                    val mine = m.senderId == me
                    Column {
                        if (prev == null || prev.createdAt.dayKey() != m.createdAt.dayKey()) {
                            DayPill(m.createdAt.dayLabel())
                        }
                        Bubble(
                            msg = m,
                            mine = mine,
                            gapTop = if (prev == null || prev.senderId != m.senderId) 11.dp else 0.dp,
                            showTime = next == null || next.senderId != m.senderId,
                            read = mine && peerRead.let { it != null && it >= m.createdAt },
                            onImage = { viewImage = m },
                            onFile = { openDocument(m) },
                        )
                    }
                }
            }
        }

        // Floating layer (header + composer) rides above the keyboard
        Box(Modifier.fillMaxSize().imePadding()) {
        if (messages.isEmpty()) {
            Text(
                "Say hi to $title",
                color = Palette.TextSecondary,
                fontSize = 15.sp,
                modifier = Modifier.align(Alignment.Center),
            )
        }

        // Floating glass header: round back button + long pill (tap the pill for contact info)
        Row(
            Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 12.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            GlassIconButton(
                icon = Icons.AutoMirrored.Rounded.ArrowBack,
                description = "Back",
                haze = haze,
                size = 52.dp,
                calm = true,
                liquid = true,
                onClick = onBack,
            )
            Row(
                Modifier
                    .weight(1f)
                    .height(56.dp)
                    .glass(haze, RoundedCornerShape(28.dp), liquid = true)
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                        if (peer != null) showContact = true
                    }
                    .padding(start = 8.dp, end = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                ProfileAvatar(initials, 40.dp, peer?.avatarPath)
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(1.dp)) {
                    Text(title, color = Palette.TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                    if (subtitle != null) {
                        Text(subtitle, color = Palette.TextSecondary, fontSize = 12.sp, maxLines = 1)
                    }
                }
                PlainIconButton(
                    Icons.Rounded.Call, "Call $title", tint = Palette.AccentSoft,
                    onClick = { onCall(title, initials) },
                )
            }
        }

        if (uploading) {
            Text(
                "Sending…",
                color = Palette.TextSecondary,
                fontSize = 13.sp,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .navigationBarsPadding()
                    .padding(bottom = 92.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Palette.tint(0.07f))
                    .padding(horizontal = 14.dp, vertical = 5.dp),
            )
        }

        // Floating glass composer (or a notice if you blocked this contact)
        if (blocked && peerId != null) {
            Row(
                Modifier
                    .align(Alignment.BottomCenter)
                    .onSizeChanged { composerPx = it.height }
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(horizontal = 12.dp)
                    .padding(bottom = 24.dp)
                    .heightIn(min = 60.dp)
                    .glass(haze, RoundedCornerShape(30.dp), liquid = true)
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Text("You blocked this contact.", color = Palette.TextSecondary, fontSize = 14.sp, modifier = Modifier.weight(1f))
                SoftButton("Unblock", Modifier.widthIn(min = 96.dp)) { scope.launch { Store.setBlocked(peerId, false) } }
            }
        } else {
            val canSend = text.isNotBlank()
            val sendAlpha by animateFloatAsState(if (canSend) 1f else 0.45f, tween(150), label = "sendAlpha")
            Row(
                Modifier
                    .align(Alignment.BottomCenter)
                    .onSizeChanged { composerPx = it.height }
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(horizontal = 12.dp)
                    .padding(bottom = 24.dp)
                    .height(60.dp)
                    .glass(haze, RoundedCornerShape(30.dp), liquid = true)
                    .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                PlainIconButton(Icons.Rounded.Add, "Attach", tint = Palette.TextPrimary) { showAttach = true }
                GlassField(
                    value = text,
                    onValueChange = { text = it },
                    placeholder = "Message",
                    modifier = Modifier.weight(1f),
                    imeAction = ImeAction.Send,
                    onImeAction = { send() },
                )
                GlassIconButton(
                    icon = Icons.Rounded.ArrowUpward,
                    description = "Send",
                    modifier = Modifier.graphicsLayer { alpha = sendAlpha },
                    size = 44.dp,
                    solid = Palette.Accent,
                    tint = Color.White,
                    calm = true,
                    onClick = { send() },
                )
            }
        }
        } // floating layer
    }

    if (showAttach) {
        AttachSheet(
            onPhoto = {
                showAttach = false
                imagePicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
            },
            onDocument = {
                showAttach = false
                docPicker.launch(arrayOf("*/*"))
            },
            onDismiss = { showAttach = false },
        )
    }

    viewImage?.let { m ->
        Dialog(onDismissRequest = { viewImage = null }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
            val bmp by produceState<Bitmap?>(null, m.attachmentPath) { value = m.attachmentPath?.let { Attachments.bitmap(it) } }
            Box(
                Modifier.fillMaxSize().background(Color.Black).clickable { viewImage = null },
                contentAlignment = Alignment.Center,
            ) {
                bmp?.let { Image(it.asImageBitmap(), "Photo", Modifier.fillMaxSize(), contentScale = ContentScale.Fit) }
            }
        }
    }

    if (showContact && peer != null) {
        ContactSheet(
            peer = peer,
            status = peerSeen?.let { lastSeenLabel(it) },
            blocked = blocked,
            closeFriend = closeFriend,
            onToggleClose = { scope.launch { Store.toggleCloseFriend(peer.id) } },
            onToggleBlock = { scope.launch { Store.setBlocked(peer.id, !blocked) } },
            onDismiss = { showContact = false },
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ContactSheet(
    peer: Profile,
    status: String?,
    blocked: Boolean,
    closeFriend: Boolean,
    onToggleClose: () -> Unit,
    onToggleBlock: () -> Unit,
    onDismiss: () -> Unit,
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = Palette.Sheet,
        contentColor = Palette.TextPrimary,
    ) {
        Column(
            Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 24.dp).padding(bottom = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            ProfileAvatar(peer.initials, 88.dp, peer.avatarPath)
            Spacer(Modifier.height(12.dp))
            Text(peer.name, color = Palette.TextPrimary, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
            Text("@${peer.username}", color = Palette.TextSecondary, fontSize = 14.sp)
            if (status != null) {
                Spacer(Modifier.height(6.dp))
                Text(status, color = Palette.AccentSoft, fontSize = 13.sp)
            }
            if (peer.about.isNotBlank()) {
                Spacer(Modifier.height(12.dp))
                Text(peer.about, color = Palette.TextPrimary, fontSize = 15.sp, textAlign = TextAlign.Center)
            }
            Spacer(Modifier.height(20.dp))
            Row(
                Modifier
                    .fillMaxWidth()
                    .heightIn(min = 52.dp)
                    .pressable(0.99f, haptic = true, onClick = onToggleClose),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text("Close friend", color = Palette.TextPrimary, fontSize = 16.sp)
                    Text("Can see your last seen and when you’re active", color = Palette.TextSecondary, fontSize = 12.sp)
                }
                GlassSwitch(closeFriend)
            }
            Spacer(Modifier.height(12.dp))
            SoftButton(if (blocked) "Unblock contact" else "Block contact", Modifier.fillMaxWidth(), onClick = onToggleBlock)
        }
    }
}

@Composable
private fun DayPill(label: String) {
    val shape = RoundedCornerShape(14.dp)
    Box(Modifier.fillMaxWidth().padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
        Text(
            label,
            color = Palette.TextSecondary,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier
                .clip(shape)
                .background(Palette.tint(0.07f))
                .border(1.dp, Palette.tint(0.08f), shape)
                .padding(horizontal = 14.dp, vertical = 5.dp),
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AttachSheet(onPhoto: () -> Unit, onDocument: () -> Unit, onDismiss: () -> Unit) {
    val sheetState = rememberModalBottomSheetState()
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = Palette.Sheet,
        contentColor = Palette.TextPrimary,
    ) {
        Column(
            Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 24.dp).padding(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            AttachRow(Icons.Rounded.Image, "Photo", "Send a picture from your gallery", onPhoto)
            AttachRow(Icons.Rounded.Description, "Document", "PDF, Word, Excel, ZIP or any file up to 25 MB", onDocument)
        }
    }
}

@Composable
private fun AttachRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().heightIn(min = 60.dp).pressable(0.99f, haptic = true, onClick = onClick),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Box(
            Modifier.size(44.dp).clip(RoundedCornerShape(22.dp)).background(Palette.Accent),
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, null, tint = Color.White, modifier = Modifier.size(22.dp))
        }
        Column(Modifier.weight(1f)) {
            Text(title, color = Palette.TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Medium)
            Text(subtitle, color = Palette.TextSecondary, fontSize = 12.sp)
        }
    }
}

@Composable
private fun Bubble(
    msg: Msg,
    mine: Boolean,
    gapTop: Dp,
    showTime: Boolean,
    read: Boolean,
    onImage: () -> Unit,
    onFile: () -> Unit,
) {
    val shape = RoundedCornerShape(20.dp)
    val fg = if (mine) Color.White else Palette.TextPrimary
    Column(
        Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = gapTop),
        horizontalAlignment = if (mine) Alignment.End else Alignment.Start,
    ) {
        Box(
            Modifier
                .widthIn(max = 270.dp)
                .clip(shape)
                .background(if (mine) Palette.Accent else Palette.BubbleIn)
                .border(
                    1.dp,
                    if (mine) Color.White.copy(alpha = 0.16f) else Palette.tint(0.08f),
                    shape,
                )
                .padding(if (msg.kind == "image") PaddingValues(3.dp) else PaddingValues(horizontal = 15.dp, vertical = 10.dp)),
        ) {
            when (msg.kind) {
                "image" -> Column {
                    ImageAttachment(msg, onImage)
                    if (msg.body.isNotBlank()) {
                        Text(
                            msg.body, color = fg, fontSize = 16.sp, lineHeight = 21.sp,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                        )
                    }
                }
                "file" -> FileAttachment(msg, fg, onFile)
                else -> Text(msg.body, color = fg, fontSize = 16.sp, lineHeight = 21.sp)
            }
        }
        if (showTime) {
            Text(
                msg.createdAt.clock() + if (read) " · Read" else "",
                color = Palette.TextSecondary,
                fontSize = 11.sp,
                modifier = Modifier.padding(start = 6.dp, end = 6.dp, top = 3.dp),
            )
        }
    }
}

@Composable
private fun ImageAttachment(msg: Msg, onClick: () -> Unit) {
    val shape = RoundedCornerShape(17.dp)
    val result by produceState<Any?>(null, msg.attachmentPath) {
        value = msg.attachmentPath?.let { Attachments.bitmap(it) } ?: "fail"
    }
    val r = result
    if (r is Bitmap) {
        val ratio = (r.width.toFloat() / r.height).coerceIn(0.6f, 1.8f)
        Image(
            r.asImageBitmap(), "Photo",
            Modifier.width(240.dp).aspectRatio(ratio).clip(shape).clickable(onClick = onClick),
            contentScale = ContentScale.Crop,
        )
    } else {
        Box(
            Modifier.width(240.dp).height(170.dp).clip(shape).background(Palette.tint(0.06f)),
            contentAlignment = Alignment.Center,
        ) {
            if (r == null) {
                CircularProgressIndicator(color = Palette.TextSecondary, strokeWidth = 2.dp, modifier = Modifier.size(24.dp))
            } else {
                Text("Photo unavailable", color = Palette.TextSecondary, fontSize = 13.sp)
            }
        }
    }
}

@Composable
private fun FileAttachment(msg: Msg, fg: Color, onClick: () -> Unit) {
    Row(
        Modifier.clickable(onClick = onClick),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Box(
            Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(fg.copy(alpha = 0.16f)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Rounded.Description, null, tint = fg, modifier = Modifier.size(22.dp))
        }
        Column(Modifier.widthIn(max = 180.dp)) {
            Text(
                msg.attachmentName ?: "Document", color = fg, fontSize = 15.sp, fontWeight = FontWeight.Medium,
                maxLines = 2, overflow = TextOverflow.Ellipsis,
            )
            Text(formatSize(msg.attachmentSize), color = fg.copy(alpha = 0.75f), fontSize = 12.sp)
        }
    }
}
