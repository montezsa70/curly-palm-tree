package app.instants.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.instants.data.Msg
import app.instants.data.VoicePlayer
import app.instants.data.decodeWaveform
import app.instants.data.formatDuration
import app.instants.ui.theme.Palette
import kotlinx.coroutines.delay
import androidx.compose.runtime.getValue

/**
 * Inside the liquid-glass bar while recording: discard, a pulsing red dot, the running time
 * and a live waveform that scrolls in from the right as you speak.
 */
@Composable
fun RecordingContent(
    levels: List<Float>,
    elapsedMs: Long,
    onCancel: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val pulse = rememberInfiniteTransition(label = "rec")
    val dot by pulse.animateFloat(
        initialValue = 1f,
        targetValue = 0.25f,
        animationSpec = infiniteRepeatable(tween(650, easing = LinearEasing), RepeatMode.Reverse),
        label = "dot",
    )
    val barColor = Palette.AccentSoft
    Row(modifier.fillMaxSize().padding(start = 6.dp, end = 18.dp), verticalAlignment = Alignment.CenterVertically) {
        PlainIconButton(Icons.Rounded.Delete, "Discard recording", tint = Palette.EndCall, onClick = onCancel)
        Spacer(Modifier.width(4.dp))
        Box(Modifier.size(9.dp).alpha(dot).clip(CircleShape).background(Palette.EndCall))
        Spacer(Modifier.width(8.dp))
        Text(
            formatDuration(elapsedMs),
            color = Palette.TextPrimary,
            fontSize = 16.sp,
            modifier = Modifier.width(42.dp),
        )
        Canvas(Modifier.weight(1f).fillMaxHeight().padding(vertical = 14.dp)) {
            val barW = 3.dp.toPx()
            val gap = 3.dp.toPx()
            val step = barW + gap
            val count = (size.width / step).toInt().coerceAtLeast(1)
            val n = levels.size
            val minH = 3.dp.toPx()
            for (i in 0 until count) {
                val idx = n - count + i
                val lv = if (idx >= 0) levels[idx] else -1f
                val h = if (lv < 0f) minH else maxOf(minH, lv * size.height)
                val x = size.width - (count - i) * step
                val fade = 0.3f + 0.7f * (i / count.toFloat())
                drawRoundRect(
                    color = barColor.copy(alpha = if (lv < 0f) 0.18f else fade),
                    topLeft = Offset(x, (size.height - h) / 2f),
                    size = Size(barW, h),
                    cornerRadius = CornerRadius(barW / 2f),
                )
            }
        }
    }
}

/** A received or sent voice note: play / pause, waveform you can tap to seek, and the time. */
@Composable
fun VoiceMessage(msg: Msg, fg: Color, onToggle: () -> Unit, onLongPress: () -> Unit = {}) {
    val current = VoicePlayer.currentId == msg.id
    val playing = current && VoicePlayer.isPlaying
    val loading = current && VoicePlayer.loading
    val total = msg.voiceDurationMs
    val pos = if (current) VoicePlayer.positionMs else 0
    val progress = if (current && total > 0) (pos / total.toFloat()).coerceIn(0f, 1f) else 0f
    val bars = remember(msg.voiceWaveform) { decodeWaveform(msg.voiceWaveform) }

    LaunchedEffect(playing) {
        while (playing) {
            VoicePlayer.refresh()
            delay(50)
        }
    }

    Row(Modifier.width(220.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Box(
            Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(fg.copy(alpha = 0.2f))
                .pointerInput(msg.id) { detectTapGestures(onLongPress = { onLongPress() }, onTap = { onToggle() }) },
            contentAlignment = Alignment.Center,
        ) {
            if (loading) {
                CircularProgressIndicator(Modifier.size(20.dp), color = fg, strokeWidth = 2.dp)
            } else {
                Icon(
                    if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                    if (playing) "Pause" else "Play",
                    tint = fg,
                    modifier = Modifier.size(24.dp),
                )
            }
        }
        Column(Modifier.weight(1f)) {
            Canvas(
                Modifier
                    .fillMaxWidth()
                    .height(30.dp)
                    .pointerInput(msg.id, current) {
                        detectTapGestures(onLongPress = { onLongPress() }) { off ->
                            if (current) VoicePlayer.seekTo(msg.id, off.x / size.width, total) else onToggle()
                        }
                    },
            ) {
                val slot = size.width / bars.size
                val barW = slot * 0.55f
                val minH = 3.dp.toPx()
                bars.forEachIndexed { i, v ->
                    val played = (i + 0.5f) / bars.size <= progress
                    val h = maxOf(minH, v * size.height)
                    drawRoundRect(
                        color = fg.copy(alpha = if (played) 1f else 0.45f),
                        topLeft = Offset(i * slot + (slot - barW) / 2f, (size.height - h) / 2f),
                        size = Size(barW, h),
                        cornerRadius = CornerRadius(barW / 2f),
                    )
                }
            }
            Text(
                formatDuration(if (current && pos > 0) pos.toLong() else total.toLong()),
                color = fg.copy(alpha = 0.8f),
                fontSize = 11.sp,
                modifier = Modifier.padding(top = 2.dp),
            )
        }
    }
}
