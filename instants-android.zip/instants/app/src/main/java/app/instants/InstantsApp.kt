package app.instants

import android.app.Application
import java.io.File

class InstantsApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // Older builds saved crash traces here; they can contain addresses and ids, so remove any that are left.
        try {
            File(filesDir, "last_crash.txt").delete()
        } catch (_: Throwable) {
        }
        app.instants.data.Session.init(this)
        app.instants.data.Cache.init(this)
        app.instants.data.LocalDb.init(this)
        app.instants.data.Avatars.init(this)
        app.instants.data.StatusMedia.init(this)
        app.instants.data.Attachments.init(this)
        app.instants.push.Push.init(this)
        app.instants.call.CallService.initChannels(this)
        app.instants.call.CallManager.init(this)
        app.instants.ui.AppLock.init(this)
        app.instants.ui.theme.ThemePrefs.init(this)
        app.instants.data.Store.init()
        app.instants.data.StatusStore.init()
        app.instants.backup.BackupPrefs.init(this)
        app.instants.backup.BackupCrypto.init(this)
        app.instants.backup.BackupSchedule.apply(this)
    }
}
