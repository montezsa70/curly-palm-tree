package app.instants

import android.app.Application
import android.util.Log
import java.io.File

/** Saves the stack trace of any crash so the next launch can show it on screen. */
class InstantsApp : Application() {
    override fun onCreate() {
        super.onCreate()
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            try {
                File(filesDir, CRASH_FILE).writeText(Log.getStackTraceString(error))
            } catch (_: Throwable) {
            }
            previous?.uncaughtException(thread, error)
        }
        app.instants.data.Session.init(this)
        app.instants.data.Cache.init(this)
        app.instants.data.LocalDb.init(this)
        app.instants.data.Avatars.init(this)
        app.instants.data.StatusMedia.init(this)
        app.instants.data.Attachments.init(this)
        app.instants.push.Push.init(this)
        app.instants.call.CallService.initChannels(this)
        app.instants.call.CallManager.init(this)
        app.instants.ui.AppLock.init(this)
        app.instants.ui.theme.ThemePrefs.init(this)
        app.instants.data.Store.init()
        app.instants.data.StatusStore.init()
        app.instants.backup.BackupPrefs.init(this)
        app.instants.backup.BackupCrypto.init(this)
        app.instants.backup.BackupSchedule.apply(this)
    }

    companion object {
        const val CRASH_FILE = "last_crash.txt"
    }
}
