package app.instants

import android.app.Application
import android.util.Log
import java.io.File

/** Saves the stack trace of any crash so the next launch can show it on screen. */
class InstantsApp : Application() {
    override fun onCreate() {
        super.onCreate()
        app.instants.data.Session.init(this)
        app.instants.data.Cache.init(this)
        app.instants.data.Avatars.init(this)
        app.instants.ui.AppLock.init(this)
        app.instants.data.Store.init()
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            try {
                File(filesDir, CRASH_FILE).writeText(Log.getStackTraceString(error))
            } catch (_: Throwable) {
            }
            previous?.uncaughtException(thread, error)
        }
    }

    companion object {
        const val CRASH_FILE = "last_crash.txt"
    }
}
