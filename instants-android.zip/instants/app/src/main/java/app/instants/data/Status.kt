package app.instants.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.time.Instant
import java.time.OffsetDateTime
import java.util.UUID

/** Backgrounds for text statuses. */
val StatusColors = listOf("#4A72B8", "#7B5EA7", "#2E8B7A", "#C95B5B", "#D08A2E", "#2B2F3A")

data class StatusItem(
    val id: String,
    val userId: String,
    val kind: String, // text | photo | video
    val body: String,
    val bgColor: String?,
    val mediaPath: String?,
    val durationSecs: Double?,
    val createdAt: Instant,
    val expiresAt: Instant,
)

/** All of one person's active statuses, oldest first. */
data class StatusGroup(
    val userId: String,
    val profile: Profile?,
    val items: List<StatusItem>,
    val mine: Boolean,
) {
    val name: String get() = if (mine) "You" else profile?.name ?: "Someone"
    val initials: String get() = profile?.initials ?: "?"
    val latest: Instant get() = items.maxOf { it.createdAt }
}

private fun JSONArray.objects(): List<JSONObject> = (0 until length()).map { getJSONObject(it) }

private fun JSONObject.toStatusItem() = StatusItem(
    id = getString("id"),
    userId = getString("user_id"),
    kind = getString("kind"),
    body = if (isNull("body")) "" else getString("body"),
    bgColor = if (isNull("bg_color")) null else getString("bg_color"),
    mediaPath = if (isNull("media_path")) null else getString("media_path"),
    durationSecs = if (isNull("duration_secs")) null else getDouble("duration_secs"),
    createdAt = OffsetDateTime.parse(getString("created_at")).toInstant(),
    expiresAt = OffsetDateTime.parse(getString("expires_at")).toInstant(),
)

/** Supabase calls for statuses. Who can see what is enforced by row level security on the server. */
object StatusRepo {
    const val MAX_VIDEO_SECS = 30.0
    const val MAX_VIDEO_BYTES = 50L * 1024 * 1024
    private const val BUCKET = "statuses"
    private const val COLS = "id,user_id,kind,body,bg_color,media_path,duration_secs,created_at,expires_at"

    private suspend fun <T> io(block: () -> T): T = withContext(Dispatchers.IO) { block() }
    private fun me(): String = Session.userId ?: throw ApiException("Not signed in")

    /** Mine plus every visible, unexpired status from my contacts. */
    suspend fun loadFeed(): List<StatusItem> = io {
        JSONArray(Api.call("GET", "/rest/v1/status_updates?order=created_at.asc&limit=500&select=$COLS"))
            .objects().map { it.toStatusItem() }
    }

    suspend fun loadViewedIds(): Set<String> = io {
        JSONArray(Api.call("GET", "/rest/v1/status_views?viewer_id=eq.${me()}&select=status_id"))
            .objects().map { it.getString("status_id") }.toSet()
    }

    /** How many people viewed each of my statuses. */
    suspend fun loadViewCounts(ids: List<String>): Map<String, Int> = io {
        if (ids.isEmpty()) {
            emptyMap()
        } else {
            JSONArray(Api.call("GET", "/rest/v1/status_views?status_id=in.(${ids.joinToString(",")})&select=status_id"))
                .objects().groupingBy { it.getString("status_id") }.eachCount()
        }
    }

    suspend fun markViewed(statusId: String) = io {
        Api.call(
            "POST", "/rest/v1/status_views?on_conflict=status_id,viewer_id",
            JSONObject().put("status_id", statusId),
            mapOf("Prefer" to "resolution=ignore-duplicates,return=minimal"),
        )
        Unit
    }

    suspend fun postText(body: String, bgColor: String) = io {
        insert(JSONObject().put("kind", "text").put("body", body.trim()).put("bg_color", bgColor))
    }

    suspend fun postPhoto(jpeg: ByteArray, caption: String) = io {
        val path = "${me()}/${UUID.randomUUID()}.jpg"
        Api.uploadObject(BUCKET, path, jpeg.toRequestBody("image/jpeg".toMediaType()))
        val row = JSONObject().put("kind", "photo").put("media_path", path)
        if (caption.isNotBlank()) row.put("body", caption.trim())
        insertOrCleanUp(row, path)
    }

    suspend fun postVideo(file: File, durationSecs: Double, caption: String) = io {
        require(durationSecs <= MAX_VIDEO_SECS) { "Videos can be up to 30 seconds" }
        val path = "${me()}/${UUID.randomUUID()}.mp4"
        Api.uploadObject(BUCKET, path, file.asRequestBody("video/mp4".toMediaType()))
        val row = JSONObject().put("kind", "video").put("media_path", path).put("duration_secs", durationSecs)
        if (caption.isNotBlank()) row.put("body", caption.trim())
        insertOrCleanUp(row, path)
    }

    suspend fun delete(item: StatusItem) = io {
        Api.call("DELETE", "/rest/v1/status_updates?id=eq.${item.id}")
        item.mediaPath?.let { try { Api.deleteObject(BUCKET, it) } catch (e: Exception) { } }
        Unit
    }

    private fun insert(row: JSONObject) {
        Api.call("POST", "/rest/v1/status_updates", row.put("user_id", me()))
    }

    /** If the row can't be saved, don't leave an orphaned file in storage. */
    private fun insertOrCleanUp(row: JSONObject, path: String) {
        try {
            insert(row)
        } catch (e: Exception) {
            try { Api.deleteObject(BUCKET, path) } catch (_: Exception) { }
            throw e
        }
    }
}

/** Downloads status media once and keeps it for the session. */
object StatusMedia {
    private var dir: File? = null
    private val photos = LruCache<String, Bitmap>(24)

    fun init(context: Context) {
        val d = File(context.cacheDir, "status").also { it.mkdirs() }
        dir = d
        // Statuses last 24h, so anything older than 36h is leftover.
        val cutoff = System.currentTimeMillis() - 36L * 3600 * 1000
        d.listFiles()?.forEach { if (it.lastModified() < cutoff) it.delete() }
    }

    suspend fun photo(path: String): Bitmap? = withContext(Dispatchers.IO) {
        photos.get(path)?.let { return@withContext it }
        try {
            val bytes = Api.downloadObject("statuses", path)
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.also { photos.put(path, it) }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            null
        }
    }

    /** Videos are saved to a file because the system player plays from a path. */
    suspend fun video(path: String): File? = withContext(Dispatchers.IO) {
        val d = dir ?: return@withContext null
        val f = File(d, path.replace('/', '_'))
        if (f.exists() && f.length() > 0) return@withContext f
        val part = File(d, f.name + ".part")
        try {
            Api.downloadObjectToFile("statuses", path, part)
            if (part.renameTo(f)) f else null
        } catch (e: CancellationException) {
            part.delete()
            throw e
        } catch (e: Exception) {
            part.delete()
            null
        }
    }

    fun clear() {
        photos.evictAll()
        dir?.listFiles()?.forEach { it.delete() }
    }
}

/** In-memory state the status UI reads from. */
object StatusStore {
    /** Contacts who have active statuses: unseen first, then newest. */
    var groups by mutableStateOf<List<StatusGroup>>(emptyList())
        private set
    var mine by mutableStateOf<StatusGroup?>(null)
        private set
    var viewed by mutableStateOf<Set<String>>(emptySet())
        private set
    var viewCounts by mutableStateOf<Map<String, Int>>(emptyMap())
        private set

    fun hasUnseen(g: StatusGroup): Boolean = g.items.any { it.id !in viewed }

    suspend fun refresh() {
        try {
            val me = Session.userId ?: return
            val items = StatusRepo.loadFeed()
            val seen = StatusRepo.loadViewedIds()
            val byUser = items.groupBy { it.userId }
            val others = byUser.keys.filter { it != me }
            val profiles = if (others.isEmpty()) emptyMap() else Repo.profilesByIds(others).associateBy { it.id }

            val built = byUser.map { (uid, list) ->
                StatusGroup(uid, if (uid == me) Store.me?.profile else profiles[uid], list.sortedBy { it.createdAt }, uid == me)
            }
            val myGroup = built.firstOrNull { it.mine }
            val counts = if (myGroup != null) StatusRepo.loadViewCounts(myGroup.items.map { it.id }) else emptyMap()

            viewed = seen
            viewCounts = counts
            mine = myGroup
            groups = built.filter { !it.mine }
                .sortedWith(compareByDescending<StatusGroup> { g -> g.items.any { it.id !in seen } }.thenByDescending { it.latest })
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            // keep showing what we have
        }
    }

    suspend fun markViewed(id: String) {
        if (id in viewed) return
        viewed = viewed + id
        try {
            StatusRepo.markViewed(id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            viewed = viewed - id
        }
    }

    fun clear() {
        groups = emptyList()
        mine = null
        viewed = emptySet()
        viewCounts = emptyMap()
        StatusMedia.clear()
    }
}
