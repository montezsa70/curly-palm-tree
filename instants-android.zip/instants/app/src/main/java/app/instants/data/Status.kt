package app.instants.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.time.Instant
import java.time.OffsetDateTime
import java.util.UUID

/** Backgrounds for text statuses. */
val StatusColors = listOf("#4A72B8", "#7B5EA7", "#2E8B7A", "#C95B5B", "#D08A2E", "#2B2F3A")

data class StatusItem(
    val id: String,
    val userId: String,
    val kind: String, // text | photo | video
    val body: String,
    val bgColor: String?,
    val mediaPath: String?,
    val durationSecs: Double?,
    val createdAt: Instant,
    val expiresAt: Instant,
)

/** All of one person's active statuses, oldest first. */
data class StatusGroup(
    val userId: String,
    val profile: Profile?,
    val items: List<StatusItem>,
    val mine: Boolean,
) {
    val name: String get() = if (mine) "You" else profile?.name ?: "Someone"
    val initials: String get() = profile?.initials ?: "?"
    val latest: Instant get() = items.maxOf { it.createdAt }
}

private fun JSONArray.objects(): List<JSONObject> = (0 until length()).map { getJSONObject(it) }

private fun JSONObject.toStatusItem() = StatusItem(
    id = getString("id"),
    userId = getString("user_id"),
    kind = getString("kind"),
    body = if (isNull("body")) "" else getString("body"),
    bgColor = if (isNull("bg_color")) null else getString("bg_color"),
    mediaPath = if (isNull("media_path")) null else getString("media_path"),
    durationSecs = if (isNull("duration_secs")) null else getDouble("duration_secs"),
    createdAt = OffsetDateTime.parse(getString("created_at")).toInstant(),
    expiresAt = OffsetDateTime.parse(getString("expires_at")).toInstant(),
)

/** Supabase calls for statuses. Who can see what is enforced by row level security on the server. */
object StatusRepo {
    const val MAX_VIDEO_SECS = 30.0
    const val MAX_VIDEO_BYTES = 50L * 1024 * 1024
    private const val BUCKET = "statuses"
    private const val COLS = "id,user_id,kind,body,bg_color,media_path,duration_secs,created_at,expires_at"

    private suspend fun <T> io(block: () -> T): T = withContext(Dispatchers.IO) { block() }
    private fun me(): String = Session.userId ?: throw ApiException("Not signed in")

    /** Mine plus every visible, unexpired status from my contacts. */
    suspend fun loadFeed(): List<StatusItem> = io {
        JSONArray(Api.call("GET", "/rest/v1/status_updates?order=created_at.asc&limit=500&select=$COLS"))
            .objects().map { it.toStatusItem() }
    }

    suspend fun loadViewedIds(): Set<String> = io {
        JSONArray(Api.call("GET", "/rest/v1/status_views?viewer_id=eq.${me()}&select=status_id"))
            .objects().map { it.getString("status_id") }.toSet()
    }

    /** How many people viewed each of my statuses. */
    suspend fun loadViewCounts(ids: List<String>): Map<String, Int> = io {
        if (ids.isEmpty()) {
            emptyMap()
        } else {
            JSONArray(Api.call("GET", "/rest/v1/status_views?status_id=in.(${ids.joinToString(",")})&select=status_id"))
                .objects().groupingBy { it.getString("status_id") }.eachCount()
        }
    }

    suspend fun markViewed(statusId: String) = io {
        Api.call(
            "POST", "/rest/v1/status_views?on_conflict=status_id,viewer_id",
            JSONObject().put("status_id", statusId),
            mapOf("Prefer" to "resolution=ignore-duplicates,return=minimal"),
        )
        Unit
    }

    suspend fun postText(body: String, bgColor: String) = io {
        insert(JSONObject().put("kind", "text").put("body", body.trim()).put("bg_color", bgColor))
    }

    suspend fun postPhoto(jpeg: ByteArray, caption: String) = io {
        val path = "${me()}/${UUID.randomUUID()}.jpg"
        Api.uploadObject(BUCKET, path, jpeg.toRequestBody("image/jpeg".toMediaType()))
        val row = JSONObject().put("kind", "photo").put("media_path", path)
        if (caption.isNotBlank()) row.put("body", caption.trim())
        insertOrCleanUp(row, path)
        StatusMedia.store(path, jpeg)
    }

    suspend fun postVideo(file: File, durationSecs: Double, caption: String) = io {
        require(durationSecs <= MAX_VIDEO_SECS) { "Videos can be up to 30 seconds" }
        val path = "${me()}/${UUID.randomUUID()}.mp4"
        Api.uploadObject(BUCKET, path, file.asRequestBody("video/mp4".toMediaType()))
        val row = JSONObject().put("kind", "video").put("media_path", path).put("duration_secs", durationSecs)
        if (caption.isNotBlank()) row.put("body", caption.trim())
        insertOrCleanUp(row, path)
        StatusMedia.store(path, file)
    }

    suspend fun delete(item: StatusItem) = io {
        Api.call("DELETE", "/rest/v1/status_updates?id=eq.${item.id}")
        item.mediaPath?.let { try { Api.deleteObject(BUCKET, it) } catch (e: Exception) { } }
        Unit
    }

    private fun insert(row: JSONObject) {
        Api.call("POST", "/rest/v1/status_updates", row.put("user_id", me()))
    }

    /** If the row can't be saved, don't leave an orphaned file in storage. */
    private fun insertOrCleanUp(row: JSONObject, path: String) {
        try {
            insert(row)
        } catch (e: Exception) {
            try { Api.deleteObject(BUCKET, path) } catch (_: Exception) { }
            throw e
        }
    }
}

/**
 * Status photos and videos kept on the phone. Anything downloaded once is opened straight from
 * disk afterwards, and new statuses are fetched in the background so they are ready before you tap.
 */
object StatusMedia {
    private var dir: File? = null
    private val photos = LruCache<String, Bitmap>(24)

    fun init(context: Context) {
        dir = File(context.filesDir, "status_media").also { it.mkdirs() }
    }

    private fun fileFor(path: String): File? = dir?.let { File(it, path.replace('/', '_')) }

    /** Keeps what I just posted, so my own status opens instantly without downloading it again. */
    fun store(path: String, bytes: ByteArray) {
        try { fileFor(path)?.writeBytes(bytes) } catch (_: Exception) { }
    }

    fun store(path: String, source: File) {
        try { fileFor(path)?.let { source.copyTo(it, overwrite = true) } } catch (_: Exception) { }
    }

    /** The local copy, downloading it first if it isn't on the phone yet. */
    private fun ensureLocal(path: String): File? {
        val f = fileFor(path) ?: return null
        if (f.exists() && f.length() > 0) return f
        val part = File(f.parentFile, f.name + ".part")
        return try {
            Api.downloadObjectToFile("statuses", path, part)
            if (part.renameTo(f)) f else null
        } catch (e: CancellationException) {
            part.delete()
            throw e
        } catch (e: Exception) {
            part.delete()
            null
        }
    }

    suspend fun photo(path: String): Bitmap? = withContext(Dispatchers.IO) {
        photos.get(path)?.let { return@withContext it }
        val f = ensureLocal(path) ?: return@withContext null
        val bmp = BitmapFactory.decodeFile(f.path)
        if (bmp == null) f.delete() else photos.put(path, bmp)
        bmp
    }

    /** Videos are played from a file, so this is also the on-disk copy. */
    suspend fun video(path: String): File? = withContext(Dispatchers.IO) { ensureLocal(path) }

    /** Downloads anything not on the phone yet (unseen statuses first, as given). */
    suspend fun prefetch(items: List<StatusItem>) = withContext(Dispatchers.IO) {
        for (item in items) {
            val p = item.mediaPath ?: continue
            ensureActive()
            ensureLocal(p)
        }
    }

    /** Deletes saved media for statuses that no longer exist (expired or deleted). */
    fun retain(paths: Set<String>) {
        val keep = paths.map { it.replace('/', '_') }.toSet()
        dir?.listFiles()?.forEach { if (!it.name.endsWith(".part") && it.name !in keep) it.delete() }
        photos.evictAll()
    }

    fun clear() {
        photos.evictAll()
        dir?.listFiles()?.forEach { it.delete() }
    }
}

/** The status feed saved on the phone so the status row and viewer have content before the network answers. */
private object StatusDisk {
    private const val KEY = "status_feed"

    class Snapshot(
        val items: List<StatusItem>,
        val seen: Set<String>,
        val counts: Map<String, Int>,
        val profiles: Map<String, Profile>,
    )

    fun save(snapshot: Snapshot) {
        try {
            val items = JSONArray()
            snapshot.items.forEach {
                items.put(
                    JSONObject().put("id", it.id).put("u", it.userId).put("k", it.kind).put("b", it.body)
                        .put("bg", it.bgColor ?: JSONObject.NULL).put("mp", it.mediaPath ?: JSONObject.NULL)
                        .put("d", it.durationSecs ?: JSONObject.NULL)
                        .put("c", it.createdAt.toEpochMilli()).put("e", it.expiresAt.toEpochMilli()),
                )
            }
            val counts = JSONObject()
            snapshot.counts.forEach { (k, v) -> counts.put(k, v) }
            val profiles = JSONArray()
            snapshot.profiles.values.forEach {
                profiles.put(
                    JSONObject().put("id", it.id).put("u", it.username).put("dn", it.displayName)
                        .put("about", it.about).put("av", it.avatarPath ?: JSONObject.NULL),
                )
            }
            Cache.putString(
                KEY,
                JSONObject().put("items", items).put("seen", JSONArray(snapshot.seen.toList()))
                    .put("counts", counts).put("profiles", profiles).toString(),
            )
        } catch (_: Exception) { }
    }

    fun load(): Snapshot? = try {
        Cache.getString(KEY)?.let { s ->
            val j = JSONObject(s)
            val items = j.getJSONArray("items").objects().map {
                StatusItem(
                    id = it.getString("id"),
                    userId = it.getString("u"),
                    kind = it.getString("k"),
                    body = it.getString("b"),
                    bgColor = if (it.isNull("bg")) null else it.getString("bg"),
                    mediaPath = if (it.isNull("mp")) null else it.getString("mp"),
                    durationSecs = if (it.isNull("d")) null else it.getDouble("d"),
                    createdAt = Instant.ofEpochMilli(it.getLong("c")),
                    expiresAt = Instant.ofEpochMilli(it.getLong("e")),
                )
            }
            val seenArr = j.getJSONArray("seen")
            val countsObj = j.getJSONObject("counts")
            val profiles = j.getJSONArray("profiles").objects().map {
                Profile(
                    it.getString("id"), it.getString("u"), it.getString("dn"), it.optString("about", ""),
                    if (it.isNull("av")) null else it.getString("av"),
                )
            }.associateBy { it.id }
            Snapshot(
                items,
                (0 until seenArr.length()).map { seenArr.getString(it) }.toSet(),
                countsObj.keys().asSequence().associateWith { countsObj.getInt(it) },
                profiles,
            )
        }
    } catch (_: Exception) {
        null
    }
}

/** In-memory state the status UI reads from. Starts from the saved copy on disk. */
object StatusStore {
    /** Contacts who have active statuses: unseen first, then newest. */
    var groups by mutableStateOf<List<StatusGroup>>(emptyList())
        private set
    var mine by mutableStateOf<StatusGroup?>(null)
        private set
    var viewed by mutableStateOf<Set<String>>(emptySet())
        private set
    var viewCounts by mutableStateOf<Map<String, Int>>(emptyMap())
        private set

    fun hasUnseen(g: StatusGroup): Boolean = g.items.any { it.id !in viewed }

    /** Call once at startup, after Store.init(). */
    fun init() {
        val s = StatusDisk.load() ?: return
        rebuild(s.items, s.seen, s.counts, s.profiles)
    }

    private fun rebuild(items: List<StatusItem>, seen: Set<String>, counts: Map<String, Int>, profiles: Map<String, Profile>) {
        val me = Session.userId ?: return
        val now = Instant.now()
        val byUser = items.filter { it.expiresAt > now }.groupBy { it.userId }
        val built = byUser.map { (uid, list) ->
            StatusGroup(uid, if (uid == me) Store.me?.profile else profiles[uid], list.sortedBy { it.createdAt }, uid == me)
        }
        viewed = seen
        viewCounts = counts
        mine = built.firstOrNull { it.mine }
        groups = built.filter { !it.mine }
            .sortedWith(compareByDescending<StatusGroup> { g -> g.items.any { it.id !in seen } }.thenByDescending { it.latest })
    }

    suspend fun refresh() {
        try {
            val me = Session.userId ?: return
            val items = StatusRepo.loadFeed()
            val seen = StatusRepo.loadViewedIds()
            val others = items.map { it.userId }.distinct().filter { it != me }
            val profiles = if (others.isEmpty()) emptyMap() else Repo.profilesByIds(others).associateBy { it.id }
            val myIds = items.filter { it.userId == me }.map { it.id }
            val counts = if (myIds.isEmpty()) emptyMap() else StatusRepo.loadViewCounts(myIds)

            rebuild(items, seen, counts, profiles)
            StatusDisk.save(StatusDisk.Snapshot(items, seen, counts, profiles))

            // Keep the files for current statuses, drop the rest, and fetch what's missing in the background
            StatusMedia.retain(items.mapNotNull { it.mediaPath }.toSet())
            val order = items.sortedWith(compareBy<StatusItem> { it.id in seen }.thenByDescending { it.createdAt })
            StatusMedia.prefetch(order)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            // keep showing what we have
        }
    }

    suspend fun markViewed(id: String) {
        if (id in viewed) return
        viewed = viewed + id
        try {
            StatusRepo.markViewed(id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            viewed = viewed - id
        }
    }

    fun clear() {
        groups = emptyList()
        mine = null
        viewed = emptySet()
        viewCounts = emptyMap()
        Cache.remove("status_feed")
        StatusMedia.clear()
    }
}
