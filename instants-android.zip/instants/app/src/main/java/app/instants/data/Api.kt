package app.instants.data

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject

object Config {
    const val SUPABASE_URL = "https://hbdeiaikwbnznsextluj.supabase.co"
    // Publishable key: safe to ship in the app. Access is enforced by row level security.
    const val SUPABASE_KEY = "sb_publishable_SVugikwRljh4S0Fgy1_X5g_i6iGpkke"
}

class ApiException(message: String, val code: Int = 0) : Exception(message)

/** Signed-in user + tokens, kept in SharedPreferences (move to encrypted storage before launch). */
object Session {
    private var prefs: SharedPreferences? = null

    var userId by mutableStateOf<String?>(null)
        private set
    var accessToken: String? = null
        private set
    var refreshToken: String? = null
        private set

    fun init(context: Context) {
        val p = context.getSharedPreferences("session", Context.MODE_PRIVATE)
        prefs = p
        accessToken = p.getString("access", null)
        refreshToken = p.getString("refresh", null)
        userId = p.getString("uid", null)
    }

    fun save(access: String, refresh: String, uid: String) {
        accessToken = access
        refreshToken = refresh
        userId = uid
        prefs?.edit()?.putString("access", access)?.putString("refresh", refresh)?.putString("uid", uid)?.apply()
    }

    fun clear() {
        accessToken = null
        refreshToken = null
        userId = null
        prefs?.edit()?.clear()?.apply()
    }
}

object Api {
    private val client = OkHttpClient()
    private val jsonType = "application/json".toMediaType()

    private fun raw(
        method: String,
        path: String,
        body: JSONObject?,
        token: String?,
        headers: Map<String, String>,
    ): String {
        val b = Request.Builder().url(Config.SUPABASE_URL + path).header("apikey", Config.SUPABASE_KEY)
        if (token != null) b.header("Authorization", "Bearer $token")
        headers.forEach { (k, v) -> b.header(k, v) }
        val payload = if (method == "GET" || method == "HEAD") null else (body?.toString() ?: "{}").toRequestBody(jsonType)
        b.method(method, payload)
        client.newCall(b.build()).execute().use { r ->
            val text = r.body?.string().orEmpty()
            if (!r.isSuccessful) throw ApiException(errorText(text, r.code), r.code)
            return text
        }
    }

    private fun errorText(text: String, code: Int): String = try {
        val j = JSONObject(text)
        listOf("msg", "message", "error_description", "error")
            .map { j.optString(it) }
            .firstOrNull { it.isNotBlank() } ?: "Error $code"
    } catch (e: Exception) {
        "Error $code"
    }

    /** Authenticated call; refreshes the session once if the token expired. */
    fun call(
        method: String,
        path: String,
        body: JSONObject? = null,
        headers: Map<String, String> = emptyMap(),
    ): String {
        try {
            return raw(method, path, body, Session.accessToken, headers)
        } catch (e: ApiException) {
            if (e.code == 401 && refresh()) return raw(method, path, body, Session.accessToken, headers)
            throw e
        }
    }

    @Synchronized
    private fun refresh(): Boolean {
        val rt = Session.refreshToken ?: return false
        return try {
            val res = JSONObject(
                raw("POST", "/auth/v1/token?grant_type=refresh_token", JSONObject().put("refresh_token", rt), null, emptyMap()),
            )
            storeSession(res)
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun storeSession(res: JSONObject) {
        Session.save(
            res.getString("access_token"),
            res.getString("refresh_token"),
            res.getJSONObject("user").getString("id"),
        )
    }

    /** Returns true if signed in right away, false if the email must be confirmed first. */
    suspend fun signUp(email: String, password: String, username: String, displayName: String): Boolean =
        withContext(Dispatchers.IO) {
            val body = JSONObject().put("email", email).put("password", password)
                .put("data", JSONObject().put("username", username).put("display_name", displayName))
            val res = JSONObject(raw("POST", "/auth/v1/signup", body, null, emptyMap()))
            if (res.has("access_token")) {
                storeSession(res)
                true
            } else {
                false
            }
        }

    suspend fun signIn(email: String, password: String) = withContext(Dispatchers.IO) {
        val body = JSONObject().put("email", email).put("password", password)
        storeSession(JSONObject(raw("POST", "/auth/v1/token?grant_type=password", body, null, emptyMap())))
    }

    fun signOut() = Session.clear()
}
