package app.instants.data

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

object Config {
    const val SUPABASE_URL = "https://hbdeiaikwbnznsextluj.supabase.co"
    // Publishable key: safe to ship in the app. Access is enforced by row level security.
    const val SUPABASE_KEY = "sb_publishable_SVugikwRljh4S0Fgy1_X5g_i6iGpkke"
}

class ApiException(message: String, val code: Int = 0) : Exception(message)

/** Signed-in user + tokens, kept in SharedPreferences (move to encrypted storage before launch). */
object Session {
    private var prefs: SharedPreferences? = null

    var userId by mutableStateOf<String?>(null)
        private set
    var accessToken: String? = null
        private set
    var refreshToken: String? = null
        private set
    var expiresAt: Long = 0L
        private set
    var email: String? = null
        private set

    fun init(context: Context) {
        val p = context.getSharedPreferences("session", Context.MODE_PRIVATE)
        prefs = p
        accessToken = p.getString("access", null)
        refreshToken = p.getString("refresh", null)
        expiresAt = p.getLong("exp", 0L)
        email = p.getString("email", null)
        userId = p.getString("uid", null)
    }

    fun save(access: String, refresh: String, uid: String, expires: Long) {
        accessToken = access
        refreshToken = refresh
        expiresAt = expires
        userId = uid
        prefs?.edit()?.putString("access", access)?.putString("refresh", refresh)
            ?.putString("uid", uid)?.putLong("exp", expires)?.apply()
    }

    fun saveEmail(value: String) {
        email = value
        prefs?.edit()?.putString("email", value)?.apply()
    }

    fun clear() {
        accessToken = null
        refreshToken = null
        expiresAt = 0L
        email = null
        userId = null
        prefs?.edit()?.clear()?.apply()
    }
}

object Api {
    private val client = OkHttpClient()
    private val jsonType = "application/json".toMediaType()

    private fun nowSec(): Long = System.currentTimeMillis() / 1000

    private fun raw(
        method: String,
        path: String,
        body: JSONObject?,
        token: String?,
        headers: Map<String, String>,
    ): String {
        val b = Request.Builder().url(Config.SUPABASE_URL + path).header("apikey", Config.SUPABASE_KEY)
        if (token != null) b.header("Authorization", "Bearer $token")
        headers.forEach { (k, v) -> b.header(k, v) }
        val payload = if (method == "GET" || method == "HEAD") null else (body?.toString() ?: "{}").toRequestBody(jsonType)
        b.method(method, payload)
        client.newCall(b.build()).execute().use { r ->
            val text = r.body?.string().orEmpty()
            if (!r.isSuccessful) throw ApiException(errorText(text, r.code), r.code)
            return text
        }
    }

    private fun errorText(text: String, code: Int): String = try {
        val j = JSONObject(text)
        listOf("msg", "message", "error_description", "error")
            .map { j.optString(it) }
            .firstOrNull { it.isNotBlank() } ?: "Error $code"
    } catch (e: Exception) {
        "Error $code"
    }

    /** Refresh the token shortly before it expires so requests never wait on a failed first try. */
    private fun ensureFresh() {
        if (Session.refreshToken != null && Session.expiresAt > 0 && nowSec() > Session.expiresAt - 60) refresh()
    }

    /** Authenticated call; refreshes the session once if the token was rejected. */
    fun call(
        method: String,
        path: String,
        body: JSONObject? = null,
        headers: Map<String, String> = emptyMap(),
    ): String {
        ensureFresh()
        try {
            return raw(method, path, body, Session.accessToken, headers)
        } catch (e: ApiException) {
            if (e.code == 401 && refresh()) return raw(method, path, body, Session.accessToken, headers)
            throw e
        }
    }

    fun rpc(name: String, body: JSONObject = JSONObject()): String = call("POST", "/rest/v1/rpc/$name", body)

    /** For functions that must work before sign-in (e.g. username check). */
    fun anonRpc(name: String, body: JSONObject): String = raw("POST", "/rest/v1/rpc/$name", body, null, emptyMap())

    @Synchronized
    private fun refresh(): Boolean {
        val rt = Session.refreshToken ?: return false
        return try {
            val res = JSONObject(
                raw("POST", "/auth/v1/token?grant_type=refresh_token", JSONObject().put("refresh_token", rt), null, emptyMap()),
            )
            storeSession(res)
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun storeSession(res: JSONObject) {
        val exp = res.optLong("expires_at", 0L).takeIf { it > 0 } ?: (nowSec() + res.optLong("expires_in", 3600L))
        Session.save(
            res.getString("access_token"),
            res.getString("refresh_token"),
            res.getJSONObject("user").getString("id"),
            exp,
        )
    }

    /** Returns true if signed in right away, false if the email must be confirmed first. */
    suspend fun signUp(email: String, password: String, username: String, displayName: String, about: String): Boolean =
        withContext(Dispatchers.IO) {
            val body = JSONObject().put("email", email).put("password", password)
                .put(
                    "data",
                    JSONObject().put("username", username).put("display_name", displayName).put("about", about),
                )
            val res = JSONObject(raw("POST", "/auth/v1/signup", body, null, emptyMap()))
            Session.saveEmail(email)
            if (res.has("access_token")) {
                storeSession(res)
                true
            } else {
                false
            }
        }

    suspend fun signIn(email: String, password: String) = withContext(Dispatchers.IO) {
        val body = JSONObject().put("email", email).put("password", password)
        storeSession(JSONObject(raw("POST", "/auth/v1/token?grant_type=password", body, null, emptyMap())))
        Session.saveEmail(email)
    }

    fun signOut() = Session.clear()

    // ---- Profile photos (private storage bucket) ----

    fun uploadAvatar(path: String, bytes: ByteArray) {
        ensureFresh()
        val req = Request.Builder()
            .url("${Config.SUPABASE_URL}/storage/v1/object/avatars/$path")
            .header("apikey", Config.SUPABASE_KEY)
            .header("Authorization", "Bearer ${Session.accessToken}")
            .post(bytes.toRequestBody("image/jpeg".toMediaType()))
            .build()
        client.newCall(req).execute().use { r ->
            if (!r.isSuccessful) throw ApiException(errorText(r.body?.string().orEmpty(), r.code), r.code)
        }
    }

    fun downloadAvatar(path: String): ByteArray {
        ensureFresh()
        val req = Request.Builder()
            .url("${Config.SUPABASE_URL}/storage/v1/object/authenticated/avatars/$path")
            .header("apikey", Config.SUPABASE_KEY)
            .header("Authorization", "Bearer ${Session.accessToken}")
            .build()
        client.newCall(req).execute().use { r ->
            if (!r.isSuccessful) throw ApiException("Photo unavailable", r.code)
            return r.body?.bytes() ?: ByteArray(0)
        }
    }

    // ---- Generic storage objects (status photos and videos) ----

    /** Videos can be tens of MB, so uploads and downloads get longer timeouts than normal requests. */
    private val mediaClient: OkHttpClient by lazy {
        client.newBuilder().readTimeout(120, TimeUnit.SECONDS).writeTimeout(120, TimeUnit.SECONDS).build()
    }

    private fun objectRequest(bucket: String, path: String, authenticatedRead: Boolean = false): Request.Builder {
        val mid = if (authenticatedRead) "authenticated/" else ""
        return Request.Builder()
            .url("${Config.SUPABASE_URL}/storage/v1/object/$mid$bucket/$path")
            .header("apikey", Config.SUPABASE_KEY)
            .header("Authorization", "Bearer ${Session.accessToken}")
    }

    // ---- Chat files and status media go through the media relay (Cloudflare R2); profile photos stay in Supabase ----

    private val relayBuckets = setOf("attachments", "statuses")

    /** Asks the media function for a short-lived R2 link (put / get), or to ack / delete a file. */
    private fun relay(action: String, bucket: String, path: String): JSONObject =
        JSONObject(
            call("POST", "/functions/v1/media", JSONObject().put("action", action).put("bucket", bucket).put("path", path)),
        )

    /** Streams a file from R2. Returns false if it isn't there (files from before the move still live in Supabase storage). */
    private fun relayDownload(bucket: String, path: String, sink: (okhttp3.ResponseBody) -> Unit): Boolean {
        val url = relay("get", bucket, path).getString("url")
        mediaClient.newCall(Request.Builder().url(url).build()).execute().use { r ->
            if (r.code == 404) return false
            if (!r.isSuccessful) throw ApiException("Media unavailable", r.code)
            sink(r.body ?: throw ApiException("Media unavailable", r.code))
            return true
        }
    }

    fun uploadObject(bucket: String, path: String, body: RequestBody) {
        if (bucket in relayBuckets) {
            val url = relay("put", bucket, path).getString("url")
            mediaClient.newCall(Request.Builder().url(url).put(body).build()).execute().use { r ->
                if (!r.isSuccessful) throw ApiException("Upload failed (${r.code})", r.code)
            }
            return
        }
        ensureFresh()
        mediaClient.newCall(objectRequest(bucket, path).post(body).build()).execute().use { r ->
            if (!r.isSuccessful) throw ApiException(errorText(r.body?.string().orEmpty(), r.code), r.code)
        }
    }

    fun downloadObject(bucket: String, path: String): ByteArray {
        if (bucket in relayBuckets) {
            var bytes: ByteArray? = null
            if (relayDownload(bucket, path) { bytes = it.bytes() }) return bytes ?: ByteArray(0)
        }
        ensureFresh()
        mediaClient.newCall(objectRequest(bucket, path, authenticatedRead = true).build()).execute().use { r ->
            if (!r.isSuccessful) throw ApiException("Media unavailable", r.code)
            return r.body?.bytes() ?: ByteArray(0)
        }
    }

    fun downloadObjectToFile(bucket: String, path: String, dest: File) {
        if (bucket in relayBuckets) {
            val found = relayDownload(bucket, path) { body ->
                body.byteStream().use { input -> dest.outputStream().use { out -> input.copyTo(out) } }
            }
            if (found) return
        }
        ensureFresh()
        mediaClient.newCall(objectRequest(bucket, path, authenticatedRead = true).build()).execute().use { r ->
            if (!r.isSuccessful) throw ApiException("Media unavailable", r.code)
            val body = r.body ?: throw ApiException("Media unavailable", r.code)
            body.byteStream().use { input -> dest.outputStream().use { out -> input.copyTo(out) } }
        }
    }

    fun deleteObject(bucket: String, path: String) {
        if (bucket in relayBuckets) {
            try { relay("delete", bucket, path) } catch (e: Exception) { }
        }
        ensureFresh()
        mediaClient.newCall(objectRequest(bucket, path).delete().build()).execute().use { }
    }

    /** "I saved this chat file on my phone": the server then deletes its copy. Only the recipient's ack counts. */
    fun ackObject(bucket: String, path: String) {
        if (bucket == "attachments") relay("ack", bucket, path)
    }
}
