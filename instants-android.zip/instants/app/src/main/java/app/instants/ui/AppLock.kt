package app.instants.ui

import android.content.Context
import android.content.SharedPreferences
import android.os.SystemClock
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import app.instants.ui.components.PrimaryButton
import app.instants.ui.theme.Palette

object AppLock {
    private var prefs: SharedPreferences? = null

    var enabled by mutableStateOf(false)
        private set
    var lastStopped = 0L

    const val AUTH = BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL

    fun init(context: Context) {
        prefs = context.getSharedPreferences("applock", Context.MODE_PRIVATE)
        enabled = prefs?.getBoolean("enabled", false) ?: false
    }

    fun canUse(context: Context): Boolean =
        BiometricManager.from(context).canAuthenticate(AUTH) == BiometricManager.BIOMETRIC_SUCCESS

    fun set(value: Boolean) {
        enabled = value
        prefs?.edit()?.putBoolean("enabled", value)?.apply()
    }
}

/** Shows a lock screen over the app on launch and after 30 seconds in the background. */
@Composable
fun LockGate(activity: FragmentActivity, content: @Composable () -> Unit) {
    var locked by remember { mutableStateOf(AppLock.enabled) }

    DisposableEffect(activity) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_STOP) {
                AppLock.lastStopped = SystemClock.elapsedRealtime()
            } else if (event == Lifecycle.Event.ON_START) {
                val away = SystemClock.elapsedRealtime() - AppLock.lastStopped
                if (AppLock.enabled && AppLock.lastStopped > 0 && away > 30_000) locked = true
            }
        }
        activity.lifecycle.addObserver(observer)
        onDispose { activity.lifecycle.removeObserver(observer) }
    }

    Box(Modifier.fillMaxSize()) {
        content()
        if (locked && AppLock.enabled) {
            LockScreen(activity) { locked = false }
        }
    }
}

@Composable
private fun LockScreen(activity: FragmentActivity, onUnlocked: () -> Unit) {
    val prompt = remember {
        BiometricPrompt(
            activity,
            ContextCompat.getMainExecutor(activity),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    onUnlocked()
                }
            },
        )
    }
    val info = remember {
        BiometricPrompt.PromptInfo.Builder()
            .setTitle("Unlock Instants")
            .setAllowedAuthenticators(AppLock.AUTH)
            .build()
    }
    LaunchedEffect(Unit) { prompt.authenticate(info) }

    Box(
        Modifier
            .fillMaxSize()
            .background(Palette.Background)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { },
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text(
                "Instants",
                color = Palette.TextPrimary,
                fontSize = 34.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = (-0.5).sp,
            )
            Spacer(Modifier.height(20.dp))
            Text("Instants is locked", color = Palette.TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(24.dp))
            PrimaryButton("Unlock", Modifier.width(200.dp).padding(horizontal = 0.dp)) { prompt.authenticate(info) }
        }
    }
}
