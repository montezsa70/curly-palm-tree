package app.instants.data

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject

/**
 * Per-chat choices made on this phone: pinned, muted, archived. Saved in [Cache] and read by the chat list
 * (swipe actions) and by push handling (muted chats don't raise a notification).
 */
object ChatPrefs {
    const val MAX_PINNED = 3
    private const val KEY = "chat_prefs"

    /** chat id -> when it was pinned / archived (epoch millis). */
    var pinned by mutableStateOf<Map<String, Long>>(emptyMap())
        private set
    var archived by mutableStateOf<Map<String, Long>>(emptyMap())
        private set
    var muted by mutableStateOf<Set<String>>(emptySet())
        private set

    fun load() {
        try {
            val raw = Cache.getString(KEY) ?: return
            val o = JSONObject(raw)
            pinned = o.optJSONObject("pin").toLongMap()
            archived = o.optJSONObject("arch").toLongMap()
            muted = o.optJSONArray("mute").let { a -> if (a == null) emptySet() else (0 until a.length()).map { a.getString(it) }.toSet() }
        } catch (e: Exception) {
        }
    }

    /** Clears memory only; the saved copy is wiped by Cache.clear(). */
    fun reset() {
        pinned = emptyMap()
        archived = emptyMap()
        muted = emptySet()
    }

    fun isPinned(chatId: String) = chatId in pinned
    fun isMuted(chatId: String) = chatId in muted

    /**
     * Archived chats stay out of the main list until the other person writes again (unless the chat is muted).
     */
    fun isArchived(chat: ChatItem): Boolean {
        val at = archived[chat.chatId] ?: return false
        if (chat.chatId in muted) return true
        val last = chat.last ?: return true
        val comesBack = last.senderId != Session.userId && last.createdAt.toEpochMilli() > at
        return !comesBack
    }

    /** False when 3 chats are already pinned. */
    fun togglePin(chatId: String): Boolean {
        if (chatId in pinned) {
            pinned = pinned - chatId
        } else {
            if (pinned.size >= MAX_PINNED) return false
            pinned = pinned + (chatId to System.currentTimeMillis())
        }
        save()
        return true
    }

    fun toggleMute(chatId: String) {
        muted = if (chatId in muted) muted - chatId else muted + chatId
        save()
    }

    fun toggleArchive(chat: ChatItem) {
        if (isArchived(chat)) {
            archived = archived - chat.chatId
        } else {
            archived = archived + (chat.chatId to System.currentTimeMillis())
            pinned = pinned - chat.chatId // an archived chat can't stay pinned
        }
        save()
    }

    private fun save() {
        val o = JSONObject()
        o.put("pin", JSONObject().also { j -> pinned.forEach { (k, v) -> j.put(k, v) } })
        o.put("arch", JSONObject().also { j -> archived.forEach { (k, v) -> j.put(k, v) } })
        o.put("mute", JSONArray(muted.toList()))
        Cache.putString(KEY, o.toString())
    }

    private fun JSONObject?.toLongMap(): Map<String, Long> {
        if (this == null) return emptyMap()
        val out = HashMap<String, Long>()
        keys().forEach { k -> out[k] = getLong(k) }
        return out
    }
}
