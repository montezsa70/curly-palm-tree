package app.instants.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.instants.data.Store
import app.instants.ui.components.Avatar
import app.instants.ui.components.pressable
import app.instants.ui.components.staggerIn
import app.instants.ui.theme.Palette

@Composable
fun SettingsTab(onSignOut: () -> Unit, bottomPadding: Dp) {
    var readReceipts by rememberSaveable { mutableStateOf(true) }
    var messageAlerts by rememberSaveable { mutableStateOf(true) }
    val top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    LaunchedEffect(Unit) { Store.refreshMe() }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(top = top + 12.dp, bottom = bottomPadding)
            .padding(horizontal = 20.dp),
    ) {
        Text(
            "Settings",
            color = Palette.TextPrimary,
            fontSize = 34.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = (-0.5).sp,
            modifier = Modifier.staggerIn(0),
        )
        Spacer(Modifier.height(14.dp))
        ProfileCard(Modifier.staggerIn(1))

        SettingsGroup("PRIVACY", 2) {
            ValueRow("Who can find me", listOf("Invite only", "Nobody"))
            Divider()
            ValueRow("Last seen", listOf("Close friends", "Nobody"))
            Divider()
            ToggleRow("Read receipts", readReceipts) { readReceipts = it }
            Divider()
            StaticRow("Blocked contacts", "2")
        }
        SettingsGroup("NOTIFICATIONS", 3) {
            ToggleRow("Message alerts", messageAlerts) { messageAlerts = it }
            Divider()
            ValueRow("Quiet hours", listOf("22:00 – 07:00", "Off"))
        }
        SettingsGroup("SECURITY", 4) {
            ValueRow("App lock", listOf("Face unlock", "Off"))
            Divider()
            ValueRow("Disappearing messages", listOf("Off", "24 hours", "7 days"))
        }
        SettingsGroup("ACCOUNT", 5) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .heightIn(min = 52.dp)
                    .pressable(0.99f, haptic = true, onClick = onSignOut)
                    .padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("Sign out", color = Palette.EndCall, fontSize = 16.sp)
            }
        }
    }
}

@Composable
private fun ProfileCard(modifier: Modifier) {
    val shape = RoundedCornerShape(20.dp)
    Row(
        modifier
            .fillMaxWidth()
            .height(76.dp)
            .pressable(0.98f, haptic = true) { }
            .clip(shape)
            .background(Color.White.copy(alpha = 0.06f))
            .border(1.dp, Palette.Hairline, shape)
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Avatar(Store.me?.initials ?: "", 52.dp)
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(Store.me?.name ?: "", color = Palette.TextPrimary, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
            Text(Store.me?.let { "@${it.username}" } ?: "", color = Palette.TextSecondary, fontSize = 14.sp)
        }
        Chevron()
    }
}

@Composable
private fun SettingsGroup(title: String, index: Int, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    Column(Modifier.staggerIn(index)) {
        Text(
            title,
            color = Palette.TextSecondary,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            letterSpacing = 0.8.sp,
            modifier = Modifier.padding(start = 4.dp, top = 18.dp, bottom = 8.dp),
        )
        Column(
            Modifier
                .fillMaxWidth()
                .clip(shape)
                .background(Color.White.copy(alpha = 0.06f))
                .border(1.dp, Palette.Hairline, shape),
            content = content,
        )
    }
}

@Composable
private fun Divider() {
    Box(Modifier.fillMaxWidth().height(1.dp).background(Color.White.copy(alpha = 0.08f)))
}

@Composable
private fun Chevron() {
    Icon(Icons.Rounded.ChevronRight, null, tint = Palette.TextSecondary, modifier = Modifier.size(18.dp))
}

/** Tapping cycles through the options with an animated value change. */
@Composable
private fun ValueRow(label: String, options: List<String>) {
    var index by rememberSaveable { mutableStateOf(0) }
    Row(
        Modifier
            .fillMaxWidth()
            .heightIn(min = 52.dp)
            .pressable(0.99f, haptic = true) { index = (index + 1) % options.size }
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text(label, color = Palette.TextPrimary, fontSize = 16.sp, modifier = Modifier.weight(1f))
        AnimatedContent(
            targetState = options[index],
            transitionSpec = {
                (slideInVertically(tween(260)) { it / 2 } + fadeIn(tween(260))) togetherWith
                    (slideOutVertically(tween(200)) { -it / 2 } + fadeOut(tween(160)))
            },
            label = "value",
        ) { value ->
            Text(value, color = Palette.TextSecondary, fontSize = 14.sp)
        }
        Chevron()
    }
}

@Composable
private fun StaticRow(label: String, value: String) {
    Row(
        Modifier
            .fillMaxWidth()
            .heightIn(min = 52.dp)
            .pressable(0.99f, haptic = true) { }
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text(label, color = Palette.TextPrimary, fontSize = 16.sp, modifier = Modifier.weight(1f))
        Text(value, color = Palette.TextSecondary, fontSize = 14.sp)
        Chevron()
    }
}

@Composable
private fun ToggleRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .heightIn(min = 52.dp)
            .pressable(0.99f, haptic = true) { onChange(!checked) }
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(label, color = Palette.TextPrimary, fontSize = 16.sp, modifier = Modifier.weight(1f))
        GlassSwitch(checked)
    }
}

@Composable
private fun GlassSwitch(checked: Boolean) {
    val bg by animateColorAsState(
        if (checked) Palette.Accent else Color.White.copy(alpha = 0.14f), tween(250), label = "swBg",
    )
    val x by animateDpAsState(
        targetValue = if (checked) 21.dp else 3.dp,
        animationSpec = spring(dampingRatio = 0.6f, stiffness = 500f),
        label = "swX",
    )
    Box(Modifier.size(46.dp, 28.dp).clip(CircleShape).background(bg)) {
        Box(Modifier.offset(x = x, y = 3.dp).size(22.dp).clip(CircleShape).background(Color.White))
    }
}
