package app.instants.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ChatBubble
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.CloudUpload
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.PrivacyTip
import androidx.compose.material.icons.rounded.Fingerprint
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.instants.backup.BackupPrefs
import app.instants.data.Store
import app.instants.ui.components.GlassSwitch
import app.instants.ui.components.ProfileAvatar
import app.instants.ui.components.pressable
import app.instants.ui.components.staggerIn
import app.instants.ui.theme.Palette
import app.instants.ui.theme.ThemePrefs

internal val lastSeenOptions = listOf(
    "contacts" to "My contacts",
    "close_friends" to "Close friends",
    "nobody" to "Nobody",
)
internal val findMeOptions = listOf(
    "invite" to "Invite only",
    "nobody" to "Nobody",
)
internal val themeOptions = listOf(
    "light" to "Light",
    "dark" to "Dark",
    "system" to "System default",
)
internal val disappearOptions = listOf(
    "0" to "Off",
    "86400" to "24 hours",
    "604800" to "7 days",
)
internal val backupFrequencyOptions = listOf(
    "off" to "Off",
    "daily" to "Daily",
    "weekly" to "Weekly",
    "monthly" to "Monthly",
)

internal fun labelOf(options: List<Pair<String, String>>, key: String) = options.firstOrNull { it.first == key }?.second ?: key

/**
 * The Settings tab is a short list of groups. Each group opens its own page (see SettingsPages.kt), so new
 * settings go on the page they belong to and this list stays the same length.
 */
@Composable
fun SettingsTab(onSignOut: () -> Unit, onNavigate: (String) -> Unit, bottomPadding: Dp) {
    val top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()

    LaunchedEffect(Unit) {
        Store.refreshMe()
        Store.refreshSocial()
    }

    val backupSummary = when {
        BackupPrefs.frequency != "off" -> "Google Drive · " + labelOf(backupFrequencyOptions, BackupPrefs.frequency).lowercase()
        BackupPrefs.connected -> "Google Drive · manual"
        else -> "Back up to your Google Drive"
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(top = top + 12.dp, bottom = bottomPadding)
            .padding(horizontal = 20.dp),
    ) {
        Text(
            "Settings",
            color = Palette.TextPrimary,
            fontSize = 34.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = (-0.5).sp,
            modifier = Modifier.staggerIn(0),
        )
        Spacer(Modifier.height(14.dp))
        ProfileCard(Modifier.staggerIn(1)) { onNavigate("editProfile") }

        Spacer(Modifier.height(18.dp))
        CardGroup(Modifier.staggerIn(2)) {
            CategoryRow(Icons.Rounded.Lock, "Privacy", "Last seen, close friends, read receipts, blocked") { onNavigate("settings/privacy") }
            InsetDivider()
            CategoryRow(Icons.Rounded.Fingerprint, "Security", "App lock") { onNavigate("settings/security") }
            InsetDivider()
            CategoryRow(Icons.Rounded.ChatBubble, "Chats", "Disappearing messages") { onNavigate("settings/chats") }
            InsetDivider()
            CategoryRow(Icons.Rounded.CloudUpload, "Chat backup", backupSummary) { onNavigate("settings/backup") }
            InsetDivider()
            CategoryRow(Icons.Rounded.Palette, "Appearance", "Theme: " + labelOf(themeOptions, ThemePrefs.mode).lowercase()) { onNavigate("settings/appearance") }
        }

        Spacer(Modifier.height(18.dp))
        val uri = androidx.compose.ui.platform.LocalUriHandler.current
        CardGroup(Modifier.staggerIn(3)) {
            CategoryRow(Icons.Rounded.Description, "Terms of Service", "The rules for using Instants") {
                try { uri.openUri(app.instants.data.Config.TERMS_URL) } catch (_: Exception) { }
            }
            InsetDivider()
            CategoryRow(Icons.Rounded.PrivacyTip, "Privacy Policy", "What we collect and why") {
                try { uri.openUri(app.instants.data.Config.PRIVACY_URL) } catch (_: Exception) { }
            }
        }

        Spacer(Modifier.height(18.dp))
        CardGroup(Modifier.staggerIn(3)) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .heightIn(min = 52.dp)
                    .pressable(0.99f, haptic = true, onClick = onSignOut)
                    .padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("Sign out", color = Palette.EndCall, fontSize = 16.sp)
            }
        }
    }
}

/** One card holding several rows. */
@Composable
internal fun CardGroup(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    Column(
        modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Palette.tint(0.06f))
            .border(1.dp, Palette.Hairline, shape),
        content = content,
    )
}

/** A row that opens a settings page: icon, title and a one-line summary. */
@Composable
internal fun CategoryRow(icon: ImageVector, title: String, subtitle: String, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .heightIn(min = 64.dp)
            .pressable(0.99f, haptic = true, onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Box(
            Modifier.size(38.dp).clip(RoundedCornerShape(12.dp)).background(Palette.Accent.copy(alpha = 0.14f)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, null, tint = Palette.Accent, modifier = Modifier.size(20.dp))
        }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(title, color = Palette.TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Medium)
            Text(subtitle, color = Palette.TextSecondary, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Chevron()
    }
}

/** A divider that starts after the icon, like the rows it separates. */
@Composable
internal fun InsetDivider() {
    Box(Modifier.fillMaxWidth().padding(start = 68.dp).height(1.dp).background(Palette.tint(0.08f)))
}

@Composable
private fun ProfileCard(modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    val p = Store.me?.profile
    Row(
        modifier
            .fillMaxWidth()
            .heightIn(min = 76.dp)
            .pressable(0.98f, haptic = true, onClick = onClick)
            .clip(shape)
            .background(Palette.tint(0.06f))
            .border(1.dp, Palette.Hairline, shape)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        ProfileAvatar(p?.initials ?: "", 52.dp, p?.avatarPath)
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(p?.name ?: "", color = Palette.TextPrimary, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
            Text(p?.let { "@${it.username}" } ?: "", color = Palette.TextSecondary, fontSize = 14.sp, maxLines = 1)
            if (!p?.about.isNullOrBlank()) {
                Text(p?.about ?: "", color = Palette.TextSecondary, fontSize = 13.sp, maxLines = 1)
            }
        }
        Chevron()
    }
}

@Composable
internal fun SettingsGroup(title: String, index: Int, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    Column(Modifier.staggerIn(index)) {
        Text(
            title,
            color = Palette.TextSecondary,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            letterSpacing = 0.8.sp,
            modifier = Modifier.padding(start = 4.dp, top = 18.dp, bottom = 8.dp),
        )
        Column(
            Modifier
                .fillMaxWidth()
                .clip(shape)
                .background(Palette.tint(0.06f))
                .border(1.dp, Palette.Hairline, shape),
            content = content,
        )
    }
}

@Composable
internal fun Divider() {
    Box(Modifier.fillMaxWidth().height(1.dp).background(Palette.tint(0.08f)))
}

@Composable
internal fun Chevron() {
    Icon(Icons.Rounded.ChevronRight, null, tint = Palette.TextSecondary, modifier = Modifier.size(18.dp))
}

@Composable
internal fun NavRow(label: String, value: String, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .heightIn(min = 52.dp)
            .pressable(0.99f, haptic = true, onClick = onClick)
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text(label, color = Palette.TextPrimary, fontSize = 16.sp, modifier = Modifier.weight(1f))
        Text(value, color = Palette.TextSecondary, fontSize = 14.sp)
        Chevron()
    }
}

@Composable
internal fun ToggleRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .heightIn(min = 52.dp)
            .pressable(0.99f, haptic = true) { onChange(!checked) }
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(label, color = Palette.TextPrimary, fontSize = 16.sp, modifier = Modifier.weight(1f))
        GlassSwitch(checked)
    }
}
