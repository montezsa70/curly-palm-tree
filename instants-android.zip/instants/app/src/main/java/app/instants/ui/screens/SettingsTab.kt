package app.instants.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.instants.data.Store
import app.instants.data.UserSettings
import app.instants.ui.AppLock
import app.instants.ui.components.ChoiceSheet
import app.instants.ui.components.GlassSwitch
import app.instants.ui.components.ProfileAvatar
import app.instants.ui.components.pressable
import app.instants.ui.components.staggerIn
import app.instants.ui.theme.Palette
import app.instants.ui.theme.ThemePrefs
import kotlinx.coroutines.launch

private val lastSeenOptions = listOf(
    "contacts" to "My contacts",
    "close_friends" to "Close friends",
    "nobody" to "Nobody",
)
private val findMeOptions = listOf(
    "invite" to "Invite only",
    "nobody" to "Nobody",
)
private val themeOptions = listOf(
    "light" to "Light",
    "dark" to "Dark",
    "system" to "System default",
)
private val disappearOptions = listOf(
    "0" to "Off",
    "86400" to "24 hours",
    "604800" to "7 days",
)

private fun labelOf(options: List<Pair<String, String>>, key: String) = options.firstOrNull { it.first == key }?.second ?: key

@Composable
fun SettingsTab(onSignOut: () -> Unit, onNavigate: (String) -> Unit, bottomPadding: Dp) {
    val top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var sheet by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        Store.refreshMe()
        Store.refreshSocial()
    }

    val me = Store.me
    val s = me?.settings ?: UserSettings()
    fun update(next: UserSettings) { scope.launch { Store.updateSettings(next) } }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(top = top + 12.dp, bottom = bottomPadding)
            .padding(horizontal = 20.dp),
    ) {
        Text(
            "Settings",
            color = Palette.TextPrimary,
            fontSize = 34.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = (-0.5).sp,
            modifier = Modifier.staggerIn(0),
        )
        Spacer(Modifier.height(14.dp))
        ProfileCard(Modifier.staggerIn(1)) { onNavigate("editProfile") }

        SettingsGroup("PRIVACY", 2) {
            NavRow("Last seen & active status", labelOf(lastSeenOptions, s.lastSeen)) { sheet = "lastSeen" }
            Divider()
            NavRow("Close friends", "${Store.closeFriendIds.size}") { onNavigate("closeFriends") }
            Divider()
            NavRow("Who can find me", labelOf(findMeOptions, s.findMe)) { sheet = "findMe" }
            Divider()
            ToggleRow("Read receipts", s.readReceipts) { update(s.copy(readReceipts = it)) }
            Divider()
            NavRow("Blocked contacts", "${Store.blockedIds.size}") { onNavigate("blocked") }
        }
        Text(
            "If you hide your last seen or turn off read receipts, you won’t see theirs either.",
            color = Palette.TextSecondary,
            fontSize = 12.sp,
            lineHeight = 17.sp,
            modifier = Modifier.padding(start = 4.dp, end = 4.dp, top = 8.dp),
        )

        SettingsGroup("MESSAGES", 3) {
            NavRow("Disappearing messages", labelOf(disappearOptions, s.disappearSecs.toString())) { sheet = "disappear" }
        }
        SettingsGroup("APPEARANCE", 4) {
            NavRow("Theme", labelOf(themeOptions, ThemePrefs.mode)) { sheet = "theme" }
        }
        SettingsGroup("SECURITY", 5) {
            ToggleRow("App lock", AppLock.enabled) { on ->
                if (on && !AppLock.canUse(context)) {
                    Toast.makeText(context, "Set up a screen lock or fingerprint on your phone first.", Toast.LENGTH_LONG).show()
                } else {
                    AppLock.set(on)
                }
            }
        }
        SettingsGroup("ACCOUNT", 6) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .heightIn(min = 52.dp)
                    .pressable(0.99f, haptic = true, onClick = onSignOut)
                    .padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("Sign out", color = Palette.EndCall, fontSize = 16.sp)
            }
        }
    }

    when (sheet) {
        "lastSeen" -> ChoiceSheet(
            title = "Last seen & active status",
            options = lastSeenOptions,
            selected = s.lastSeen,
            footer = "Applies to both. If you hide yours from someone, you won’t see theirs either.",
            onSelect = { update(s.copy(lastSeen = it)) },
            onDismiss = { sheet = null },
        )
        "findMe" -> ChoiceSheet(
            title = "Who can find me",
            options = findMeOptions,
            selected = s.findMe,
            footer = "With “Nobody”, your invite codes stop working until you switch back.",
            onSelect = { update(s.copy(findMe = it)) },
            onDismiss = { sheet = null },
        )
        "theme" -> ChoiceSheet(
            title = "Theme",
            options = themeOptions,
            selected = ThemePrefs.mode,
            onSelect = { ThemePrefs.set(it) },
            onDismiss = { sheet = null },
        )
        "disappear" -> ChoiceSheet(
            title = "Disappearing messages",
            options = disappearOptions,
            selected = s.disappearSecs.toString(),
            footer = "Messages you send are deleted after this time. Messages already sent aren’t affected.",
            onSelect = { update(s.copy(disappearSecs = it.toInt())) },
            onDismiss = { sheet = null },
        )
    }
}

@Composable
private fun ProfileCard(modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    val p = Store.me?.profile
    Row(
        modifier
            .fillMaxWidth()
            .heightIn(min = 76.dp)
            .pressable(0.98f, haptic = true, onClick = onClick)
            .clip(shape)
            .background(Palette.tint(0.06f))
            .border(1.dp, Palette.Hairline, shape)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        ProfileAvatar(p?.initials ?: "", 52.dp, p?.avatarPath)
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(p?.name ?: "", color = Palette.TextPrimary, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
            Text(p?.let { "@${it.username}" } ?: "", color = Palette.TextSecondary, fontSize = 14.sp, maxLines = 1)
            if (!p?.about.isNullOrBlank()) {
                Text(p?.about ?: "", color = Palette.TextSecondary, fontSize = 13.sp, maxLines = 1)
            }
        }
        Chevron()
    }
}

@Composable
private fun SettingsGroup(title: String, index: Int, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    Column(Modifier.staggerIn(index)) {
        Text(
            title,
            color = Palette.TextSecondary,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            letterSpacing = 0.8.sp,
            modifier = Modifier.padding(start = 4.dp, top = 18.dp, bottom = 8.dp),
        )
        Column(
            Modifier
                .fillMaxWidth()
                .clip(shape)
                .background(Palette.tint(0.06f))
                .border(1.dp, Palette.Hairline, shape),
            content = content,
        )
    }
}

@Composable
private fun Divider() {
    Box(Modifier.fillMaxWidth().height(1.dp).background(Palette.tint(0.08f)))
}

@Composable
private fun Chevron() {
    Icon(Icons.Rounded.ChevronRight, null, tint = Palette.TextSecondary, modifier = Modifier.size(18.dp))
}

@Composable
private fun NavRow(label: String, value: String, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .heightIn(min = 52.dp)
            .pressable(0.99f, haptic = true, onClick = onClick)
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text(label, color = Palette.TextPrimary, fontSize = 16.sp, modifier = Modifier.weight(1f))
        Text(value, color = Palette.TextSecondary, fontSize = 14.sp)
        Chevron()
    }
}

@Composable
private fun ToggleRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .heightIn(min = 52.dp)
            .pressable(0.99f, haptic = true) { onChange(!checked) }
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(label, color = Palette.TextPrimary, fontSize = 16.sp, modifier = Modifier.weight(1f))
        GlassSwitch(checked)
    }
}
