package app.instants.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.instants.data.Api
import app.instants.data.ApiException
import app.instants.ui.components.GlassField
import app.instants.ui.components.PrimaryButton
import app.instants.ui.components.pressable
import app.instants.ui.theme.Palette
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

@Composable
fun AuthScreen(onDone: () -> Unit) {
    var signUp by rememberSaveable { mutableStateOf(true) }
    var name by rememberSaveable { mutableStateOf("") }
    var username by rememberSaveable { mutableStateOf("") }
    var email by rememberSaveable { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var info by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val focus = LocalFocusManager.current

    fun submit() {
        error = null
        info = null
        val u = username.trim().lowercase()
        if (email.isBlank() || !email.contains("@")) { error = "Enter a valid email."; return }
        if (password.length < 6) { error = "Password must be at least 6 characters."; return }
        if (signUp && !Regex("^[a-z0-9_]{3,20}$").matches(u)) {
            error = "Username: 3–20 letters, numbers or underscores."
            return
        }
        focus.clearFocus()
        scope.launch {
            loading = true
            try {
                if (signUp) {
                    val signedIn = Api.signUp(email.trim(), password, u, name.trim())
                    if (signedIn) {
                        onDone()
                    } else {
                        info = "Check your email to confirm your account, then sign in."
                        signUp = false
                    }
                } else {
                    Api.signIn(email.trim(), password)
                    onDone()
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: ApiException) {
                error = friendly(e.message)
            } catch (e: Exception) {
                error = "Couldn’t connect. Check your internet and try again."
            }
            loading = false
        }
    }

    Box(Modifier.fillMaxSize().background(Palette.Charcoal)) {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Box(Modifier.size(260.dp), contentAlignment = Alignment.Center) {
                SoftRings()
                Box(
                    Modifier.size(80.dp).clip(CircleShape).background(Palette.Glass)
                        .border(1.dp, Palette.GlassBorder, CircleShape),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(Icons.Rounded.Bolt, null, tint = Color(0xFFB8CDF2), modifier = Modifier.size(34.dp))
                }
            }
            Text(
                "Welcome to Instants",
                color = Palette.TextPrimary,
                fontSize = 30.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = (-0.5).sp,
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(6.dp))
            Text(
                if (signUp) "Create your account to get started." else "Sign in to continue.",
                color = Palette.TextSecondary,
                fontSize = 15.sp,
            )
            Spacer(Modifier.height(22.dp))

            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                AnimatedVisibility(signUp) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        AuthField(name, { name = it }, "Your name")
                        AuthField(username, { username = it }, "Username")
                    }
                }
                AuthField(email, { email = it }, "Email", KeyboardType.Email)
                AuthField(password, { password = it }, "Password", KeyboardType.Password, hidden = true)
            }

            error?.let {
                Spacer(Modifier.height(12.dp))
                Text(it, color = Color(0xFFE29A9A), fontSize = 13.sp, textAlign = TextAlign.Center)
            }
            info?.let {
                Spacer(Modifier.height(12.dp))
                Text(it, color = Palette.AccentSoft, fontSize = 13.sp, textAlign = TextAlign.Center)
            }

            Spacer(Modifier.height(16.dp))
            PrimaryButton(
                text = if (loading) "Please wait…" else if (signUp) "Create account" else "Sign in",
                enabled = !loading,
            ) { submit() }
            Spacer(Modifier.height(16.dp))
            Text(
                if (signUp) "Already have an account? Sign in" else "New here? Create an account",
                color = Palette.AccentSoft,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.pressable(0.96f) {
                    signUp = !signUp
                    error = null
                    info = null
                }.padding(8.dp),
            )
            Spacer(Modifier.height(24.dp))
        }
    }
}

private fun friendly(m: String?): String = when {
    m == null -> "Something went wrong."
    m.contains("already registered", true) -> "That email already has an account. Try signing in."
    m.contains("Database error", true) -> "That username is taken. Try another one."
    m.contains("Invalid login", true) -> "Wrong email or password."
    m.contains("Email not confirmed", true) -> "Confirm your email first, then sign in."
    else -> m
}

@Composable
private fun AuthField(
    value: String,
    onChange: (String) -> Unit,
    placeholder: String,
    keyboardType: KeyboardType = KeyboardType.Text,
    hidden: Boolean = false,
) {
    Box(
        Modifier
            .fillMaxWidth()
            .height(54.dp)
            .clip(CircleShape)
            .background(Color.White.copy(alpha = 0.07f))
            .border(1.dp, Palette.Hairline, CircleShape)
            .padding(horizontal = 20.dp),
        contentAlignment = Alignment.CenterStart,
    ) {
        GlassField(
            value = value,
            onValueChange = onChange,
            placeholder = placeholder,
            modifier = Modifier.fillMaxWidth(),
            keyboardType = keyboardType,
            visualTransformation = if (hidden) PasswordVisualTransformation() else VisualTransformation.None,
        )
    }
}

/** Almost-invisible slow motion behind the logo. */
@Composable
private fun SoftRings() {
    val inf = rememberInfiniteTransition(label = "rings")
    val pulse by inf.animateFloat(
        initialValue = 1f, targetValue = 1.05f,
        animationSpec = infiniteRepeatable(tween(5200, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulse",
    )
    val spin by inf.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(90000, easing = LinearEasing)),
        label = "spin",
    )
    Canvas(Modifier.size(260.dp)) {
        listOf(56.dp, 92.dp, 126.dp).forEachIndexed { i, r ->
            drawCircle(
                color = (if (i % 2 == 0) Palette.AccentSoft else Color.White).copy(alpha = 0.07f),
                radius = r.toPx() * pulse,
                style = Stroke(1.dp.toPx()),
            )
        }
        rotate(spin) {
            drawCircle(
                color = Color.White.copy(alpha = 0.06f),
                radius = 108.dp.toPx(),
                style = Stroke(1.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 10f))),
            )
            drawCircle(
                color = Palette.AccentSoft.copy(alpha = 0.3f),
                radius = 3.dp.toPx(),
                center = Offset(center.x, center.y - 108.dp.toPx()),
            )
        }
    }
}
