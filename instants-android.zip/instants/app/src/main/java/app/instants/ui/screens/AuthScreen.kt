package app.instants.ui.screens

import android.app.Activity
import android.content.ContextWrapper
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.ExperimentalAnimationApi
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import app.instants.R
import app.instants.data.Api
import app.instants.data.ApiException
import app.instants.data.Repo
import app.instants.data.Store
import app.instants.data.initialsOf
import app.instants.ui.components.GlassIconButton
import app.instants.ui.components.ProfileAvatar
import app.instants.ui.components.pressable
import app.instants.ui.components.rememberPhotoPicker
import app.instants.ui.theme.Palette
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val USERNAME = Regex("^[a-z0-9_]{3,20}$")

// Onboarding is always light: a white page, the logo's blue and black outlines.
private val Ink = Color(0xFF111318)
private val InkSoft = Color(0xFF667085)
private val Blue = Palette.Accent
private val ErrorRed = Color(0xFFC0392B)

/** Just wide enough for the label: pills never stretch edge to edge. */
private val PillWidth = 280.dp

private val OnboardingAbouts = listOf("Available", "Busy", "At work", "At the gym", "Message only")

private enum class Step(val depth: Int) { Welcome(0), Login(1), Email(1), Profile(2) }

/**
 * One continuous page: the photo background stays put while the content slides sideways (and the photo
 * blurs and washes out as you move deeper), so nothing ever "opens a new screen".
 */
@OptIn(ExperimentalAnimationApi::class, ExperimentalLayoutApi::class)
@Composable
fun AuthScreen(onDone: () -> Unit) {
    var step by rememberSaveable { mutableStateOf(Step.Welcome) }
    var name by rememberSaveable { mutableStateOf("") }
    var email by rememberSaveable { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var username by rememberSaveable { mutableStateOf("") }
    var about by rememberSaveable { mutableStateOf("Available") }
    var photo by remember { mutableStateOf<ByteArray?>(null) }
    var avail by remember { mutableStateOf<Boolean?>(null) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var info by remember { mutableStateOf<String?>(null) }
    var finishing by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val focus = LocalFocusManager.current
    val pickPhoto = rememberPhotoPicker { photo = it }

    val u = username.trim().lowercase()
    val usernameOk = USERNAME.matches(u)

    // Dark status-bar icons on this white page, whatever the app theme is
    val view = LocalView.current
    DisposableEffect(Unit) {
        val activity = generateSequence(view.context) { (it as? ContextWrapper)?.baseContext }
            .filterIsInstance<Activity>().firstOrNull()
        val controller = activity?.window?.let { WindowCompat.getInsetsController(it, view) }
        controller?.isAppearanceLightStatusBars = true
        controller?.isAppearanceLightNavigationBars = true
        onDispose {
            controller?.isAppearanceLightStatusBars = !Palette.dark
            controller?.isAppearanceLightNavigationBars = !Palette.dark
        }
    }

    // Live "is this username free?" check
    LaunchedEffect(u, step) {
        avail = null
        if (step == Step.Profile && usernameOk) {
            delay(450)
            avail = try {
                Repo.usernameAvailable(u)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                true
            }
        }
    }

    fun clearMessages() {
        error = null
        info = null
    }

    fun go(to: Step) {
        clearMessages()
        focus.clearFocus()
        step = to
    }

    fun handleError(e: Exception) {
        error = if (e is ApiException) friendly(e.message) else "Couldn’t connect. Check your internet and try again."
    }

    /** The account is ready: fade the page out and let the app fade in behind it, with a short pause between. */
    fun finish() {
        finishing = true
        scope.launch {
            delay(1100)
            onDone()
        }
    }

    fun signIn() {
        clearMessages()
        if (email.isBlank() || !email.contains("@")) { error = "Enter a valid email."; return }
        if (password.isEmpty()) { error = "Enter your password."; return }
        focus.clearFocus()
        scope.launch {
            loading = true
            try {
                Api.signIn(email.trim(), password)
                Store.refreshMe()
                finish()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // A wrong password and "no such account" are different problems; tell them apart
                val registered = try { Repo.emailRegistered(email) } catch (x: Exception) { true }
                if (!registered && e is ApiException) {
                    error = "There’s no account with that email yet."
                } else {
                    handleError(e)
                }
            }
            loading = false
        }
    }

    /** Sign-up step 1: if the email already has an account, take them to the right place instead. */
    fun continueFromEmail() {
        clearMessages()
        if (email.isBlank() || !email.contains("@")) { error = "Enter a valid email."; return }
        if (password.length < 6) { error = "Password must be at least 6 characters."; return }
        focus.clearFocus()
        scope.launch {
            loading = true
            try {
                if (Repo.emailRegistered(email)) {
                    // They already have an account: try the password they just typed, otherwise ask on the login page
                    try {
                        Api.signIn(email.trim(), password)
                        Store.refreshMe()
                        finish()
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        password = ""
                        step = Step.Login
                        info = "That email already has an account. Enter its password to log in."
                    }
                } else {
                    step = Step.Profile
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                handleError(e)
            }
            loading = false
        }
    }

    fun createAccount() {
        clearMessages()
        focus.clearFocus()
        scope.launch {
            loading = true
            try {
                val aboutText = about.trim().ifBlank { "Available" }
                val signedIn = Api.signUp(email.trim(), password, u, name.trim(), aboutText)
                if (signedIn) {
                    val bytes = photo
                    if (bytes != null) {
                        try {
                            val path = Repo.uploadAvatar(bytes)
                            Repo.updateProfile(name.trim(), u, aboutText, path, keepAvatar = false)
                        } catch (e: CancellationException) {
                            throw e
                        } catch (e: Exception) {
                            // account exists; the photo can be added later from Edit profile
                        }
                    }
                    Store.refreshMe()
                    finish()
                } else {
                    step = Step.Login
                    info = "Check your email to confirm your account, then log in."
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                handleError(e)
            }
            loading = false
        }
    }

    BackHandler(enabled = step != Step.Welcome && !finishing) {
        go(if (step == Step.Profile) Step.Email else Step.Welcome)
    }

    val calm by animateFloatAsState(
        if (step == Step.Welcome) 0f else 1f, tween(700, easing = FastOutSlowInEasing), label = "calm",
    )
    val leave by animateFloatAsState(if (finishing) 1f else 0f, tween(650, easing = LinearEasing), label = "leave")

    Box(Modifier.fillMaxSize().background(Color.White)) {
        OnboardingBackdrop(calm)

        Box(Modifier.fillMaxSize().graphicsLayer { alpha = 1f - leave }) {
            AnimatedContent(
                targetState = step,
                modifier = Modifier.fillMaxSize(),
                transitionSpec = {
                    val ease = FastOutSlowInEasing
                    if (targetState.depth >= initialState.depth) {
                        (slideInHorizontally(tween(460, easing = ease)) { it / 4 } + fadeIn(tween(360, 80))) togetherWith
                            (slideOutHorizontally(tween(460, easing = ease)) { -it / 5 } + fadeOut(tween(220)))
                    } else {
                        (slideInHorizontally(tween(460, easing = ease)) { -it / 4 } + fadeIn(tween(360, 80))) togetherWith
                            (slideOutHorizontally(tween(460, easing = ease)) { it / 5 } + fadeOut(tween(220)))
                    }
                },
                label = "onboarding",
            ) { s ->
                when (s) {
                    Step.Welcome -> WelcomePage(onSignUp = { go(Step.Email) }, onLogin = { go(Step.Login) })

                    Step.Email -> Page(scrollable = true) {
                        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).fillMaxWidth().padding(horizontal = 28.dp)) {
                            Spacer(Modifier.height(72.dp))
                            Doodles(Modifier.fillMaxWidth().aspectRatio(380f / 120f))
                            Spacer(Modifier.height(18.dp))
                            Text(
                                "Say it.\nIt’s there.", color = Ink, fontSize = 40.sp, lineHeight = 42.sp,
                                fontWeight = FontWeight.ExtraBold, letterSpacing = (-1).sp,
                            )
                            Spacer(Modifier.height(10.dp))
                            Text(
                                "Private chats, voice notes and statuses that vanish in 24 hours.",
                                color = InkSoft, fontSize = 16.sp, lineHeight = 22.sp,
                            )
                        }
                        Column(
                            Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            OnbField(email, { email = it }, "Email", KeyboardType.Email)
                            OnbField(
                                password, { password = it }, "Password", KeyboardType.Password, hidden = true,
                                ime = ImeAction.Done, onIme = { continueFromEmail() },
                            )
                            Messages(error, info)
                            Spacer(Modifier.height(2.dp))
                            BluePill(if (loading) "Checking…" else "Continue", enabled = !loading) { continueFromEmail() }
                            TextLink("Already have an account? Log in") { go(Step.Login) }
                        }
                    }

                    Step.Login -> Page(scrollable = true) {
                        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).fillMaxWidth().padding(horizontal = 28.dp)) {
                            Spacer(Modifier.height(96.dp))
                            Text(
                                "Welcome\nback.", color = Ink, fontSize = 40.sp, lineHeight = 42.sp,
                                fontWeight = FontWeight.ExtraBold, letterSpacing = (-1).sp,
                            )
                            Spacer(Modifier.height(10.dp))
                            Text("Log in to pick up where you left off.", color = InkSoft, fontSize = 16.sp)
                        }
                        Column(
                            Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            OnbField(email, { email = it }, "Email", KeyboardType.Email)
                            OnbField(
                                password, { password = it }, "Password", KeyboardType.Password, hidden = true,
                                ime = ImeAction.Done, onIme = { signIn() },
                            )
                            Messages(error, info)
                            Spacer(Modifier.height(2.dp))
                            BluePill(if (loading) "Please wait…" else "Log in", enabled = !loading) { signIn() }
                            TextLink("New here? Sign up") { go(Step.Email) }
                        }
                    }

                    Step.Profile -> Page(scrollable = true) {
                        Column(
                            Modifier.weight(1f).verticalScroll(rememberScrollState()).fillMaxWidth().padding(horizontal = 28.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                        ) {
                            Spacer(Modifier.height(72.dp))
                            Text(
                                "Make it yours.", color = Ink, fontSize = 32.sp,
                                fontWeight = FontWeight.ExtraBold, letterSpacing = (-0.8).sp,
                            )
                            Spacer(Modifier.height(18.dp))
                            ProfileAvatar(
                                initials = initialsOf(name.trim().ifBlank { "?" }),
                                size = 104.dp,
                                avatarPath = null,
                                modifier = Modifier.pressable(0.97f, onClick = pickPhoto),
                                localBytes = photo,
                            )
                            Spacer(Modifier.height(12.dp))
                            Row(
                                Modifier
                                    .height(40.dp)
                                    .pressable(0.96f, haptic = true, onClick = pickPhoto)
                                    .clip(CircleShape)
                                    .border(1.5.dp, Ink, CircleShape)
                                    .padding(horizontal = 18.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                Icon(Icons.Rounded.CameraAlt, null, tint = Ink, modifier = Modifier.size(18.dp))
                                Text(
                                    if (photo == null) "Add photo" else "Change photo",
                                    color = Ink, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                                )
                            }
                            Spacer(Modifier.height(22.dp))
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                OnbField(name, { name = it }, "Your name")
                                OnbField(username, { username = it.lowercase().filter { c -> c != ' ' } }, "Username")
                                val hint: Pair<String, Color>? = when {
                                    u.isEmpty() -> null
                                    !usernameOk -> "3–20 letters, numbers or underscores" to InkSoft
                                    avail == null -> "Checking…" to InkSoft
                                    avail == true -> "@$u is available" to Blue
                                    else -> "@$u is taken" to ErrorRed
                                }
                                if (hint != null) Text(hint.first, color = hint.second, fontSize = 13.sp)
                            }
                            Spacer(Modifier.height(20.dp))
                            Text("About", color = Ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                            Spacer(Modifier.height(10.dp))
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
                                verticalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.widthIn(max = 320.dp),
                            ) {
                                OnboardingAbouts.forEach { t -> AboutChip(t, about == t) { about = t } }
                            }
                            Spacer(Modifier.height(16.dp))
                        }
                        Column(
                            Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            Messages(error, info)
                            BluePill(
                                if (loading) "Creating…" else "Create account",
                                enabled = !loading && name.isNotBlank() && usernameOk && avail == true,
                            ) { createAccount() }
                        }
                    }
                }
            }

            if (step != Step.Welcome) {
                GlassIconButton(
                    icon = Icons.AutoMirrored.Rounded.ArrowBack,
                    description = "Back",
                    size = 48.dp,
                    calm = true,
                    tint = Ink,
                    modifier = Modifier.align(Alignment.TopStart).statusBarsPadding().padding(horizontal = 12.dp, vertical = 8.dp),
                    onClick = { go(if (step == Step.Profile) Step.Email else Step.Welcome) },
                )
            }
        }

        // After "Create account" / log in: a calm white beat with the logo, then the app fades in
        if (leave > 0f) {
            Box(Modifier.fillMaxSize().graphicsLayer { alpha = leave }.background(Color.White), contentAlignment = Alignment.Center) {
                val pulse = rememberInfiniteTransition(label = "pulse")
                val sc by pulse.animateFloat(
                    1f, 1.08f, infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pulseScale",
                )
                Image(
                    painterResource(R.drawable.instants_logo), null,
                    Modifier.size(96.dp).graphicsLayer { scaleX = sc; scaleY = sc },
                )
            }
        }
    }
}

/** The group photo, sharp at the top, blurred and washed to white where the buttons are. */
@Composable
private fun OnboardingBackdrop(calm: Float) {
    val photo = painterResource(R.drawable.onboarding_people)
    Box(Modifier.fillMaxSize()) {
        Image(photo, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        // Blurred copy, fading in from the middle down (this is the frosted area behind the buttons)
        Image(
            photo, null,
            Modifier
                .fillMaxSize()
                .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
                .blur(26.dp)
                .drawWithContent {
                    drawContent()
                    drawRect(
                        Brush.verticalGradient(0f to Color.Transparent, 0.42f to Color.Transparent, 0.72f to Color.Black, 1f to Color.Black),
                        blendMode = BlendMode.DstIn,
                    )
                },
            contentScale = ContentScale.Crop,
        )
        // Whole photo blurs as soon as you leave the welcome page
        Image(
            photo, null,
            Modifier.fillMaxSize().graphicsLayer { alpha = calm }.blur(30.dp),
            contentScale = ContentScale.Crop,
        )
        // White wash: bottom of the welcome page, then the whole page
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(0f to Color.Transparent, 0.5f to Color.White.copy(0.15f), 0.78f to Color.White.copy(0.82f), 1f to Color.White),
            ),
        )
        Box(Modifier.fillMaxSize().graphicsLayer { alpha = calm * 0.93f }.background(Color.White))
    }
}

@Composable
private fun WelcomePage(onSignUp: () -> Unit, onLogin: () -> Unit) {
    Box(Modifier.fillMaxSize()) {
        // Logo in the middle of the photo
        Box(
            Modifier
                .align(Alignment.Center)
                .size(124.dp)
                .shadow(24.dp, CircleShape, ambientColor = Color.Black.copy(0.3f), spotColor = Color.Black.copy(0.3f))
                .clip(CircleShape)
                .background(Color.White),
            contentAlignment = Alignment.Center,
        ) {
            Image(painterResource(R.drawable.instants_logo), "Instants", Modifier.size(84.dp))
        }
        Column(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(bottom = 36.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(
                "Instants", color = Ink, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-0.6).sp,
            )
            Text("Chat the way it should feel.", color = InkSoft, fontSize = 15.sp)
            Spacer(Modifier.height(6.dp))
            BluePill("Sign up", onClick = onSignUp)
            OutlinePill("Log in", onClick = onLogin)
        }
    }
}

/** Page frame for the form steps: content on top, controls pinned to the bottom, keyboard-aware. */
@Composable
private fun Page(scrollable: Boolean, content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding(), content = content)
}

@Composable
private fun BluePill(text: String, enabled: Boolean = true, onClick: () -> Unit) {
    val a by animateFloatAsState(if (enabled) 1f else 0.45f, tween(200), label = "pillAlpha")
    Box(
        Modifier
            .widthIn(max = PillWidth)
            .fillMaxWidth()
            .height(52.dp)
            .graphicsLayer { alpha = a }
            .pressable(0.97f, haptic = true) { if (enabled) onClick() }
            .clip(CircleShape)
            .background(Blue),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun OutlinePill(text: String, onClick: () -> Unit) {
    Box(
        Modifier
            .widthIn(max = PillWidth)
            .fillMaxWidth()
            .height(52.dp)
            .pressable(0.97f, haptic = true, onClick = onClick)
            .clip(CircleShape)
            .border(1.5.dp, Ink, CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = Ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun TextLink(text: String, onClick: () -> Unit) {
    Text(
        text, color = Blue, fontSize = 14.sp, fontWeight = FontWeight.Medium,
        modifier = Modifier.pressable(0.96f, onClick = onClick).padding(8.dp),
    )
}

@Composable
private fun Messages(error: String?, info: String?) {
    error?.let {
        Text(it, color = ErrorRed, fontSize = 13.sp, textAlign = TextAlign.Center, modifier = Modifier.widthIn(max = 300.dp))
    }
    info?.let {
        Text(it, color = Blue, fontSize = 13.sp, textAlign = TextAlign.Center, modifier = Modifier.widthIn(max = 300.dp))
    }
}

@Composable
private fun AboutChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .height(36.dp)
            .pressable(0.94f, haptic = true, onClick = onClick)
            .clip(CircleShape)
            .background(if (selected) Blue else Color.Transparent)
            .border(1.5.dp, if (selected) Blue else Ink.copy(0.55f), CircleShape)
            .padding(horizontal = 16.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, color = if (selected) Color.White else Ink, fontSize = 14.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun OnbField(
    value: String,
    onChange: (String) -> Unit,
    placeholder: String,
    keyboardType: KeyboardType = KeyboardType.Text,
    hidden: Boolean = false,
    ime: ImeAction = ImeAction.Next,
    onIme: () -> Unit = {},
) {
    val fm = LocalFocusManager.current
    Box(
        Modifier
            .widthIn(max = PillWidth)
            .fillMaxWidth()
            .height(50.dp)
            .clip(CircleShape)
            .background(Color.White.copy(0.9f))
            .border(1.5.dp, Ink.copy(0.85f), CircleShape)
            .padding(horizontal = 20.dp),
        contentAlignment = Alignment.CenterStart,
    ) {
        BasicTextField(
            value = value,
            onValueChange = onChange,
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            visualTransformation = if (hidden) PasswordVisualTransformation() else VisualTransformation.None,
            textStyle = TextStyle(color = Ink, fontSize = 16.sp),
            cursorBrush = SolidColor(Blue),
            keyboardOptions = KeyboardOptions(keyboardType = keyboardType, imeAction = ime),
            keyboardActions = KeyboardActions(onAny = { if (ime == ImeAction.Next) fm.moveFocus(FocusDirection.Down) else onIme() }),
            decorationBox = { inner ->
                Box(contentAlignment = Alignment.CenterStart) {
                    if (value.isEmpty()) Text(placeholder, color = InkSoft, fontSize = 16.sp)
                    inner()
                }
            },
        )
    }
}

/**
 * Hand-drawn blue doodles that draw themselves in one after another (a chat bubble, a bolt, a heart, a sparkle
 * and a squiggle), then bob gently.
 */
@Composable
private fun Doodles(modifier: Modifier = Modifier) {
    val progress = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        delay(250)
        progress.animateTo(1f, tween(3200, easing = LinearEasing))
    }
    val bob = rememberInfiniteTransition(label = "doodleBob")
    val dy by bob.animateFloat(-3f, 3f, infiniteRepeatable(tween(2200, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "dy")

    val shapes = remember {
        listOf(
            // chat bubble
            Path().apply {
                moveTo(40f, 12f); lineTo(130f, 12f); quadTo(152f, 12f, 152f, 34f); lineTo(152f, 60f)
                quadTo(152f, 82f, 130f, 82f); lineTo(78f, 82f); lineTo(52f, 104f); lineTo(56f, 82f)
                lineTo(40f, 82f); quadTo(18f, 82f, 18f, 60f); lineTo(18f, 34f); quadTo(18f, 12f, 40f, 12f)
            },
            // typing dots
            Path().apply { addOval(androidx.compose.ui.geometry.Rect(Offset(52f, 44f), 5f)) },
            Path().apply { addOval(androidx.compose.ui.geometry.Rect(Offset(80f, 44f), 5f)) },
            Path().apply { addOval(androidx.compose.ui.geometry.Rect(Offset(108f, 44f), 5f)) },
            // lightning bolt
            Path().apply {
                moveTo(205f, 6f); lineTo(176f, 62f); lineTo(202f, 62f); lineTo(184f, 112f)
                lineTo(232f, 46f); lineTo(206f, 46f); lineTo(226f, 6f); close()
            },
            // heart
            Path().apply {
                moveTo(285f, 104f); cubicTo(240f, 74f, 250f, 28f, 285f, 52f)
                cubicTo(320f, 28f, 330f, 74f, 285f, 104f)
            },
            // sparkle
            Path().apply {
                moveTo(347f, 6f); lineTo(354f, 30f); lineTo(378f, 38f); lineTo(354f, 46f); lineTo(347f, 70f)
                lineTo(340f, 46f); lineTo(316f, 38f); lineTo(340f, 30f); close()
            },
            // squiggle underline
            Path().apply {
                moveTo(20f, 116f); quadTo(40f, 100f, 60f, 116f); quadTo(80f, 132f, 100f, 116f)
                quadTo(120f, 100f, 140f, 116f); quadTo(160f, 132f, 180f, 116f)
            },
        )
    }
    Canvas(modifier) {
        val k = size.width / 380f
        val n = shapes.size
        shapes.forEachIndexed { i, shape ->
            val start = i / n.toFloat() * 0.7f
            val local = ((progress.value - start) / 0.3f).coerceIn(0f, 1f)
            if (local <= 0f) return@forEachIndexed
            val measure = PathMeasure().apply { setPath(shape, false) }
            val out = Path()
            measure.getSegment(0f, measure.length * local, out, true)
            val wave = if (i % 2 == 0) dy else -dy
            withTransform({
                translate(0f, wave * k)
                scale(k, k, Offset.Zero)
            }) {
                drawPath(out, Blue, style = Stroke(width = 3.2f, cap = StrokeCap.Round, join = StrokeJoin.Round))
            }
        }
    }
}

private fun friendly(m: String?): String = when {
    m == null -> "Something went wrong."
    m.contains("already registered", true) -> "That email already has an account."
    m.contains("Database error", true) -> "That username is taken. Try another one."
    m.contains("Invalid login", true) -> "Wrong email or password."
    m.contains("Email not confirmed", true) -> "Confirm your email first, then log in."
    else -> m
}
