package app.instants.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.instants.R
import app.instants.data.Api
import app.instants.data.ApiException
import app.instants.data.Repo
import app.instants.data.Store
import app.instants.data.initialsOf
import app.instants.ui.components.AboutPicker
import app.instants.ui.components.GlassField
import app.instants.ui.components.GlassIconButton
import app.instants.ui.components.PrimaryButton
import app.instants.ui.components.ProfileAvatar
import app.instants.ui.components.SoftButton
import app.instants.ui.components.pressable
import app.instants.ui.components.rememberPhotoPicker
import app.instants.ui.theme.Palette
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val USERNAME = Regex("^[a-z0-9_]{3,20}$")

/** mode 0 = sign in, 1 = sign up step 1 (name, email, password), 2 = sign up step 2 (photo, username, about). */
@Composable
fun AuthScreen(onDone: () -> Unit) {
    var mode by rememberSaveable { mutableStateOf(1) }
    var name by rememberSaveable { mutableStateOf("") }
    var email by rememberSaveable { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var username by rememberSaveable { mutableStateOf("") }
    var about by rememberSaveable { mutableStateOf("Available") }
    var photo by remember { mutableStateOf<ByteArray?>(null) }
    var avail by remember { mutableStateOf<Boolean?>(null) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var emailTaken by remember { mutableStateOf(false) }
    var info by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val focus = LocalFocusManager.current
    val pickPhoto = rememberPhotoPicker { photo = it }

    val u = username.trim().lowercase()
    val usernameOk = USERNAME.matches(u)

    // Live "is this username free?" check on step 2
    LaunchedEffect(u, mode) {
        avail = null
        if (mode == 2 && usernameOk) {
            delay(450)
            avail = try {
                Repo.usernameAvailable(u)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                true
            }
        }
    }

    fun clearMessages() {
        error = null
        info = null
        emailTaken = false
    }

    fun handleError(e: Exception) {
        if (e is ApiException) {
            emailTaken = e.message?.contains("already registered", true) == true
            error = friendly(e.message)
        } else {
            error = "Couldn’t connect. Check your internet and try again."
        }
    }

    fun goNext() {
        clearMessages()
        if (name.isBlank()) { error = "Enter your name."; return }
        if (email.isBlank() || !email.contains("@")) { error = "Enter a valid email."; return }
        if (password.length < 6) { error = "Password must be at least 6 characters."; return }
        focus.clearFocus()
        mode = 2
    }

    fun signIn() {
        clearMessages()
        if (email.isBlank() || !email.contains("@")) { error = "Enter a valid email."; return }
        if (password.isEmpty()) { error = "Enter your password."; return }
        focus.clearFocus()
        scope.launch {
            loading = true
            try {
                Api.signIn(email.trim(), password)
                Store.refreshMe()
                onDone()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                handleError(e)
            }
            loading = false
        }
    }

    fun createAccount() {
        clearMessages()
        focus.clearFocus()
        scope.launch {
            loading = true
            try {
                val aboutText = about.trim().ifBlank { "Available" }
                val signedIn = Api.signUp(email.trim(), password, u, name.trim(), aboutText)
                if (signedIn) {
                    val bytes = photo
                    if (bytes != null) {
                        try {
                            val path = Repo.uploadAvatar(bytes)
                            Repo.updateProfile(name.trim(), u, aboutText, path, keepAvatar = false)
                        } catch (e: CancellationException) {
                            throw e
                        } catch (e: Exception) {
                            // account exists; the photo can be added later from Edit profile
                        }
                    }
                    Store.refreshMe()
                    onDone()
                } else {
                    info = "Check your email to confirm your account, then sign in."
                    mode = 0
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                handleError(e)
            }
            loading = false
        }
    }

    Box(Modifier.fillMaxSize().background(Palette.Background)) {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            // Space for the fixed back button on step 2
            Spacer(Modifier.height(if (mode == 2) 72.dp else 40.dp))

            if (mode != 2) {
                Image(
                    painter = painterResource(R.drawable.instants_logo),
                    contentDescription = "Instants",
                    modifier = Modifier.size(96.dp),
                )
                Spacer(Modifier.height(20.dp))
            }
            if (mode != 0) {
                Text("Step $mode of 2", color = Palette.TextSecondary, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                Spacer(Modifier.height(6.dp))
            }
            Text(
                when (mode) {
                    0 -> "Welcome back"
                    1 -> "Create your account"
                    else -> "Set up your profile"
                },
                color = Palette.TextPrimary,
                fontSize = 30.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = (-0.5).sp,
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(6.dp))
            Text(
                when (mode) {
                    0 -> "Sign in to continue."
                    1 -> "Start with your name and email."
                    else -> "Add a photo, pick a username and set your About."
                },
                color = Palette.TextSecondary,
                fontSize = 15.sp,
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(24.dp))

            if (mode == 2) {
                PhotoUploader(
                    initials = initialsOf(name.trim().ifBlank { "?" }),
                    photo = photo,
                    onPick = pickPhoto,
                )
                Spacer(Modifier.height(24.dp))
            }

            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (mode == 1) {
                    AuthField(name, { name = it }, "Your name")
                }
                if (mode != 2) {
                    AuthField(email, { email = it }, "Email", KeyboardType.Email)
                    AuthField(password, { password = it }, "Password", KeyboardType.Password, hidden = true)
                }
                if (mode == 2) {
                    AuthField(username, { username = it.lowercase() }, "Username")
                    val hint: Pair<String, Color>? = when {
                        u.isEmpty() -> null
                        !usernameOk -> "3–20 letters, numbers or underscores" to Palette.TextSecondary
                        avail == null -> "Checking…" to Palette.TextSecondary
                        avail == true -> "@$u is available" to Palette.AccentSoft
                        else -> "@$u is taken" to Palette.Error
                    }
                    if (hint != null) {
                        Text(hint.first, color = hint.second, fontSize = 13.sp, modifier = Modifier.padding(start = 8.dp))
                    }
                    Spacer(Modifier.height(4.dp))
                    Text("About", color = Palette.TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                    AboutPicker(about) { about = it }
                }
            }

            error?.let {
                Spacer(Modifier.height(12.dp))
                Text(it, color = Palette.Error, fontSize = 13.sp, textAlign = TextAlign.Center)
            }
            info?.let {
                Spacer(Modifier.height(12.dp))
                Text(it, color = Palette.AccentSoft, fontSize = 13.sp, textAlign = TextAlign.Center)
            }
            if (emailTaken) {
                Spacer(Modifier.height(12.dp))
                SoftButton("Sign in instead", Modifier.fillMaxWidth()) {
                    clearMessages()
                    mode = 0
                }
            }

            Spacer(Modifier.height(16.dp))
            PrimaryButton(
                text = when {
                    loading -> "Please wait…"
                    mode == 0 -> "Sign in"
                    mode == 1 -> "Next"
                    else -> "Create account"
                },
                enabled = !loading && (mode != 2 || (usernameOk && avail == true)),
            ) {
                when (mode) {
                    0 -> signIn()
                    1 -> goNext()
                    else -> createAccount()
                }
            }
            if (mode != 2) {
                Spacer(Modifier.height(16.dp))
                Text(
                    if (mode == 1) "Already have an account? Sign in" else "New here? Create an account",
                    color = Palette.AccentSoft,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.pressable(0.96f) {
                        clearMessages()
                        mode = if (mode == 1) 0 else 1
                    }.padding(8.dp),
                )
            }
            Spacer(Modifier.height(24.dp))
        }

        // Fixed back button: same position as Settings pages, stays put while scrolling
        if (mode == 2) {
            GlassIconButton(
                icon = Icons.AutoMirrored.Rounded.ArrowBack,
                description = "Back",
                size = 48.dp,
                calm = true,
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .statusBarsPadding()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                onClick = { clearMessages(); mode = 1 },
            )
        }
    }
}

/** A clear place to add a profile photo: preview + an explicit button. */
@Composable
private fun PhotoUploader(initials: String, photo: ByteArray?, onPick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
        ProfileAvatar(
            initials = initials,
            size = 112.dp,
            avatarPath = null,
            modifier = Modifier.pressable(0.97f, onClick = onPick),
            localBytes = photo,
        )
        Row(
            Modifier
                .height(48.dp)
                .pressable(0.96f, haptic = true, onClick = onPick)
                .clip(CircleShape)
                .background(Palette.Accent)
                .padding(horizontal = 20.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Icon(Icons.Rounded.CameraAlt, null, tint = Color.White, modifier = Modifier.size(20.dp))
            Text(
                if (photo == null) "Add profile photo" else "Change photo",
                color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
            )
        }
        Text("Optional. You can add it later.", color = Palette.TextSecondary, fontSize = 12.sp)
    }
}

private fun friendly(m: String?): String = when {
    m == null -> "Something went wrong."
    m.contains("already registered", true) -> "That email already has an account."
    m.contains("Database error", true) -> "That username is taken. Try another one."
    m.contains("Invalid login", true) -> "Wrong email or password."
    m.contains("Email not confirmed", true) -> "Confirm your email first, then sign in."
    else -> m
}

@Composable
private fun AuthField(
    value: String,
    onChange: (String) -> Unit,
    placeholder: String,
    keyboardType: KeyboardType = KeyboardType.Text,
    hidden: Boolean = false,
) {
    Box(
        Modifier
            .fillMaxWidth()
            .height(54.dp)
            .clip(CircleShape)
            .background(Palette.tint(0.07f))
            .border(1.dp, Palette.Hairline, CircleShape)
            .padding(horizontal = 20.dp),
        contentAlignment = Alignment.CenterStart,
    ) {
        GlassField(
            value = value,
            onValueChange = onChange,
            placeholder = placeholder,
            modifier = Modifier.fillMaxWidth(),
            keyboardType = keyboardType,
            visualTransformation = if (hidden) PasswordVisualTransformation() else VisualTransformation.None,
        )
    }
}
