package app.instants.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.instants.data.ChatItem
import app.instants.data.Store
import app.instants.ui.components.Ic
import app.instants.ui.components.LIcon
import app.instants.ui.components.ProfileAvatar
import app.instants.ui.components.pressable
import app.instants.ui.theme.Palette
import kotlinx.coroutines.launch

/** The (+) action on the Calls tab: pick someone you already chat with and start a call. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NewCallSheet(onDismiss: () -> Unit, onCall: (ChatItem) -> Unit) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val scope = rememberCoroutineScope()
    val people = Store.chats.filter { it.peer != null }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = Palette.Sheet,
        contentColor = Palette.TextPrimary,
    ) {
        Column(Modifier.fillMaxWidth().navigationBarsPadding().padding(bottom = 16.dp)) {
            Text(
                "New call", color = Palette.TextPrimary, fontSize = 22.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp),
            )
            if (people.isEmpty()) {
                Text(
                    "No contacts yet. Invite someone from the Chats tab to start calling.",
                    color = Palette.TextSecondary, fontSize = 15.sp, lineHeight = 21.sp, textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 32.dp, vertical = 32.dp),
                )
            } else {
                LazyColumn(Modifier.heightIn(max = 480.dp)) {
                    items(people, key = { it.chatId }) { chat ->
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .pressable(0.985f, haptic = true) {
                                    scope.launch { sheetState.hide() }.invokeOnCompletion {
                                        onDismiss()
                                        onCall(chat)
                                    }
                                }
                                .padding(horizontal = 24.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(14.dp),
                        ) {
                            ProfileAvatar(chat.initials, 46.dp, chat.peer?.avatarPath)
                            Text(
                                chat.title, color = Palette.TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.SemiBold,
                                maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f),
                            )
                            Box(
                                Modifier.size(40.dp).clip(CircleShape).background(Palette.tint(0.07f))
                                    .border(1.dp, Palette.Hairline, CircleShape),
                                contentAlignment = Alignment.Center,
                            ) { LIcon(Ic.Calls, Palette.AccentSoft, 19.dp) }
                        }
                    }
                }
            }
        }
    }
}
