package app.instants.data

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.asRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant
import java.time.LocalDate
import java.time.OffsetDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter

fun initialsOf(name: String): String =
    name.split(" ").filter { it.isNotBlank() }.take(2).joinToString("") { it.first().uppercase() }.ifBlank { "?" }

data class Profile(
    val id: String,
    val username: String,
    val displayName: String,
    val about: String = "",
    val avatarPath: String? = null,
) {
    val name: String get() = displayName.ifBlank { username }
    val initials: String get() = initialsOf(name)
}

/** Private settings. lastSeen: contacts | close_friends | nobody. findMe: invite | nobody. */
data class UserSettings(
    val lastSeen: String = "close_friends",
    val findMe: String = "invite",
    val readReceipts: Boolean = true,
    val disappearSecs: Int = 0,
)

data class Me(val profile: Profile, val settings: UserSettings)

data class Msg(
    val id: String,
    val chatId: String,
    val senderId: String,
    val body: String,
    val createdAt: Instant,
    val kind: String = "text", // text | image | file | voice
    val attachmentPath: String? = null,
    val attachmentName: String? = null,
    val attachmentMime: String? = null,
    val attachmentSize: Long = 0L,
    val voiceDurationMs: Int = 0,
    val voiceWaveform: String? = null, // bar heights 0-99, comma separated
    val replyTo: String? = null,            // id of the message this one answers
    val statusQuote: StatusQuote? = null,   // or the status it answers
    val deletedAt: Instant? = null,         // set = deleted for everyone (only a tombstone is left)
    val deliveredAt: Instant? = null,
    val readAt: Instant? = null,
) {
    val deleted: Boolean get() = deletedAt != null

    /** One line for the chat list. */
    val preview: String
        get() = if (deleted) "This message was deleted" else when (kind) {
            "image" -> body.ifBlank { "Photo" }
            "file" -> attachmentName ?: "Document"
            "voice" -> "Voice message (" + formatDuration(voiceDurationMs.toLong()) + ")"
            "call" -> "Voice call"
            else -> body
        }
}

/**
 * The line a call entry shows in the chat and in the chat list. The server writes the entry when a call ends:
 * the body is "ended:<seconds>", "missed", "cancelled", "declined", "busy" or "failed", and the caller is the sender.
 */
fun Msg.callLabel(me: String?): String {
    val outgoing = senderId == me
    val seconds = body.substringAfter(':', "").toLongOrNull() ?: 0L
    return when (body.substringBefore(':')) {
        "ended" -> (if (outgoing) "Outgoing call" else "Incoming call") + " · " + formatDuration(seconds * 1000)
        "declined" -> if (outgoing) "Call declined" else "Declined call"
        "cancelled" -> if (outgoing) "Cancelled call" else "Missed call"
        "missed" -> if (outgoing) "No answer" else "Missed call"
        "busy" -> if (outgoing) "Busy" else "Missed call"
        "failed" -> "Call couldn't connect"
        else -> "Voice call"
    }
}

/** True for a call I did not get to take, or one that never connected. */
fun Msg.callWentWrong(me: String?): Boolean {
    val outcome = body.substringBefore(':')
    return outcome == "failed" || (senderId != me && outcome in setOf("missed", "cancelled", "busy"))
}

/** A status that a message replies to, copied into the message because statuses expire after 24 hours. */
data class StatusQuote(val kind: String, val text: String, val bg: String?)

data class ChatItem(
    val chatId: String,
    val peer: Profile?,
    val title: String,
    val last: Msg?,
    val unread: Int,
    val peerLastRead: Instant?,
    val sortKey: Instant,
    val peerLastDelivered: Instant? = null,
) {
    /** Tick state of my last message in this chat (null if the last message isn't mine). */
    fun tickFor(msg: Msg, me: String?): Tick? = when {
        msg.senderId != me -> null
        peerLastRead != null && peerLastRead >= msg.createdAt -> Tick.Read
        peerLastDelivered != null && peerLastDelivered >= msg.createdAt -> Tick.Delivered
        else -> Tick.Sent
    }

    val initials: String get() = initialsOf(title)
}

enum class Tick { Sent, Delivered, Read }

data class ThreadData(val messages: List<Msg>, val peerLastRead: Instant?)

private fun JSONArray.list(): List<JSONObject> = (0 until length()).map { getJSONObject(it) }
private fun parseInstant(s: String): Instant = OffsetDateTime.parse(s).toInstant()
private fun JSONObject.instantOrNull(key: String): Instant? = if (isNull(key)) null else parseInstant(getString(key))

// ---- Time labels ----
private val zone: ZoneId get() = ZoneId.systemDefault()
fun Instant.clock(): String = atZone(zone).format(DateTimeFormatter.ofPattern("H:mm"))
fun Instant.dayKey(): LocalDate = atZone(zone).toLocalDate()
fun Instant.listLabel(): String {
    val d = dayKey()
    val today = LocalDate.now(zone)
    return when {
        d == today -> clock()
        d == today.minusDays(1) -> "Yesterday"
        d.isAfter(today.minusDays(7)) -> atZone(zone).format(DateTimeFormatter.ofPattern("EEEE"))
        else -> atZone(zone).format(DateTimeFormatter.ofPattern("d MMM"))
    }
}
fun Instant.dayLabel(): String {
    val d = dayKey()
    val today = LocalDate.now(zone)
    return when {
        d == today -> "Today"
        d == today.minusDays(1) -> "Yesterday"
        else -> atZone(zone).format(DateTimeFormatter.ofPattern("EEE, d MMM"))
    }
}

/** "Today at 9:41", "Yesterday at 21:05", "3 Nov 2026 at 8:12" */
fun Instant.detailLabel(): String {
    val d = dayKey()
    val today = LocalDate.now(zone)
    val day = when {
        d == today -> "Today"
        d == today.minusDays(1) -> "Yesterday"
        else -> atZone(zone).format(DateTimeFormatter.ofPattern("d MMM yyyy"))
    }
    return "$day at ${clock()}"
}

/** "Active now" if seen in the last ~minute, otherwise "Last seen today at 9:41". */
fun lastSeenLabel(seen: Instant): String {
    if (Instant.now().epochSecond - seen.epochSecond < 75) return "Active now"
    val d = seen.dayKey()
    val today = LocalDate.now(zone)
    return when {
        d == today -> "Last seen today at ${seen.clock()}"
        d == today.minusDays(1) -> "Last seen yesterday at ${seen.clock()}"
        else -> "Last seen " + seen.atZone(zone).format(DateTimeFormatter.ofPattern("d MMM"))
    }
}

private const val PROFILE_COLS = "id,username,display_name,about,avatar_path"
private const val MSG_COLS = "id,chat_id,sender_id,body,created_at,kind,attachment_path,attachment_name,attachment_mime,attachment_size,voice_duration_ms,voice_waveform,reply_to,status_quote,deleted_at,delivered_at,read_at"

/** All Supabase queries live here. */
object Repo {
    private suspend fun <T> io(block: () -> T): T = withContext(Dispatchers.IO) { block() }
    private fun me(): String = Session.userId ?: throw ApiException("Not signed in")
    private fun receiptsOn(): Boolean = Store.me?.settings?.readReceipts != false

    private fun JSONObject.toProfile() = Profile(
        getString("id"),
        getString("username"),
        optString("display_name", ""),
        optString("about", ""),
        if (isNull("avatar_path")) null else getString("avatar_path"),
    )

    private fun JSONObject.toMsg() = Msg(
        id = getString("id"),
        chatId = getString("chat_id"),
        senderId = getString("sender_id"),
        body = getString("body"),
        createdAt = parseInstant(getString("created_at")),
        kind = optString("kind", "text").ifBlank { "text" },
        attachmentPath = if (isNull("attachment_path")) null else getString("attachment_path"),
        attachmentName = if (isNull("attachment_name")) null else getString("attachment_name"),
        attachmentMime = if (isNull("attachment_mime")) null else getString("attachment_mime"),
        attachmentSize = optLong("attachment_size", 0L),
        voiceDurationMs = optInt("voice_duration_ms", 0),
        voiceWaveform = if (isNull("voice_waveform")) null else getString("voice_waveform"),
        replyTo = if (isNull("reply_to")) null else getString("reply_to"),
        statusQuote = optJSONObject("status_quote")?.let {
            StatusQuote(it.optString("kind", "text"), it.optString("text", ""), if (it.isNull("bg")) null else it.optString("bg"))
        },
        deletedAt = instantOrNull("deleted_at"),
        deliveredAt = instantOrNull("delivered_at"),
        readAt = if (receiptsOn()) instantOrNull("read_at") else null,
    )

    // ---- Me ----
    suspend fun loadMe(): Me = io {
        val me = me()
        val profile = JSONArray(Api.call("GET", "/rest/v1/profiles?id=eq.$me&select=$PROFILE_COLS"))
            .list().first().toProfile()
        val s = JSONArray(
            Api.call(
                "GET",
                "/rest/v1/user_settings?user_id=eq.$me&select=last_seen_visibility,find_me,read_receipts,disappear_after_secs",
            ),
        ).list().firstOrNull()?.let {
            UserSettings(
                it.getString("last_seen_visibility"),
                it.getString("find_me"),
                it.getBoolean("read_receipts"),
                it.getInt("disappear_after_secs"),
            )
        } ?: UserSettings()
        Me(profile, s)
    }

    /** Pass keepAvatar = true to leave the photo untouched; otherwise avatarPath (null removes it). */
    suspend fun updateProfile(displayName: String, username: String, about: String, avatarPath: String?, keepAvatar: Boolean) = io {
        val body = JSONObject().put("display_name", displayName).put("username", username).put("about", about)
        if (!keepAvatar) body.put("avatar_path", avatarPath ?: JSONObject.NULL)
        Api.call("PATCH", "/rest/v1/profiles?id=eq.${me()}", body)
        Unit
    }

    suspend fun updateSettings(s: UserSettings) = io {
        Api.call(
            "PATCH", "/rest/v1/user_settings?user_id=eq.${me()}",
            JSONObject().put("last_seen_visibility", s.lastSeen).put("find_me", s.findMe)
                .put("read_receipts", s.readReceipts).put("disappear_after_secs", s.disappearSecs),
        )
        Unit
    }

    suspend fun usernameAvailable(username: String): Boolean = io {
        Api.anonRpc("username_available", JSONObject().put("_u", username)).trim() == "true"
    }

    /** True when this email already has an account (works before sign-in). */
    suspend fun emailRegistered(email: String): Boolean = io {
        Api.anonRpc("email_registered", JSONObject().put("_email", email.trim())).trim() == "true"
    }

    /** Uploads a square JPEG and returns its storage path. */
    suspend fun uploadAvatar(bytes: ByteArray): String = io {
        val path = "${me()}/${System.currentTimeMillis()}.jpg"
        Api.uploadAvatar(path, bytes)
        Avatars.put(path, bytes)
        path
    }

    // ---- People ----
    suspend fun profilesByIds(ids: Collection<String>): List<Profile> = io {
        if (ids.isEmpty()) {
            emptyList()
        } else {
            JSONArray(Api.call("GET", "/rest/v1/profiles?id=in.(${ids.joinToString(",")})&select=$PROFILE_COLS"))
                .list().map { it.toProfile() }
        }
    }

    suspend fun loadContacts(): List<Profile> {
        val ids = io {
            JSONArray(Api.call("GET", "/rest/v1/contacts?user_id=eq.${me()}&select=contact_id"))
                .list().map { it.getString("contact_id") }
        }
        return profilesByIds(ids).sortedBy { it.name.lowercase() }
    }

    suspend fun loadBlockedIds(): Set<String> = io {
        JSONArray(Api.call("GET", "/rest/v1/blocks?blocker_id=eq.${me()}&select=blocked_id"))
            .list().map { it.getString("blocked_id") }.toSet()
    }

    suspend fun loadCloseFriendIds(): Set<String> = io {
        JSONArray(Api.call("GET", "/rest/v1/close_friends?user_id=eq.${me()}&select=friend_id"))
            .list().map { it.getString("friend_id") }.toSet()
    }

    suspend fun block(id: String) = io {
        Api.call("POST", "/rest/v1/blocks", JSONObject().put("blocker_id", me()).put("blocked_id", id))
        Unit
    }

    /** Sends a report to the moderators. Give the message id to report a message, or the person's id to report a person. */
    suspend fun submitReport(reportedUser: String?, messageId: String?, chatId: String?, reason: String, details: String) = io {
        Api.rpc(
            "submit_report",
            JSONObject()
                .put("_reported_user", reportedUser ?: JSONObject.NULL)
                .put("_message_id", messageId ?: JSONObject.NULL)
                .put("_chat_id", chatId ?: JSONObject.NULL)
                .put("_reason", reason)
                .put("_details", details.ifBlank { null } ?: JSONObject.NULL),
        )
        Unit
    }

    suspend fun unblock(id: String) = io {
        Api.call("DELETE", "/rest/v1/blocks?blocker_id=eq.${me()}&blocked_id=eq.$id")
        Unit
    }

    suspend fun addCloseFriend(id: String) = io {
        Api.call("POST", "/rest/v1/close_friends", JSONObject().put("user_id", me()).put("friend_id", id))
        Unit
    }

    suspend fun removeCloseFriend(id: String) = io {
        Api.call("DELETE", "/rest/v1/close_friends?user_id=eq.${me()}&friend_id=eq.$id")
        Unit
    }

    // ---- Presence ----
    suspend fun touchPresence() = io {
        Api.rpc("touch_presence")
        Unit
    }

    /** Only returns people who allow you to see their status AND whom you allow to see yours. */
    suspend fun statuses(ids: List<String>): Map<String, Instant> = io {
        if (ids.isEmpty()) {
            emptyMap()
        } else {
            val arr = JSONArray()
            ids.forEach { arr.put(it) }
            JSONArray(Api.rpc("get_statuses", JSONObject().put("_ids", arr)))
                .list().associate { it.getString("user_id") to parseInstant(it.getString("last_seen_at")) }
        }
    }

    // ---- Chats ----
    suspend fun loadChats(): List<ChatItem> = io {
        val me = me()
        val mine = JSONArray(
            Api.call("GET", "/rest/v1/chat_members?user_id=eq.$me&select=chat_id,joined_at,chats(is_group,name)"),
        ).list()
        if (mine.isEmpty()) return@io emptyList<ChatItem>()

        val ids = mine.joinToString(",") { it.getString("chat_id") }
        val reads: Map<String, Instant> = JSONArray(
            Api.call("GET", "/rest/v1/chat_reads?user_id=eq.$me&select=chat_id,last_read_at"),
        ).list().associate { it.getString("chat_id") to parseInstant(it.getString("last_read_at")) }
        val others = JSONArray(
            Api.call("GET", "/rest/v1/chat_members?chat_id=in.($ids)&user_id=neq.$me&select=chat_id,user_id,receipt_at"),
        ).list()
        val peerIds = others.map { it.getString("user_id") }.distinct()
        val profiles: Map<String, Profile> = if (peerIds.isEmpty()) {
            emptyMap()
        } else {
            JSONArray(Api.call("GET", "/rest/v1/profiles?id=in.(${peerIds.joinToString(",")})&select=$PROFILE_COLS"))
                .list().map { it.toProfile() }.associateBy { it.id }
        }
        val byChat = JSONArray(
            Api.call(
                "GET",
                "/rest/v1/messages?chat_id=in.($ids)&order=created_at.desc&limit=400&select=$MSG_COLS",
            ),
        ).list().map { it.toMsg() }.groupBy { it.chatId }
        val showReceipts = receiptsOn()
        val delivered = loadDelivered(ids)
        Attachments.saveIncoming(byChat.values.flatten())

        mine.map { m ->
            val chatId = m.getString("chat_id")
            val chat = m.optJSONObject("chats")
            val peerRow = others.firstOrNull { it.getString("chat_id") == chatId }
            val peer = peerRow?.let { profiles[it.getString("user_id")] }
            val lastRead = reads[chatId] ?: parseInstant(m.getString("joined_at"))
            val msgs = byChat[chatId].orEmpty()
            val groupName = if (chat != null && !chat.isNull("name")) chat.getString("name") else null
            ChatItem(
                chatId = chatId,
                peer = peer,
                title = peer?.name ?: groupName ?: "Chat",
                last = msgs.firstOrNull(),
                unread = msgs.count { it.senderId != me && it.createdAt > lastRead },
                peerLastRead = if (showReceipts) peerRow?.instantOrNull("receipt_at") else null,
                sortKey = msgs.firstOrNull()?.createdAt ?: parseInstant(m.getString("joined_at")),
                peerLastDelivered = delivered[chatId],
            )
        }.sortedByDescending { it.sortKey }
    }

    // ---- Delivery ticks ----
    // Needs the `delivered_at` column and `mark_chat_delivered` function (see supabase/delivery_ticks.sql).
    // Until that migration is run both calls fail quietly, and chats just show "sent" then "read".
    private var deliveryTracking = true
    private val deliveredMarked = HashMap<String, Instant>()

    private fun loadDelivered(ids: String): Map<String, Instant> {
        if (!deliveryTracking) return emptyMap()
        return try {
            JSONArray(
                Api.call("GET", "/rest/v1/chat_members?chat_id=in.($ids)&user_id=neq.${me()}&select=chat_id,delivered_at"),
            ).list().mapNotNull { r -> r.instantOrNull("delivered_at")?.let { r.getString("chat_id") to it } }.toMap()
        } catch (e: Exception) {
            deliveryTracking = false
            emptyMap()
        }
    }

    /** Tells the senders that their newest messages reached this phone. */
    suspend fun markDelivered(chats: List<ChatItem>) = io {
        if (!deliveryTracking) return@io
        val me = me()
        for (c in chats) {
            val last = c.last ?: continue
            if (last.senderId == me) continue
            val done = deliveredMarked[c.chatId]
            if (done != null && done >= last.createdAt) continue
            try {
                Api.rpc("mark_chat_delivered", JSONObject().put("_chat_id", c.chatId))
                deliveredMarked[c.chatId] = last.createdAt
            } catch (e: Exception) {
                deliveryTracking = false
                return@io
            }
        }
    }

    suspend fun loadThread(chatId: String): ThreadData = io {
        val me = me()
        val msgs = JSONArray(
            Api.call(
                "GET",
                "/rest/v1/messages?chat_id=eq.$chatId&order=created_at.desc&limit=300&select=$MSG_COLS",
            ),
        ).list().map { it.toMsg() }.reversed()
        val peer = JSONArray(
            Api.call("GET", "/rest/v1/chat_members?chat_id=eq.$chatId&user_id=neq.$me&select=receipt_at"),
        ).list().firstOrNull()
        ThreadData(msgs, if (receiptsOn()) peer?.instantOrNull("receipt_at") else null)
    }

    /** A text message. replyTo = the message it answers; statusQuote = the status it answers (from the status viewer). */
    suspend fun send(chatId: String, body: String, replyTo: String? = null, statusQuote: StatusQuote? = null): Msg = io {
        val row = JSONObject().put("chat_id", chatId).put("sender_id", me()).put("body", body)
        if (replyTo != null) row.put("reply_to", replyTo)
        if (statusQuote != null) {
            row.put(
                "status_quote",
                JSONObject().put("kind", statusQuote.kind).put("text", statusQuote.text).put("bg", statusQuote.bg ?: JSONObject.NULL),
            )
        }
        val res = Api.call("POST", "/rest/v1/messages", row, mapOf("Prefer" to "return=representation"))
        JSONArray(res).getJSONObject(0).toMsg()
    }

    /** Delete for me: the message stays for the other person. The server stops returning it to me. */
    suspend fun hideMessage(id: String) = io {
        Api.call(
            "POST", "/rest/v1/message_hides?on_conflict=user_id,message_id",
            JSONObject().put("message_id", id),
            mapOf("Prefer" to "resolution=ignore-duplicates,return=minimal"),
        )
        Unit
    }

    /**
     * Delete for everyone (my own messages only). The database wipes the message and keeps a "deleted" marker for
     * both people; the file, if there was one, is then removed from Cloudflare R2 too.
     */
    suspend fun deleteForEveryone(id: String) = io {
        val old = Api.rpc("delete_message_for_everyone", JSONObject().put("_message_id", id)).trim().removeSurrounding("\"")
        if (old.isNotEmpty() && old != "null") {
            try { Api.deleteObject(Attachments.BUCKET, old) } catch (_: Exception) { }
        }
        Unit
    }

    /** Uploads the file to the private attachments bucket, then adds the message that points to it. */
    suspend fun sendAttachment(chatId: String, a: PreparedAttachment, replyTo: String? = null): Msg = io {
        val ext = a.name.substringAfterLast('.', "").lowercase().filter { it.isLetterOrDigit() }.take(8)
        val path = "$chatId/${java.util.UUID.randomUUID()}" + if (ext.isNotEmpty()) ".$ext" else ""
        val type = try { a.mime.toMediaType() } catch (e: Exception) { "application/octet-stream".toMediaType() }
        Api.uploadObject(Attachments.BUCKET, path, a.file.asRequestBody(type))
        try {
            val res = Api.call(
                "POST", "/rest/v1/messages",
                JSONObject().put("chat_id", chatId).put("sender_id", me()).put("body", "")
                    .put("kind", if (a.isImage) "image" else "file")
                    .put("attachment_path", path).put("attachment_name", a.name)
                    .put("attachment_mime", a.mime).put("attachment_size", a.size)
                    .apply { if (replyTo != null) put("reply_to", replyTo) },
                mapOf("Prefer" to "return=representation"),
            )
            val msg = JSONArray(res).getJSONObject(0).toMsg()
            Attachments.storeSent(msg.id, path, a.file, a.name, a.isImage)
            msg
        } catch (e: Exception) {
            try { Api.deleteObject(Attachments.BUCKET, path) } catch (_: Exception) { }
            throw e
        }
    }

    /** Uploads a recorded voice note to the attachments bucket, then adds the message that points to it. */
    suspend fun sendVoice(chatId: String, v: RecordedVoice, replyTo: String? = null): Msg = io {
        val path = "$chatId/${java.util.UUID.randomUUID()}.m4a"
        Api.uploadObject(Attachments.BUCKET, path, v.file.asRequestBody("audio/mp4".toMediaType()))
        try {
            val res = Api.call(
                "POST", "/rest/v1/messages",
                JSONObject().put("chat_id", chatId).put("sender_id", me()).put("body", "")
                    .put("kind", "voice")
                    .put("attachment_path", path).put("attachment_name", "voice.m4a")
                    .put("attachment_mime", "audio/mp4").put("attachment_size", v.file.length())
                    .put("voice_duration_ms", v.durationMs).put("voice_waveform", v.waveform)
                    .apply { if (replyTo != null) put("reply_to", replyTo) },
                mapOf("Prefer" to "return=representation"),
            )
            val msg = JSONArray(res).getJSONObject(0).toMsg()
            Attachments.storeSentVoice(path, v.file)
            msg
        } catch (e: Exception) {
            try { Api.deleteObject(Attachments.BUCKET, path) } catch (_: Exception) { }
            throw e
        }
    }

    suspend fun markRead(chatId: String) = io {
        Api.rpc("mark_chat_read", JSONObject().put("_chat_id", chatId))
        Unit
    }

    suspend fun createInvite(): String = io {
        val res = Api.call(
            "POST", "/rest/v1/invites",
            JSONObject().put("created_by", me()),
            mapOf("Prefer" to "return=representation"),
        )
        JSONArray(res).getJSONObject(0).getString("code")
    }

    /** Returns the id of the chat opened with the person who made the invite. */
    suspend fun redeemInvite(code: String): String = io {
        Api.call("POST", "/rest/v1/rpc/redeem_invite", JSONObject().put("_code", code.trim().lowercase()))
            .trim().trim('"')
    }
}

/** In-memory state the screens read from. Starts from the on-disk cache so nothing waits on the network. */
object Store {
    var chats by mutableStateOf<List<ChatItem>>(emptyList())
        private set
    var loaded by mutableStateOf(false)
        private set
    var me by mutableStateOf<Me?>(null)
        private set
    var blockedIds by mutableStateOf<Set<String>>(emptySet())
        private set
    var closeFriendIds by mutableStateOf<Set<String>>(emptySet())
        private set
    var callTarget by mutableStateOf<Pair<String, String>?>(null)

    fun init() {
        me = Cache.loadMe()
        chats = Cache.loadChats()
        loaded = Cache.chatsLoadedBefore()
        blockedIds = Cache.loadIds("blocked")
        closeFriendIds = Cache.loadIds("close")
        CallLog.init()
    }

    suspend fun refreshChats() {
        try {
            val fresh = Repo.loadChats()
            chats = fresh
            loaded = true
            Cache.saveChats(fresh)
            Repo.markDelivered(fresh)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            // keep showing what we have
        }
    }

    suspend fun refreshMe() {
        try {
            applyMe(Repo.loadMe())
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
        }
    }

    suspend fun refreshSocial() {
        try {
            blockedIds = Repo.loadBlockedIds()
            closeFriendIds = Repo.loadCloseFriendIds()
            Cache.saveIds("blocked", blockedIds)
            Cache.saveIds("close", closeFriendIds)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
        }
    }

    fun applyMe(value: Me) {
        me = value
        Cache.saveMe(value)
    }

    /** Optimistic: the UI changes instantly, then it syncs (and reverts if it fails). */
    suspend fun updateSettings(next: UserSettings) {
        val before = me ?: return
        applyMe(before.copy(settings = next))
        try {
            Repo.updateSettings(next)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            applyMe(before)
        }
    }

    suspend fun toggleCloseFriend(id: String) {
        val wasOn = id in closeFriendIds
        closeFriendIds = if (wasOn) closeFriendIds - id else closeFriendIds + id
        Cache.saveIds("close", closeFriendIds)
        try {
            if (wasOn) Repo.removeCloseFriend(id) else Repo.addCloseFriend(id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            closeFriendIds = if (wasOn) closeFriendIds + id else closeFriendIds - id
            Cache.saveIds("close", closeFriendIds)
        }
    }

    suspend fun setBlocked(id: String, blocked: Boolean) {
        blockedIds = if (blocked) blockedIds + id else blockedIds - id
        Cache.saveIds("blocked", blockedIds)
        try {
            if (blocked) Repo.block(id) else Repo.unblock(id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            blockedIds = if (blocked) blockedIds - id else blockedIds + id
            Cache.saveIds("blocked", blockedIds)
        }
    }

    fun clear() {
        chats = emptyList()
        loaded = false
        me = null
        blockedIds = emptySet()
        closeFriendIds = emptySet()
        CallLog.clear()
        Cache.clear()
        Avatars.clear()
        Attachments.clear()
    }
}
