package app.instants.data

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.asRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant
import java.time.LocalDate
import java.time.OffsetDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter

fun initialsOf(name: String): String =
    name.split(" ").filter { it.isNotBlank() }.take(2).joinToString("") { it.first().uppercase() }.ifBlank { "?" }

data class Profile(
    val id: String,
    val username: String,
    val displayName: String,
    val about: String = "",
    val avatarPath: String? = null,
) {
    val name: String get() = displayName.ifBlank { username }
    val initials: String get() = initialsOf(name)
}

/** Private settings. lastSeen: contacts | close_friends | nobody. findMe: invite | nobody. */
data class UserSettings(
    val lastSeen: String = "close_friends",
    val findMe: String = "invite",
    val readReceipts: Boolean = true,
    val disappearSecs: Int = 0,
)

data class Me(val profile: Profile, val settings: UserSettings)

data class Msg(
    val id: String,
    val chatId: String,
    val senderId: String,
    val body: String,
    val createdAt: Instant,
    val kind: String = "text", // text | image | file
    val attachmentPath: String? = null,
    val attachmentName: String? = null,
    val attachmentMime: String? = null,
    val attachmentSize: Long = 0L,
) {
    /** One line for the chat list. */
    val preview: String
        get() = when (kind) {
            "image" -> "\uD83D\uDCF7 " + body.ifBlank { "Photo" }
            "file" -> "\uD83D\uDCC4 " + (attachmentName ?: "Document")
            else -> body
        }
}

data class ChatItem(
    val chatId: String,
    val peer: Profile?,
    val title: String,
    val last: Msg?,
    val unread: Int,
    val peerLastRead: Instant?,
    val sortKey: Instant,
) {
    val initials: String get() = initialsOf(title)
}

data class ThreadData(val messages: List<Msg>, val peerLastRead: Instant?)

private fun JSONArray.list(): List<JSONObject> = (0 until length()).map { getJSONObject(it) }
private fun parseInstant(s: String): Instant = OffsetDateTime.parse(s).toInstant()
private fun JSONObject.instantOrNull(key: String): Instant? = if (isNull(key)) null else parseInstant(getString(key))

// ---- Time labels ----
private val zone: ZoneId get() = ZoneId.systemDefault()
fun Instant.clock(): String = atZone(zone).format(DateTimeFormatter.ofPattern("H:mm"))
fun Instant.dayKey(): LocalDate = atZone(zone).toLocalDate()
fun Instant.listLabel(): String {
    val d = dayKey()
    val today = LocalDate.now(zone)
    return when {
        d == today -> clock()
        d == today.minusDays(1) -> "Yesterday"
        d.isAfter(today.minusDays(7)) -> atZone(zone).format(DateTimeFormatter.ofPattern("EEEE"))
        else -> atZone(zone).format(DateTimeFormatter.ofPattern("d MMM"))
    }
}
fun Instant.dayLabel(): String {
    val d = dayKey()
    val today = LocalDate.now(zone)
    return when {
        d == today -> "Today"
        d == today.minusDays(1) -> "Yesterday"
        else -> atZone(zone).format(DateTimeFormatter.ofPattern("EEE, d MMM"))
    }
}

/** "Active now" if seen in the last ~minute, otherwise "Last seen today at 9:41". */
fun lastSeenLabel(seen: Instant): String {
    if (Instant.now().epochSecond - seen.epochSecond < 75) return "Active now"
    val d = seen.dayKey()
    val today = LocalDate.now(zone)
    return when {
        d == today -> "Last seen today at ${seen.clock()}"
        d == today.minusDays(1) -> "Last seen yesterday at ${seen.clock()}"
        else -> "Last seen " + seen.atZone(zone).format(DateTimeFormatter.ofPattern("d MMM"))
    }
}

private const val PROFILE_COLS = "id,username,display_name,about,avatar_path"
private const val MSG_COLS = "id,chat_id,sender_id,body,created_at,kind,attachment_path,attachment_name,attachment_mime,attachment_size"

/** All Supabase queries live here. */
object Repo {
    private suspend fun <T> io(block: () -> T): T = withContext(Dispatchers.IO) { block() }
    private fun me(): String = Session.userId ?: throw ApiException("Not signed in")
    private fun receiptsOn(): Boolean = Store.me?.settings?.readReceipts != false

    private fun JSONObject.toProfile() = Profile(
        getString("id"),
        getString("username"),
        optString("display_name", ""),
        optString("about", ""),
        if (isNull("avatar_path")) null else getString("avatar_path"),
    )

    private fun JSONObject.toMsg() = Msg(
        id = getString("id"),
        chatId = getString("chat_id"),
        senderId = getString("sender_id"),
        body = getString("body"),
        createdAt = parseInstant(getString("created_at")),
        kind = optString("kind", "text").ifBlank { "text" },
        attachmentPath = if (isNull("attachment_path")) null else getString("attachment_path"),
        attachmentName = if (isNull("attachment_name")) null else getString("attachment_name"),
        attachmentMime = if (isNull("attachment_mime")) null else getString("attachment_mime"),
        attachmentSize = optLong("attachment_size", 0L),
    )

    // ---- Me ----
    suspend fun loadMe(): Me = io {
        val me = me()
        val profile = JSONArray(Api.call("GET", "/rest/v1/profiles?id=eq.$me&select=$PROFILE_COLS"))
            .list().first().toProfile()
        val s = JSONArray(
            Api.call(
                "GET",
                "/rest/v1/user_settings?user_id=eq.$me&select=last_seen_visibility,find_me,read_receipts,disappear_after_secs",
            ),
        ).list().firstOrNull()?.let {
            UserSettings(
                it.getString("last_seen_visibility"),
                it.getString("find_me"),
                it.getBoolean("read_receipts"),
                it.getInt("disappear_after_secs"),
            )
        } ?: UserSettings()
        Me(profile, s)
    }

    /** Pass keepAvatar = true to leave the photo untouched; otherwise avatarPath (null removes it). */
    suspend fun updateProfile(displayName: String, username: String, about: String, avatarPath: String?, keepAvatar: Boolean) = io {
        val body = JSONObject().put("display_name", displayName).put("username", username).put("about", about)
        if (!keepAvatar) body.put("avatar_path", avatarPath ?: JSONObject.NULL)
        Api.call("PATCH", "/rest/v1/profiles?id=eq.${me()}", body)
        Unit
    }

    suspend fun updateSettings(s: UserSettings) = io {
        Api.call(
            "PATCH", "/rest/v1/user_settings?user_id=eq.${me()}",
            JSONObject().put("last_seen_visibility", s.lastSeen).put("find_me", s.findMe)
                .put("read_receipts", s.readReceipts).put("disappear_after_secs", s.disappearSecs),
        )
        Unit
    }

    suspend fun usernameAvailable(username: String): Boolean = io {
        Api.anonRpc("username_available", JSONObject().put("_u", username)).trim() == "true"
    }

    /** Uploads a square JPEG and returns its storage path. */
    suspend fun uploadAvatar(bytes: ByteArray): String = io {
        val path = "${me()}/${System.currentTimeMillis()}.jpg"
        Api.uploadAvatar(path, bytes)
        Avatars.put(path, bytes)
        path
    }

    // ---- People ----
    suspend fun profilesByIds(ids: Collection<String>): List<Profile> = io {
        if (ids.isEmpty()) {
            emptyList()
        } else {
            JSONArray(Api.call("GET", "/rest/v1/profiles?id=in.(${ids.joinToString(",")})&select=$PROFILE_COLS"))
                .list().map { it.toProfile() }
        }
    }

    suspend fun loadContacts(): List<Profile> {
        val ids = io {
            JSONArray(Api.call("GET", "/rest/v1/contacts?user_id=eq.${me()}&select=contact_id"))
                .list().map { it.getString("contact_id") }
        }
        return profilesByIds(ids).sortedBy { it.name.lowercase() }
    }

    suspend fun loadBlockedIds(): Set<String> = io {
        JSONArray(Api.call("GET", "/rest/v1/blocks?blocker_id=eq.${me()}&select=blocked_id"))
            .list().map { it.getString("blocked_id") }.toSet()
    }

    suspend fun loadCloseFriendIds(): Set<String> = io {
        JSONArray(Api.call("GET", "/rest/v1/close_friends?user_id=eq.${me()}&select=friend_id"))
            .list().map { it.getString("friend_id") }.toSet()
    }

    suspend fun block(id: String) = io {
        Api.call("POST", "/rest/v1/blocks", JSONObject().put("blocker_id", me()).put("blocked_id", id))
        Unit
    }

    suspend fun unblock(id: String) = io {
        Api.call("DELETE", "/rest/v1/blocks?blocker_id=eq.${me()}&blocked_id=eq.$id")
        Unit
    }

    suspend fun addCloseFriend(id: String) = io {
        Api.call("POST", "/rest/v1/close_friends", JSONObject().put("user_id", me()).put("friend_id", id))
        Unit
    }

    suspend fun removeCloseFriend(id: String) = io {
        Api.call("DELETE", "/rest/v1/close_friends?user_id=eq.${me()}&friend_id=eq.$id")
        Unit
    }

    // ---- Presence ----
    suspend fun touchPresence() = io {
        Api.rpc("touch_presence")
        Unit
    }

    /** Only returns people who allow you to see their status AND whom you allow to see yours. */
    suspend fun statuses(ids: List<String>): Map<String, Instant> = io {
        if (ids.isEmpty()) {
            emptyMap()
        } else {
            val arr = JSONArray()
            ids.forEach { arr.put(it) }
            JSONArray(Api.rpc("get_statuses", JSONObject().put("_ids", arr)))
                .list().associate { it.getString("user_id") to parseInstant(it.getString("last_seen_at")) }
        }
    }

    // ---- Chats ----
    suspend fun loadChats(): List<ChatItem> = io {
        val me = me()
        val mine = JSONArray(
            Api.call("GET", "/rest/v1/chat_members?user_id=eq.$me&select=chat_id,joined_at,chats(is_group,name)"),
        ).list()
        if (mine.isEmpty()) return@io emptyList<ChatItem>()

        val ids = mine.joinToString(",") { it.getString("chat_id") }
        val reads: Map<String, Instant> = JSONArray(
            Api.call("GET", "/rest/v1/chat_reads?user_id=eq.$me&select=chat_id,last_read_at"),
        ).list().associate { it.getString("chat_id") to parseInstant(it.getString("last_read_at")) }
        val others = JSONArray(
            Api.call("GET", "/rest/v1/chat_members?chat_id=in.($ids)&user_id=neq.$me&select=chat_id,user_id,receipt_at"),
        ).list()
        val peerIds = others.map { it.getString("user_id") }.distinct()
        val profiles: Map<String, Profile> = if (peerIds.isEmpty()) {
            emptyMap()
        } else {
            JSONArray(Api.call("GET", "/rest/v1/profiles?id=in.(${peerIds.joinToString(",")})&select=$PROFILE_COLS"))
                .list().map { it.toProfile() }.associateBy { it.id }
        }
        val byChat = JSONArray(
            Api.call(
                "GET",
                "/rest/v1/messages?chat_id=in.($ids)&order=created_at.desc&limit=400&select=$MSG_COLS",
            ),
        ).list().map { it.toMsg() }.groupBy { it.chatId }
        val showReceipts = receiptsOn()

        mine.map { m ->
            val chatId = m.getString("chat_id")
            val chat = m.optJSONObject("chats")
            val peerRow = others.firstOrNull { it.getString("chat_id") == chatId }
            val peer = peerRow?.let { profiles[it.getString("user_id")] }
            val lastRead = reads[chatId] ?: parseInstant(m.getString("joined_at"))
            val msgs = byChat[chatId].orEmpty()
            val groupName = if (chat != null && !chat.isNull("name")) chat.getString("name") else null
            ChatItem(
                chatId = chatId,
                peer = peer,
                title = peer?.name ?: groupName ?: "Chat",
                last = msgs.firstOrNull(),
                unread = msgs.count { it.senderId != me && it.createdAt > lastRead },
                peerLastRead = if (showReceipts) peerRow?.instantOrNull("receipt_at") else null,
                sortKey = msgs.firstOrNull()?.createdAt ?: parseInstant(m.getString("joined_at")),
            )
        }.sortedByDescending { it.sortKey }
    }

    suspend fun loadThread(chatId: String): ThreadData = io {
        val me = me()
        val msgs = JSONArray(
            Api.call(
                "GET",
                "/rest/v1/messages?chat_id=eq.$chatId&order=created_at.desc&limit=300&select=$MSG_COLS",
            ),
        ).list().map { it.toMsg() }.reversed()
        val peer = JSONArray(
            Api.call("GET", "/rest/v1/chat_members?chat_id=eq.$chatId&user_id=neq.$me&select=receipt_at"),
        ).list().firstOrNull()
        ThreadData(msgs, if (receiptsOn()) peer?.instantOrNull("receipt_at") else null)
    }

    suspend fun send(chatId: String, body: String): Msg = io {
        val res = Api.call(
            "POST", "/rest/v1/messages",
            JSONObject().put("chat_id", chatId).put("sender_id", me()).put("body", body),
            mapOf("Prefer" to "return=representation"),
        )
        JSONArray(res).getJSONObject(0).toMsg()
    }

    /** Uploads the file to the private attachments bucket, then adds the message that points to it. */
    suspend fun sendAttachment(chatId: String, a: PreparedAttachment): Msg = io {
        val ext = a.name.substringAfterLast('.', "").lowercase().filter { it.isLetterOrDigit() }.take(8)
        val path = "$chatId/${java.util.UUID.randomUUID()}" + if (ext.isNotEmpty()) ".$ext" else ""
        val type = try { a.mime.toMediaType() } catch (e: Exception) { "application/octet-stream".toMediaType() }
        Api.uploadObject(Attachments.BUCKET, path, a.file.asRequestBody(type))
        try {
            val res = Api.call(
                "POST", "/rest/v1/messages",
                JSONObject().put("chat_id", chatId).put("sender_id", me()).put("body", "")
                    .put("kind", if (a.isImage) "image" else "file")
                    .put("attachment_path", path).put("attachment_name", a.name)
                    .put("attachment_mime", a.mime).put("attachment_size", a.size),
                mapOf("Prefer" to "return=representation"),
            )
            val msg = JSONArray(res).getJSONObject(0).toMsg()
            Attachments.storeSent(msg.id, path, a.file, a.name, a.isImage)
            msg
        } catch (e: Exception) {
            try { Api.deleteObject(Attachments.BUCKET, path) } catch (_: Exception) { }
            throw e
        }
    }

    suspend fun markRead(chatId: String) = io {
        Api.rpc("mark_chat_read", JSONObject().put("_chat_id", chatId))
        Unit
    }

    suspend fun createInvite(): String = io {
        val res = Api.call(
            "POST", "/rest/v1/invites",
            JSONObject().put("created_by", me()),
            mapOf("Prefer" to "return=representation"),
        )
        JSONArray(res).getJSONObject(0).getString("code")
    }

    /** Returns the id of the chat opened with the person who made the invite. */
    suspend fun redeemInvite(code: String): String = io {
        Api.call("POST", "/rest/v1/rpc/redeem_invite", JSONObject().put("_code", code.trim().lowercase()))
            .trim().trim('"')
    }
}

/** In-memory state the screens read from. Starts from the on-disk cache so nothing waits on the network. */
object Store {
    var chats by mutableStateOf<List<ChatItem>>(emptyList())
        private set
    var loaded by mutableStateOf(false)
        private set
    var me by mutableStateOf<Me?>(null)
        private set
    var blockedIds by mutableStateOf<Set<String>>(emptySet())
        private set
    var closeFriendIds by mutableStateOf<Set<String>>(emptySet())
        private set
    var callTarget by mutableStateOf<Pair<String, String>?>(null)

    fun init() {
        me = Cache.loadMe()
        chats = Cache.loadChats()
        loaded = Cache.chatsLoadedBefore()
        blockedIds = Cache.loadIds("blocked")
        closeFriendIds = Cache.loadIds("close")
    }

    suspend fun refreshChats() {
        try {
            val fresh = Repo.loadChats()
            chats = fresh
            loaded = true
            Cache.saveChats(fresh)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            // keep showing what we have
        }
    }

    suspend fun refreshMe() {
        try {
            applyMe(Repo.loadMe())
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
        }
    }

    suspend fun refreshSocial() {
        try {
            blockedIds = Repo.loadBlockedIds()
            closeFriendIds = Repo.loadCloseFriendIds()
            Cache.saveIds("blocked", blockedIds)
            Cache.saveIds("close", closeFriendIds)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
        }
    }

    fun applyMe(value: Me) {
        me = value
        Cache.saveMe(value)
    }

    /** Optimistic: the UI changes instantly, then it syncs (and reverts if it fails). */
    suspend fun updateSettings(next: UserSettings) {
        val before = me ?: return
        applyMe(before.copy(settings = next))
        try {
            Repo.updateSettings(next)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            applyMe(before)
        }
    }

    suspend fun toggleCloseFriend(id: String) {
        val wasOn = id in closeFriendIds
        closeFriendIds = if (wasOn) closeFriendIds - id else closeFriendIds + id
        Cache.saveIds("close", closeFriendIds)
        try {
            if (wasOn) Repo.removeCloseFriend(id) else Repo.addCloseFriend(id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            closeFriendIds = if (wasOn) closeFriendIds + id else closeFriendIds - id
            Cache.saveIds("close", closeFriendIds)
        }
    }

    suspend fun setBlocked(id: String, blocked: Boolean) {
        blockedIds = if (blocked) blockedIds + id else blockedIds - id
        Cache.saveIds("blocked", blockedIds)
        try {
            if (blocked) Repo.block(id) else Repo.unblock(id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            blockedIds = if (blocked) blockedIds - id else blockedIds + id
            Cache.saveIds("blocked", blockedIds)
        }
    }

    fun clear() {
        chats = emptyList()
        loaded = false
        me = null
        blockedIds = emptySet()
        closeFriendIds = emptySet()
        Cache.clear()
        Avatars.clear()
        Attachments.clear()
    }
}
