package app.instants.data

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant
import java.time.LocalDate
import java.time.OffsetDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter

fun initialsOf(name: String): String =
    name.split(" ").filter { it.isNotBlank() }.take(2).joinToString("") { it.first().uppercase() }.ifBlank { "?" }

data class Profile(val id: String, val username: String, val displayName: String) {
    val name: String get() = displayName.ifBlank { username }
    val initials: String get() = initialsOf(name)
}

data class Msg(val id: String, val chatId: String, val senderId: String, val body: String, val createdAt: Instant)

data class ChatItem(
    val chatId: String,
    val peer: Profile?,
    val title: String,
    val last: Msg?,
    val unread: Int,
    val peerLastRead: Instant?,
    val sortKey: Instant,
) {
    val initials: String get() = initialsOf(title)
}

data class ThreadData(val messages: List<Msg>, val peerLastRead: Instant?)

private fun JSONArray.list(): List<JSONObject> = (0 until length()).map { getJSONObject(it) }
private fun parseInstant(s: String): Instant = OffsetDateTime.parse(s).toInstant()

// ---- Time labels ----
private val zone: ZoneId get() = ZoneId.systemDefault()
fun Instant.clock(): String = atZone(zone).format(DateTimeFormatter.ofPattern("H:mm"))
fun Instant.dayKey(): LocalDate = atZone(zone).toLocalDate()
fun Instant.listLabel(): String {
    val d = dayKey()
    val today = LocalDate.now(zone)
    return when {
        d == today -> clock()
        d == today.minusDays(1) -> "Yesterday"
        d.isAfter(today.minusDays(7)) -> atZone(zone).format(DateTimeFormatter.ofPattern("EEEE"))
        else -> atZone(zone).format(DateTimeFormatter.ofPattern("d MMM"))
    }
}
fun Instant.dayLabel(): String {
    val d = dayKey()
    val today = LocalDate.now(zone)
    return when {
        d == today -> "Today"
        d == today.minusDays(1) -> "Yesterday"
        else -> atZone(zone).format(DateTimeFormatter.ofPattern("EEE, d MMM"))
    }
}

/** All Supabase queries live here. */
object Repo {
    private suspend fun <T> io(block: () -> T): T = withContext(Dispatchers.IO) { block() }
    private fun me(): String = Session.userId ?: throw ApiException("Not signed in")

    private fun JSONObject.toProfile() = Profile(getString("id"), getString("username"), optString("display_name", ""))
    private fun JSONObject.toMsg() = Msg(
        getString("id"), getString("chat_id"), getString("sender_id"), getString("body"), parseInstant(getString("created_at")),
    )

    suspend fun myProfile(): Profile? = io {
        JSONArray(Api.call("GET", "/rest/v1/profiles?id=eq.${me()}&select=id,username,display_name"))
            .list().firstOrNull()?.toProfile()
    }

    suspend fun loadChats(): List<ChatItem> = io {
        val me = me()
        val mine = JSONArray(
            Api.call("GET", "/rest/v1/chat_members?user_id=eq.$me&select=chat_id,last_read_at,joined_at,chats(is_group,name)"),
        ).list()
        if (mine.isEmpty()) return@io emptyList<ChatItem>()

        val ids = mine.joinToString(",") { it.getString("chat_id") }
        val others = JSONArray(
            Api.call("GET", "/rest/v1/chat_members?chat_id=in.($ids)&user_id=neq.$me&select=chat_id,user_id,last_read_at"),
        ).list()
        val peerIds = others.map { it.getString("user_id") }.distinct()
        val profiles: Map<String, Profile> = if (peerIds.isEmpty()) {
            emptyMap()
        } else {
            JSONArray(
                Api.call("GET", "/rest/v1/profiles?id=in.(${peerIds.joinToString(",")})&select=id,username,display_name"),
            ).list().map { it.toProfile() }.associateBy { it.id }
        }
        val byChat = JSONArray(
            Api.call(
                "GET",
                "/rest/v1/messages?chat_id=in.($ids)&order=created_at.desc&limit=400&select=id,chat_id,sender_id,body,created_at",
            ),
        ).list().map { it.toMsg() }.groupBy { it.chatId }

        mine.map { m ->
            val chatId = m.getString("chat_id")
            val chat = m.optJSONObject("chats")
            val peerRow = others.firstOrNull { it.getString("chat_id") == chatId }
            val peer = peerRow?.let { profiles[it.getString("user_id")] }
            val lastRead = parseInstant(m.getString("last_read_at"))
            val msgs = byChat[chatId].orEmpty()
            val groupName = if (chat != null && !chat.isNull("name")) chat.getString("name") else null
            ChatItem(
                chatId = chatId,
                peer = peer,
                title = peer?.name ?: groupName ?: "Chat",
                last = msgs.firstOrNull(),
                unread = msgs.count { it.senderId != me && it.createdAt > lastRead },
                peerLastRead = peerRow?.let { parseInstant(it.getString("last_read_at")) },
                sortKey = msgs.firstOrNull()?.createdAt ?: parseInstant(m.getString("joined_at")),
            )
        }.sortedByDescending { it.sortKey }
    }

    suspend fun loadThread(chatId: String): ThreadData = io {
        val me = me()
        val msgs = JSONArray(
            Api.call(
                "GET",
                "/rest/v1/messages?chat_id=eq.$chatId&order=created_at.desc&limit=300&select=id,chat_id,sender_id,body,created_at",
            ),
        ).list().map { it.toMsg() }.reversed()
        val peer = JSONArray(
            Api.call("GET", "/rest/v1/chat_members?chat_id=eq.$chatId&user_id=neq.$me&select=last_read_at"),
        ).list().firstOrNull()
        ThreadData(msgs, peer?.let { parseInstant(it.getString("last_read_at")) })
    }

    suspend fun send(chatId: String, body: String): Msg = io {
        val res = Api.call(
            "POST", "/rest/v1/messages",
            JSONObject().put("chat_id", chatId).put("sender_id", me()).put("body", body),
            mapOf("Prefer" to "return=representation"),
        )
        JSONArray(res).getJSONObject(0).toMsg()
    }

    suspend fun markRead(chatId: String) = io {
        Api.call(
            "PATCH", "/rest/v1/chat_members?chat_id=eq.$chatId&user_id=eq.${me()}",
            JSONObject().put("last_read_at", Instant.now().toString()),
        )
        Unit
    }

    suspend fun createInvite(): String = io {
        val res = Api.call(
            "POST", "/rest/v1/invites",
            JSONObject().put("created_by", me()),
            mapOf("Prefer" to "return=representation"),
        )
        JSONArray(res).getJSONObject(0).getString("code")
    }

    /** Returns the id of the chat opened with the person who made the invite. */
    suspend fun redeemInvite(code: String): String = io {
        Api.call("POST", "/rest/v1/rpc/redeem_invite", JSONObject().put("_code", code.trim().lowercase()))
            .trim().trim('"')
    }
}

/** In-memory cache the screens read from. */
object Store {
    var chats by mutableStateOf<List<ChatItem>>(emptyList())
        private set
    var loaded by mutableStateOf(false)
        private set
    var me by mutableStateOf<Profile?>(null)
        private set
    var callTarget by mutableStateOf<Pair<String, String>?>(null)

    suspend fun refreshChats() {
        try {
            chats = Repo.loadChats()
            loaded = true
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            // keep showing what we have
        }
    }

    suspend fun refreshMe() {
        try {
            me = Repo.myProfile()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
        }
    }

    fun clear() {
        chats = emptyList()
        loaded = false
        me = null
    }
}
