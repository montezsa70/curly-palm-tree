package app.instants.push

import app.instants.data.Session
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

/** Receives pushes from Firebase, also while the app is closed. */
class PushService : FirebaseMessagingService() {
    override fun onNewToken(token: String) {
        Push.onNewToken(token)
    }

    override fun onMessageReceived(message: RemoteMessage) {
        val data = message.data
        val chatId = data["chat_id"] ?: return
        if (Session.userId == null) return
        // Already looking at this conversation: the new message shows up there on its own.
        if (Push.activeChatId == chatId) return
        Push.show(applicationContext, chatId, data["title"] ?: "Instants", data["body"] ?: "New message")
    }
}
