package app.instants.push

import app.instants.data.Attachments
import app.instants.data.Session
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeoutOrNull

/** Receives pushes from Firebase, also while the app is closed. */
class PushService : FirebaseMessagingService() {
    override fun onNewToken(token: String) {
        Push.onNewToken(token)
    }

    override fun onMessageReceived(message: RemoteMessage) {
        val data = message.data
        when (data["type"]) {
            "incoming_call" -> {
                app.instants.call.CallManager.onIncomingPush(data)
                return
            }
            "call_cancelled" -> {
                app.instants.call.CallManager.onCancelPush(data["call_id"])
                return
            }
        }
        val chatId = data["chat_id"] ?: return
        if (Session.userId == null) return
        // Already looking at this conversation: the new message shows up there on its own.
        if (Push.activeChatId == chatId) return
        Push.show(applicationContext, chatId, data["title"] ?: "Instants", data["body"] ?: "New message")
        // Save any new photo, voice note or document right now, even though the app is closed.
        // This runs on Firebase's background thread; whatever doesn't finish in time is picked up when the app opens.
        try {
            runBlocking { withTimeoutOrNull(15_000) { Attachments.saveIncomingIn(chatId) } }
        } catch (_: Exception) {
        }
    }
}
