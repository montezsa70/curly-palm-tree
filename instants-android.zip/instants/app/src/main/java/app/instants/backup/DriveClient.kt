package app.instants.backup

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.common.api.Scope
import kotlinx.coroutines.suspendCancellableCoroutine
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

class DriveException(message: String, val code: Int = 0) : Exception(message)

/** The person must tap through Google's consent screen again. */
class NeedsSignInException : Exception("Reconnect Google Drive to continue")

data class RemoteBackup(val id: String, val name: String, val size: Long, val modified: String)

/**
 * Talks to the person's own Google Drive. Backups go in the app's hidden "appDataFolder": only Instants can
 * see them, they don't clutter My Drive, and they count towards the person's own Drive storage, not ours.
 * The only permission asked for is drive.appdata.
 */
object DriveClient {
    private const val SCOPE = "https://www.googleapis.com/auth/drive.appdata"
    private const val FILES = "https://www.googleapis.com/drive/v3/files"

    private val http = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(300, TimeUnit.SECONDS)
        .writeTimeout(300, TimeUnit.SECONDS)
        .build()

    sealed class Auth {
        class Token(val token: String) : Auth()
        class NeedsConsent(val intent: PendingIntent) : Auth()
    }

    /** Gets an access token. Silent once the person has agreed; otherwise returns the consent screen to show. */
    suspend fun authorize(context: Context): Auth = suspendCancellableCoroutine { cont ->
        val request = AuthorizationRequest.builder().setRequestedScopes(listOf(Scope(SCOPE))).build()
        Identity.getAuthorizationClient(context).authorize(request)
            .addOnSuccessListener { result ->
                val pending = result.pendingIntent
                val token = result.accessToken
                when {
                    result.hasResolution() && pending != null -> cont.resume(Auth.NeedsConsent(pending))
                    token != null -> cont.resume(Auth.Token(token))
                    else -> cont.resumeWithException(DriveException("Google didn't return access"))
                }
            }
            .addOnFailureListener { e -> cont.resumeWithException(e) }
    }

    /** After the consent screen closes. */
    fun tokenFrom(context: Context, data: Intent?): String =
        Identity.getAuthorizationClient(context).getAuthorizationResultFromIntent(data).accessToken
            ?: throw DriveException("Google didn't return access")

    private fun fail(code: Int, body: String?): Nothing {
        val message = try {
            JSONObject(body.orEmpty()).getJSONObject("error").getString("message")
        } catch (e: Exception) {
            "Google Drive error ($code)"
        }
        if (code == 401) throw NeedsSignInException()
        throw DriveException(message, code)
    }

    /** Newest first. */
    fun list(token: String): List<RemoteBackup> {
        val url = FILES.toHttpUrl().newBuilder()
            .addQueryParameter("spaces", "appDataFolder")
            .addQueryParameter("fields", "files(id,name,size,modifiedTime)")
            .addQueryParameter("orderBy", "modifiedTime desc")
            .addQueryParameter("pageSize", "20")
            .addQueryParameter("q", "name contains 'instants-backup'")
            .build()
        http.newCall(Request.Builder().url(url).header("Authorization", "Bearer $token").build()).execute().use { r ->
            val body = r.body?.string()
            if (!r.isSuccessful) fail(r.code, body)
            val files: JSONArray = JSONObject(body.orEmpty()).optJSONArray("files") ?: JSONArray()
            return (0 until files.length()).map {
                val f = files.getJSONObject(it)
                RemoteBackup(f.getString("id"), f.getString("name"), f.optString("size", "0").toLongOrNull() ?: 0L, f.optString("modifiedTime"))
            }
        }
    }

    /** Uploads in one streamed request, to the hidden app folder. */
    fun upload(token: String, name: String, file: File) {
        val meta = JSONObject().put("name", name).put("parents", JSONArray().put("appDataFolder"))
        val start = Request.Builder()
            .url("https://www.googleapis.com/upload/drive/v3/files?uploadType=resumable")
            .header("Authorization", "Bearer $token")
            .header("X-Upload-Content-Type", "application/octet-stream")
            .header("X-Upload-Content-Length", file.length().toString())
            .post(meta.toString().toRequestBody("application/json; charset=UTF-8".toMediaType()))
            .build()
        val session = http.newCall(start).execute().use { r ->
            if (!r.isSuccessful) fail(r.code, r.body?.string())
            r.header("Location") ?: throw DriveException("Google Drive didn't accept the upload")
        }
        val put = Request.Builder()
            .url(session)
            .put(file.asRequestBody("application/octet-stream".toMediaType()))
            .build()
        http.newCall(put).execute().use { r ->
            if (!r.isSuccessful) fail(r.code, r.body?.string())
        }
    }

    fun download(token: String, id: String, dest: File) {
        val url = "$FILES/$id".toHttpUrl().newBuilder().addQueryParameter("alt", "media").build()
        http.newCall(Request.Builder().url(url).header("Authorization", "Bearer $token").build()).execute().use { r ->
            if (!r.isSuccessful) fail(r.code, r.body?.string())
            val body = r.body ?: throw DriveException("Empty download")
            body.byteStream().use { input -> dest.outputStream().use { input.copyTo(it) } }
        }
    }

    fun delete(token: String, id: String) {
        http.newCall(Request.Builder().url("$FILES/$id").header("Authorization", "Bearer $token").delete().build()).execute().use { }
    }
}
