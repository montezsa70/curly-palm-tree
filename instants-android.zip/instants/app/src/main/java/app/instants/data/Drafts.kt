package app.instants.data

import androidx.compose.runtime.mutableStateMapOf

/**
 * Unsent text, one per chat. Kept in memory for the chat list (so "Draft: ..." updates live) and in the
 * encrypted local database ([LocalDb]) so it survives closing the app.
 */
object Drafts {
    private val map = mutableStateMapOf<String, String>()

    fun load() {
        map.clear()
        map.putAll(LocalDb.loadDrafts())
    }

    /** Reading this inside a composable makes it update when the draft changes. */
    fun get(chatId: String): String = map[chatId].orEmpty()

    fun set(chatId: String, text: String) {
        if (text.isBlank()) map.remove(chatId) else map[chatId] = text
        LocalDb.saveDraft(chatId, text)
    }

    /** Forgets everything in memory (the database rows are wiped by LocalDb.clear). */
    fun reset() = map.clear()
}
