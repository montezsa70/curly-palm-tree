package app.instants.ui.screens

import android.os.SystemClock
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Call
import androidx.compose.material.icons.rounded.CallEnd
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.MicOff
import androidx.compose.material.icons.rounded.ScreenShare
import androidx.compose.material.icons.rounded.StopScreenShare
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.util.lerp
import androidx.compose.ui.viewinterop.AndroidView
import app.instants.call.CallManager
import app.instants.call.CallPhase
import app.instants.ui.components.ProfileAvatar
import app.instants.ui.components.GlassIconButton
import app.instants.ui.theme.Palette
import dev.chrisbanes.haze.HazeState
import dev.chrisbanes.haze.haze
import kotlinx.coroutines.delay
import org.webrtc.RendererCommon
import org.webrtc.SurfaceViewRenderer
import org.webrtc.VideoTrack

private val AcceptGreen = Color(0xFF3FAE6A)

/** The call itself: ringing out, connecting, talking, and (when either side shares) the shared screen. */
@Composable
fun InCallScreen(onShareRequest: () -> Unit) {
    val haze = remember { HazeState() }
    val top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val phase = CallManager.phase
    val connected = phase == CallPhase.Connected
    val video = CallManager.remoteVideo
    val showVideo = CallManager.peerSharing && video != null && phase != CallPhase.Ended

    var now by remember { mutableLongStateOf(SystemClock.elapsedRealtime()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(500)
            now = SystemClock.elapsedRealtime()
        }
    }
    val seconds = if (CallManager.connectedAtMs > 0) ((now - CallManager.connectedAtMs) / 1000).toInt().coerceAtLeast(0) else 0
    val timer = if (seconds >= 3600) "%d:%02d:%02d".format(seconds / 3600, seconds / 60 % 60, seconds % 60)
    else "%02d:%02d".format(seconds / 60, seconds % 60)
    val status = when {
        phase == CallPhase.Ended -> CallManager.endText
        phase == CallPhase.Outgoing -> "Calling…"
        phase == CallPhase.Connecting -> "Connecting…"
        CallManager.reconnecting -> "Reconnecting…"
        else -> timer
    }
    val labelColor = if (showVideo) Color.White else Palette.TextSecondary

    Box(Modifier.fillMaxSize().background(if (showVideo) Color.Black else Palette.Background)) {
        if (showVideo) {
            RemoteVideo(video, Modifier.fillMaxSize())
            Column(
                Modifier.fillMaxWidth().padding(top = top + 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Column(
                    Modifier.background(Color.Black.copy(alpha = 0.45f), RoundedCornerShape(18.dp))
                        .padding(horizontal = 18.dp, vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(CallManager.peerName, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                    Text(status, color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
                }
            }
            Box(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(220.dp)
                    .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.65f)))),
            )
        } else {
            Column(
                Modifier.fillMaxSize().haze(haze).padding(top = top + 64.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                RippleAvatar(CallManager.peerInitials, CallManager.peerAvatarPath)
                Spacer(Modifier.height(4.dp))
                Text(
                    CallManager.peerName,
                    color = Palette.TextPrimary,
                    fontSize = 30.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = (-0.4).sp,
                )
                Spacer(Modifier.height(8.dp))
                Text(status, color = Palette.TextSecondary, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                if (CallManager.sharingScreen) {
                    Spacer(Modifier.height(18.dp))
                    Text(
                        "You're sharing your screen · Stop",
                        color = Palette.TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier
                            .background(Palette.tint(0.08f), RoundedCornerShape(16.dp))
                            .clickable { CallManager.stopScreenShare() }
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                    )
                }
            }
        }

        Row(
            Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 48.dp),
            horizontalArrangement = Arrangement.spacedBy(20.dp),
        ) {
            CallControl("Mute", if (CallManager.muted) Icons.Rounded.MicOff else Icons.Rounded.Mic, CallManager.muted, haze, labelColor = labelColor) {
                CallManager.toggleMute()
            }
            CallControl("Speaker", Icons.Rounded.VolumeUp, CallManager.speakerOn, haze, labelColor = labelColor) {
                CallManager.toggleSpeaker()
            }
            CallControl(
                if (CallManager.sharingScreen) "Stop" else "Share",
                if (CallManager.sharingScreen) Icons.Rounded.StopScreenShare else Icons.Rounded.ScreenShare,
                CallManager.sharingScreen, haze,
                enabled = connected, labelColor = labelColor,
            ) {
                if (CallManager.sharingScreen) CallManager.stopScreenShare() else onShareRequest()
            }
            CallControl("End", Icons.Rounded.CallEnd, false, haze, danger = true, labelColor = labelColor) { CallManager.hangUp() }
        }
    }
}

/** What the phone shows while someone is calling you. */
@Composable
fun IncomingCallScreen(onAccept: () -> Unit, onDecline: () -> Unit) {
    val haze = remember { HazeState() }
    val top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    Box(Modifier.fillMaxSize().background(Palette.Background)) {
        Column(
            Modifier.fillMaxSize().haze(haze).padding(top = top + 64.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            RippleAvatar(CallManager.peerInitials, CallManager.peerAvatarPath)
            Spacer(Modifier.height(4.dp))
            Text(
                CallManager.peerName,
                color = Palette.TextPrimary,
                fontSize = 30.sp,
                fontWeight = FontWeight.SemiBold,
                letterSpacing = (-0.4).sp,
            )
            Spacer(Modifier.height(8.dp))
            Text("Instants voice call", color = Palette.TextSecondary, fontSize = 15.sp, fontWeight = FontWeight.Medium)
        }
        Row(
            Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 64.dp),
            horizontalArrangement = Arrangement.spacedBy(72.dp),
        ) {
            CallControl("Decline", Icons.Rounded.CallEnd, false, haze, danger = true, onClick = onDecline)
            CallControl("Accept", Icons.Rounded.Call, false, haze, accept = true, onClick = onAccept)
        }
    }
}

@Composable
private fun RippleAvatar(initials: String, avatarPath: String?) {
    val inf = rememberInfiniteTransition(label = "call")
    val p by inf.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(3200, easing = LinearEasing)),
        label = "ripple",
    )
    val breathe by inf.animateFloat(
        initialValue = 1f, targetValue = 1.035f,
        animationSpec = infiniteRepeatable(tween(2400, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "breathe",
    )
    Box(Modifier.size(340.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(340.dp)) {
            listOf(p, (p + 0.5f) % 1f).forEach { t ->
                drawCircle(
                    color = Palette.AccentSoft.copy(alpha = (1f - t) * 0.12f),
                    radius = lerp(108.dp.toPx(), 168.dp.toPx(), t),
                    style = Stroke(width = 1.dp.toPx()),
                )
            }
            drawCircle(color = Palette.tint(0.08f), radius = 108.dp.toPx(), style = Stroke(width = 1.dp.toPx()))
        }
        ProfileAvatar(
            initials, 176.dp, avatarPath,
            Modifier.graphicsLayer { scaleX = breathe; scaleY = breathe },
        )
    }
}

@Composable
private fun RemoteVideo(track: VideoTrack?, modifier: Modifier) {
    val context = LocalContext.current
    val renderer = remember {
        SurfaceViewRenderer(context).apply {
            init(CallManager.eglBase.eglBaseContext, null)
            setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FIT)
            setEnableHardwareScaler(true)
        }
    }
    DisposableEffect(track) {
        track?.addSink(renderer)
        onDispose {
            try {
                track?.removeSink(renderer)
            } catch (_: Exception) {
            }
        }
    }
    DisposableEffect(Unit) { onDispose { renderer.release() } }
    AndroidView(factory = { renderer }, modifier = modifier)
}

@Composable
private fun CallControl(
    label: String,
    icon: ImageVector,
    active: Boolean,
    haze: HazeState,
    danger: Boolean = false,
    accept: Boolean = false,
    enabled: Boolean = true,
    labelColor: Color = Palette.TextSecondary,
    onClick: () -> Unit,
) {
    val fill by animateColorAsState(
        if (active) Palette.TextPrimary.copy(alpha = 0.95f) else Color.Transparent, tween(250), label = "ctlFill",
    )
    val tint by animateColorAsState(
        if (active) Palette.Background else if (danger || accept) Color.White else Palette.TextPrimary,
        tween(250), label = "ctlTint",
    )
    Column(
        Modifier.alpha(if (enabled) 1f else 0.4f),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        GlassIconButton(
            icon = icon,
            description = label,
            haze = haze,
            size = 64.dp,
            tint = tint,
            fill = fill,
            solid = if (danger) Palette.EndCall else if (accept) AcceptGreen else null,
            onClick = { if (enabled) onClick() },
        )
        Text(label, color = labelColor, fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}
