package app.instants.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CallEnd
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.MicOff
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.util.lerp
import app.instants.data.MockStore
import app.instants.ui.components.Avatar
import app.instants.ui.components.GlassIconButton
import app.instants.ui.theme.Palette
import dev.chrisbanes.haze.HazeState
import dev.chrisbanes.haze.haze
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun InCallScreen(contactId: String, onEnd: () -> Unit) {
    val contact = MockStore.contact(contactId)
    val haze = remember { HazeState() }
    val scope = rememberCoroutineScope()
    var connected by remember { mutableStateOf(false) }
    var ended by remember { mutableStateOf(false) }
    var elapsed by remember { mutableStateOf(0) }
    var muted by remember { mutableStateOf(false) }
    var speaker by remember { mutableStateOf(false) }
    val top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()

    // Mock call: ring for a moment, then connect and start the timer.
    LaunchedEffect(Unit) {
        delay(1800)
        connected = true
        while (!ended) {
            delay(1000)
            elapsed++
        }
    }

    fun endCall() {
        if (ended) return
        ended = true
        scope.launch {
            delay(700)
            onEnd()
        }
    }

    val status = when {
        ended -> "Call ended"
        !connected -> "Calling…"
        else -> "%02d:%02d".format(elapsed / 60, elapsed % 60)
    }

    val inf = rememberInfiniteTransition(label = "call")
    val p by inf.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(3200, easing = LinearEasing)),
        label = "ripple",
    )
    val breathe by inf.animateFloat(
        initialValue = 1f, targetValue = 1.035f,
        animationSpec = infiniteRepeatable(tween(2400, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "breathe",
    )

    Box(Modifier.fillMaxSize().background(Palette.Charcoal)) {
        Column(
            Modifier.fillMaxSize().haze(haze).padding(top = top + 64.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Box(Modifier.size(340.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.size(340.dp)) {
                    listOf(p, (p + 0.5f) % 1f).forEach { t ->
                        drawCircle(
                            color = Palette.AccentSoft.copy(alpha = (1f - t) * 0.12f),
                            radius = lerp(108.dp.toPx(), 168.dp.toPx(), t),
                            style = Stroke(width = 1.dp.toPx()),
                        )
                    }
                    drawCircle(
                        color = Color.White.copy(alpha = 0.08f),
                        radius = 108.dp.toPx(),
                        style = Stroke(width = 1.dp.toPx()),
                    )
                }
                Avatar(
                    contact.initials, 176.dp,
                    Modifier.graphicsLayer { scaleX = breathe; scaleY = breathe },
                    fontSize = 56.sp,
                )
            }
            Spacer(Modifier.height(4.dp))
            Text(
                contact.name,
                color = Palette.TextPrimary,
                fontSize = 30.sp,
                fontWeight = FontWeight.SemiBold,
                letterSpacing = (-0.4).sp,
            )
            Spacer(Modifier.height(8.dp))
            AnimatedContent(
                targetState = status,
                transitionSpec = {
                    if (initialState == "Calling…" || targetState == "Call ended") {
                        fadeIn(tween(300)) togetherWith fadeOut(tween(200))
                    } else {
                        fadeIn(tween(1)) togetherWith fadeOut(tween(1))
                    }
                },
                label = "status",
            ) { s ->
                Text(s, color = Palette.TextSecondary, fontSize = 15.sp, fontWeight = FontWeight.Medium)
            }
        }

        Row(
            Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(bottom = 56.dp),
            horizontalArrangement = Arrangement.spacedBy(32.dp),
        ) {
            CallControl("Mute", if (muted) Icons.Rounded.MicOff else Icons.Rounded.Mic, muted, haze) { muted = !muted }
            CallControl("Speaker", Icons.Rounded.VolumeUp, speaker, haze) { speaker = !speaker }
            CallControl("End", Icons.Rounded.CallEnd, false, haze, danger = true) { endCall() }
        }
    }
}

@Composable
private fun CallControl(
    label: String,
    icon: ImageVector,
    active: Boolean,
    haze: HazeState,
    danger: Boolean = false,
    onClick: () -> Unit,
) {
    val fill by animateColorAsState(
        if (active) Color(0xF2F4F5F7) else Color.Transparent, tween(250), label = "ctlFill",
    )
    val tint by animateColorAsState(
        if (active) Palette.Charcoal else if (danger) Color.White else Palette.TextPrimary,
        tween(250), label = "ctlTint",
    )
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
        GlassIconButton(
            icon = icon,
            description = label,
            haze = haze,
            size = 68.dp,
            tint = tint,
            fill = fill,
            solid = if (danger) Palette.EndCall else null,
            onClick = onClick,
        )
        Text(label, color = Palette.TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}
