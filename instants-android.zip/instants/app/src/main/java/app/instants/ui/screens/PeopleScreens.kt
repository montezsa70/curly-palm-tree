package app.instants.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.instants.data.Profile
import app.instants.data.Repo
import app.instants.data.Store
import app.instants.ui.components.GlassSwitch
import app.instants.ui.components.ProfileAvatar
import app.instants.ui.components.ScreenHeader
import app.instants.ui.components.SoftButton
import app.instants.ui.components.pressable
import app.instants.ui.theme.Palette
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

@Composable
fun CloseFriendsScreen(onBack: () -> Unit) {
    var contacts by remember { mutableStateOf<List<Profile>?>(null) }
    val scope = rememberCoroutineScope()
    LaunchedEffect(Unit) {
        contacts = try {
            Repo.loadContacts()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            emptyList()
        }
    }

    Column(Modifier.fillMaxSize().background(Palette.Background)) {
        ScreenHeader("Close friends", onBack)
        Text(
            "Only the people you pick can see your last seen and when you’re active (if you choose “Close friends” in Privacy). They are never told they’re on the list.",
            color = Palette.TextSecondary,
            fontSize = 14.sp,
            lineHeight = 20.sp,
            modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp),
        )
        val list = contacts
        when {
            list == null -> Unit
            list.isEmpty() -> EmptyNote("No contacts yet. Invite someone first.")
            else -> LazyColumn(contentPadding = PaddingValues(bottom = 24.dp), modifier = Modifier.navigationBarsPadding()) {
                items(list, key = { it.id }) { p ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .pressable(0.985f, haptic = true) { scope.launch { Store.toggleCloseFriend(p.id) } }
                            .padding(horizontal = 20.dp, vertical = 10.dp)
                            .heightIn(min = 48.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        ProfileAvatar(p.initials, 46.dp, p.avatarPath)
                        PersonText(p, Modifier.weight(1f))
                        GlassSwitch(p.id in Store.closeFriendIds)
                    }
                }
            }
        }
    }
}

@Composable
fun BlockedScreen(onBack: () -> Unit) {
    var profiles by remember { mutableStateOf<List<Profile>?>(null) }
    val scope = rememberCoroutineScope()
    val ids = Store.blockedIds
    LaunchedEffect(ids) {
        profiles = try {
            Repo.profilesByIds(ids).sortedBy { it.name.lowercase() }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            emptyList()
        }
    }

    Column(Modifier.fillMaxSize().background(Palette.Background)) {
        ScreenHeader("Blocked contacts", onBack)
        Text(
            "Blocked people can’t message you, and they can’t see your last seen, photo or About.",
            color = Palette.TextSecondary,
            fontSize = 14.sp,
            lineHeight = 20.sp,
            modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp),
        )
        val list = profiles
        when {
            ids.isEmpty() -> EmptyNote("You haven’t blocked anyone.")
            list == null -> Unit
            else -> LazyColumn(contentPadding = PaddingValues(bottom = 24.dp), modifier = Modifier.navigationBarsPadding()) {
                items(list, key = { it.id }) { p ->
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp).heightIn(min = 48.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        ProfileAvatar(p.initials, 46.dp, p.avatarPath)
                        PersonText(p, Modifier.weight(1f))
                        SoftButton("Unblock", Modifier.width(96.dp)) { scope.launch { Store.setBlocked(p.id, false) } }
                    }
                }
            }
        }
    }
}

@Composable
private fun PersonText(p: Profile, modifier: Modifier) {
    Column(modifier, verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(p.name, color = Palette.TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text("@${p.username}", color = Palette.TextSecondary, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun EmptyNote(text: String) {
    Box(Modifier.fillMaxWidth().padding(top = 64.dp, start = 32.dp, end = 32.dp), contentAlignment = Alignment.Center) {
        Text(text, color = Palette.TextSecondary, fontSize = 15.sp, textAlign = TextAlign.Center)
    }
}
