plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("com.google.gms.google-services")
}

android {
    namespace = "app.instants"
    compileSdk = 35

    defaultConfig {
        applicationId = "app.instants"
        minSdk = 35            // Android 15+
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
    }

    // The same signing key on every build (CI included). Google Drive access is tied to the app's signature,
    // and a changing key would also stop new builds from installing over the old one.
    signingConfigs {
        create("shared") {
            storeFile = file("instants-shared.p12")
            storeType = "pkcs12"
            storePassword = "instants"
            keyAlias = "instants"
            keyPassword = "instants"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("shared")
        }
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.10.01"))
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.navigation:navigation-compose:2.8.3")
    // Real backdrop blur for the frosted glass surfaces
    implementation("dev.chrisbanes.haze:haze:1.0.2")
    // Networking (Supabase REST + auth)
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    // App lock (fingerprint / face / screen lock)
    implementation("androidx.biometric:biometric:1.1.0")
    implementation("androidx.fragment:fragment-ktx:1.8.5")
    // Push notifications (Firebase Cloud Messaging only; accounts and data stay on Supabase)
    implementation(platform("com.google.firebase:firebase-bom:33.5.1"))
    implementation("com.google.firebase:firebase-messaging")
    // Chat backup: scheduled backups, and Google Drive permission (the Drive calls themselves use OkHttp)
    implementation("androidx.work:work-runtime-ktx:2.9.1")
    implementation("com.google.android.gms:play-services-auth:21.2.0")
}
