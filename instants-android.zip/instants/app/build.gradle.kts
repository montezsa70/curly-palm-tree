import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("com.google.gms.google-services")
}

// Release signing details come from keystore.properties (not committed; see keystore.properties.example and RELEASE.md)
// or from environment variables, never from this file.
val uploadProps = Properties().apply {
    val file = rootProject.file("keystore.properties")
    if (file.exists()) file.inputStream().use { load(it) }
}
fun uploadSetting(key: String, env: String): String? =
    uploadProps.getProperty(key)?.takeIf { it.isNotBlank() } ?: System.getenv(env)?.takeIf { it.isNotBlank() }

android {
    namespace = "app.instants"
    compileSdk = 36

    defaultConfig {
        applicationId = "app.instants"
        minSdk = 35            // Android 15+
        targetSdk = 36         // Google Play requires API 36 for new apps and updates (from 31 Aug 2026)
        versionCode = 1
        versionName = "0.1.0"
    }

    signingConfigs {
        // DEVELOPMENT ONLY, and public: this key is in the repository on purpose, so every debug build (CI included)
        // has the same signature and installs over the previous one. It must never sign a release.
        create("shared") {
            storeFile = file("instants-shared.p12")
            storeType = "pkcs12"
            storePassword = "instants"
            keyAlias = "instants"
            keyPassword = "instants"
        }
        // The private upload key for Google Play. Its file and passwords live outside the repository.
        create("upload") {
            val path = uploadSetting("UPLOAD_STORE_FILE", "INSTANTS_UPLOAD_STORE_FILE")
            if (path != null) {
                storeFile = file(path)
                storePassword = uploadSetting("UPLOAD_STORE_PASSWORD", "INSTANTS_UPLOAD_STORE_PASSWORD")
                keyAlias = uploadSetting("UPLOAD_KEY_ALIAS", "INSTANTS_UPLOAD_KEY_ALIAS")
                keyPassword = uploadSetting("UPLOAD_KEY_PASSWORD", "INSTANTS_UPLOAD_KEY_PASSWORD")
            }
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("shared")
        }
        release {
            // Signed with the upload key when it is configured; otherwise the build is left unsigned (never the dev key).
            val upload = signingConfigs.getByName("upload")
            signingConfig = if (upload.storeFile != null) upload else null
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.10.01"))
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.lifecycle:lifecycle-process:2.8.7")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.navigation:navigation-compose:2.8.3")
    // Real backdrop blur for the frosted glass surfaces
    implementation("dev.chrisbanes.haze:haze:1.0.2")
    // Networking (Supabase REST + auth)
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    // App lock (fingerprint / face / screen lock)
    implementation("androidx.biometric:biometric:1.1.0")
    implementation("androidx.fragment:fragment-ktx:1.8.5")
    // Push notifications (Firebase Cloud Messaging only; accounts and data stay on Supabase)
    implementation(platform("com.google.firebase:firebase-bom:33.5.1"))
    implementation("com.google.firebase:firebase-messaging")
    // Chat backup: scheduled backups, and Google Drive permission (the Drive calls themselves use OkHttp)
    implementation("androidx.work:work-runtime-ktx:2.9.1")
    // WebRTC for voice calls and screen sharing (Google's libwebrtc, packaged by Stream; classes live in org.webrtc)
    implementation("io.getstream:stream-webrtc-android:1.3.10")
    // On-phone video compression before a status video is uploaded
    implementation("androidx.media3:media3-transformer:1.5.1")
    implementation("androidx.media3:media3-effect:1.5.1")
    implementation("androidx.media3:media3-common:1.5.1")
    implementation("com.google.android.gms:play-services-auth:21.2.0")
}
