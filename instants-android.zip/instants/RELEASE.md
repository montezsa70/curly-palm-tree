# Releasing Instants to Google Play

The app targets API 36 (Android 16), which Google Play requires for new apps and updates. Release builds are shrunk with R8
and are signed with a **private upload key that never goes in the repository**.

## 1. Make the upload key (once)

Run this on your own computer, and keep the file **outside** the project folder:

```
keytool -genkeypair -v -keystore ~/keys/instants-upload.jks -alias instants-upload \
  -keyalg RSA -keysize 2048 -validity 10000
```

Back the file and both passwords up somewhere safe (a password manager). With Play App Signing, a lost upload key can be
reset through Play support, but it is slow, so back it up anyway.

## 2. Tell the build where it is

Copy `keystore.properties.example` to `keystore.properties` (it is ignored by git) and fill it in. For CI you can use the
environment variables `INSTANTS_UPLOAD_STORE_FILE`, `INSTANTS_UPLOAD_STORE_PASSWORD`, `INSTANTS_UPLOAD_KEY_ALIAS` and
`INSTANTS_UPLOAD_KEY_PASSWORD` instead. Without these the release build is left **unsigned**: it never falls back to the
development key.

## 3. Build and upload the bundle

```
gradle bundleRelease
```

The file is `app/build/outputs/bundle/release/app-release.aab`. Create the app in the Play Console, turn on **Play App Signing**
when it asks, and upload the bundle. Raise `versionCode` in `app/build.gradle.kts` for every upload. The R8 mapping file travels
inside the bundle, so crash reports in Play Console are readable.

## 4. Google sign-in for Drive backup (this is what breaks if skipped)

Drive backup identifies the app by package name and signing certificate, and the app on a user's phone is signed by **Play's**
key, not yours. In Google Cloud Console (same project as Firebase), Credentials, create one **Android** OAuth client for each
certificate, all with package `app.instants`:

| Certificate | Where to find its SHA-1 |
| --- | --- |
| Development (debug builds) | already set up: `16:EF:10:28:AB:F3:C3:88:9B:52:19:AA:60:6A:23:A3:C1:39:D0:F5` |
| Your upload key | `keytool -list -v -keystore ~/keys/instants-upload.jks -alias instants-upload` |
| Play's app signing key | Play Console, your app, Test and release, App signing |

Keep the consent screen on **In production**. Add the same SHA-1s under Firebase, Project settings, your Android app.

## 5. Settings to change in the dashboards before launch

- Supabase, Authentication: turn **on** "Confirm email"; turn on leaked-password protection; set the minimum password length
  to 8 or more; review the rate limits and consider a CAPTCHA.
- Google Cloud Console, Credentials: restrict the Firebase API key to Android apps with package `app.instants` and the SHA-1s above.
- Cloudflare R2: check the bucket expiry rules match what the privacy policy says (`attachments/` and `statuses/`).
- Publish `docs/` (for example with GitHub Pages), set `Config.LEGAL_BASE_URL`, and fill in the contact details in the legal pages.
- Play Console: privacy policy URL, the Data safety form, and the delete-account page URL (`docs/delete-account.html`).

## 6. Smoke test the release build

R8 can remove code that is only used by reflection, so install a **release** build before uploading, for example from
`bundletool build-apks`, or `gradle assembleRelease` with the upload key configured. Then check: sign-up and sign-in, sending
and receiving text, photos, voice notes and documents, push notifications, statuses, a voice call with screen sharing,
Drive backup and restore, delete account.

## About the development key in the repository

`app/instants-shared.p12` (password `instants`) signs **debug builds only**. It is public on purpose: with it, every build from
CI has the same signature, so a new build installs over the previous one without losing the chat database, and the development
Drive OAuth client keeps working. Nothing protects data with it, and it is never used for a release. To retire it later, remove it and
the `shared` signing config; every new debug build will then need an uninstall first.
