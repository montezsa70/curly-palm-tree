# Instants

Minimal, private messaging app for Android 15+ (Kotlin, Jetpack Compose). Light theme by default (dark theme in Settings > Appearance), soft blue accents, frosted glass UI (Haze). The logo icon is used only for the app icon, splash screen and sign-up; the home screen uses the "Instants" wordmark.

**Backend:** Supabase (project "Instants chats"): email + password accounts, invite-only contacts, 1:1 chats, messages, profile photos (private storage), privacy settings, close friends, blocking, presence. New messages appear through light polling (every 2 s in a chat, 4 s in the chat list). **Statuses:** text, photo and video (max 30 s, MP4) updates that last 24 hours, shown as a row on the chat list and visible only to mutual, unblocked contacts (enforced by row level security; media lives in the private `statuses` bucket). The voice call screen is still a demo (no real calling yet). Message alerts / quiet hours are hidden until push notifications exist.

**Instant feel:** profile, settings, chat list and recent messages are cached on the phone and shown immediately, then refreshed in the background.

## Push notifications
Firebase Cloud Messaging only delivers the "new message" signal. A database trigger on `messages` calls the `send-push` Edge Function, which looks up each recipient's phone in `device_tokens` and sends the alert. The text of a message is never sent through Google; the alert says "New message", "Sent a photo" or "Sent a document". `app/google-services.json` is safe to commit. The Firebase service account key lives only in the Supabase secret `FCM_SERVICE_ACCOUNT` and must never be committed.

## One-time Supabase setting
Dashboard -> Authentication -> Sign In / Providers -> Email -> turn **off** "Confirm email" while testing, otherwise sign-ups must be confirmed through an email link before signing in.

## Build the APK with GitHub Actions
1. Push this folder's contents to the `main` branch of a GitHub repo.
2. Actions tab -> run **Build APK**.
3. Download the `instants-debug-apk` artifact and install `app-debug.apk` on an Android 15+ device.

## Structure
- `data/Api.kt` Supabase config, session, HTTP
- `data/Repo.kt` queries, models, in-memory store
- `ui/screens/` Auth, Chats, Calls, Settings, Chat, In-call, invite sheet, tab shell
- `ui/components/` glass surface, press feedback, buttons, text field
- `data/Status.kt` status models, Supabase calls, media cache, store
- `ui/screens/StatusScreens.kt` status row, full-screen viewer, composer
- `ui/AppNav.kt` navigation and page transitions
