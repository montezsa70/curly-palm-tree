# Instants

Minimal, private messaging app for Android 15+ (Kotlin, Jetpack Compose). Light theme by default (dark theme in Settings > Appearance), soft blue accents, frosted glass UI (Haze). The logo icon is used only for the app icon, splash screen and sign-up; the home screen uses the "Instants" wordmark.

**Backend:** Supabase (project "Instants chats"): email + password accounts, invite-only contacts, 1:1 chats, messages, profile photos (private storage), privacy settings, close friends, blocking, presence. New messages appear through light polling (every 2 s in a chat, 4 s in the chat list). **Statuses:** text, photo and video (max 30 s, MP4) updates that last 24 hours, shown as a row on the chat list and visible only to mutual, unblocked contacts (enforced by row level security; media lives in the private `statuses` bucket). The voice call screen is still a demo (no real calling yet). Message alerts / quiet hours are hidden until push notifications exist.

**Instant feel:** profile, settings, chat list and recent messages are cached on the phone and shown immediately, then refreshed in the background.

## Push notifications
Firebase Cloud Messaging only delivers the "new message" signal. A database trigger on `messages` calls the `send-push` Edge Function, which looks up each recipient's phone in `device_tokens` and sends the alert. The text of a message is never sent through Google; the alert says "New message", "Sent a photo" or "Sent a document". `app/google-services.json` is safe to commit. The Firebase service account key lives only in the Supabase secret `FCM_SERVICE_ACCOUNT` and must never be committed.

## One-time Supabase setting
Dashboard -> Authentication -> Sign In / Providers -> Email -> turn **off** "Confirm email" while testing, otherwise sign-ups must be confirmed through an email link before signing in.

## Build the APK with GitHub Actions
1. Push this folder's contents to the `main` branch of a GitHub repo.
2. Actions tab -> run **Build APK**.
3. Download the `instants-debug-apk` artifact and install `app-debug.apk` on an Android 15+ device.

## Structure
- `data/Api.kt` Supabase config, session, HTTP
- `data/Repo.kt` queries, models, in-memory store
- `ui/screens/` Auth, Chats, Calls, Settings, Chat, In-call, invite sheet, tab shell
- `ui/components/` glass surface, press feedback, buttons, text field
- `data/Status.kt` status models, Supabase calls, media cache, store
- `ui/screens/StatusScreens.kt` status row, full-screen viewer, composer
- `ui/AppNav.kt` navigation and page transitions

## Media storage (Cloudflare R2)

Chat photos, voice notes, documents and status media are stored temporarily in a private Cloudflare R2 bucket (`instants-media`), not Supabase storage. The app asks the `media` Edge Function for a short-lived upload/download link; the R2 keys live only in Supabase secrets. When the recipient's phone has saved a chat file, it acks and the server deletes its copy; R2 lifecycle rules remove anything left over (`attachments/` after 14 days, `statuses/` after 2 days). Texts and message records stay in Supabase. Profile photos stay in Supabase storage.

## Local database and chat backup

- **Local database** (`data/LocalDb.kt`): messages and the chat list are kept on the phone in SQLite, every row sealed with AES-256-GCM. The data key is random and stored only in wrapped form (the wrapping key lives in the Android Keystore). `Cache` keeps its old API and now reads and writes this database, so the screens didn't change.
- **Chat backup** (`backup/`): Settings > Chat backup. Backs up the local messages (and optionally photos, voice notes and documents) to a hidden app folder in the person's own Google Drive (`drive.appdata` scope only). Backups are encrypted on the phone with a key made from the person's backup password (PBKDF2-HMAC-SHA256, 210k rounds, chunked AES-256-GCM), so only the owner can open them. Schedule: off / daily / weekly / monthly (WorkManager, Wi-Fi only unless allowed). Restore: Settings > Chat backup > Restore.
- **Settings** is now a short list of groups (`ui/screens/SettingsTab.kt`); each group has its own page in `SettingsPages.kt`. Add new settings to the page they belong to.
- **Signing**: debug builds use the fixed key `app/instants-shared.p12` (alias `instants`, password `instants`). It is for development builds only; use a private release key for anything published.

### One-time Google setup for Drive backup
1. Google Cloud Console (same project as Firebase) > APIs & Services > enable **Google Drive API**.
2. Google Auth Platform / OAuth consent screen: add the scope `.../auth/drive.appdata`; set publishing status to **In production** (this scope needs no verification; in Testing mode permission expires after 7 days).
3. Credentials > Create OAuth client ID > **Android**: package `app.instants`, SHA-1 `16:EF:10:28:AB:F3:C3:88:9B:52:19:AA:60:6A:23:A3:C1:39:D0:F5`.
