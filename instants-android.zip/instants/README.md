# Instants

Minimal, private messaging app for Android 15+ (Kotlin, Jetpack Compose). Charcoal background, soft blue accents, frosted glass UI (Haze).

**Backend:** Supabase (project "Instants chats"): email + password accounts, invite-only contacts, 1:1 chats, messages. New messages appear through light polling (every 2 s in a chat, 4 s in the chat list). The voice call screen is still a demo (no real calling yet).

## One-time Supabase setting
Dashboard -> Authentication -> Sign In / Providers -> Email -> turn **off** "Confirm email" while testing, otherwise sign-ups must be confirmed through an email link before signing in.

## Build the APK with GitHub Actions
1. Push this folder's contents to the `main` branch of a GitHub repo.
2. Actions tab -> run **Build APK**.
3. Download the `instants-debug-apk` artifact and install `app-debug.apk` on an Android 15+ device.

## Structure
- `data/Api.kt` Supabase config, session, HTTP
- `data/Repo.kt` queries, models, in-memory store
- `ui/screens/` Auth, Chats, Calls, Settings, Chat, In-call, invite sheet, tab shell
- `ui/components/` glass surface, press feedback, buttons, text field
- `ui/AppNav.kt` navigation and page transitions
