# Moderation: how reports are handled

Reports arrive in `public.reports` (only the service role can read it, so use the Supabase dashboard SQL editor).
Google Play expects a documented process; this is it. Aim to look at new reports **within 24 hours**.

## Review

```sql
-- open reports, newest first, with who is involved
select r.id, r.created_at, r.reason, r.details, r.message_kind, r.message_text,
       rep.username as reporter, tgt.username as reported,
       (select count(*) from public.reports x where x.reported_user_id = r.reported_user_id) as reports_against_user
from public.reports r
join public.profiles rep on rep.id = r.reporter_id
join public.profiles tgt on tgt.id = r.reported_user_id
where r.status = 'open'
order by r.created_at desc;
```

`message_text` is a copy of the reported text (first 500 characters), kept in case the sender deletes the message.
Photos, voice notes and documents are not copied into the report: they are removed from the server after the recipient
downloads them. Judge those from the reporter's details and the pattern of reports.

## Decide

| Outcome | What to do |
| --- | --- |
| Nothing wrong | `update public.reports set status = 'dismissed', reviewed_at = now() where id = '<id>';` |
| Warn | Contact the person (email is in the dashboard under Authentication), then mark `actioned`. |
| Remove the person | Ban in the dashboard (Authentication, Users, Ban user) or: `update auth.users set banned_until = 'infinity' where id = '<user id>';` then mark `actioned`. |
| Illegal content (for example child sexual abuse material) | Ban at once, keep the report, and report it to the authorities / the relevant hotline in your country. Do not copy or forward the material itself. |

Repeat offenders: three or more `actioned` reports against one person is grounds for a permanent ban.

## Keep records

Do not delete rows from `reports` when you act on them; change `status`. Reports are deleted automatically when the
reported or reporting account is deleted.
