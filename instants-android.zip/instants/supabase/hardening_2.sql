-- Pre-launch hardening, step 3 (audit item B2): a per-user daily upload quota for the media function. Safe to run again.
-- Service-only: RLS is on and there are no policies, so only the Edge Functions (service role) can read or change it.

create table if not exists public.upload_usage (
  user_id uuid not null references auth.users (id) on delete cascade,
  day     date not null default ((now() at time zone 'utc')::date),
  uploads int  not null default 0,
  bytes   bigint not null default 0,
  primary key (user_id, day)
);
alter table public.upload_usage enable row level security;
revoke all on public.upload_usage from anon, authenticated;
comment on table public.upload_usage is 'Service-only: uploads and bytes per user per day, written by the media function.';

-- Counts one upload against today's limits. False means "over the limit" and nothing is counted.
create or replace function public.take_upload_quota(_user uuid, _bytes bigint, _max_uploads int, _max_bytes bigint)
returns boolean
language plpgsql
security definer
set search_path to ''
as $$
declare
  counted int;
begin
  if _bytes <= 0 or _bytes > _max_bytes then
    return false;
  end if;
  insert into public.upload_usage as u (user_id, day, uploads, bytes)
  values (_user, (now() at time zone 'utc')::date, 1, _bytes)
  on conflict (user_id, day) do update
    set uploads = u.uploads + 1, bytes = u.bytes + _bytes
    where u.uploads + 1 <= _max_uploads and u.bytes + _bytes <= _max_bytes;
  get diagnostics counted = row_count;
  return counted > 0;
end;
$$;
revoke all on function public.take_upload_quota(uuid, bigint, int, bigint) from public, anon, authenticated;
grant execute on function public.take_upload_quota(uuid, bigint, int, bigint) to service_role;
