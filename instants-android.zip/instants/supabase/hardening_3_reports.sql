-- Pre-launch hardening, step 4 (audit item P0-4): reporting users and messages. Safe to run again.
--
-- Reports are written only through submit_report() (which checks the reporter really is in that chat and limits how many
-- they can send) and are readable only by the service role, i.e. by you in the dashboard. See supabase/MODERATION.md.

create table if not exists public.reports (
  id               uuid primary key default gen_random_uuid(),
  reporter_id      uuid not null references auth.users (id) on delete cascade,
  reported_user_id uuid not null references auth.users (id) on delete cascade,
  chat_id          uuid,
  message_id       uuid,
  message_kind     text,
  message_text     text check (message_text is null or char_length(message_text) <= 500), -- copy, in case the message is deleted later
  reason           text not null check (reason in ('spam', 'harassment', 'inappropriate', 'other')),
  details          text check (details is null or char_length(details) <= 1000),
  status           text not null default 'open' check (status in ('open', 'reviewing', 'actioned', 'dismissed')),
  created_at       timestamptz not null default now(),
  reviewed_at      timestamptz
);
create index if not exists reports_status_idx on public.reports (status, created_at desc);
create index if not exists reports_reported_idx on public.reports (reported_user_id);
alter table public.reports enable row level security;
revoke all on public.reports from anon, authenticated;
comment on table public.reports is 'Service-only: user reports for moderation. Written by submit_report().';

create or replace function public.submit_report(
  _reported_user uuid,
  _message_id uuid,
  _chat_id uuid,
  _reason text,
  _details text
)
returns uuid
language plpgsql
security definer
set search_path to ''
as $function$
declare
  me uuid := auth.uid();
  target uuid := _reported_user;
  chat uuid := _chat_id;
  kind text;
  body text;
  clean_details text := nullif(btrim(coalesce(_details, '')), '');
  new_id uuid;
begin
  if me is null then
    raise exception 'Not signed in';
  end if;
  if _reason is null or _reason not in ('spam', 'harassment', 'inappropriate', 'other') then
    raise exception 'Choose a reason';
  end if;
  if clean_details is not null and char_length(clean_details) > 1000 then
    raise exception 'Details are too long';
  end if;
  if (select count(*) from public.reports where reporter_id = me and created_at > now() - interval '24 hours') >= 20 then
    raise exception 'You have sent a lot of reports today. Try again tomorrow.';
  end if;

  if _message_id is not null then
    -- Reporting a message: it must be in a chat I am in, and it must be someone else's.
    select m.chat_id, m.sender_id, m.kind, case when m.kind in ('text', 'image') then left(m.body, 500) else null end
      into chat, target, kind, body
      from public.messages m
     where m.id = _message_id
       and exists (select 1 from public.chat_members cm where cm.chat_id = m.chat_id and cm.user_id = me);
    if target is null then
      raise exception 'Message not found';
    end if;
  elsif _chat_id is not null then
    if not exists (select 1 from public.chat_members where chat_id = _chat_id and user_id = me)
       or target is null
       or not exists (select 1 from public.chat_members where chat_id = _chat_id and user_id = target) then
      raise exception 'Chat not found';
    end if;
  else
    -- Reporting a person (from their profile): we must share a chat.
    if target is null or not exists (
      select 1 from public.chat_members a
      join public.chat_members b on b.chat_id = a.chat_id
      where a.user_id = me and b.user_id = target
    ) then
      raise exception 'Person not found';
    end if;
  end if;

  if target = me then
    raise exception 'You can''t report yourself';
  end if;

  insert into public.reports (reporter_id, reported_user_id, chat_id, message_id, message_kind, message_text, reason, details)
  values (me, target, chat, _message_id, kind, body, _reason, clean_details)
  returning id into new_id;
  return new_id;
end;
$function$;

revoke all on function public.submit_report(uuid, uuid, uuid, text, text) from public, anon;
grant execute on function public.submit_report(uuid, uuid, uuid, text, text) to authenticated;
