import { createClient } from "npm:@supabase/supabase-js@2";

// Wakes the other person's phone for a call (Firebase Cloud Messaging, high priority, data only).
//
//   { call_id, event: "ring" }    -> "incoming_call": the phone shows the incoming call screen
//   { call_id, event: "cancel" }  -> "call_cancelled": the caller hung up / gave up before it was answered
//
// verify_jwt is off because the function checks the signed-in user itself: only the CALLER of that call can
// trigger a push, and only to the callee. The push carries the caller's name and nothing else.

const sa = JSON.parse(Deno.env.get("FCM_SERVICE_ACCOUNT") ?? "{}");
const admin = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
  { auth: { persistSession: false } },
);

const enc = new TextEncoder();

function b64url(input: ArrayBuffer | string): string {
  const bytes = typeof input === "string" ? enc.encode(input) : new Uint8Array(input);
  let s = "";
  bytes.forEach((b) => (s += String.fromCharCode(b)));
  return btoa(s).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

function pemToDer(pem: string): ArrayBuffer {
  const b64 = pem.replace(/-----[^-]+-----/g, "").replace(/\s+/g, "");
  const bin = atob(b64);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out.buffer;
}

let cached: { token: string; exp: number } | null = null;

async function accessToken(): Promise<string> {
  const now = Math.floor(Date.now() / 1000);
  if (cached && cached.exp - 60 > now) return cached.token;

  const header = b64url(JSON.stringify({ alg: "RS256", typ: "JWT" }));
  const claim = b64url(JSON.stringify({
    iss: sa.client_email,
    scope: "https://www.googleapis.com/auth/firebase.messaging",
    aud: "https://oauth2.googleapis.com/token",
    iat: now,
    exp: now + 3600,
  }));
  const key = await crypto.subtle.importKey(
    "pkcs8",
    pemToDer(sa.private_key),
    { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" },
    false,
    ["sign"],
  );
  const sig = await crypto.subtle.sign("RSASSA-PKCS1-v1_5", key, enc.encode(`${header}.${claim}`));
  const res = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer",
      assertion: `${header}.${claim}.${b64url(sig)}`,
    }),
  });
  const j = await res.json();
  if (!res.ok) throw new Error("google token error: " + (j.error_description ?? j.error ?? res.status));
  cached = { token: j.access_token, exp: now + (j.expires_in ?? 3600) };
  return cached.token;
}

type Result = "ok" | "dead" | "fail";

async function sendOne(token: string, data: Record<string, string>): Promise<Result> {
  const res = await fetch(`https://fcm.googleapis.com/v1/projects/${sa.project_id}/messages:send`, {
    method: "POST",
    headers: { Authorization: `Bearer ${await accessToken()}`, "Content-Type": "application/json" },
    // A ringing call is worthless after half a minute, so FCM should not keep it around.
    body: JSON.stringify({ message: { token, data, android: { priority: "HIGH", ttl: "30s" } } }),
  });
  if (res.ok) return "ok";
  const text = await res.text();
  console.error("fcm error", res.status, text.slice(0, 300));
  if (res.status === 404 || text.includes("UNREGISTERED")) return "dead";
  return "fail";
}

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { "Content-Type": "application/json" } });

Deno.serve(async (req) => {
  try {
    if (req.method !== "POST") return json({ error: "POST only" }, 405);

    const jwt = (req.headers.get("Authorization") ?? "").replace(/^Bearer\s+/i, "");
    const { data: auth } = await admin.auth.getUser(jwt);
    const me = auth?.user?.id;
    if (!me) return json({ error: "Not signed in" }, 401);

    const body = await req.json().catch(() => ({}));
    const callId = typeof body.call_id === "string" ? body.call_id : "";
    const event = body.event;
    if (callId.length < 8 || (event !== "ring" && event !== "cancel")) return json({ error: "bad request" }, 400);

    const { data: call } = await admin
      .from("calls")
      .select("id, chat_id, caller_id, callee_id, status, created_at")
      .eq("id", callId)
      .maybeSingle();
    if (!call || call.caller_id !== me) return json({ error: "Not your call" }, 403);

    if (event === "ring") {
      const fresh = Date.now() - new Date(call.created_at).getTime() < 60_000;
      if (call.status !== "ringing" || !fresh) return json({ sent: 0, reason: "not ringing" });
      // One ring per call: whoever claims it first sends it, any repeat is refused.
      const { data: claimed } = await admin.from("calls")
        .update({ ring_pushed_at: new Date().toISOString() })
        .eq("id", callId).is("ring_pushed_at", null).select("id");
      if (!claimed || claimed.length === 0) return json({ sent: 0, reason: "already rung" });
    } else {
      // "Cancelled" only makes sense once the call is no longer ringing, and is sent once.
      if (call.status === "ringing") return json({ sent: 0, reason: "call still ringing" });
      const { data: claimed } = await admin.from("calls")
        .update({ cancel_pushed_at: new Date().toISOString() })
        .eq("id", callId).is("cancel_pushed_at", null).select("id");
      if (!claimed || claimed.length === 0) return json({ sent: 0, reason: "already sent" });
    }

    const { data: tokens } = await admin.from("device_tokens").select("token").eq("user_id", call.callee_id);
    if (!tokens || tokens.length === 0) return json({ sent: 0, reason: "no devices" });

    let data: Record<string, string>;
    if (event === "ring") {
      const { data: caller } = await admin
        .from("profiles")
        .select("display_name, username, avatar_path")
        .eq("id", call.caller_id)
        .maybeSingle();
      data = {
        type: "incoming_call",
        call_id: call.id,
        chat_id: call.chat_id,
        caller_name: caller?.display_name || caller?.username || "Instants",
        avatar_path: caller?.avatar_path || "",
      };
    } else {
      data = { type: "call_cancelled", call_id: call.id };
    }

    let sent = 0;
    const dead: string[] = [];
    for (const { token } of tokens) {
      const r = await sendOne(token, data);
      if (r === "ok") sent++;
      else if (r === "dead") dead.push(token);
    }
    if (dead.length > 0) await admin.from("device_tokens").delete().in("token", dead);

    return json({ sent, removed: dead.length });
  } catch (e) {
    console.error("call-push failed", e instanceof Error ? e.message : String(e));
    return json({ error: "failed" }, 500);
  }
});
