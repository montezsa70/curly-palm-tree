import { createClient } from "npm:@supabase/supabase-js@2";

// Hands a phone short-lived Cloudflare TURN credentials for ONE active call.
//
// The long-lived Cloudflare TURN key (CF_TURN_KEY_ID / CF_TURN_API_TOKEN) only ever lives in Supabase secrets.
// verify_jwt is off because the function checks the signed-in user itself (same as `media`): the caller must be
// one of the two people on a call that is still ringing or in progress.

const admin = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
  { auth: { persistSession: false } },
);

// Two hours: long enough for a normal call (a TURN allocation cannot be refreshed after its credential expires),
// short enough that a leaked credential is of little use.
const TTL_SECONDS = 2 * 60 * 60;

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { "Content-Type": "application/json" } });

Deno.serve(async (req) => {
  try {
    if (req.method !== "POST") return json({ error: "POST only" }, 405);

    const jwt = (req.headers.get("Authorization") ?? "").replace(/^Bearer\s+/i, "");
    const { data: auth } = await admin.auth.getUser(jwt);
    const me = auth?.user?.id;
    if (!me) return json({ error: "Not signed in" }, 401);

    const body = await req.json().catch(() => ({}));
    const callId = typeof body.call_id === "string" ? body.call_id : "";
    if (callId.length < 8) return json({ error: "bad request" }, 400);

    const { data: call } = await admin
      .from("calls")
      .select("caller_id, callee_id, status, created_at, answered_at")
      .eq("id", callId)
      .maybeSingle();
    const onCall = call && (call.caller_id === me || call.callee_id === me);
    if (!onCall || !["ringing", "accepted"].includes(call.status)) {
      return json({ error: "No active call" }, 403);
    }
    // A call nobody answered within about a minute is over, and no call needs credentials hours after it was answered.
    const now = Date.now();
    if (call.status === "ringing" && now - new Date(call.created_at).getTime() > 70_000) {
      return json({ error: "No active call" }, 403);
    }
    if (call.status === "accepted" && call.answered_at && now - new Date(call.answered_at).getTime() > 3 * 60 * 60_000) {
      return json({ error: "No active call" }, 403);
    }

    // A real call needs one or two requests; this only stops someone farming relay bandwidth.
    const { data: allowed } = await admin.rpc("take_rate_token", {
      _user: me,
      _kind: "turn",
      _max: 20,
      _window: "10 minutes",
    });
    if (allowed !== true) return json({ error: "Too many requests. Try again in a few minutes." }, 429);

    const keyId = Deno.env.get("CF_TURN_KEY_ID");
    const token = Deno.env.get("CF_TURN_API_TOKEN");
    if (!keyId || !token) return json({ error: "TURN is not configured" }, 500);

    const res = await fetch(
      `https://rtc.live.cloudflare.com/v1/turn/keys/${keyId}/credentials/generate-ice-servers`,
      {
        method: "POST",
        headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
        body: JSON.stringify({ ttl: TTL_SECONDS }),
      },
    );
    if (!res.ok) {
      console.error("cloudflare turn error", res.status, (await res.text()).slice(0, 200));
      return json({ error: "TURN provider error" }, 502);
    }
    const data = await res.json();
    const list = Array.isArray(data.iceServers) ? data.iceServers : [data.iceServers];

    // Port 53 is only an escape hatch for very restrictive networks; it just slows candidate gathering otherwise.
    const iceServers = list.map((s: { urls: string | string[] }) => ({
      ...s,
      urls: (Array.isArray(s.urls) ? s.urls : [s.urls]).filter((u: string) => !u.includes(":53")),
    }));
    return json({ iceServers });
  } catch (e) {
    console.error("turn-credentials failed", e instanceof Error ? e.message : String(e));
    return json({ error: "failed" }, 500);
  }
});
