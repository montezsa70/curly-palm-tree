import { createClient } from "npm:@supabase/supabase-js@2";

// Deletes the signed-in person's account and everything of theirs that is stored on the server.
//
//   { password }  -> checks the password again (so a stolen, still-signed-in phone cannot delete the account),
//                    removes their files from Cloudflare R2 and Supabase Storage, then deletes the auth user.
//                    Every table row follows by cascade (messages they sent, contacts, statuses, calls, reports, tokens...).
//
// verify_jwt is off because the function checks the caller itself, like the other functions.

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const ANON_KEY = Deno.env.get("SUPABASE_ANON_KEY") ?? "";
const ACCOUNT = Deno.env.get("R2_ACCOUNT_ID") ?? "";
const ACCESS_KEY = Deno.env.get("R2_ACCESS_KEY_ID") ?? "";
const SECRET_KEY = Deno.env.get("R2_SECRET_ACCESS_KEY") ?? "";
const R2_BUCKET = Deno.env.get("R2_BUCKET") ?? "";

const admin = createClient(SUPABASE_URL, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, { auth: { persistSession: false } });

const MAX_R2_DELETES = 3000; // anything beyond this is cleared by the bucket's expiry rules

const enc = new TextEncoder();
const hex = (buf: ArrayBuffer) => [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");
const sha256Hex = async (s: string) => hex(await crypto.subtle.digest("SHA-256", enc.encode(s)));
const rfc3986 = (s: string) =>
  encodeURIComponent(s).replace(/[!'()*]/g, (c) => "%" + c.charCodeAt(0).toString(16).toUpperCase());

async function hmac(key: ArrayBuffer | Uint8Array, data: string): Promise<ArrayBuffer> {
  const k = await crypto.subtle.importKey("raw", key, { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  return crypto.subtle.sign("HMAC", k, enc.encode(data));
}

// Same AWS Signature V4 query signing as the media function.
async function presign(method: string, objectKey: string, expires: number): Promise<string> {
  const host = `${ACCOUNT}.r2.cloudflarestorage.com`;
  const amzDate = new Date().toISOString().replace(/[:-]|\.\d{3}/g, "");
  const date = amzDate.slice(0, 8);
  const scope = `${date}/auto/s3/aws4_request`;
  const uri = "/" + [R2_BUCKET, ...objectKey.split("/")].map(rfc3986).join("/");
  const params: Record<string, string> = {
    "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
    "X-Amz-Credential": `${ACCESS_KEY}/${scope}`,
    "X-Amz-Date": amzDate,
    "X-Amz-Expires": String(expires),
    "X-Amz-SignedHeaders": "host",
  };
  const query = Object.keys(params).sort().map((k) => `${rfc3986(k)}=${rfc3986(params[k])}`).join("&");
  const canonical = [method, uri, query, `host:${host}\n`, "host", "UNSIGNED-PAYLOAD"].join("\n");
  const toSign = ["AWS4-HMAC-SHA256", amzDate, scope, await sha256Hex(canonical)].join("\n");
  let k = await hmac(enc.encode("AWS4" + SECRET_KEY), date);
  k = await hmac(k, "auto");
  k = await hmac(k, "s3");
  k = await hmac(k, "aws4_request");
  return `https://${host}${uri}?${query}&X-Amz-Signature=${hex(await hmac(k, toSign))}`;
}

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { "Content-Type": "application/json" } });

/** Removes every file under <folder>/ in a Supabase Storage bucket. Returns how many it could not remove. */
async function emptyStorageFolder(bucket: string, folder: string): Promise<number> {
  let failed = 0;
  for (let round = 0; round < 20; round++) {
    const { data, error } = await admin.storage.from(bucket).list(folder, { limit: 1000 });
    if (error) return failed + 1;
    const names = (data ?? []).filter((o) => o.id).map((o) => `${folder}/${o.name}`);
    if (names.length === 0) break;
    const { error: rmError } = await admin.storage.from(bucket).remove(names);
    if (rmError) return failed + names.length;
  }
  return failed;
}

Deno.serve(async (req) => {
  try {
    if (req.method !== "POST") return json({ error: "method not allowed" }, 405);

    const jwt = (req.headers.get("Authorization") ?? "").replace(/^Bearer\s+/i, "");
    const { data: auth } = await admin.auth.getUser(jwt);
    const user = auth?.user;
    if (!user || !user.email) return json({ error: "Not signed in" }, 401);

    const body = await req.json().catch(() => ({}));
    const password = typeof body.password === "string" ? body.password : "";
    if (password.length === 0 || password.length > 200) return json({ error: "Enter your password to confirm" }, 400);

    // Confirm it really is them: sign in again with the password.
    const check = await fetch(`${SUPABASE_URL}/auth/v1/token?grant_type=password`, {
      method: "POST",
      headers: { apikey: ANON_KEY, "Content-Type": "application/json" },
      body: JSON.stringify({ email: user.email, password }),
    });
    if (!check.ok) return json({ error: "That password isn't right" }, 403);

    const uid = user.id;
    let notRemoved = 0;

    // 1. Files in Cloudflare R2: attachments they sent and their status media.
    const { data: files } = await admin.rpc("account_files", { _uid: uid });
    const list = (files ?? []) as { bucket: string; path: string }[];
    const r2Ready = ACCOUNT && ACCESS_KEY && SECRET_KEY && R2_BUCKET;
    if (r2Ready) {
      const todo = list.slice(0, MAX_R2_DELETES);
      for (let i = 0; i < todo.length; i += 10) {
        const results = await Promise.all(todo.slice(i, i + 10).map(async (f) => {
          try {
            const res = await fetch(await presign("DELETE", `${f.bucket}/${f.path}`, 60), { method: "DELETE" });
            return res.ok || res.status === 404;
          } catch {
            return false;
          }
        }));
        notRemoved += results.filter((ok) => !ok).length;
      }
      notRemoved += Math.max(0, list.length - MAX_R2_DELETES);
    }

    // 2. Files in Supabase Storage: profile photo folder, older status files, and older attachments they sent.
    notRemoved += await emptyStorageFolder("avatars", uid);
    notRemoved += await emptyStorageFolder("statuses", uid);
    const legacy = list.filter((f) => f.bucket === "attachments").map((f) => f.path);
    for (let i = 0; i < legacy.length; i += 100) {
      await admin.storage.from("attachments").remove(legacy.slice(i, i + 100)); // missing files are not an error
    }

    // 3. The account itself. The database removes everything that belongs to it.
    const { error: delError } = await admin.auth.admin.deleteUser(uid);
    if (delError) {
      console.error("deleteUser failed", delError.message);
      return json({ error: "We couldn't delete your account. Please try again." }, 500);
    }

    // 4. Chats that nobody is left in.
    await admin.rpc("purge_orphan_chats");

    if (notRemoved > 0) console.error("account deleted but some files were not removed:", notRemoved);
    return json({ ok: true });
  } catch (e) {
    console.error("delete-account failed", e instanceof Error ? e.message : String(e));
    return json({ error: "We couldn't delete your account. Please try again." }, 500);
  }
});
