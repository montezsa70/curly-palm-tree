import { createClient } from "npm:@supabase/supabase-js@2";

// Temporary media relay. Photos, voice notes, documents and status media live in Cloudflare R2.
// The app never holds the R2 keys: it asks this function for a short-lived link, then talks to R2 directly.
//
//   put    -> link to upload a file (I must be allowed to put it there; size and type are checked here)
//   get    -> link to download a file (I must be allowed to see it)
//   ack    -> I saved a chat attachment on my phone: delete the server copy (recipient only)
//   delete -> remove a file I uploaded (cleanup after a failed send, deleting a status)
//
// verify_jwt is off because the gateway check does not cover every token type; the function checks the
// caller itself with the auth server, and then checks every request against the database.

const ACCOUNT = Deno.env.get("R2_ACCOUNT_ID") ?? "";
const ACCESS_KEY = Deno.env.get("R2_ACCESS_KEY_ID") ?? "";
const SECRET_KEY = Deno.env.get("R2_SECRET_ACCESS_KEY") ?? "";
const R2_BUCKET = Deno.env.get("R2_BUCKET") ?? "";

const admin = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
  { auth: { persistSession: false } },
);

const BUCKETS = new Set(["attachments", "statuses"]);
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const SAFE_PATH = /^[A-Za-z0-9._-]+(\/[A-Za-z0-9._-]+)+$/;
const MIME = /^[a-z0-9][a-z0-9.+-]*\/[a-z0-9][a-z0-9.+-]*$/;

// ---- upload limits ----
const MB = 1024 * 1024;
const MAX_ATTACHMENT_BYTES = 25 * MB; // chat photos, voice notes and documents
const STATUS_LIMITS: Record<string, number> = { "image/jpeg": 10 * MB, "video/mp4": 50 * MB };
const MAX_UPLOADS_PER_DAY = 400;
const MAX_BYTES_PER_DAY = 1536 * MB;

const enc = new TextEncoder();
const hex = (buf: ArrayBuffer) =>
  [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");
const sha256Hex = async (s: string) => hex(await crypto.subtle.digest("SHA-256", enc.encode(s)));
const rfc3986 = (s: string) =>
  encodeURIComponent(s).replace(/[!'()*]/g, (c) => "%" + c.charCodeAt(0).toString(16).toUpperCase());

async function hmac(key: ArrayBuffer | Uint8Array, data: string): Promise<ArrayBuffer> {
  const k = await crypto.subtle.importKey("raw", key, { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  return crypto.subtle.sign("HMAC", k, enc.encode(data));
}

/**
 * AWS Signature V4 query-string signing (what R2's S3 API expects). Checked against AWS's published test vector.
 * For uploads the exact file size is signed too (content-length): R2 refuses a body of any other size, so the limit
 * checked here cannot be dodged by uploading something bigger than was asked for.
 */
async function presign(method: string, objectKey: string, expires: number, contentLength?: number): Promise<string> {
  const host = `${ACCOUNT}.r2.cloudflarestorage.com`;
  const amzDate = new Date().toISOString().replace(/[:-]|\.\d{3}/g, "");
  const date = amzDate.slice(0, 8);
  const scope = `${date}/auto/s3/aws4_request`;
  const uri = "/" + [R2_BUCKET, ...objectKey.split("/")].map(rfc3986).join("/");
  const signedHeaders = contentLength === undefined ? "host" : "content-length;host";
  const canonicalHeaders = contentLength === undefined
    ? `host:${host}\n`
    : `content-length:${contentLength}\nhost:${host}\n`;
  const params: Record<string, string> = {
    "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
    "X-Amz-Credential": `${ACCESS_KEY}/${scope}`,
    "X-Amz-Date": amzDate,
    "X-Amz-Expires": String(expires),
    "X-Amz-SignedHeaders": signedHeaders,
  };
  const query = Object.keys(params).sort().map((k) => `${rfc3986(k)}=${rfc3986(params[k])}`).join("&");
  const canonical = [method, uri, query, canonicalHeaders, signedHeaders, "UNSIGNED-PAYLOAD"].join("\n");
  const toSign = ["AWS4-HMAC-SHA256", amzDate, scope, await sha256Hex(canonical)].join("\n");
  let k = await hmac(enc.encode("AWS4" + SECRET_KEY), date);
  k = await hmac(k, "auto");
  k = await hmac(k, "s3");
  k = await hmac(k, "aws4_request");
  const signature = hex(await hmac(k, toSign));
  return `https://${host}${uri}?${query}&X-Amz-Signature=${signature}`;
}

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { "Content-Type": "application/json" } });

// ---- permission checks (all use the service role, so each rule is spelled out here) ----

async function isChatMember(chatId: string, userId: string): Promise<boolean> {
  if (!UUID.test(chatId)) return false;
  const { data } = await admin.from("chat_members").select("user_id")
    .eq("chat_id", chatId).eq("user_id", userId).maybeSingle();
  return !!data;
}

/** Can this user see a status file? Mine, or a visible, unexpired status of a contact. */
async function canSeeStatusFile(path: string, userId: string): Promise<boolean> {
  if (path.split("/")[0] === userId) return true;
  for (const column of ["media_path", "thumb_path"]) {
    const { data } = await admin.from("status_updates").select("user_id, expires_at")
      .eq(column, path).limit(1).maybeSingle();
    if (!data || new Date(data.expires_at).getTime() <= Date.now()) continue;
    const { data: visible } = await admin.rpc("status_update_visible", { _author: data.user_id, _viewer: userId });
    if (visible === true) return true;
  }
  return false;
}

Deno.serve(async (req) => {
  try {
    if (req.method !== "POST") return json({ error: "method not allowed" }, 405);
    if (!ACCOUNT || !ACCESS_KEY || !SECRET_KEY || !R2_BUCKET) return json({ error: "storage not configured" }, 500);

    // Who is calling?
    const jwt = (req.headers.get("Authorization") ?? "").replace(/^Bearer\s+/i, "");
    const { data: auth } = await admin.auth.getUser(jwt);
    const userId = auth?.user?.id;
    if (!userId) return json({ error: "not signed in" }, 401);

    const { action, bucket, path, size, mime } = await req.json();
    if (typeof bucket !== "string" || !BUCKETS.has(bucket)) return json({ error: "bad bucket" }, 400);
    if (typeof path !== "string" || path.length > 200 || path.includes("..") || !SAFE_PATH.test(path)) {
      return json({ error: "bad path" }, 400);
    }
    const folder = path.split("/")[0];
    const key = `${bucket}/${path}`; // the bucket name is a prefix, so each kind can have its own expiry rule

    switch (action) {
      case "put": {
        const allowed = bucket === "attachments" ? await isChatMember(folder, userId) : folder === userId;
        if (!allowed) return json({ error: "not allowed" }, 403);

        // The app says how big the file is and what it is; both are checked, and the size is signed into the link.
        const bytes = typeof size === "number" && Number.isSafeInteger(size) ? size : 0;
        if (bytes <= 0) return json({ error: "size required" }, 400);
        const type = typeof mime === "string" ? mime.toLowerCase() : "";
        if (type.length > 100 || !MIME.test(type)) return json({ error: "bad type" }, 400);
        const limit = bucket === "attachments" ? MAX_ATTACHMENT_BYTES : STATUS_LIMITS[type];
        if (!limit) return json({ error: "this kind of file can't be used here" }, 415);
        if (bytes > limit) return json({ error: "That file is too large", max: limit }, 413);

        const { data: within } = await admin.rpc("take_upload_quota", {
          _user: userId,
          _bytes: bytes,
          _max_uploads: MAX_UPLOADS_PER_DAY,
          _max_bytes: MAX_BYTES_PER_DAY,
        });
        if (within !== true) return json({ error: "Upload limit reached for today. Try again tomorrow." }, 429);

        return json({ url: await presign("PUT", key, 600, bytes) });
      }

      case "get": {
        const allowed = bucket === "attachments" ? await isChatMember(folder, userId) : await canSeeStatusFile(path, userId);
        if (!allowed) return json({ error: "not allowed" }, 403);
        return json({ url: await presign("GET", key, 600) });
      }

      case "ack": {
        // Only the person who received the attachment can tell us it is safely on their phone.
        if (bucket !== "attachments") return json({ ok: true, deleted: false });
        const { data: msg } = await admin.from("messages").select("sender_id, chat_id")
          .eq("attachment_path", path).limit(1).maybeSingle();
        if (!msg || msg.sender_id === userId || !(await isChatMember(msg.chat_id, userId))) {
          return json({ ok: true, deleted: false });
        }
        const res = await fetch(await presign("DELETE", key, 60), { method: "DELETE" });
        return json({ ok: res.ok, deleted: res.ok });
      }

      case "delete": {
        let allowed = false;
        if (bucket === "statuses") {
          allowed = folder === userId;
        } else if (await isChatMember(folder, userId)) {
          // Cleanup after a failed send (no message yet), or removing my own message's file.
          const { data: msg } = await admin.from("messages").select("sender_id")
            .eq("attachment_path", path).limit(1).maybeSingle();
          allowed = !msg || msg.sender_id === userId;
        }
        if (!allowed) return json({ error: "not allowed" }, 403);
        const res = await fetch(await presign("DELETE", key, 60), { method: "DELETE" });
        return json({ ok: res.ok });
      }

      default:
        return json({ error: "unknown action" }, 400);
    }
  } catch (e) {
    console.error("media failed", e instanceof Error ? e.message : String(e));
    return json({ error: "failed" }, 500);
  }
});
