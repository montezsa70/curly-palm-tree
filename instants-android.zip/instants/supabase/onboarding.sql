-- Lets the sign-up screen ask "does this email already have an account?" before it asks for a profile.
-- Already applied to the "Instants chats" project. Safe to run again.
create or replace function public.email_registered(_email text)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (select 1 from auth.users u where lower(u.email) = lower(trim(_email)));
$$;
revoke all on function public.email_registered(text) from public;
grant execute on function public.email_registered(text) to anon, authenticated;
