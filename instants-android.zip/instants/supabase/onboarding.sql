-- Lets the sign-up screen ask "does this email already have an account?" before it asks for a profile.
-- Rate limited per caller IP so it can't be used to scan for registered emails.
-- Already applied to the "Instants chats" project. Safe to run again.

create table if not exists public.rate_limits (
  bucket       text        not null,
  key          text        not null,
  window_start timestamptz not null default now(),
  hits         integer     not null default 0,
  primary key (bucket, key)
);
alter table public.rate_limits enable row level security;   -- no policies: only the functions below touch it
revoke all on public.rate_limits from anon, authenticated;

create or replace function public.email_registered(_email text)
returns boolean
language plpgsql
security definer
set search_path = ''
as $$
declare
  headers  json := coalesce(nullif(current_setting('request.headers', true), ''), '{}')::json;
  caller   text := coalesce(
                     headers->>'cf-connecting-ip',
                     nullif(trim(split_part(coalesce(headers->>'x-forwarded-for', ''), ',', 1)), ''),
                     'unknown');
  max_hits constant integer := 8;                  -- checks allowed ...
  win      constant interval := interval '10 minutes'; -- ... per window, per caller
  h integer;
begin
  insert into public.rate_limits as r (bucket, key, window_start, hits)
  values ('email_registered', caller, now(), 1)
  on conflict (bucket, key) do update
    set hits         = case when r.window_start < now() - win then 1 else r.hits + 1 end,
        window_start = case when r.window_start < now() - win then now() else r.window_start end
  returning r.hits into h;

  if h > max_hits then
    raise exception 'too_many_requests';
  end if;

  -- tidy up stale rows now and then
  if random() < 0.02 then
    delete from public.rate_limits where window_start < now() - interval '1 day';
  end if;

  return exists (select 1 from auth.users u where lower(u.email) = lower(trim(_email)));
end;
$$;
revoke all on function public.email_registered(text) from public;
grant execute on function public.email_registered(text) to anon, authenticated;
