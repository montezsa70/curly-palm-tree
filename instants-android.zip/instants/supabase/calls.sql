-- Voice calls and screen sharing: call records + WebRTC signaling (offer / answer / ICE / screen-share flag).
-- Media never touches Supabase: it flows peer to peer, or through the Cloudflare TURN relay when a direct path fails.
-- Safe to run again.

-- ---- tables ----------------------------------------------------------------------------------
create table if not exists public.calls (
  id          uuid primary key default gen_random_uuid(),
  chat_id     uuid not null,
  caller_id   uuid not null references auth.users (id) on delete cascade,
  callee_id   uuid not null references auth.users (id) on delete cascade,
  status      text not null default 'ringing'
              check (status in ('ringing', 'accepted', 'declined', 'cancelled', 'missed', 'busy', 'ended')),
  created_at  timestamptz not null default now(),
  answered_at timestamptz,
  ended_at    timestamptz
);
create index if not exists calls_callee_idx on public.calls (callee_id, created_at desc);
create index if not exists calls_caller_idx on public.calls (caller_id, created_at desc);

create table if not exists public.call_signals (
  id         bigint generated always as identity primary key,
  call_id    uuid not null references public.calls (id) on delete cascade,
  from_id    uuid not null,
  to_id      uuid not null,
  kind       text not null check (kind in ('offer', 'answer', 'ice', 'screen')),
  payload    jsonb not null,
  created_at timestamptz not null default now()
);
create index if not exists call_signals_call_idx on public.call_signals (call_id, id);

-- ---- row level security: read-only for the two people on the call; every write goes through the functions below ----
alter table public.calls enable row level security;
alter table public.call_signals enable row level security;

drop policy if exists calls_select on public.calls;
create policy calls_select on public.calls
  for select to authenticated using (auth.uid() in (caller_id, callee_id));

drop policy if exists call_signals_select on public.call_signals;
create policy call_signals_select on public.call_signals
  for select to authenticated using (to_id = auth.uid());

revoke all on public.calls from anon, authenticated;
revoke all on public.call_signals from anon, authenticated;
grant select on public.calls to authenticated;
grant select on public.call_signals to authenticated;

-- ---- live delivery through Supabase Realtime -------------------------------------------------
do $$
begin
  begin
    alter publication supabase_realtime add table public.calls;
  exception when duplicate_object then null;
  end;
  begin
    alter publication supabase_realtime add table public.call_signals;
  exception when duplicate_object then null;
  end;
end $$;

-- ---- start a call (one-to-one chats only) ----------------------------------------------------
create or replace function public.start_call(_chat_id uuid)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  me uuid := auth.uid();
  peer uuid;
  member_count int;
  new_id uuid;
begin
  if me is null then
    raise exception 'Not signed in';
  end if;
  if not exists (select 1 from public.chat_members where chat_id = _chat_id and user_id = me) then
    raise exception 'Not a member of this chat';
  end if;
  select count(*) into member_count from public.chat_members where chat_id = _chat_id;
  if member_count <> 2 then
    raise exception 'Calls only work in one-to-one chats';
  end if;
  select user_id into peer from public.chat_members where chat_id = _chat_id and user_id <> me;
  if exists (
    select 1 from public.blocks
    where (blocker_id = peer and blocked_id = me) or (blocker_id = me and blocked_id = peer)
  ) then
    raise exception 'You can''t call this person';
  end if;

  -- Anything of mine that was left open (app killed mid-call) is closed first.
  update public.calls
     set status = case when status = 'accepted' then 'ended'
                       when caller_id = me then 'cancelled'
                       else 'busy' end,
         ended_at = now()
   where status in ('ringing', 'accepted') and (caller_id = me or callee_id = me);

  insert into public.calls (chat_id, caller_id, callee_id)
  values (_chat_id, me, peer)
  returning id into new_id;
  return new_id;
end;
$$;

-- ---- answer ----------------------------------------------------------------------------------
create or replace function public.answer_call(_call_id uuid)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  update public.calls
     set status = 'accepted', answered_at = now()
   where id = _call_id and callee_id = auth.uid() and status = 'ringing';
  if not found then
    raise exception 'This call is no longer available';
  end if;
end;
$$;

-- ---- end / decline / cancel (idempotent) -----------------------------------------------------
-- _status is a hint: the final status is decided from who is asking and how far the call got.
create or replace function public.end_call(_call_id uuid, _status text default 'ended')
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  me uuid := auth.uid();
  c public.calls;
  final_status text;
begin
  select * into c from public.calls
   where id = _call_id and me in (caller_id, callee_id)
   for update;
  if not found or c.status not in ('ringing', 'accepted') then
    return;
  end if;

  if c.status = 'accepted' then
    final_status := 'ended';
  elsif me = c.caller_id then
    final_status := case when _status = 'missed' then 'missed' else 'cancelled' end;
  else
    final_status := case when _status = 'busy' then 'busy' else 'declined' end;
  end if;

  update public.calls set status = final_status, ended_at = now() where id = _call_id;
  -- Candidates contain network addresses: wipe them as soon as the call is over.
  update public.call_signals set payload = '{}'::jsonb where call_id = _call_id;
end;
$$;

-- ---- send a signaling message to the other person --------------------------------------------
create or replace function public.call_signal(_call_id uuid, _kind text, _payload jsonb)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  me uuid := auth.uid();
  c public.calls;
begin
  select * into c from public.calls where id = _call_id and me in (caller_id, callee_id);
  if not found or c.status not in ('ringing', 'accepted') then
    raise exception 'Call is not active';
  end if;
  if _kind not in ('offer', 'answer', 'ice', 'screen') then
    raise exception 'Unknown signal';
  end if;
  if pg_column_size(_payload) > 32768 then
    raise exception 'Signal too large';
  end if;
  insert into public.call_signals (call_id, from_id, to_id, kind, payload)
  values (_call_id, me, case when me = c.caller_id then c.callee_id else c.caller_id end, _kind, _payload);
end;
$$;

revoke all on function public.start_call(uuid) from public, anon;
revoke all on function public.answer_call(uuid) from public, anon;
revoke all on function public.end_call(uuid, text) from public, anon;
revoke all on function public.call_signal(uuid, text, jsonb) from public, anon;
grant execute on function public.start_call(uuid) to authenticated;
grant execute on function public.answer_call(uuid) to authenticated;
grant execute on function public.end_call(uuid, text) to authenticated;
grant execute on function public.call_signal(uuid, text, jsonb) to authenticated;

-- ---- housekeeping ----------------------------------------------------------------------------
-- Old signaling rows are useless; call records are kept for 30 days. Schedule with pg_cron if you like:
--   select cron.schedule('purge-calls', '17 3 * * *', $$ select public.purge_old_calls() $$);
create or replace function public.purge_old_calls()
returns void
language sql
security definer
set search_path = public
as $$
  delete from public.call_signals where created_at < now() - interval '1 day';
  delete from public.calls where created_at < now() - interval '30 days';
$$;
revoke all on function public.purge_old_calls() from public, anon, authenticated;
