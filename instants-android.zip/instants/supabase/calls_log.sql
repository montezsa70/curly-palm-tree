-- Call history: a "call" entry in the chat when a call ends, plus the data the Calls tab needs.
-- Safe to run again. Run after calls.sql.

-- When the audio actually connected (call duration counts from here, and "accepted but never connected" means it failed).
alter table public.calls add column if not exists connected_at timestamptz;
alter table public.calls drop constraint if exists calls_status_check;
alter table public.calls add constraint calls_status_check
  check (status in ('ringing', 'accepted', 'declined', 'cancelled', 'missed', 'busy', 'ended', 'failed'));

-- Chats may now hold a "call" entry. Its body is the outcome: ended:<seconds>, missed, cancelled, declined, busy or failed.
-- The sender is the caller.
alter table public.messages drop constraint if exists messages_kind_check;
alter table public.messages add constraint messages_kind_check
  check (kind = any (array['text', 'image', 'file', 'voice', 'call']));
alter table public.messages drop constraint if exists messages_attachment_check;
alter table public.messages add constraint messages_attachment_check
  check (
    (kind in ('text', 'call') and attachment_path is null)
    or (kind = any (array['image', 'file', 'voice']) and attachment_path is not null)
  );

-- A call entry must never trigger a "New message" push.
create or replace function public.notify_new_message()
returns trigger
language plpgsql
security definer
set search_path to ''
as $function$
begin
  if new.kind = 'call' then
    return new;
  end if;
  begin
    perform net.http_post(
      url := 'https://hbdeiaikwbnznsextluj.supabase.co/functions/v1/send-push',
      headers := '{"Content-Type": "application/json"}'::jsonb,
      body := jsonb_build_object('message_id', new.id),
      timeout_milliseconds := 5000
    );
  exception when others then
    null;
  end;
  return new;
end;
$function$;

-- Either phone calls this once the audio is flowing.
create or replace function public.call_connected(_call_id uuid)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  update public.calls
     set connected_at = coalesce(connected_at, now())
   where id = _call_id and auth.uid() in (caller_id, callee_id) and status = 'accepted';
end;
$$;
revoke all on function public.call_connected(uuid) from public, anon;
grant execute on function public.call_connected(uuid) to authenticated;

-- end_call now also writes the entry into the chat.
create or replace function public.end_call(_call_id uuid, _status text default 'ended')
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  me uuid := auth.uid();
  c public.calls;
  final_status text;
  entry text;
begin
  select * into c from public.calls
   where id = _call_id and me in (caller_id, callee_id)
   for update;
  if not found or c.status not in ('ringing', 'accepted') then
    return;
  end if;

  if c.status = 'accepted' then
    final_status := case when c.connected_at is not null then 'ended' else 'failed' end;
  elsif me = c.caller_id then
    final_status := case when _status = 'missed' then 'missed'
                         when _status = 'failed' then 'failed'
                         else 'cancelled' end;
  else
    final_status := case when _status = 'busy' then 'busy'
                         when _status = 'failed' then 'failed'
                         else 'declined' end;
  end if;

  update public.calls set status = final_status, ended_at = now() where id = _call_id;
  -- Candidates contain network addresses: wipe them as soon as the call is over.
  update public.call_signals set payload = '{}'::jsonb where call_id = _call_id;

  entry := case
    when final_status = 'ended' then 'ended:' || greatest(0, floor(extract(epoch from (now() - c.connected_at))))::int::text
    else final_status
  end;
  insert into public.messages (chat_id, sender_id, body, kind)
  values (c.chat_id, c.caller_id, entry, 'call');
end;
$$;
