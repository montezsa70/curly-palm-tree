-- Delivery ticks for the chat list (one tick = sent, two = delivered, blue two = read).
-- Run once in the Supabase SQL editor. Until then the app shows "sent" and "read" only.

alter table public.chat_members
  add column if not exists delivered_at timestamptz;

-- Called by the recipient's phone when new messages arrive on it.
create or replace function public.mark_chat_delivered(_chat_id uuid)
returns void
language sql
security definer
set search_path = public
as $$
  update public.chat_members
     set delivered_at = now()
   where chat_id = _chat_id
     and user_id = auth.uid();
$$;

revoke all on function public.mark_chat_delivered(uuid) from public;
grant execute on function public.mark_chat_delivered(uuid) to authenticated;
