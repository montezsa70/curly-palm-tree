-- Message actions (reply, delete for me, delete for everyone, message info) and text-status fonts.
-- Already applied to the "Instants chats" project; kept here so the repo matches the database.
-- Safe to run again.

-- ---- columns ---------------------------------------------------------------------------------
alter table public.messages
  add column if not exists reply_to      uuid references public.messages (id) on delete set null,
  add column if not exists status_quote  jsonb,        -- a status this message replies to: {kind, text, bg}
  add column if not exists deleted_at    timestamptz,  -- set = "deleted for everyone" (the row stays as a tombstone)
  add column if not exists delivered_at  timestamptz,  -- when the recipient's phone received it
  add column if not exists read_at       timestamptz;  -- when the recipient read it (only if they send read receipts)

alter table public.status_updates add column if not exists font text;
alter table public.status_updates drop constraint if exists status_updates_font_check;
alter table public.status_updates
  add constraint status_updates_font_check
  check (font is null or font in ('classic', 'serif', 'mono', 'script', 'condensed'));

-- ---- delete for me ---------------------------------------------------------------------------
create table if not exists public.message_hides (
  user_id    uuid not null default auth.uid() references auth.users (id) on delete cascade,
  message_id uuid not null references public.messages (id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, message_id)
);
create index if not exists message_hides_message_idx on public.message_hides (message_id);

alter table public.message_hides enable row level security;
revoke all on public.message_hides from anon;
revoke all on public.message_hides from authenticated;
grant select, insert on public.message_hides to authenticated;

drop policy if exists message_hides_select_own on public.message_hides;
create policy message_hides_select_own on public.message_hides
  for select to authenticated using (user_id = (select auth.uid()));

-- A helper (not a plain subquery) so this policy and the messages select policy can't loop into each other.
create or replace function public.can_hide_message(_message_id uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.messages m
    where m.id = _message_id and public.is_chat_member(m.chat_id)
  );
$$;
revoke all on function public.can_hide_message(uuid) from public, anon;
grant execute on function public.can_hide_message(uuid) to authenticated;

drop policy if exists message_hides_insert_own on public.message_hides;
create policy message_hides_insert_own on public.message_hides
  for insert to authenticated
  with check (user_id = (select auth.uid()) and public.can_hide_message(message_id));

-- Messages I hid no longer come back from any query (thread, chat list, realtime).
drop policy if exists messages_select_member on public.messages;
create policy messages_select_member on public.messages
  for select to authenticated
  using (
    public.is_chat_member(chat_id)
    and (expires_at is null or expires_at > now())
    and not exists (
      select 1 from public.message_hides h
      where h.message_id = messages.id and h.user_id = (select auth.uid())
    )
  );

-- A message deleted for everyone keeps its row with an empty body, so the body rule must allow that.
alter table public.messages drop constraint if exists messages_body_check;
alter table public.messages add constraint messages_body_check
  check (
    char_length(body) <= 4000
    and (char_length(body) >= 1 or attachment_path is not null or deleted_at is not null)
  );

-- ---- delete for everyone ---------------------------------------------------------------------
-- Only the sender. The row stays (so both chats show "This message was deleted") but its content is wiped.
-- Returns the file path the message had, so the app can also delete it from Cloudflare R2.
create or replace function public.delete_message_for_everyone(_message_id uuid)
returns text
language plpgsql
security definer
set search_path = ''
as $$
declare
  me uuid := (select auth.uid());
  old_path text;
begin
  if me is null then
    raise exception 'not allowed';
  end if;

  select attachment_path into old_path
    from public.messages
   where id = _message_id and sender_id = me
   for update;
  if not found then
    raise exception 'not allowed';
  end if;

  update public.messages
     set body = '',
         kind = 'text',
         attachment_path = null,
         attachment_name = null,
         attachment_mime = null,
         attachment_size = null,
         voice_duration_ms = null,
         voice_waveform = null,
         reply_to = null,
         status_quote = null,
         deleted_at = coalesce(deleted_at, now())
   where id = _message_id;

  return old_path;
end;
$$;

revoke all on function public.delete_message_for_everyone(uuid) from public, anon;
grant execute on function public.delete_message_for_everyone(uuid) to authenticated;

-- ---- per-message delivered / read times ------------------------------------------------------
create or replace function public.mark_chat_delivered(_chat_id uuid)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  me uuid := (select auth.uid());
begin
  if me is null or not public.is_chat_member(_chat_id) then
    return;
  end if;
  update public.chat_members set delivered_at = now()
   where chat_id = _chat_id and user_id = me;
  update public.messages set delivered_at = now()
   where chat_id = _chat_id and sender_id <> me and delivered_at is null;
end;
$$;

revoke all on function public.mark_chat_delivered(uuid) from public, anon;
grant execute on function public.mark_chat_delivered(uuid) to authenticated;

create or replace function public.mark_chat_read(_chat_id uuid)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare me uuid := (select auth.uid());
begin
  if me is null or not public.is_chat_member(_chat_id) then
    raise exception 'not allowed';
  end if;
  insert into public.chat_reads (chat_id, user_id, last_read_at) values (_chat_id, me, now())
  on conflict (chat_id, user_id) do update set last_read_at = now();

  update public.messages set delivered_at = now()
   where chat_id = _chat_id and sender_id <> me and delivered_at is null;

  if coalesce((select read_receipts from public.user_settings where user_id = me), true) then
    update public.chat_members set receipt_at = now() where chat_id = _chat_id and user_id = me;
    update public.messages set read_at = now()
     where chat_id = _chat_id and sender_id <> me and read_at is null;
  end if;
end;
$$;
