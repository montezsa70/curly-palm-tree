-- Pre-launch hardening, step 7 (audit items B7, B8). Safe to run again.
-- Calls: limits that normal use never meets, a 60-second ring timeout on the server, one ring push per call.
-- Invites: an attempt limit and longer codes.

-- ---- a small shared rate limiter (service-only) ----------------------------------------------
create table if not exists public.rate_events (
  user_id uuid not null references auth.users (id) on delete cascade,
  kind    text not null,
  at      timestamptz not null default now()
);
create index if not exists rate_events_idx on public.rate_events (user_id, kind, at desc);
alter table public.rate_events enable row level security;
revoke all on public.rate_events from anon, authenticated;
comment on table public.rate_events is 'Service-only: recent events per user, for rate limits. Written by take_rate_token().';

-- True and records the event if this user has done fewer than _max of this kind within _window; otherwise false.
create or replace function public.take_rate_token(_user uuid, _kind text, _max int, _window interval)
returns boolean
language plpgsql
security definer
set search_path to ''
as $$
declare
  used int;
begin
  delete from public.rate_events where user_id = _user and kind = _kind and at < now() - _window;
  select count(*) into used from public.rate_events where user_id = _user and kind = _kind;
  if used >= _max then
    return false;
  end if;
  insert into public.rate_events (user_id, kind) values (_user, _kind);
  return true;
end;
$$;
revoke all on function public.take_rate_token(uuid, text, int, interval) from public, anon, authenticated;
grant execute on function public.take_rate_token(uuid, text, int, interval) to service_role;

-- ---- calls ----------------------------------------------------------------------------------
alter table public.calls add column if not exists ring_pushed_at timestamptz;
alter table public.calls add column if not exists cancel_pushed_at timestamptz;

-- A call nobody answered within 60 seconds is over: mark it missed and leave the entry in the chat.
create or replace function public.expire_stale_calls(_user uuid)
returns void
language plpgsql
security definer
set search_path to ''
as $$
declare
  c record;
begin
  for c in
    select id, chat_id, caller_id from public.calls
     where status = 'ringing' and created_at < now() - interval '60 seconds'
       and (caller_id = _user or callee_id = _user)
     for update
  loop
    update public.calls set status = 'missed', ended_at = now() where id = c.id;
    update public.call_signals set payload = '{}'::jsonb where call_id = c.id;
    insert into public.messages (chat_id, sender_id, body, kind) values (c.chat_id, c.caller_id, 'missed', 'call');
  end loop;
end;
$$;
revoke all on function public.expire_stale_calls(uuid) from public, anon, authenticated;

create or replace function public.start_call(_chat_id uuid)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  me uuid := auth.uid();
  peer uuid;
  member_count int;
  new_id uuid;
begin
  if me is null then
    raise exception 'Not signed in';
  end if;
  if not exists (select 1 from public.chat_members where chat_id = _chat_id and user_id = me) then
    raise exception 'Not a member of this chat';
  end if;
  select count(*) into member_count from public.chat_members where chat_id = _chat_id;
  if member_count <> 2 then
    raise exception 'Calls only work in one-to-one chats';
  end if;
  select user_id into peer from public.chat_members where chat_id = _chat_id and user_id <> me;
  if exists (
    select 1 from public.blocks
    where (blocker_id = peer and blocked_id = me) or (blocker_id = me and blocked_id = peer)
  ) then
    raise exception 'You can''t call this person';
  end if;

  perform public.expire_stale_calls(me);

  -- Anything of mine that was left open (app killed mid-call) is closed first.
  update public.calls
     set status = case when status = 'accepted' then 'ended'
                       when caller_id = me then 'cancelled'
                       else 'busy' end,
         ended_at = now()
   where status in ('ringing', 'accepted') and (caller_id = me or callee_id = me);

  -- Limits that real conversations never reach.
  if (select count(*) from public.calls where caller_id = me and created_at > now() - interval '1 minute') >= 20 then
    raise exception 'Too many calls. Try again in a minute.';
  end if;
  if (
    select count(*) from public.calls
     where caller_id = me and callee_id = peer and created_at > now() - interval '10 minutes'
       and status in ('missed', 'cancelled', 'declined', 'busy')
  ) >= 5 then
    raise exception 'This person didn''t pick up. Try again in a few minutes.';
  end if;

  insert into public.calls (chat_id, caller_id, callee_id)
  values (_chat_id, me, peer)
  returning id into new_id;
  return new_id;
end;
$$;

create or replace function public.answer_call(_call_id uuid)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  perform public.expire_stale_calls(auth.uid());
  update public.calls
     set status = 'accepted', answered_at = now()
   where id = _call_id and callee_id = auth.uid() and status = 'ringing';
  if not found then
    raise exception 'This call is no longer available';
  end if;
end;
$$;

create or replace function public.call_signal(_call_id uuid, _kind text, _payload jsonb)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  me uuid := auth.uid();
  c public.calls;
begin
  select * into c from public.calls where id = _call_id and me in (caller_id, callee_id);
  if found and c.status = 'ringing' and c.created_at < now() - interval '60 seconds' then
    perform public.expire_stale_calls(me);
    raise exception 'Call is not active';
  end if;
  if not found or c.status not in ('ringing', 'accepted') then
    raise exception 'Call is not active';
  end if;
  if _kind not in ('offer', 'answer', 'ice', 'screen') then
    raise exception 'Unknown signal';
  end if;
  if pg_column_size(_payload) > 32768 then
    raise exception 'Signal too large';
  end if;
  insert into public.call_signals (call_id, from_id, to_id, kind, payload)
  values (_call_id, me, case when me = c.caller_id then c.callee_id else c.caller_id end, _kind, _payload);
end;
$$;

-- ---- invites ----------------------------------------------------------------------------------
-- New codes are 32 characters (about 122 bits); codes already handed out keep working.
alter table public.invites alter column code set default replace(gen_random_uuid()::text, '-', '');

-- A bad code returns null instead of raising an error. When a function raises, the database undoes everything it did,
-- including the attempt it just counted, so failed guesses would never add up. Only "too many attempts" raises.
create or replace function public.redeem_invite(_code text)
returns uuid
language plpgsql
security definer
set search_path to ''
as $function$
declare
  inv public.invites%rowtype;
  me uuid := (select auth.uid());
  direct_chat uuid;
begin
  if me is null then raise exception 'not authenticated'; end if;

  -- Guessing codes is the only reason to try many: 10 attempts per 10 minutes is far more than anyone needs.
  if not public.take_rate_token(me, 'redeem_invite', 10, interval '10 minutes') then
    raise exception 'Too many attempts. Try again in a few minutes.';
  end if;

  select * into inv from public.invites where code = _code for update;
  -- Unknown, used, expired, your own, or from someone who can't be found: all look the same.
  if not found or inv.used_by is not null or inv.expires_at < now() or inv.created_by = me then
    return null;
  end if;
  if coalesce((select find_me from public.user_settings where user_id = inv.created_by), 'invite') = 'nobody'
     or exists (select 1 from public.blocks where blocker_id = inv.created_by and blocked_id = me) then
    return null;
  end if;

  update public.invites set used_by = me, used_at = now() where code = _code;

  insert into public.contacts (user_id, contact_id)
  values (me, inv.created_by), (inv.created_by, me)
  on conflict do nothing;

  select c.id into direct_chat
  from public.chats c
  join public.chat_members a on a.chat_id = c.id and a.user_id = me
  join public.chat_members b on b.chat_id = c.id and b.user_id = inv.created_by
  where not c.is_group
  limit 1;

  if direct_chat is null then
    insert into public.chats (is_group, created_by) values (false, me) returning id into direct_chat;
    insert into public.chat_members (chat_id, user_id)
    values (direct_chat, me), (direct_chat, inv.created_by);
  end if;

  return direct_chat;
end;
$function$;
