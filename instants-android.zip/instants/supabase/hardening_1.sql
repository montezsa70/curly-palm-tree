-- Pre-launch hardening, step 1 (audit items B4, B3, B10). Safe to run again.

-- B4. status_update_visible can no longer be used by strangers to probe who is whose contact.
-- Policies call it as the signed-in user with their own id; the media function calls it with the service role.
create or replace function public.status_update_visible(_author uuid, _viewer uuid)
returns boolean
language sql
stable
security definer
set search_path to ''
as $function$
  select (
      _author = _viewer
      or (
        exists (select 1 from public.contacts c where c.user_id = _author and c.contact_id = _viewer)
        and not exists (
          select 1 from public.blocks b
          where (b.blocker_id = _author and b.blocked_id = _viewer)
             or (b.blocker_id = _viewer and b.blocked_id = _author)
        )
      )
    )
    and (
      (select auth.role()) = 'service_role'
      or _viewer = (select auth.uid())
    );
$function$;

revoke execute on function public.status_update_visible(uuid, uuid) from public, anon;
grant execute on function public.status_update_visible(uuid, uuid) to authenticated, service_role;

-- Event-trigger helper: it should never be callable through the API.
revoke execute on function public.rls_auto_enable() from public, anon, authenticated;

-- B3. Chat files and status media upload through the media function (Cloudflare R2). The old Supabase "attachments"
-- bucket is only read as a fallback for files from before the move, so nobody needs to upload into it any more.
drop policy if exists attachments_insert_member on storage.objects;

-- B10. Names: bounded length, and a sign-up with a bad or reserved username falls back to a generated one
-- instead of failing with a generic database error.
alter table public.profiles drop constraint if exists profiles_display_name_check;
alter table public.profiles add constraint profiles_display_name_check check (char_length(display_name) <= 50);

create or replace function public.username_available(_u text)
returns boolean
language sql
stable
security definer
set search_path to ''
as $function$
  select _u ~ '^[a-z0-9_]{3,20}$'
    and _u <> all (array['admin', 'administrator', 'support', 'instants', 'instants_app', 'help', 'moderator', 'system', 'root', 'official', 'staff', 'security'])
    and not exists (select 1 from public.profiles where username = _u);
$function$;

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path to ''
as $function$
declare
  fallback text := 'user' || substr(replace(new.id::text, '-', ''), 1, 8);
  wanted text := lower(coalesce(new.raw_user_meta_data->>'username', ''));
  shown text := left(coalesce(new.raw_user_meta_data->>'display_name', ''), 50);
  bio text := coalesce(nullif(left(new.raw_user_meta_data->>'about', 140), ''), 'Available');
begin
  if not public.username_available(wanted) then
    wanted := fallback;
  end if;
  begin
    insert into public.profiles (id, username, display_name, about) values (new.id, wanted, shown, bio);
  exception when unique_violation then
    -- someone took the name between the availability check and now
    insert into public.profiles (id, username, display_name, about) values (new.id, fallback, shown, bio);
  end;
  insert into public.user_settings (user_id) values (new.id);
  return new;
end;
$function$;
