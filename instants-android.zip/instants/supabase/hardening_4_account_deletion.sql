-- Pre-launch hardening, step 5 (audit item P0-3): helpers for the delete-account Edge Function. Safe to run again.
-- Everything a user owns in the database goes when their auth user is deleted (every foreign key cascades or clears);
-- these two functions cover what the database cannot do by itself. Service-only.

-- The files in storage that belong to this user: attachments they sent and their status photos / videos.
create or replace function public.account_files(_uid uuid)
returns table (bucket text, path text)
language sql
stable
security definer
set search_path to ''
as $$
  select 'attachments'::text, m.attachment_path from public.messages m
   where m.sender_id = _uid and m.attachment_path is not null
  union all
  select 'statuses'::text, s.media_path from public.status_updates s
   where s.user_id = _uid and s.media_path is not null
  union all
  select 'statuses'::text, s.thumb_path from public.status_updates s
   where s.user_id = _uid and s.thumb_path is not null;
$$;
revoke all on function public.account_files(uuid) from public, anon, authenticated;
grant execute on function public.account_files(uuid) to service_role;

-- A chat whose members have all deleted their accounts has nothing left in it.
create or replace function public.purge_orphan_chats()
returns int
language plpgsql
security definer
set search_path to ''
as $$
declare
  removed int;
begin
  delete from public.chats c
   where not exists (select 1 from public.chat_members m where m.chat_id = c.id);
  get diagnostics removed = row_count;
  return removed;
end;
$$;
revoke all on function public.purge_orphan_chats() from public, anon, authenticated;
grant execute on function public.purge_orphan_chats() to service_role;
